# Questão 92: Da visão da essência divina por parte dos bem-aventurados.
Em seguida devemos tratar do concernente aos bem-aventurados depois do juízo geral. E primeiro da
visão com que contemplam a essência divina, no que principalmente lhes consiste a beatitude. Segundo,
da beatitude deles e das suas mansões. Terceiro, do modo como se comportarão para com os
condenados. Quarto, dos dotes implicados na felicidade de que gozam. Quinto, das auréolas que lhes dá
perfeição e ornato à felicidade.
Na primeira questão discutem-se três artigos:

## Art. 1 — Se o intelecto humano pode chegar a ver a essência de Deus.
O primeiro discute-se assim. ─ Parece que o intelecto humano não pode chegar a ver a essência de
Deus.

1. ─ Pois, diz o Evangelho: Ninguém jamais viu a Deus. E, segundo a exposição de Crisóstomo, nem as
próprias essências celestes, i. é, os Querubins e os Serafins, não puderam nunca ver a Deus tal como é.
Ora, aos homens não foi prometida senão a igualdade com os anjos: Serão como os anjos de Deus no
céu, diz o Evangelho. Logo, nem os santos na pátria verão a essência de Deus.

2. Demais. ─ Dionísio assim argumenta: Não podemos ter conhecimento senão do que existe. Ora, tudo
o que existe é finito, por pertencer a um gênero determinado. E assim, Deus. Sendo infinito, é superior a
tudo quanto existe. Ora, não podemos conhecê-lo por estar acima do nosso conhecimento.

3. Demais. ─ Dionísio mostra que o modo perfeitissimo pelo qual o nosso intelecto pode unir-se com
Deus é quando se lhe une como ao desconhecido. Ora, o que vemos em essência não nos é
desconhecido. Logo, é impossível o nosso intelecto ver a Deus em essência.

4. Demais. ─ Dionísio diz: As trevas de que Deus se rodeia, a que chama luz superabundante, estão
encobertas a qualquer luz e escondidas a todo conhecimento; e quem, vendo a Deus, compreendeu o
que viu, não o viu a ele, propriamente, mas somente alguma cousa de Deus. Logo, nenhum intelecto
criado poderá ver a essência de Deus.

5. Demais. ─ Como diz Dionísio, Deus é certamente invisível na sua existência por causa da
superabundância da sua claridade. Ora, a sua claridade, assim como sobreexcede o intelecto do homem
nesta vida, também o sobreexcederá na pátria. Logo, sendo invisível ao homem neste mundo, sê-lo-á
também na pátria.

6. Demais. ─ Sendo o inteligível a perfeição do intelecto, há de haver uma proporção entre o inteligível e
o intelecto, o visível e o visto. Ora, não é possível nenhuma proporção entre o nosso intelecto e a
essência divina, distantes uma do outro ao infinito. Logo, o nosso intelecto não poderá atingir a essência
divina.

7. Demais. ─ Mais dista Deus, do nosso intelecto que o inteligível criado, do sentido. Ora, os sentidos de
nenhum modo podem chegar a ver uma criatura espiritual. Logo, nem o nosso intelecto pode chegar a
ver a divina essência.

8. Demais. ─ Todo intelecto que em ato intelige um objeto há de necessariamente ser informado pela
semelhança do objeto inteligido, princípio da operação intelectual nesse determinado caso, como o
calor é o princípio da calefação. Se, portanto, o nosso intelecto inteligir a Deus, há de ser
necessariamente por uma semelhança informadora do intelecto. Ora, tal não pode ser a essência divina
em si mesma, porque a forma e o informado devem constituir um só ser; mas a essência difere do nosso
intelecto, por si mesma e pela sua existência. Logo, a forma informadora do nosso intelecto, quando
intelige a Deus, há de por força ser uma semelhança impressa por Deus em o nosso intelecto. Ora, essa
semelhança, sendo algo de criado, não pode levar ao conhecimento de Deus senão como o efeito leva
ao conhecimento da causa. Logo, é impossível ao nosso intelecto ver a Deus, senão apoiando-se num
efeito dele. Ora, ver a Deus mediante os seus efeitos não é vê-lo por essência. Logo, o nosso intelecto
não poderá ver a Deus em essência.

9. Demais. ─ A essência divina dista mais do nosso intelecto, que qualquer anjo ou inteligência separada.
Ora, como diz Avicena, o ser que uma inteligência tem em nosso intelecto não é a essência mesma
dessa inteligência, nele existente, porque então a ciência, que dessa inteligência tivéssemos, seria
substancial e não acidental. Mas esse conhecimento consiste na impressão do ser dessa inteligência em
nosso intelecto. Logo, Deus não está em nosso intelecto, para poder ser por este inteligido, senão
enquanto uma impressão produzida no intelecto. Ora, essa impressão não no pode conduzir ao
conhecimento da divina essência, porque distando desta ao infinito, degeneraria noutra espécie muito
mais que se a espécie do branco degenerasse na do preto. Logo, como não dizemos que vê o branco
aquele em cuja vista a espécie do branco degenerasse na do preto, por má disposição do órgão, assim
também o nosso intelecto, que pela referida impressão é que inteligiria a Deus, não pode ver a essência
divina.
10. Demais. ─ Nos seres separados da matéria o intelecto e o inteligido se identificam, diz Aristóteles.
Ora, Deus é por excelência o ser separado da matéria. Logo, como um intelecto criado não pode chegar
a se identificar com a essência incriada, não é possível o nosso intelecto ver a Deus em essência.
11. Demais. ─ Tudo o que vemos em essência nós o conhecemos na sua quididade. Ora, o nosso
intelecto não pode saber o que é Deus, mas somente o que não é, como dizem Dionísio e Damasceno.
Logo, o nosso intelecto não poderá ver a Deus em essência.
12. Demais. ─ Todo infinito, como tal, nos é desconhecido. Ora, Deus é omnimodamente infinito. Logo, é
de nós absolutamente desconhecido. Portanto, não pode ser visto na sua essência por nenhum intelecto
criado.
13. Demais. ─ Agostinho diz, que Deus é por natureza invisível. Ora, o que em Deus existe pela sua
natureza mesma não é susceptível de mudança nenhuma. Logo, não pode Deus ser visto na sua
essência.
14. Demais. ─ O que tem um modo de existir mas é visto de outro modo, não é visto tal como é. Ora,
Deus existe de um modo e é visto pelos santos na pátria de outro. Pois, tem o seu modo próprio de
existir, mas os santos na pátria o vêem ao modo deles. Logo, não será visto pelos santos tal como é.
Portanto, não será visto em essência.
15. Demais. ─ O que é mediatamente visto não é em essência. Ora, Deus na pátria será visto mediante o
lume da glória, conforme aquilo da Escritura: No teu lume veremos o lume. Logo, não será visto em
essência.
16. Demais. ─ Deus na pátria será visto face a face, como diz o Apóstolo. Ora, um homem a quem vemos
face a face por semelhança o vemos. Logo, Deus na pátria será visto por uma semelhança. Portanto, não
por essência.
Mas, em contrário, o Apóstolo: Nós agora vemos a Deus como por um espelho, em enigmas; mas então
face a face. Ora, o que vemos face a face por essência o vemos. Logo, Deus será visto em essência pelos
santos, na pátria.

2. Demais. ─ A Escritura diz: Quando ele aparecer, seremos semelhantes a ele, porquanto nós outros o
veremos bem como ele é. Logo, em essência o veremos.

3. Demais. ─ Aquilo do Apóstolo ─ Quando tiver entregado o reino a Deus e ao Padre, diz a Glosa: Onde,
i. é, na pátria, a essência do Padre, do Filho e do Espírito Santo será vista; é a suma beatitude, só
concedida aos puros de coração. Logo, os bem-aventurados verão a Deus por essência.

4. Demais. ─ O Evangelho diz: Aquele que me ama será amado de meu Pai, e eu o amarei também e me
manifestarei a ele. Ora, o que se manifesta é visto em essência. Logo, Deus será visto em essência na
pátria, pelos bem-aventurados.

5. Demais. ─ Aquilo da Escritura ─ Nenhum homem me verá e depois viverá, Gregório refuta a opinião
dos que diziam, que nesse país da felicidade Deus poderá ser visto no seu resplendor, mas não poderá
ser contemplado na sua natureza mesma; pois, não difere o seu resplendor, da sua natureza. Ora, a sua
natureza é a sua essência. Logo, Deus será em visto em essência.

6. Demais. ─ O desejo dos santos de nenhum modo pode ser frustrado. Ora, o desejo comum dos santos
é ver a Deus em essência, conforme o diz a Escritura: Mostra-me a tua glória. E noutro lugar: Mostra-nos
o teu rosto e seremos salvos. E o Evangelho: Mostra-nos o Pai e isso nos basta. Logo, os santos verão a
Deus em essência.

SOLUÇÃO. ─ Assim como, de acordo com a fé, pomos como o fim último da vida humana a visão de
Deus, assim os filósofos consideravam como a felicidade última do homem inteligir no seu ser mesmo as
substâncias separadas da matéria. Por onde, nesta questão, a mesma dificuldade e a mesma diversidade
se encontram entre os filósofos e entre os teólogos.
Assim, certos filósofos eram de opinião que o nosso intelecto possível nunca pode chegar à intelecção
das substâncias separadas. Tal Alfarabío, no fim da sua Ética; embora tivesse ensinado o contrário no
livro do intelecto, como o refere o Comentador. Semelhantemente, alguns teólogos ensinaram que o
intelecto humano não pode chegar nunca a ver a essência de Deus. E tanto esses filósofos como esses
teólogos os levou a pensarem assim a distância entre o nosso intelecto e a essência divina Ou as outras
substâncias separadas. Pois, como o intelecto em ato de certo modo se identifica com o inteligível em
ato, parece difícil, que de algum modo o intelecto criado venha a ser a essência incriada. Donde o dizer
Crisóstomo: Como poderá uma criatura ver o incriado? E maior dificuldade encontram, nesta matéria, os
que ensinam ser o intelecto possível sujeito à geração e à corrupção, como uma faculdade dependente
do corpo, não só no exercício da visão divina, mas também no da visão de quaisquer substâncias
separadas.
Mas esta doutrina é absolutamente insustentável. ─ Primeiro, porque repugna à autoridade da Escritura
canônica, como diz Agostinho. ─ Segundo, porque, sendo inteligir a operação por excelência própria ao
homem, há de ser ela o fundamento de se atribuir a cada um a sua beatitude; a qual se realizará quando
essa operação se lhe exercer em toda sua plenitude. Ora, sendo a perfeição do ser que intelige em ato o
objeto mesmo inteligido, se pela operação perfeitíssima do nosso intelecto não chegássemos a ver a
essência divina, mas um outro ser, deveríamos necessariamente de concluir que esse outro, e não Deus,
seria a causa da nossa beatitude. E, como a perfeição última de qualquer ser consiste na união com o
seu princípio, resulta que outro ser, e não Deus, é o princípio criador do homem. O que, segundo
pensamos, é absurdo. Como também caem no mesmo absurdo os filósofos que ensinam emanarem as
nossas almas das substâncias separadas, de modo que finalmente possamos um dia inteligi-las. Por isso,
devemos admitir, segundo pensamos, que o nosso intelecto chegará um dia a ver a essência divina; e,
segundo os filósofos, que chegará a ver a essência das substâncias separadas.
Mas como será isso possível, é o que resta indagar.
Assim, certos, como Alfarábio e Avempace, afirmaram que pelo fato mesmo de o nosso intelecto
inteligir quaisquer inteligíveis, chega a ver a essência das substâncias separadas. E para o demonstrarem
recorrem a uma dupla demonstração. ─ A primeira é a seguinte. Assim como a natureza específica não
se diversifica nos diversos indivíduos senão enquanto unida aos princípios individuantes, assim uma
forma inteligida não se diversifica entre um sujeito e outro, senão enquanto unida a diversas formas
imaginárias. Portanto,quando o intelecto separa a forma inteligida, das formas imaginárias, resta a
quididade inteligida, que é uma mesma nos diversos sujeitos que inteligem. E tal é a quídidade da
substância separada. Por onde, quando o nosso intelecto chega à abstração suma de uma quididade
inteligível qualquer, intelige então a quidídade da substância separada que lhe é semelhante. ─ A
segunda é a seguinte. Ao nosso intelecto é natural abstrair a quidídade de todos os inteligíveis, que a
têem. Se, portanto, a quidídade abstraída, de um determinado ser que tem quididade, for uma
quidídade, mas sem quidídade, inteligindo o intelecto intelige a quidídade da substância separada,
disposta de tal maneira. Porque as substâncias separadas são quididades subsistentes, sem quididade;
pois, como diz Avicena, a quididade de um ser simples é esse ser simples mesmo. Se, portanto, a
quididade abstraída de um objeto particular sensível fôr uma quidídade com quidídade, o intelecto
poderá então abstrair essa quídídade. Por onde, como não é possível proceder ao infinito, teremos que
chegar a uma quididade sem quididade, pela qual o intelecto intelige a quidídade separada.
Mas estes argumentos não colhem. ─ Primeiro, porque a quididade da substância material, que o nosso
intelecto abstrai, não é da mesma natureza que a quididade das substâncias separadas. Portanto, do
fato de o nosso intelecto abstrair as quididades das cousas materiais e as conhecer, não se conclui que
conheça a quididade das substâncias separadas; e muito menos a essência divina, de natureza
absolutamente diversa de toda quidídade criada. ─ Segundo, porque, dado que fosse da mesma
natureza, contudo, conhecida a quidídade de um ser composto, nem por isso se conheceria a da
substância separada, senão mediante o gênero remotíssimo da substância. Ora, este conhecimento,
sem se chegar às propriedades do ser, é imperfeito. Assim, quem só conhece o homem como animal,
não o conhece senão enquanto existente em potência; e muito menos o conhecerá, se não lhe conhecer
senão a natureza da substância.
Por onde, conhecer assim a Deus ou as outras substâncias separadas não é ver a essência divina nem a
quididade das substâncias separadas; mas é conhecer mediante o efeito e quase num espelho.
Por isso, Avicena introduz um outro modo de conhecer as substâncias separadas e é o seguinte. As
substâncias separadas são por nós conhecidas mediante as imagens (intentiones) das suas quididades,
que são umas semelhanças destas, não delas abstraídas, pois são imateriais, mas por elas impressas nas
nossas almas.
Mas esta explicação também não da suficientemente conta da visão divina, de que ora tratamos. Pois,
como sabemos, tudo o recebido por um recipiente o é ao modo deste. Por onde, a semelhança da
essência divina impressa em o nosso intelecto o será ao modo deste. Ora, o modo de receber, do nosso
intelecto, não tem capacidade para receber plenamente a semelhança divina. Ora, a falta de perfeita
semelhança pode se dar de tantos modos quantos os de dissemelhança. Assim, primeiro, a semelhança
é falha, quando a forma é participada na mesma essência específica que tem, mas não no seu mesmo
modo de perfeição; assim, um objeto pouco branco se assemelha defeituosamente a outro, muito
branco. Outro modo, ainda mais defeituoso, é quando a semelhança não reproduz a mesma essência
genérica. Tal a semelhança entre dois objetos ─ um de cor cítrica ou amarelada, e outro de cor branca.
Enfim, outro modo ainda mais deficiente é quando a semelhança não reproduz a mesma essência
genérica, senão só analógica ou proporcionalmente; tal a semelhança entre a brancura e um homem
fundada apenas no fato de ambos constituírem seres. Pois, para a nossa vista conhecer a brancura é
preciso que os nossos olhos recebam a semelhança dela na sua natureza específica, embora não no seu
mesmo modo de ser, pois, tem modos diferentes de existir a forma no sentido e no objeto exterior à
alma; assim, se os olhos recebessem a forma de um limão não diríamos que viam a brancura. Assim
também para o nosso intelecto inteligir uma quididade, é necessário que receba a semelhança dela na
sua essência específica, embora talvez não sejam os mesmos o modo de existir da semelhança e o da
quididade. Pois, a forma existente no intelecto ou no sentido não é princípio de conhecimento ao modo
de existir que essa forma tem em nós e fora de nós, mas pela razão que lhe dá uma comunidade com o
objeto externo. Por onde é claro que por nenhuma semelhança em si recebida pode um intelecto criado
inteligir a Deus a ponto de lhe ver imediatamente a essência. Por isso também certos, apesar de
afirmarem que a essência divina só pode ser vista desse modo referido, disseram contudo que não é a
essência em si mesma que é vista, mas um quase fulgor ou raio dela. Portanto, esse modo de explicar a
visão de Deus não satisfaz ao que, no caso vertente, entendemos por tal visão.
Devemos, pois, recorrer a outra explicação, também dada por outros filósofos, como Alexandre de
Afrodísias e Averroes, e é a seguinte. Todo conhecimento supõe necessariamente uma forma pela qual
conhecemos ou vemos o objeto. Ora, a forma pela qual o intelecto recebe a perfeição de ver as
substâncias separadas, não é a quididade que o nosso intelecto abstrai dos seres compostos, como
ensina a, primeira opinião; nem nenhuma impressão recebida da substância separada pelo nosso
intelecto, como pretende a segunda; mas é a própria substância separada, que se une ao intelecto como
forma, de modo que essa substância separada é a um tempo o que inteligimos e o meio por que
inteligimos. E seja o que for das outras substâncias separadas, contudo é este modo referido de
conhecer o que devemos admitir para explicar a visão da essência divina; do contrário, qualquer outra
forma que nos informasse o intelecto, não no poderia levar à visão da essência divina.
O que não se deve entender como se a essência divina fosse a verdadeira forma do nosso intelecto; ou
que a essência divina e o nosso intelecto se identificassem, absolutamente falando, como, na ordem da
natureza, à forma e a matéria se unem. Mas que a essência divina é proporcionada ao nosso intelecto
como a forma o é à matéria. Pois, sempre que dois, seres, dos quais um é mais perfeito que outro, são
recebidos por um terceiro, a proporção desses dois seres entre si, do mais perfeito para o menos
perfeito, é como a proporção entre a forma e a matéria. Assim, a luz e a cor recebidas por um corpo
diáfano, a luz está para a cor, como a forma para a matéria. Do mesmo modo, quando a alma recebe a
luz intelectiva e a própria essência divina, que vem habitar em nós, embora não as receba a ambas do
mesmo modo, a essência divina estará para o intelecto ─ como a forma para a matéria.
E que isso basta para o nosso intelecto poder, mediante a divina essência, ver a essa mesma essência,
podemos prová-lo do modo seguinte. Assim como uma forma natural, que dá a existência a um ser, e a
matéria, constituem absolutamente falando, um mesmo ser, assim a forma, pela qual o intelecto
intelige, e o próprio intelecto constituem uma identidade, no ato de intelecção. Ora, na ordem natural,
um ser por si subsistente não pode ser forma de matéria nenhuma, se esse ser tiver a matéria como
uma das suas partes; porque não pode a matéria ser forma de nenhum ser. Mas se esse ser por si
subsistente for só forma, nada lhe impede ser forma de uma determinada matéria e tornar-se o
princípio de existência do ser composto; tal o caso da alma. Ora, no intelecto é mister considerar o
intelecto potencial, como a matéria; e a espécie inteligível como a forma; e sendo o ato mesmo de
inteligir como o composto da matéria e forma. Por onde, se há um ser por si subsistente, nada contende
além da sua própria inteligibilidade, um tal ser pode ser a forma mediante a qual o intelecto intelige.
Ora, um tal ser é inteligível pelo que tem de atual e não pelo que tivesse de potencial, como o ensina
Aristóteles; e a prova é que é necessário abstrair a forma inteligível, da matéria e de todas as
propriedades da matéria. Logo, sendo a divina essência um ato puro, pode ser a forma pela qual o
intelecto intelige. E tal será a visão beatífica. Por isso diz o Mestre, que a união da alma e do corpo é um
exemplo da beatifica união pela qual o espírito se une a Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A autoridade citada é susceptível de tríplice explicação,
como o expõe Agostinho. ─ Num sentido, exclui a visão corpórea pela qual ninguém vê nem verá jamais
a Deus em essência. ─ Noutro, excluem-se da visão intelectual da essência de Deus os que ainda vivem
neste mundo. ─ Enfim noutro, exclui-se a visão compreensiva, do intelecto criado. E é neste sentido que
entende o texto Crisóstomo. Por isso acrescenta: No lugar em questão o Evangelista entende por
conhecimento uma certíssima contemplação e uma compreensão tão perfeita como a tem o Padre e o
Filho. Tal é o sentido do Evangelista. Por isso acrescenta: O unigênito, que está no seio do Pai, esse é
quem o deu a conhecer, querendo assim mostrar, pela compreensão do Filho, que é Filho de Deus.

RESPOSTA À SEGUNDA. ─ Assim como Deus, pela sua essência infinita, excede todos os seres de
existência limitada, assim o seu conhecimento, pelo qual conhece, supera todo e qualquer
conhecimento. Por onde, a mesma proporção existente entre o nosso conhecimento e a nossa essência
criada é a que existe entre o conhecimento divino e a essência infinita. Ora, para o conhecimento
concorrem dois elementos, a saber, o sujeito conhecente e o meio pelo qual conhece. Ora, a visão pela
qual veremos a Deus por essência é a mesma pela qual Deus se vê, no concernente ao princípio dessa
visão; porque, assim como ele se vê pela sua essência, assim também nós o veremos a ele. Mas há
diversidade quanto ao sujeito conhecente entre o intelecto divino e o nosso. Pois, no conhecimento, o
objeto conhecido depende da forma pela qual conhecemos; assim, pela forma de uma pedra é que a
vemos. Mas a eficácia de um conhecimento depende da virtude do sujeito conhecente; assim quem tem
vista mais aguda vê melhor. Por onde, na visão do céu veremos o mesmo que Deus vê, i. é, a sua
essência, mas não com a mesma eficácia.

RESPOSTA À TERCEIRA. ─ Dionísio se refere, no lugar citado, ao conhecimento que temos de Deus nesta
vida, mediante alguma forma criada, que nos informa o intelecto para o elevar à visão divina. Mas,
como diz Agostinho, Deus transcende a qualquer forma do nosso intelecto; porque seja qual for a forma
concebida por ele, essa não no pode alçar ao conhecimento da essência de Deus. Por isso Deus não
pode ser atingido pela nossa inteligência. Mas, já neste mundo nós o conhecemos perfeitissimamente,
sabendo que transcende tudo o que o nosso intelecto possa conceber; e assim a ele nos unimos como
ao quase desconhecido. Mas na pátria nós o veremos pela forma da sua essência; e lhe estaremos
unidos como o estamos ao que conhecemos.

RESPOSTA À QUARTA. ─ A luz é Deus, como diz o Evangelho. Ora, o lume é a impressão da luz num
objeto iluminado. E como a essência divina tem uma modalidade de ser diferente que a de qualquer
semelhança dela impressa em o nosso intelecto, por isso diz que as trevas divinas estão encobertas a
qualquer luz, porque a essência divina, a que chama trevas por causa da sua superabundante luz,
permanece indemonstrável pela só impressão recebida em o nosso intelecto. E assim fica essa essência
inacessível a todo conhecimento por onde tudo o que conceba na inteligência quem quer que veja a
Deus, nada disso é Deus, mas algum dos efeitos divinos.

RESPOSTA À QUINTA. ─ O lume divino, embora excede qualquer forma de que seja nesta vida
susceptível o nosso intelecto, não excede contudo a própria essência divina, que será na pátria a quase
forma do nosso intelecto. Por onde, presentemente nos seja invisível, então nos há de ser visível.

RESPOSTA À SEXTA. ─ Embora não haja nenhuma proporção entre o finito e o infinito, porque o excesso
do infinito sobre o finito não é determinado, pode contudo haver entre ambos a relação de semelhança
de proporções; pois, assim como um finito é adequado a outro, assim o infinito ao infinito. Mas para
podermos conhecer totalmente um objeto, há umas vezes necessidade de proporção entre este e o
sujeito; pois, é forçoso a faculdade do sujeito conhecente adequar-se à cognoscibilidade do objeto
conhecido. Ora, essa igualdade é uma proporção. Pode porém se dar que a cognoscibilidade do objeto
conhecido exceda a virtude intelectiva do sujeito conhecente; assim, quando conhecemos a Deus, ou
inversamente, como quando ele conhece as criaturas. E então não pode haver proporção entre o sujeito
conhecente e o objeto conhecido, mas apenas uma proporcionalidade; de modo que como está o
sujeito para a sua virtude cognoscitiva, assim esteja o objeto conhecido para a sua cognoscibilidade. E
essa proporcionalidade basta para o infinito ser conhecido pelo finito ou inversamente. ─ Ou podemos
responder que a proporção, na sua acepção primária, significa a relação entre duas quantidades
fundada num certo excesso, ou igualdade; mas depois passou a significar qualquer relação entre uma
cousa e outra. Neste sentido, dizemos que a matéria deve ser proporcionada à forma; e nada impede
então dizermos que o nosso intelecto, embora finito, é proporcionado à visão da essência infinita; mas
não a compreendê-la, por causa da imensidade dessa essência.

RESPOSTA À SÉTIMA. ─ Há duas espécies de semelhança e de dissemelhança. ─ Uma fundada na
conveniência natural. E então mais difere Deus de um intelecto criado que um inteligível criado, dos
nossos sentidos. ─ Outra, fundada na proporcionalidade. E então, dá-se o inverso do primeiro caso; pois
os nossos sentidos não são proporcionados a conhecer o imaterial, como o intelecto é proporcionado a
conhecer qualquer objeto imaterial. E esta semelhança é necessária para o ato do conhecimento, mas
não a primeira; pois, como sabemos, o intelecto, que intelige uma pedra não tem a mesma semelhança
do ser natural dela. Assim também a vista pode perceber a cor amarelada do mel e do fel, embora não
perceba a doçura do mel; porque há maior conveniência, quanto à visibilidade, entre o amarelado do fel
e o do mel, do que entre o mel e a sua doçura.

RESPOSTA À OITAVA. ─ Na visão pela qual havemos de ver a essência de Deus, será a própria essência a
como forma pela qual o intelecto inteligira. Nem é necessário, que a essência divina e o nosso intelecto
se identifiquem, absolutamente falando; mas apenas que constituam uma unidade relativamente ao ato
de inteligir.

RESPOSTA À NONA. ─ No sentido exposto não admitimos a doutrina de Avicena; pois, também os
outros filósofos a repelem. Salvo se quisermos dizer que Avicena se refere ao conhecimento das
substâncias separadas, enquanto conhecidas pelos hábitos das ciências especulativas e pelas
semelhanças dos outros seres. E isso o diz para mostrar que a ciência não é em nós uma substância, mas
um acidente. ─ E contudo a divina essência, embora mais difira, nas suas propriedades naturais, do
nosso intelecto, que deste difere a substância do anjo, contudo é de natureza mais inteligível; pois, é ato
puro, sem mesela de nenhuma potência, o que não se dá com as outras substâncias separadas. Nem o
conhecimento, pelo qual veremos a Deus em essência, será, relativamente ao objeto visto, do gênero do
acidente, senão só quanto ato mesmo da intelecção, que não será a substância mesma do sujeito
inteligente nem a do objeto inteligido.

RESPOSTA À DÉCIMA. ─ A substância separada da matéria tanto pode inteligir-se a si mesma como os
demais seres; e em ambos os sentidos pode verificar-se a autoridade citada. Pois, como a essência
mesma da substância separada seja inteligível por si mesma e em ato, por estar separada da matéria,
resulta que, quando se intelige a si mesma, o sujeito inteligente e o objeto inteligível absolutamente se
identificam; porquanto ela não se intelige por nenhuma espécie intencional diversa de si, como se dá
conosco quando inteligimos as causas materiais. E este é o modo de pensar do Filósofo, como está claro
pelo que diz o Comentador, no lugar aduzido. Mas quando a inteligência separada intelige as outras
causas, o intelecto em ato forma uma unidade com o objeto inteligido em ato, porque a forma do
objeto inteligido torna-se a forma do intelecto enquanto atuallzado, e não por ser a essência mesma do
intelecto, como o prova Avicena. Porque a essência do intelecto permanece a mesma sob as duas
formas, pois, intelige dois objetos sucessivamente, do mesmo modo por que a matéria-prima
permanece a mesma sob formas diversas. Por isso o Comentador também compara o intelecto possível,
neste ponto, com a matéria-prima. Donde, pois de nenhum modo se segue que o nosso intelecto, vendo
a Deus, se transforme na própria essência divina; mas que esta ela para ele como a perfeição e a forma.

RESPOSTA À UNDÉCIMA. ─ A autoridade citada e todas as semelhantes devem entender-se do
conhecimento pelo qual conhecemos a Deus neste mundo, pela razão já aduzída.

RESPOSTA À DUODÉCIMA. ─ O infinito, privativamente considerado, nos é desconhecido, como tal;
pois, não exprime então senão a ausência de qualquer complemento, pelo qual temos o conhecimento
das causas. Por onde, o infinito se reduz à matéria sujeita à privação, como esta claro em Aristóteles.
Mas o infinito, considerado negativamente, pela remoção da matéria que o determina; pois, a forma
também é de certo modo determinada pela matéria. Por onde, o infinito neste sentido é o ser
cognoscível por excelência. E deste modo é que Deus é infinito.

RESPOSTA À DÉCIMA TERCEIRA. ─ Agostinho se refere à visão corpórea pela qual nunca veremos a
Deus. O que é claro pelo que disse antes: Do modo pelo qual vemos as chamadas causas sensíveis deste
mundo, desse nunca ninguém verá a Deus nem poderá vê-la; pois, é por natureza invisível, como
incorruptível. Ora, assim como por sua natureza é o ser soberano, assim é em si mesmo considerado o
ser inteligível por excelência. E só por deficiência nossa é que não o inteligimos. Por onde, o fato de
chegarmos a vê-la, sem que antes isso nos tivesse sido possível, não é por nenhuma mudança dele,
senão nossa.

RESPOSTA À DÉCIMA QUARTA. ─ Deus na pátria será visto pelos santos tal como é, considerado o modo
de ser do objeto visto; pois, os santos o verão na modalidade de existência que realmente é a sua. Mas
se esse modo se refere ao sujeito conhecente então não será visto tal como é; pois, o intelecto criado
não terá uma acuidade de visão igual à inteligibilidade da essência divina.

RESPOSTA À DÉCIMA QUINTA. ─ Há três espécies de meios que tornam possível a visão corporal e
intelectual. ─ O primeiro é o sob o qual vemos. Este é o que torna a vista apta para ver, em geral, sem
lhe determinar a visão a nenhum objeto especial. Tal é a luz material para a visão corpórea e o lume do
intelecto agente para o intelecto possível. ─ O segundo é o meio pelo qual vemos. E esse é a forma
visível, pela qual tanto a visão corpórea como a intelectual se determina a um objeto especial; assim
pela forma de uma pedra nós a conhecemos. ─ O terceiro é o meio no qual vemos. Este é o pela vista do
qual a visão atinge um determinado objeto. Assim, olhando para um espelho vemos o que ele reflete; e
vendo uma imagem conhecemos o objeto a que ela pertence. Assim também o intelecto, pelo
conhecimento da causa é levado ao do efeito e inversamente. ─ Ora, na visão da pátria não haverá o
terceiro meio: não conheceremos a Deus mediante espécies dos outros seres, como agora o
conhecemos, razão pela qual dizemos que agora vemos num espelho. Nem haverá o segundo meio,
porque será pela própria essência divina que o nosso intelecto verá a Deus. Mas só haverá o primeiro,
que elevará o nosso intelecto de modo a poder unir-se à substância incriada da maneira por que
dissemos. Ora, nem por supor esse meio se poderá dizer que o nosso conhecimento é mediato; porque
não é um meio existente entre o sujeito conhecente e o objeto conhecido, mas é o que dá ao sujeito a
virtude cognoscitiva.

RESPOSTA À DÉCIMA SEXTA. ─ Não podemos dizer das criaturas corpóreas que são vistas
imediatamente, senão quando ao que há nelas que possa unir-se à vista, a esta se une. Ora, não podem
unir-se à vista pela sua essência mesma, em razão da sua materialidade. Por isso, então são vistas
imediatamente, quando a semelhança delas se une à vista. Ora, Deus pode, pela sua essência, unir-se ao
intelecto. Por onde, não seria visto imediatamente, sem a sua essência unir-se ao nosso intelecto. E essa
visão imediata se chama ─ visão face a face. Além disso, a semelhança de uma cousa corpórea é
recebida pela vista com a mesma essência que tem no objeto, embora não segundo o mesmo modo de
existir; por isso tal semelhança conduz diretamente ao conhecimento da cousa. Ora, nenhuma
semelhança pode desse modo conduzir-nos o intelecto à visão de Deus, como do sobredito se colhe.
Não há, portanto, símil.

## Art. 2 — Se os santos, depois da ressurreição, verão a Deus com os olhos do corpo.
O segundo discute-se assim. ─ Parece que os santos, depois da ressurreição, verão a Deus com os
olhos do corpo.

1. ─ Pois, os olhos glorificados tem maior acuidade que os olhos não-glorificados. Ora, o santo homem
Job viu a Deus com seus olhos, conforme ele próprio o diz: Eu te ouvi por ouvido de orelha, mas agora te
vê o meu olho. Logo e com muito maior razão, os olhos glorificados poderão ver a Deus por essência.

2. Demais. ─ Diz ainda Job: Na minha própria carne verei o meu Salvador. Logo, na pátria veremos a
Deus com os olhos do corpo.

3. Demais. ─ Agostinho, tratando da visão dos olhos glorificados, assim se exprime: Os olhos dos
glorificados terão uma virtude mais excelente, não por serem dotados de vista mais aguda que a
atribuída às serpentes ou à águia; pois, por máxima que seja a penetração do olhar desses animais não
podem ver senão corpos. Ao passo que os olhos glorificados poderão também ver seres incorpóreos.
Ora, toda potência cognoscitiva capaz de conhecer o incorpóreo, pode elevar-se até a visão de Deus.
Logo, os olhos glorificados poderão ver a Deus.

4. Demais. ─ A mesma diferença existe entre um ser corpóreo e um incorpóreo e inversamente. Ora,
olhos incorpóreos podem ver cousas corpóreas. Logo, os olhos do corpo podem ver o incorpóreo.
Donde a mesma conclusão que antes.

5. Demais. ─ Aquilo de Job ─ Parou diante de mim um cujo rosto eu não conhecia, etc., diz Gregório: O
homem que, se quisesse observar o preceito, havia de tornar-se espiritual na sua carne, pelo pecado
tornou-se carnal até na alma. Ora, por ter-se tornado de espiritual a carnal, como diz no mesmo lugar,
não tem outros pensamentos que os hauridos nessas imagens corpóreas. Logo, mesmo quando a sua
carne for espiritualizada, como está prometido aos santos, depois da ressurreição, poderá ver as cousas
espirituais mesmo com os olhos da carne. Donde a mesma conclusão de antes.

6. Demais. ─ Só Deus pode beatificar o homem. Ora, será o homem beatificado não só na alma senão
também no corpo. Logo, poderá ver a Deus não só com os olhos do intelecto, mas também com os do
corpo.

7. Demais. ─ Assim como Deus nos está presente no intelecto pela sua essência, assim também nos
estará presente aos sentidos, pois, será, tudo em todos, na frase do Apóstolo. Ora, será contemplado
pelo nosso intelecto pela união da sua essência com ele. Logo, poderá ser visto também pelos sentidos.
Mas, em contrário. ─ Diz Ambrósio: Deus não pode ser percebido pelos olhos do corpo, nem circunscrito
pela vista, nem apalpado pelo tato. Logo, nenhum sentido corpóreo verá a Deus.

2. Jerônimo diz: Os olhos do corpo não poderão ver, não somente a divindade do Pai, mas nem a do
Filho nem a do Espírito Santo; vê-lo-ão porém os olhos da alma, sendo por isso dito ─ Bem-aventurados
os limpos de coração.

3. Demais. ─ Diz ainda Jerônimo: Os seres incorpóreos não podem ser vistos pelos olhos da carne. Ora,
Deus é o ser incorpóreo por excelência. Logo, etc.

4. Demais. ─ Agostinho diz: A Deus nunca ninguém o viu tal como é, nem nesta vida, nem na vida dos
anjos, assim como agora vemos as causas visíveis a este mundo, com os olhos do corpo. Ora, chama-se
vida dos anjos a vida bem-aventurada, que viverão os ressuscitados. Logo, etc.

5. Demais. ─ A Escritura diz que o homem foi feito à imagem de Deus por ser destinado a contemplá-lo,
como ensina Agostinho. Ora, é pela alma e não pela carne que o homem é a imagem de Deus. Logo,
pelo intelecto e não pela carne que verá a Deus.

SOLUÇÃO. ─ Uma causa pode ser percebida pelos sentidos do nosso corpo de dois modos: em si mesmo
e por acidente. Em si mesmo percebem o que, por si mesmo é capaz de lhes causar uma paixão. Ora, em
si mesmo considerado pode um objeto causar uma paixão ou ao sentido como tal, ou a um determinado
sentido como tal. Ora, o que, deste segundo modo, por si mesmo pode causar uma paixão no sentido,
chama-se sensível próprio; assim a cor em relação à vista e o som, em relação ao ouvido. Mas como o
sentido como tal tem que se servir de um órgão corpóreo, nada pode receber senão corporalmente,
pois tudo o que um ser recebe ao seu modo o recebe. Por onde, todos os sensíveis causam paixão ao
sentido como tal, na medida em que tem uma certa extensão. Por isso, a extensão e todos os seus
consectários, como o movimento, o repouso, o número e atribuições semelhantes chamam-se sensíveis
comuns, em si mesmos considerados. Por acidente porém sentimos o que não nos causa paixão ao
sentido, nem como sentido, nem como um determinado sentido, senão enquanto em união com um
sensível, capaz de por si mesmo influenciar o sentido. Assim Sócrates, filho de Diaris, amigos e idéias
semelhantes, conhecidos em si mesmos e na sua universalidade pelo intelecto, e particularizadas pela
potência imaginativa, no homem, e pela estimativa nos animais irracionais. Esses sensíveis dizemos que
os sentidos externos percebem, por acidente embora, quando, a potência apreensiva, à que é próprio
conhecer esses cognoscíveis, imediatamente e sem vacilar e sem nenhum discurso, os apreende
mediante um sensível que é apreendido diretamente pelo sentido; do mesmo modo que concluímos ser
uma pessoa viva o só fato de a vermos falar. Mas quando o conhecimento sensível se processa
diversamente, não dizemos que o sentido percebe, mesmo acidentalmente.
Ora, digo que Deus de nenhum modo pode ser visto pelos olhos do corpo, nem percebido por nenhum
sentido, como se fosse em si mesmo visível, nem nesta vida nem na pátria. Pois, se privarmos um
sentido como tal, dos seus elementos constitutivos, já não será sentido; e se privarmos a vista do que
como tal a constitui, deixará de ser vista. Ora, o sentido, como tal, percebe a extensão; e a vista, como
um sentido determinado, percebe a cor. É, portanto, impossível à vista perceber o que não tem cor nem
extensão, salvo se se tomasse a palavra sentido em acepção equívoca. Ora, como a vista e os outros
sentidos hão de existir no corpo glorioso especificamente os mesmos que existiam no corpo não
glorioso, não poderá a vista contemplar a essência divina como se lhe fosse um ser em si mesmo visível.
Mas a verá como um visível por acidente. De tal modo que, de um lado, os olhos do corpo glorificado
verão a imensidade da glória de Deus manifestando-se nos corpos, sobretudo nos gloriosos e, por
excelência, no corpo de Cristo; e, de outro lado, o intelecto verá a Deus tão claramente, de maneira que,
mediante a visão das causas materiais, perceberá a Deus, como pelo falar, de uma pessoa lhe
percebemos a vida. Embora, pois, na pátria, o nosso intelecto não tenha a visão de Deus mediante as
criaturas, contudo o verá manifesto nas criaturas vistas com os olhos do corpo. E esse modo de ser Deus
visto com os olhos do corpo, Agostinho o admite, como facilmente se convencerá quem lhe atender as
palavras seguintes. Podemos crer, diz, com grande verossimilhança, que, depois da ressurreição,
veremos os corpos componentes do céu novo e da terra nova, de modo a percebermos a onipresença
de Deus e o seu governo universal, com uma visão claríssima. Não como agora compreendemos as
cousas invisíveis de Deus por aquelas que foram feitas, mas do modo pelo qual, quando vemos um
homem, não o cremos vivo, mas o vemos imediatamente como tal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ As palavras citadas de Job entendem-se da visão
espiritual, da qual diz o Apóstolo: Para que ele esclareça os olhos do nosso coração.

RESPOSTA À SEGUNDA. ─ A autoridade aduzida não se entende como significando que havemos de ver
a Deus com os olhos do corpo, mas que o veremos depois de ressuscitado o nosso corpo.

RESPOSTA À TERCEIRA. ─ Agostinho, nas palavras citadas, se exprime duvidosa e condicionalmente.
Como é claro pelo que diz antes: Os olhos lhes terão um poder de visão muito diverso se puderem com
eles ver essa natureza incorpórea. Depois acrescenta: Uma força portanto, etc.; para em seguida
resolver a dúvida, como se disse.

RESPOSTA À QUARTA. ─ Todo conhecimento supõe uma abstração da matéria. Por onde, quanto mais
abstrata da matéria fora forma corpórea, tanto mais será um princípio de conhecimento. Por isso a
forma unida à matéria de nenhum modo é princípio de conhecimento; a forma sensível já o é de certo
modo, na medida em que está separada da matéria; e muito mais a existente em o nosso intelecto. Por
onde, os olhos do espírito, isentos de tudo o que possa impedir o conhecimento, podem perceber um
ser material. Mas daí não resulta que os olhos do corpo, de capacidade cognitiva limitada, por estarem
ligados à matéria, possa ter conhecimento perfeito dos cognoscíveis incorpóreos.

RESPOSTA À QUINTA. ─ Embora o intelecto feito carnal não possa conhecer senão mediante os
sentidos, contudo conhece de maneira imaterial. Semelhantemente, os olhos do corpo tudo o que
apreendem hão de apreender de modo material. Portanto, não podem ver o que não pode ser
materialmente percebido.

RESPOSTA À SEXTA. ─ A beatitude é a perfeição do homem enquanto homem. Ora, o homem não o é
pelo seu corpo, mas sobretudo pela alma; o corpo lhe pertence à essência senão enquanto aperfeiçoado
pela alma. Por onde, a beatitude do homem não consiste principalmente senão no ato da alma, donde
deriva para o corpo por uma certa redundância, como do sobredito se colige. Portanto, uma certa
beatitude do nosso corpo consistirá em ver a Deus manifesto nas criaturas sensíveis e sobretudo no
corpo de Cristo.

RESPOSTA À SÉTIMA. ─ O intelecto pode perceber o espiritual, mas não os olhos do corpo. Por onde, o
intelecto poderá conhecer a essência divina a que está unida, mas não o podem os olhos da carne.

## Art. 3 — Se os santos, vendo a Deus em essência, vêem tudo o que Deus vê em si mesmo.
O terceiro discute-se assim. ─ Parece que os santos, vendo a Deus, vêem tudo o que Deus em si
mesmo vê.

1. ─ Pois, como diz Isidoro, os anjos conhecem no Verbo de Deus todas as causas, antes de serem feitas.
Ora, os santos serão iguais aos anjos, diz o Evangelho. Logo, vendo a Deus, vêem tudo.

2. Demais. ─ Gregório diz: No céu todos contemplarão a Deus no seio da mesma claridade; que há, pois,
que aí não conhecerão ao que tudo sabe? Ora, refere-se aos santos, que vêem a Deus em essência.
Logo, os que vêem a Deus em essência tudo conhecerão.

3. Demais. ─ Como diz Aristóteles, o intelecto, conhecendo o máximo, pode, com maior razão, conhecer
o mínimo. Ora, Deus é o máximo inteligível. Logo, a visão de Deus aumentará ao máximo a potência do
intelecto. Logo, o intelecto, vendo-o, inteligirá tudo.

4. Demais. ─ O intelecto só não pode entender o que o supera. Ora, nenhuma criatura supera o intelecto
que vê a Deus; pois, como diz Gregório, toda criatura é mesquinha para a alma que vê o Criador. Logo,
os que vêem a Deus por essência tudo conhecem.

5. Demais. ─ Toda potência passiva que não chega a atualizar-se é imperfeita. Ora, o intelecto possível
da alma humana é uma potência passiva em relação a qualquer conhecimento; pois, o intelecto possível
é o que se pode tornar em todas as cousas, como o define Aristéles. ─ Se, portanto, na beatitude celeste
não inteligisse todas as cousas, ficaria imperfeito. O que é absurdo.

6. Demais. ─ Quem vê um espelho vê tudo o que ele reflete. Ora, no Verbo de Deus, como em um
espelho, tudo se reflete, pois é ele a razão e a semelhança de todas as cousas. Logo; os santos, vendo a
Deus em essência, verão todas as cousas criadas.

7. Demais. ─ Diz a Escritura: Aos justos se lhes concederá o seu desejo. Ora, os santos, desejam saber
tudo, porque todos os homens naturalmente desejam saber; e a glória não aniquila a natureza. Logo,
lhes concederá Deus, que tudo conheçam.

8. Demais. ─ A ignorância é uma penalidade em a vida presente. Ora, de toda penalidade os santos serão
livres pela glória. Logo, também de toda ignorância. Logo, conhecerão tudo.

9. Demais. ─ A beatitude dos santos, antes de estar na alma está no corpo. Ora, os corpos dos santos
serão reconstituídos na glória à semelhança do corpo de Cristo, como o diz o Apóstolo. Logo, também as
almas serão aperfeiçoadas à semelhança da alma de Cristo. Ora, a alma de Cristo verá a tudo no Verbo.
Portanto, todas as almas dos santos verão todas as cousas no Verbo.
10. Demais. ─ Como o sentido, também o intelecto conhece tudo o por cuja semelhança é informado.
Ora, a divina essência mais expressivamente contém a imagem de qualquer ser que qualquer outra
semelhança dele. Logo, como na visão da beatitude a essência divina será como a forma do nosso
intelecto, parece que os santos, vendo a Deus, tudo verão.
11. Demais. ─ O Comentador diz, que se o intelecto agente fosse a forma do intelecto possível nós
compreenderíamos todas as cousas. Ora, a essência divina representa mais claramente todas as cousas
que o intelecto agente. Logo, o intelecto que vir a Deus em essência tudo conhecerá.
12. Demais. ─ É porque os anjos inferiores, na sua condição atual, não conhecem tudo, que são
iluminados, para conhecerem o que ignorem, pelos anjos superiores. Ora, depois do dia de juízo, um
anjo não mais iluminará a outro; pois, então, cessará toda superioridade, diz a Glosa a um lugar do
Apóstolo. Logo, os anjos inferiores então conhecerão todas as cousas. E pela mesma razão todos os
outros santos, que vêem a Deus em essência.
Mas, em contrário. ─ Como diz Dionísio, os anjos superiores purificam os inferiores da sua ignorância.
Ora, os anjos inferiores vêem a essência divina. Logo, o anjo que vê a essência divina pode ignorar certas
cousas. Ora, nenhuma alma verá a Deus mais perfeitamente que os anjos. Logo, as almas que vêem a
Deus não conhecerão necessariamente todas as cousas.

2. Demais. ─ Só Cristo não tem o espírito por medida, como diz o Evangelho. Ora, só a Cristo, por não ter
o espírito por medida, cabe ver todas as cousas no Verbo; por isso, o Evangelho diz no mesmo lugar: O
Pai todas as cousas pôs na sua mão. Logo, a ninguém mais senão a Cristo cabe conhecer todas as cousas
no Verbo.

3. Demais. ─ Quanto mais perfeitamente é conhecido um princípio, tanto mais lhe conhecemos os
efeitos, por meio dele. Ora, aos que vêem a Deus por essência uns o conhecem mais perfeitamente que
outros, a êle o princípio de todas as cousas. Logo, uns conhecem mais cousas que outros. E portanto,
nem todos sabem tudo.

SOLUÇÃO. ─ Deus, vendo a sua essência, conhece todas as cousas que existem, existirão e existiram. E
esse se chama o conhecimento de visão, porque, à semelhança da visão corporal, conhece todas as
cousas como presentes, Além disso, conhece, na visão da sua essência, tudo o que pode fazer, embora
nunca o tenha feito nem haja de fazer. Do contrário, não conheceria perfeitamente o seu poder. Pois,
uma potência não pode ser conhecida sem se lhe conhecerem os objetos. E a isso se chama conhecer
por conhecimento de simples inteligência.
Ora, é impossível a um intelecto criado conhecer, pela visão da essência divina, tudo o que Deus pode
fazer. Porque, quanto mais perfeitamente é conhecido um princípio, tanto mais cousas nele
conhecemos. Assim, num princípio de demonstração, quem tiver engenho mais perspicaz verá maior
número de conclusões que outro, de inteligência mais tardonha. Ora, a extensão do poder divino se
funda no que pode fazer. O intelecto, portanto, que visse na essência divina todas as cousas que Deus
pode fazer, esse ato de intelecção seria tão perfeito na sua extensão, como a extensão do poder divino
na produção dos seus efeitos. E portanto, uma tal inteligência compreenderia o poder divino. O que é
impossível a toda inteligência criada. Mas todas aquelas cousas que Deus conhece pelo conhecimento
de visão, há um intelecto criado ─ a alma de Cristo, que as conhece no Verbo. Quanto porém aos mais,
que vêem a essência divina, há duas opiniões a respeito.
Assim, uns dizem que todos os que vêem a Deus em essência, vêem tudo o que Deus vê por ciência de
visão. ─ Mas isto repugna ao ensinamento dos Santos Padres, que afirmam haver certas cousas que os
anjos ignoram; e contudo sabemos, pela fé, que todos vêem a essência de Deus. Por isso outros dizem
que todos os que vêem a Deus por essência não vêem por isso tudo o que Deus vê, por não
compreenderem a divina essência. Pois, do fato de conhecermos uma causa não decorre
necessariamente que lhe conheçamos todos os efeitos, salvo se compreendermos perfeitamente a
causa; e isso, no caso de Deus, não é possível a nenhum intelecto criado. Por onde, cada um dos que
vêem a Deus em essência tanto mais cousas nela verá, quanto mais clara a visão que dela tiver. Razão
pela qual pode, sobre elas, um instruir a outro. E assim a ciência dos anjos e das almas dos santos pode
crescer até o dia do juízo; como tudo o concernente ao prêmio acidental. Mas não mais progredirá
depois desse dia, porque então tudo entrará no seu estado definitivo. E nesse estado é possível que
todos conheçam tudo o que Deus conheça por ciência de visão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O dito de Isidoro ─ os anjos conhecem no Verbo todas as
causas, antes de serem feitas ─ não pode referir-se ao que Deus conhece por ciência de simples
inteligência, porque são cousas que nunca virão à existência; mas é referente só ao que Deus conhece
por ciência de visão. E mesmo dessas não diz ele que todos os anjos as conheçam, senão só alguns. E
ainda esses, que as conhecem, não as conhecem todas perfeitamente. Pois, numa mesma cousa
podemos distinguir muitas razões de inteligibilidade, como as suas diversas propriedades e relações com
outras cousas. E é possível que, de uma mesma cousa conhecida por dois em comum, um perceba mais
razões de inteligibilidade que outro; que essas razões um a receba de outro. Por isso diz Dionísio que os
anjos inferiores são instruídos pelos superiores, nas razões cognoscíveis das cousas. Por isso também os
anjos, que conhecem todas as criaturas, nem por isso perceberão necessariamente tudo o que nelas
pode ser inteligido.

RESPOSTA À SEGUNDA. ─ As palavras, citadas de Gregório mostram que na visão dos bem-aventurados
nada faltará, para o conhecimento de todas as cousas, a parte da divina essência, meio pelo qual a visão
se exerce, e mediante a qual Deus vê todas as cousas. E se todas não são conhecidas será por defeito do
intelecto criado, que não compreende a essência divina.

RESPOSTA À TERCEIRA. ─ O intelecto criado não vê a essência divina ao modo pelo qual ela existe, mas
ao modo próprio de ele conhecer, que é finito. Donde, da sua eficácia cognoscitiva, proveniente da
referida visão, não resulta necessariamente que seja ampliado ao infinito, a ponto de conhecer todas as
cousas.

RESPOSTA À QUARTA. ─ A deficiência do conhecimento resulta não só do excesso e do defeito do
cognoscível em relação ao intelecto, mas também da falta de união entre o intelecto e aquilo que é a
razão da cognoscibilidade. Assim, a vista não verá uma pedra por não estar unida à espécie da pedra.
Embora, pois, ao intelecto que vê a Deus esteja unida a própria essência divina, razão de ser de todas as
cousas, não é enquanto razão de todas elas que lhe está o intelecto unido, mas enquanto razão só de
certas cousas, e de tantas mais quanto a maior plenitude com que um intelecto vir a divina essência.

RESPOSTA À QUINTA. ─ Quando uma potência passiva for perfectível por várias perfeições coordenadas
entre si, desde que recebeu a sua última perfeição, não é mais considerada imperfeita, mesmo se lhe
faltarem algumas disposições prévias. Ora, todo conhecimento, que aperfeiçoe o intelecto criado,
ordena-se como ao fim, ao conhecimento de Deus. Por onde, quem vise a Deus por essência, mesmo
que nada mais conhecesse, teria um intelecto perfeito. Nem é mais perfeito pelo fato de ter outro
conhecimento concomitante com o da essência divina, salvo se, assim, conhecer também a Deus mais
perfeitamente. Por isso, diz Agostinho: Infeliz do homem que, conhecendo tudo a mais, i. é, as criaturas,
te ignora contudo a ti. Feliz porém da que te conhece a ti ainda que ignore tudo mais. Mas aquele que te
conhecer a ti e às criaturas, não será par isso mais feliz, porque só par ti o é.

RESPOSTA À SEXTA. ─ O Verbo de Deus é um espelho, mas dotado de vontade; e por isso, assim como
se manifesta a quem quiser, assim manifestará em si o que quiser. Nem há símil com um espelho
material, que não tem o poder de deixar-se ver Ou não. ─ Ou podemos responder, que num espelho
material, tanto as cousas como o espelho são vistos na sua forma própria; embora o espelho seja visto
mediante a forma refletida do objeto, p. ex., uma pedra, a qual a qual porém seria vista na sua forma
própria refletida pelo espelho, cousa distinta dela. E assim, a mesma razão de conhecermos um é a de
conhecermos outro. Mas no espelho incriado veremos as cousas pela forma mesma dele assim como
conhecemos os efeitos pela semelhança com a causa, e não ao contrário. Mas daí não resulta
necessariamente que, quem contemple o espelho eterno, veja tudo o que nele se reflete. Do mesmo
modo que quem conhece uma causa não lhe conhece necessariamente todos os efeitos, salvo se tiver
plena compreensão dela.

RESPOSTA À SÉTIMA. ─ O desejo dos santos de conhecerem todas as cousas será realizado pelo só fato
de virem a Deus; assim como o desejo deles de terem todos os bens será satisfeito pela posse que terão
de Deus. Pois, assim como Deus, pela sua bondade perfeita, satisfaz plenamente ao nosso desejo; e com
a posse de Deus de certo modo possuímos tudo, assim a visão divina satisfaz plenamente ao intelecto,
conforme aquilo do Evangelho: Senhor, mostra-nos o Pai e isso nos basta.

RESPOSTA À OITAVA. ─ A ignorância, no seu sentido próprio implica uma privação e, como tal uma
pena, e consiste em não sabermos o que deveríamos ou teríamos a obrigação de saber. Ora, de nenhum
destes modos os santos na pátria sofrerão detrimento na sua ciência. Mas a ignorância pode também
ser tomada, num sentido geral, por qualquer espécie de nesciência. E então os anjos e os santos na
pátria ignorarão certas cousas. Por isso Dionísio diz que serão purificados da nesciência, que, neste
sentido, não é uma penalidade, mas apenas uma deficiência. Nem há de a glória necessariamente
eliminar toda deficiência como essa; pois, a essa luz, poderíamos também considerar uma deficiência de
Lino, para, de não ser alçado à mesma glória de Pedro.

RESPOSTA À NONA. ─ O nosso corpo se conformará com o de Cristo, na glória, por semelhança e não
por igualdade; pois, será resplendente como o corpo de Cristo, mas não igualmente. Da mesma
maneira, a nossa alma terá uma glória semelhante à da alma de Cristo, mas não em grau igual. Assim
também terá a ciência, como a alma de Cristo, mas não na mesma extensão, a ponto de saber tudo,
como o sabe a alma de Cristo.

RESPOSTA À DÉCIMA. ─ Embora a essência divina seja a razão da cognoscibilidade de todas as cousas,
nem por isso, em quanto razão dessa cognoscibilidade universal está unida a qualquer intelecto criado.
A objeção, pois, não colhe.

RESPOSTA À UNDÉCIMA. ─ O intelecto agente é uma forma proporcionada ao intelecto possível, assim
como a potência da matéria é proporcionada à potência do agente natural. De modo que tudo o
existente na potência passiva da matéria ou do intelecto possível também exista na potência ativa do
intelecto agente ou do agente natural. Por onde, se o intelecto agente se tornar a forma do intelecto
possível, necessariamente este último conhecerá todas as cousas que a virtude do intelecto agente
puder atingir. Ora, a essência divina não é uma forma proporcionada desse modo, ao nosso intelecto.
Logo, não há símil.

RESPOSTA À DUODÉCIMA. ─ Nada impede admitir-se que depois do dia de juízo, uma vez plenamente
consumada a glória dos homens e a dos anjos, que todos os bem-aventurados conhecerão tudo o que
Deus conhece pela ciência de visão. Mas de modo que nem todos verão tudo na essência divina. A alma
de Cristo porém, como vê agora, verá nela então todas as cousas; ao passo que os outros santos nela
verão mais ou menos cousas, conforme o grau de claridade com que conhecerem a Deus. E assim a alma
de Cristo, do que, mais que os outros, vir no Verbo, iluminá-los-á a todos; donde o dizer a Escritura: A
claridade de Deus iluminou a cidade de Jerusalém e a lâmpada dela é o Cordeiro. E semelhantemente,
os superiores iluminarão os inferiores, não por uma nova iluminação, de modo que aumentasse a
ciência dos inferiores; mas por uma iluminação continuada, como se supusesse o sol, em repouso, a
iluminar o ar. Por isso diz a Escritura: Os que tiverem ensinado a muitos o caminho da justiça, esses
luzirão com as estréias por toda a eternidade. Quanto à superioridade de uma ordem sobre outra, o
Apóstolo diz que cessará quanto à ação de Deus, nesta vida, sobre nós, mediante os ministérios das
diversas ordens de anjos, como claramente o diz uma Glosa a esse lugar do Apóstolo.