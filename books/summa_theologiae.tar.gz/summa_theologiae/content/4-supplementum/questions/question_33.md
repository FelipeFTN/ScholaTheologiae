# Questão 33: Da reiteração deste sacramento.
Em seguida, devemos tratar da reiteração deste sacramento.
Sobre o que duas questões se discutem:

## Art. 1 — Se este sacramento deve ser reiterado.
O primeiro discute-se assim. ─ Parece que este sacramento não deve ser reiterado.

1. ─ Pois, mais nobre é a unção feita a uma pessoa que a uma pedra. Ora, não se reitera a unção do altar
senão se esse altar for partido. Logo, também não deve ser reiterada a extrema unção feita a uma
pessoa.

2. Demais. ─ Além de um extremo nada mais há. Ora, esta é a chamada extrema unção. Logo, não deve
ser reiterada.
Mas, em contrário. ─ Este sacramento é uma medicação espiritual feita a modo de medicação corporal.
Ora, a medicação do corpo é susceptível de ser reiterada. Logo, também este sacramento pode ser
reiterado.

SOLUÇÃO. ─ Nenhum sacramento ou sacramental de efeito perpétuo pode ser reiterado; pois, o
contrário significaria que o sacramento não teria eficácia para produzir tal efeito, e a reiteração seria
irreverência para com ele. Mas, sacramento sem efeito perpétuo pode, sem irreverência, ser reiterado,
de modo que a reiteração realize o efeito não chegado a termo. E como a saúde do corpo e da alma, que
é o efeito deste sacramento, pode ser perdida, depois de obtida como efeito dele, por isso este
sacramento pode, sem irreverência, ser reiterado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A unção da pedra se faz para a consagração mesma do
altar, e a pedra a conserva perpetuamente enquanto o altar dura; por isso não pode ser reiterada. Ao
passo que esta unção não se faz para consagrar a pessoa ungida, pois, não imprime caráter. Logo, o
símile não colhe.

RESPOSTA À SEGUNDA. ─ O que na apreciação nossa é um extremo pode não sê-lo na realidade das
causas. Assim, este sacramento se chama extrema unção, porque não deve ser ministrado senão
àqueles cuja morte julgamos próxima.

## Art. 2 — Se pode ser reiterado na mesma enfermidade.
O segundo discute-se assim. ─ Parece que não deve ser reiterado na mesma enfermidade.

1. ─ Pois, a cada doença se lhe aplica o seu remédio. Ora, este sacramento é um remédio espiritual.
Logo, não deve ser aplicado mais de uma vez à mesma doença.

2. Demais. ─ Se esta unção pudesse reiterar-se na mesma doença, um enfermo poderia ser ungido todo
o dia. O que é absurdo.
Mas, em contrário, às vezes uma doença se prolonga muito, depois de ter sido o sacramento recebido: e
assim podem-se contrair novas relíquias de pecado, contra as quais principalmente és te sacramento é
conferido. Logo, deve ser repetida a unção.

SOLUÇÃO. ─ Este sacramento não concerne tanto à doença como ao estado de doença; pois, não deve
ser conferido senão aos enfermos que julgamos próximos de morrer. Ora, certas doenças não são
prolongadas. Por onde, se se ministra este sacramento só quando o doente se acha em perigo de morte,
não sairá ele desse estado senão depois de curado e então de novo não deve ser ungido. Mas, se sofrer
recidiva, já será outra doença e poder-se-lhe-à então fazer outra unção. Há porém certas doenças
prolongadas, como a héctica, a hidropsia e semelhantes. E tais doentes não devem ser ungidos senão
quando se julgar que correm perigo de morte. E se escapar a esse perigo, na duração da mesma
enfermidade, mas vindo depois, ainda durante ela, a correr de novo tal perigo, poderá ser ungido de
novo, pois já é por assim dizer outra doença, embora, absolutamente falando seja a mesma.
Donde se deduzem as RESPOSTAS ÀS OBJEÇÕES.
O Sacramento da ordem