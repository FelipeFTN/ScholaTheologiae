# Questão 64: Dos anexos ao matrimônio, e primeiro, do cumprimento do dever conjugal.
Em seguida devemos tratar dos anexos ao matrimônio. E primeiro, do cumprimento do dever conjugal.
Segundo, da pluralidade de mulheres. Terceiro, da bigamia. Quarto, do libelo de repúdio. Quinto, dos
filhos ilegitimamente nascidos.
Na primeira questão discutem-se dez artigos:

## Art. 1 — Se um cônjuge esta obrigado, por necessidade de preceito, a cumprir para com o outro o dever conjugal.
O primeiro discute-se assim. ─ Parece que um cônjuge não está obrigado, por necessidade de preceito,
a cumprir para com o outro o dever conjugal.

1. Pois, o cumprimento de um preceito não pode impedir ninguém de receber a Eucaristia. Ora, o
marido que não cumprir para com a mulher o dever conjugal não pode comer a carne do Cordeiro, diz
Jerônimo, citado pelo Mestre. Logo, cumprir o dever conjugal não é de necessidade de preceito.

2. Demais. ─ Todos podemos licitamente nos abster do que nos é nocivo à pessoa. Ora, pode ser nocivo
a um cumprir o dever conjugal para com o outro que o pede, quer em razão de uma doença, quer pelo
fato de já ter cumprido. Logo, parece lícito a um negar o cumprimento desse dever ao outro, que o
pede.

3. Demais. ─ Quem se faz impotente para cumprir o a que está obrigado por preceito peca. Portanto,
quem está obrigado por preceito a cumprir o dever conjugal, parece que peca se, por jejuar ou
enfraquecer o corpo, se tornar impotente para o cumprimento desse dever. O que não é verdadeiro.

4. Demais. ─ O matrimônio, segundo o Filósofo, se ordena à geração e à educação dos filhos, e além
disso, à comunicação da vida. Ora, a lepra contraria ambos esses fins do matrimônio; porque, sendo
uma doença contagiosa, não está a mulher obrigada a coabitar com o marido leproso. Também essa
doença frequentemente se transmite aos filhos. Logo, parece que para com o marido leproso não está a
mulher obrigada ao dever conjugal.
Mas, em contrário. ─ Assim como o escravo é propriedade do senhor, assim um cônjuge esta sob o
poder do outro. Ora, o escravo esta obrigado, por necessidade de preceito, a cumprir o seu dever para
com o senhor, conforme aquilo do Apóstolo. Pagai a todos o que lhes é devido a quem tributo, tributo,
etc. Logo, cada cônjuge está obrigado, por necessidade de preceito, a cumprir para com o outro, o dever
conjugal.

2. Demais. ─ O matrimônio se ordena a evitar a fornicação, como diz o Apóstolo. Ora, esse fim do
matrimônio não poderia ser alcançado se um não estivesse obrigado a cumprir para com o outro,
quando excitado pela concupiscência, o dever conjugal. Logo, cumpri-lo é de necessidade de preceito.

SOLUÇÃO. ─ O matrimônio foi principalmente instituído como função da natureza. Logo, no seu
exercício devemos obedecer à inclinação da natureza em virtude da qual a função nutritiva não ministra
a gerativa senão o supérfluo à conservação do matrimônio. Pois, a ordem natural é um ser primeiro
aperfeiçoar-se a si próprio, e depois comunicar a outros da sua perfeição. Ora, esta é também a ordem
da caridade, que aperfeiçoa a natureza. Por onde, como a mulher não tem poder sobre o homem senão
quanto à função gerativa, e não quanto ao ordenado à conservação do indivíduo, está o marido
obrigado ao dever conjugal, no atinente à geração dos filhos, salva porém primeiro à integridade
pessoal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O cumprimento de um dever pode tornar uma pessoa
inábil para exercer um ofício sagrado; assim o juiz que condena o réu à morte por dever, torna-se
irregular. Semelhantemente, quem, por necessidade de preceito, cumpre o dever conjugal, torna-se
inepto a exercer ofícios divinos; não que o ato conjugal seja pecaminoso, mas em razão da sua
carnalidade. E assim, segundo diz o Mestre, Jerônimo se refere só, aos ministros da Igreja, não porém a
outros que devem ser entregues ao juízo próprio; e tanto podem, por causa de reverência deixar de
receber o corpo de Cristo, como recebê-lo por devoção, sem pecado.

RESPOSTA À SEGUNDA. ─ A mulher não tem poder sobre o corpo do marido, senão salvas as energias
pessoais dele, como se disse. Por onde, ultrapassando os seus direitos, já não lhe pede o cumprimento
do dever conjugal, mas faz exigências injustas. Por isso, o marido não está obrigado a satisfazê-la

RESPOSTA À TERCEIRA. ─ O marido que se tornar impotente para cumprir o dever conjugal, por causa
resultante do próprio matrimônio. por exemplo, já o haver cumprido, não tem a mulher o direito de lhe
pedir a renovação do ato; e, pedindo-lhe de novo o cumprimento do dever, mais se revela meretriz, que
esposa, Pode porém, tornar-se incapaz de cumpri-lo. E então, sendo a causa lícita não fica obrigado à
renovação do ato, nem pode a mulher exigi-lo. Sendo ilícita porém, então peca e de
certo modo lhe é imputável o pecado da esposa se, por isso, cair em fornicação. Por onde, deve fazer o
possível para que a mulher seja continente.

RESPOSTA À QUARTA. ─ A lepra dissolve os esponsais, mas não o matrimônio. Portanto, a mulher está
obrigada ao dever conjugal, mesmo que o marido seja leproso. Mas, não está obrigada a coabitar com
ele; porque não se contamina tão facilmente pelo coito, como se contaminaria pela coabitação
frequente. E embora gere uma prole enferma, contudo é melhor a esta existir, que de nenhum modo ter
a existência.

## Art. 2 — Se o marido está obrigado a cumprir o dever conjugal se a esposa não Ih'o pede.
O segundo discute-se assim. ─ Parece que o marido não está obrigado ao dever conjugal se a esposa
não lh'o pede.

1. Pois, um preceito afirmativo não obriga senão por tempo determinado. Ora, o tempo determinado do
cumprimento do dever conjugal não pode ser senão quando pedido. Logo, em outra ocasião não pode
ser cumprido.

2. Demais. ─ De todos devemos presumir o melhor. Ora, também aos cônjuges é melhor praticar a
continência, que usar do matrimônio. Logo, se expressamente não o pedir a mulher, deve o marido
presumir que lhe apraz a continência. E então obrigado não está ao dever conjugal.

3. Demais. ─ Assim como a mulher tem poder sobre o marido, assim o escravo sobre o senhor. Ora, ao
senhor não está obrigado o escravo a servir, senão quando dele recebe uma ordem. Logo, nem o marido
está obrigado ao dever conjugal para com a mulher senão quando esta lh'o pede.

4. Demais. ─ O marido pode às vezes rogar à esposa que pede o cumprimento do dever conjugal, que
não o exija. Logo, e com maior razão, pode não o cumprir, quando ela não o exija.
Mas, em contrário. ─ O cumprimento do dever conjugal constitui um remédio contra a concupiscência
da mulher. Ora, o médico, a quem um doente foi confiado, está obrigado a lhe curar a doença, mesmo
se o doente não lh'o pede. Logo, o marido está obrigado ao dever conjugal, mesmo se a mulher não lh'o
pede.

2. Demais. ─ O superior está obrigado a dar o remédio da correção aos pecados dos súditos, mesmo
contra a vontade deles. Ora, o cumprimento do dever conjugal pelo marido se ordena a evitar os
pecados da mulher. Logo, está o marido às vezes obrigado a cumpri-lo, mesmo se não lh'o pede a
mulher.

SOLUÇÃO. ─ De dois modos pode ser pedido o dever conjugal. Expressamente, quando um o pede ao
outro por palavra. Interpretativamente, quando o marido percebe, por certos sinais da mulher, que ela
lhe pede o cumprimento desse dever, mas por vergonha se cala. Por onde, mesmo que não o peça
expressamente por palavras, o marido esta obrigado a satisfazê-la, quando a mulher manifesta, por
sinais essa vontade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O tempo determinado não é só quando é pedido, mas
quanto tem-se fundado em certos sinais, um perigo, se o dever conjugal não for cumprido; pois, para
evitar o pecado é que o cumprimento desse dever foi imposto.

RESPOSTA À SEGUNDA. ─ O marido pode assim presumir da mulher, quando não descobre nela sinais
contrários. Mas, se os descobre, estulta será a presunção.

RESPOSTA À TERCEIRA. ─ O senhor não se envergonha de pedir ao escravo que lhe faça o serviço
devido, como a mulher de pedir ao marido o cumprimento do dever conjugal. Se porém, o senhor não o
pedisse, por ignorância ou por outra causa, nem por isso o escravo estaria isento de cumprir o dever,
havendo algum perigo a temer. A isto o Apóstolo chama não servir ao olho, e o ordena aos escravos.

RESPOSTA À QUARTA. ─ O marido não deve dissuadir a mulher de pedir o dever conjugal, senão por
alguma razão aceitável. E mesmo então não a deve dissuadir com grandes instâncias, por causa de
perigo iminente que ela possa correr.

## Art. 3 — Se é lícito à mulher menstruada pedir o cumprimento do dever conjugal.
O terceiro discute-se assim. ─ Parece lícito à mulher menstruada pedir o cumprimento do dever
conjugal.

1. Pois, assim como pela lei mosaica a mulher menstruada era imunda, assim o homem padecente de
fluxo seminal. Ora, o homem nestas condições pode pedir o cumprimento desse dever. Logo, pela
mesma razão, a mulher menstruada.

2. Demais. ─ Mais grave doença é a lepra que o fato de menstruação; e causa maior dano para os filhos.
Ora, a leprosa pode pedir o cumprimento do dever conjugal. Logo, etc.

3. Demais. ─ Se à menstruada não é lícito pedir o cumprimento do dever conjugal, não é isso senão em
virtude de defeitos que deve evitar nos filhos. Ora, sendo a mulher estéril, não há defeitos a temer.
Logo, parece que ao menos a estéril menstruada pode pedir tal cumprimento.
Mas, em contrário, a Escritura: Não terás acesso à mulher que padece o seu mênstruo. Ao que diz
Agostinho: Depois de já ter suficientemente proibido, repete aqui a proibição, a fim de não parece tê-lo
feito antes, só em figura.

2. Demais. ─ Isaías diz: Todas as vossas justiças são como o pano de uma mulher menstruada. O que
assim comenta Jerônimo: Em tais circunstâncias devem os maridos se abster das mulheres, porque se
concebem filhos mal conformados ─ cegos, coxos, leprosos; e por não terem os pais se envergonhado de
ter relações nessas circunstâncias, o pecado deles se manifesta em público.

SOLUÇÃO. ─ Ter o marido relação com a esposa menstruada a Lei Mosaica o proibia por duas razões:
Por imundícia e pelo dano que frequentemente dessa cópula resultava para a prole. Quanto àquela, era
esse um preceito cerimonial, Mas era moral, quanto à segunda razão. Porque, sendo o matrimônio
principalmente ordenado ao bem dos filhos, desordenado é todo uso dele que impede esse bem. Por
isso, esse preceito também obriga na vigência da Lei Nova, pela segunda razão, embora não pela
primeira. ─ Mas, o fluxo menstrual pode ser natural ou inatural. Natural quando a mulher sã o sofre em
tempos determinados. Inatural quando sofre do sofre fluxo de sangue, desordenadamente, por alguma
enfermidade. Por onde, sendo o fluxo menstrual inatural, não é proibido ao marido ter relações com a
esposa nessas condições, sobretudo na vigência da Lei Nova. Ora, por causa da enfermidade, pois então
a mulher não pode conceber em tal estado; que por ser esse fluxo perpétuo e diuturno, o que
importaria em o marido dever abster-se perpetuamente. Mas, quando a mulher sofre fluxo natural pode
conceber; além disso, esse fluxo menstrual dura pouco tempo. Por isso, é proibido ao marido ter
relações com a esposa nessas circunstâncias. Semelhantemente, é proibido à mulher menstruada pedir
o cumprimento do dever conjugal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O fluxo seminal no homem é efeito de doença; nem o
semen assim fluente é apto para a geração. Além disso, esse padecimento é diuturno ou perpétuo como
a lepra. Logo, não há símile na objeção. Donde se deduz a resposta também à segunda objeção.

RESPOSTA À TERCEIRA. ─ Enquanto a mulher padece o fluxo menstrual não se pode ter certeza se é
estéril. Pois, certas são estéreis na juventude, que no decurso do tempo se tornam fecundas e
inversamente, como diz o Filósofo.

## Art. 4 — Se a mulher menstruada deve cumprir o dever conjugal se o marido o pede.
O quarto discute-se assim. ─ Parece que a menstruada não deve cumprir o dever conjugal para com o
marido que o pede.

1. Pois, como diz a Escritura, quem tiver acesso à mulher menstruada, serão ambos punidos de morte.
Logo, parece que tanto quem cumpre o dever conjugal com quem o pede pecam mortalmente.

2. Demais. ─ O Apóstolo diz: Não somente os que estas coisas fazem, senão também os que consentem
aos que as fazem são dignos de morte. Ora, quem exige o cumprimento do dever conjugal, sabendo que
a esposa está menstruada, peca mortalmente. Logo, também a mulher que consente em lh'o cumprir.

3. Demais. ─ Não se deve dar uma espada a um louco, não vá ele matar-se. Logo, pela mesma razão,
nem a esposa menstruada deve entregar o seu corpo ao marido, a fim de não o matar espiritualmente.
Mas, em contrário. ─ Diz o Apóstolo: A mulher não tem poder no seu corpo, mas tem-no o marido. Logo,
a mulher, mesmo menstruada, de cumprir o dever conjugal ao marido que o pede.

2. Demais. ─ A mulher menstruada não deve ser ocasião de pecado para o marido. Ora se a este que lh'o
pede, ela não cumprir o dever conjugal, mesmo quando menstruada, dará ao marido ocasião de pecar,
pois talvez vá ele cair em fornicação. Logo, etc.

SOLUÇÃO. ─ Nesta matéria certos opinaram, que assim como a mulher menstruada não deve pedir o
cumprimento do dever conjugal, assim também não o deve cumprir. Pois, assim como não estaria
obrigado a ele se padecesse uma enfermidade, que pudesse lhe resultar mal, pela prática do ato sexual,
assim também não o está, para evitar perigo de filhos estropiados. ─ Mas, esta opinião é contrária ao
matrimônio, que concede poder absoluto ao marido sobre o corpo da mulher, quanto ao ato
matrimonial. Nem há símile entre a enfermidade, que poderia resultar para os filhos, e o perigo de mal
para o corpo próprio dela; pois, não é certo o mal para filhos apenas eventuais.
Por isso, outros dizem que à mulher menstruada nunca é lícito pedir o cumprimento do dever conjugal.
Se lh'o pedir porém o marido, fá-lo ciente ou ignorantemente. Se cientemente, então deve a mulher
dissuadi-lo com pedidos e advertências; mas não de maneira tão instante, que lhe pudesse vir a ser a
causa de praticar atos condenáveis, se a isso o souber inclinado. Se porém o fizer ignorantemente, então
a mulher pode lhe pedir o adiamento para outra ocasião ou alegar uma doença, que lhe impede o
cumprimento do dever conjugal, se não temer daí nenhum perigo para o marido. Mas, se afinal o
marido não desistir do seu desejo, deve cumprir o dever conjugal. Não lhe será a ela porém acertado
revelar ao marido o seu estado, não vá ele conceber abominação para com a esposa, salvo se ela puder
contar com a prudência dêle.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Isto se deve entender quando ambos consentem
voluntariamente, mas, não se a mulher cumprir o dever conjugal involutariamente.

RESPOSTA À SEGUNDA. - Como não há consentimento sem vontade, não pode a mulher consentir ao
pecado do marido, senão cumprindo voluntariamente o dever conjugal. Pois, fazendo-o
involuntariamente, antes o sofre do que o consente.

RESPOSTA À TERCEIRA. ─ Deve-se dar a espada ao louco quando, pelo não fazer, teme-se um perigo
maior. E o mesmo se dá no caso proposto.

## Art. 5 — Se marido e mulher estão no mesmo pé de igualdade quanto ao ato matrimonial.
O quinto discute-se assim. ─ Parece que marido e mulher não estão no mesmo pé de igualdade,
quanto ao ato matrimonial.

1. Pois, o agente é mais nobre que o paciente, como diz Agostinho. Ora, no ato conjugal o marido se
comporta como agente, e a mulher como paciente. Logo, não estão, quanto a esse ato, no mesmo pede
igualdade.

2. Demais. ─ A mulher só está obrigada ao dever conjugal para com o marido quando Ih'o ele pedir; o
marido, porém, está obrigado a ele, mesmo sem lh'o a mulher pedir. Logo, não estão no mesmo pé de
igualdade, quanto ao ato matrimonial.

3. ─ Demais. ─ No matrimônio a mulher foi feita para o marido, conforme aquilo da Escritura: Façamos
um adjutório semelhante a ele. Ora, um fim sempre é mais principal que o meio. Logo, etc,.

4. Demais. ─ O matrimônio foi principalmente ordenado para o ato conjugal. Ora, no matrimônio o
varão é a cabeça da mulher, na frase do Apóstolo. Logo, não estão no mesmo pé de igualdade quanto a
esse ato.
Mas, em contrário, o Apóstolo: A mulher não tem poder no seu corpo. E o mesmo diz do marido. Logo,
estão no mesmo pé de igualdade, quanto ao ato matrimonial.

2. Demais. ─ O matrimônio, por ser uma união, é uma relação de igualdade, como foi dito. Portanto, o
marido e a mulher estão em pé de igualdade quanto ao ato matrimonial.

SOLUÇÃO. ─ Há uma dupla igualdade: a quantitativa e a proporcional. A igualdade quantitativa é a
existente entre duas quantidades da mesma medida; assim entre duas, de dois côvados cada uma. A
igualdade proporcional é a existente entre duas proporções da mesma espécie; assim entre um duplo e
outro duplo. Ora, se nos referimos à primeira espécie de igualdade, marido e mulher não são iguais no
matrimônio, em quanto ao ato conjugal, em que a parte mais nobre é a do homem; nem quanto ao
governo da casa, onde o marido governa e a mulher é governada Mas, pela segunda espécie de
igualdade, ambos são iguais tanto em relação ao ato conjugal como ao governo da casa. Pois, assim
como o marido esta obrigado para com a mulher, quanto ao ato conjugal e ao governo da casa, pelo que
diz respeito à sua parte; assim está a mulher, pelo que lhe concerne, obrigada para com o marido. Por
isso diz o Mestre, que são iguais tanto em cumprir como em retribuir o dever conjugal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora ser agente seja mais nobre que ser paciente,
contudo há a mesma proporção do paciente para sofrer, como do agente para agir. E por aí, há no caso
igualdade de proporção.

RESPOSTA À SEGUNDA. ─ Isso só acidentalmente se dá. Pois, por exercer a parte mais nobre no ato
conjugal, é que naturalmente não se envergonha, como a mulher, de pedir o cumprimento do dever
conjugal. Essa a razão pela qual não esta
a mulher obrigada ao ato matrimonial, se não no pede o marido, como o esta ele, mesmo sem lh'o ela
pedir.

RESPOSTA À TERCEIRA. ─ Isso mostra não serem iguais, absolutamente falando; mas não que não o
sejam proporcionalmente.

RESPOSTA À QUARTA. ─ Embora a cabeça seja mais principal que os membros, contudo, assim como os
membros dependem, para as suas funções, da cabeça, assim também ela, deles, para o exercício das
suas. Por onde, há no caso igualdade de proporção.

## Art. 6 — Se marido e mulher podem emitir voto contrário ao dever conjugal sem consentimento mútuo.
O sexto discute-se assim. ─ Parece que marido e mulher podem emitir voto contrário ao dever
conjugal, sem consentimento mútuo.

1. Pois, marido e mulher estão obrigados ao dever conjugal, como se disse. Ora, é lícito ao marido,
mesmo se lh'o proibir a mulher, alistar-se como cruzado, em defesa da Terra Santa. Logo, também lícito
o será à esposa. Portanto, como em tais circunstâncias fica impedido o cumprimento do dever conjugal,
pode um, sem o consentir o outro cônjuge, emitir esse voto.

2. Demais. ─ Para um cônjuge fazer um voto não precisa obter o consentimento do outro, quando este
não pode dissentir, sem pecado. Ora, um cônjuge não pode, sem pecado deixar de consentir que o
outro faça voto de continência perpétuo ou temporário; porque impedir o progresso espiritual é pecado
contra o Espírito Santo. Logo, pode um fazer voto de continência, perpétuo ou temporário, sem o
consentimento do outro.

3. Demais. ─ O ato matrimonial tanto compreende o cumprimento como a retribuição do dever
conjugal. Ora, um pode, sem o consentimento do outro fazer o voto de não pedir o cumprimento desse
dever, pois isso está no seu poder. Logo, pela mesma razão, o de não o retribuir.

4. Demais. - Ninguém pode ser obrigado, por preceito de um superior, ao que não lhe é lícito,
absolutamente falando, ligar por um voto ou fazer; pois não há de ser de obediência em matéria ilícita.
Ora, o prelado superior pode ordenar ao marido, pelo ocupar num determinado serviço, que se
abstenha do ato conjugal, temporariamente. Logo, também isso poderia ele próprio fazer e pronunciar
um voto impediente do dever conjugal.
Mas, em contrário, o Apóstolo: Não vos defraudeis um ao outro, senão talvez de comum acordo por
algum tempo, para vos aplicardes à oração.

2. Demais. ─ Ninguém pode fazer voto relativamente ao que é alheio. Ora, o marido não tem poder no
seu corpo, mas tem no a mulher, na frase do Apóstolo. Logo, sem o seu consentimento, não pode o
marido fazer voto de continência, nem perpétuo, nem temporário.

SOLUÇÃO. ─ Fazer voto é próprio da vontade, como o próprio nome o indica. Por onde, só podemos
fazer voto em relação àqueles bens, que dependem da nossa vontade. Ora, tais não são as obrigações
que nos ligam a terceiros. Portanto, em relação a estes não podemos fazer voto sem o consentimento
de quem dependemos. Ora, estando os cônjuges obrigados um para com o outro ao dever conjugal,
impediente da continência, não pode um, sem consentimento do outro, fazer voto de continência. E se
o fizer peca; e não deve cumprir o voto, mas penitenciar-se de o haver mal feito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Bastante provável é que a mulher deva querer uma
continência temporária por socorrer às necessidades da Igreja universal. Por isso, como favor por ter o
marido a cruz e partir em defesa da Terra Santa, a Igreja determinou que a possa receber sem o
consentimento da esposa. Assim, como também poderia militar em favor de seu senhor temporal, de
quem recebeu o feudo, sem o consentimento dela. Mas, nem por isso fica a mulher privada do seu
direito, pois poderá acompanhá-lo, ─ Nem há símile entre marido e mulher. Pois, como é o marido quem
deve governar a mulher, e não ao inverso, mais obrigada está a mulher a seguir ao marido que ao
contrário. Além disso, a mulher, com maior perigo para a castidade, que o marido, andaria em excursões
por terras estranhas; e com menos utilidade para a Igreja. Por isso, não pode ela fazer esse voto sem a
permissão do marido.

RESPOSTA À SEGUNDA. ─ O cônjuge, que dissentir do ato de continência do outro, não peca: pois não o
faz por lhe impedir o bem, mas para não acarretar um dano para si mesmo.

RESPOSTA À TERCEIRA. ─ Nesta matéria duas são as opiniões. ─ Assim, certos dizem, que pode um sem
o consentimento do outro, fazer voto de não pedir o cumprimento do dever conjugal, mas não o de não
o retribuir. Porque quanto a pedi-lo ou não, cada um é independente; não porém, quanto ao retribuir. ─
Mas, o não pedir nunca um esse cumprimento tornaria o matrimônio demasiado oneroso ao outro, que
ficaria sempre sujeito ao acanhamento de o pedir. Por isso, e mais provavelmente, dizem outros, que
nenhum pode fazer voto sem o consentir o outro cônjuge.

RESPOSTA À QUARTA. ─ Assim como a mulher recebe poder sobre o corpo do marido, salvo aquilo em
que este pode dispor do seu próprio corpo, assim também salvo ficará aquilo em que está obrigado para
com o senhor. Por onde, assim corno a mulher não pode pedir ao marido o cumprimento do dever
conjugal em detrimento da saúde corporal deste, assim também não o pode, impedindo os seus deveres
para com o senhor. Mas, fora daí, não pode o senhor proibi-lo de retribuir o dever conjugal.

## Art. 7 — Se em dias santos deve ser proibido pedir o cumprimento do dever conjugal.
O sétimo discute-se assim. ─ Parece que em dias santos não deve ninguém ficar proibido de pedir o
cumprimento do dever conjugal.

1. Pois, devemos obviar a um mal quando ele se faz sentir. Ora, pode dar-se que o ímpeto da
concupiscência se faça sentir em dia festivo. Logo, há o dever de o obviar pela petição do ato
matrimonial.

2. Demais. ─ Não há outra razão de não se dever pedir o cumprimento do dever conjugal, nos dias
festivos, senão a de serem destinados à oração. Ora, nesses dias apenas certas horas é que são
destinadas à oração. Logo, nas outras horas é lícito pedir o cumprimento do dever conjugal.
Mas, em contrário. ─ Assim como certos lugares são santos por serem deputados a cerimônias sagradas,
assim, pela mesma razão certos tempos são santos. Ora, num lugar santo não é lícito pedir o ato
matrimonial. Logo, nem em tempo santo.

SOLUÇÃO. ─ O ato matrimonial, embora isento de culpa, contudo, por deprimir a razão, por causa do
prazer carnal, torna o homem incapaz dos bens espirituais. Por isso, nos dias em que deve sobretudo
vacar às coisas espirituais, não é lícito pedir o cumprimento do dever conjugal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Nesse tempo podem, empregar-se outros meios de
reprimir a concupiscência, como a oração e outros tais, que também empregam os que vivem em
continência perpétua.

RESPOSTA À SEGUNDA. ─ Embora não estejamos obrigados a orar em todas as horas, contudo o
estamos a nos dispormos, durante o dia todo, a orar.

## Art. 8 — Se quem pede o cumprimento do dever conjugal em dia santo peca mortalmente.
O oitavo discute-se assim. ─ Parece que quem pede o cumprimento do dever conjugal em dia santo
peca mortalmente.

1. Pois, Gregório refere o caso de uma mulher que, tendo tido durante à noite cópula carnal com o
marido, vindo de manhã à procissão, foi arrebatada pelo diabo. Ora, isto não se daria se não tivesse
pecado mortalmente.

2. Demais. ─ Todo o que age contra o preceito divino peca mortalmente. Ora, o senhor ordenou; quando
os hebreus iam receber a Lei: não vos achegueis a vossas mulheres. Logo, e com maior razão, pecam
mortalmente os que tiverem conjunção carnal com a esposa, em tempo que a Lei Nova considera
consagrado ao Senhor.
Mas, em contrário. ─ Nenhuma circunstância pode agravar o pecado ao infinito. Ora, o tempo indevido é
uma circunstância. Logo, não agrava ao infinito o pecado, de modo a tornar mortal o pecado que, a não
ser assim, seria venial.

SOLUÇÃO. ─ Pedir o cumprimento do dever em dia festivo, não é circunstância que altere o gênero de
pecado. Logo, não se pode agravar ao infinito. Portanto, não peca mortalmente o marido nem a mulher,
pedindo o referido cumprimento em dia festivo. Contudo, mais grave será o pecado, se o ato
matrimonial for pedido só por prazer, do que por temor de cair em pecado da carne.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Essa mulher não foi punida por ter retribuído o dever
conjugal, mas por ter depois, temerariamente e contra a consciência, tomado parte num ato sagrado.

RESPOSTA À SEGUNDA. ─ Por essa autoridade não se pode provar que tal ato é pecado mortal, senão só
inconveniente. Pois, muitas exigências fazia a Lei Velha, dada a homens carnais, atinentes à purificação
da carne, por necessidade de preceito, que a Lei Nova não faz, por ser a lei do espírito, na expressão do
Apóstolo.

## Art. 9 — Se há obrigação do dever conjugal em dia festivo.
O nono discute-se assim. ─ Parece que não há obrigação do dever conjugal em dia festivo.

1. Pois, tanto os que pecam como os que consentem no pecado são punidos, como diz o Apóstolo. Ora,
quem retribui o ato matrimonial, consente no que o outro pede, que peca. Logo, também peca.

2. Demais. ─ Por preceito afirmativo estamos obrigados a orar; portanto, em tempo determinado. Logo,
no tempo em que esta um obrigado a orar, não está obrigado a retribuir o dever conjugal. Assim como
não o esta no tempo em que estiver obrigado a um serviço especial para com o senhor temporal.
Mas, em contrário, o Apóstolo: Não vos defraudeis um ao outro, senão talvez de comum acordo por
algum tempo etc. Logo, quando um cônjuge pede o cumprimento do dever conjugal o outro esta
obrigado a ele.

SOLUÇÃO. ─ A mulher tem poder sobre o corpo do marido no atinente ao ato da geração, e ao inverso.
Por onde, está cada qual obrigado a retribuir o dever conjugal para com o outro, em qualquer tempo e
em qualquer hora, salva a honestidade devida que nessas circunstâncias se exige, porque não há de o
dever matrimonial ser retribuído logo, em público.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Esse, pelo que de si depende, não consente, mas antes,
involuntariamente e com dor é que pratica o ato dele exigido. Portanto, não peca. Pois, para evitar o
pecado da carne, ordenou Deus que sempre um cônjuge cumpra o dever conjugal para com o outro,
que o pede, para não lhe dar nenhuma ocasião de pecar.

RESPOSTA À SEGUNDA. ─ Não há nenhuma hora, a ponto determinada à oração, que não possa ser
substituída por outras. Por isso, a objeção não colhe.

## Art. 10 — Se as núpcias devem ser proibidas em certos tempos.
O décimo discute-se assim. ─ Parece que as núpcias não devem ser proibidas em certos tempos.

1. Pois, o matrimônio é um sacramento. Ora, nesses tempos não fica proibida a celebração dos outros
sacramentos. Logo, nem deve ficar a do matrimônio.

2. Demais. ─ Mais impróprio é pedir nos dias festivos o cumprimento do dever conjugal, que celebrar o
matrimônio. Logo, nesses dias o cumprimento desse pode ser pedido. Portanto, também podem
celebrar-se núpcias.

3. Demais. ─ Os matrimônios celebrados contra a determinação da Igreja devem ser dissolvidos. Ora,
não no deve, se for o casamento celebrado nesses tempos. Logo, não deveriam ser proibidos pela lei
eclesiástica.
Mas, em contrário, a Escritura: há tempo de dar abraços e tempo de se por longe deles.

SOLUÇÃO. ─ Os recém-casados, por causa do novo gênero de vida em que entram, ficam possuídos do
desejo do ato matrimonial; daí o costume de manifestarem, quando se casam, por certos festejos a
alegria dissipada que os domina. Razão por que, nos tempos em que devemos sobretudo nos elevar às
coisas espirituais, a Igreja proibiu celebrarem-se núpcias. E isto é desde o advento até a Epifania, por
causa da comunhão, que segundo os antigo; cânones, costuma-se convenientemente fazer na
maturidade. E desde a Septuagésirna até as oitavas da Páscoa, por causa da comunhão pascoal. E desde
três dias antes da ascenção até as oitavas do Pentecostes, por causa da preparação à comunhão que
nesse tempo se deve tomar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A celebração do matrimônio é acompanhada de uma
certa alegria mundana e carnal, o que não se dá com os outros sacramentos. Logo, o símile não colhe.

RESPOSTA À SEGUNDA. ─ Não há tanta dissipação das almas no ato de cumprir e retribuir o dever
conjugal, como na celebração do casamento. Logo, o símile não colhe.

RESPOSTA À TERCEIRA. ─ Como o tempo não ê da essência do matrimônio, nem por ser contraído em
tempo impróprio deixa de ser válido. Nem os cônjuges se separam perpetuamente, mas só por um
tempo ─ para fazerem penitência pela transgressão que cometeram da lei da Igreja, Tal o sentido que
devemos dar às palavras do Mestre.
