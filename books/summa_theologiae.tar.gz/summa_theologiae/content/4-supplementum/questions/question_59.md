# Questão 59: Da disparidade de culto como impedimento ao matrimônio.
Em seguida devemos tratar da disparidade de culto como impedimento ao matrimônio.
E nesta questão discutem-se seis artigos:

## Art. 1 — Se um fiel pode casar com um infiel.
O primeiro discute-se assim. ─ Parece que um fiel pode contrair casamento com um infiel.

1. Pois, José casou com uma egípcia, e Ester com Assuero. Ora, em ambos os casos havia disparidade de
culto por ser um infiel, e o outro fiel. Logo, a disparidade de culto precedente ao matrimônio não no
impede.

2. Demais. ─ A fé ensinada pelo Testamento Velho é a mesma ensinada pelo Novo. Ora, segundo a lei
antiga, podia um fiel casar com um infiel, como o refere a Escritura: Se saíres a pelejar contra os teus
inimigos e vires entre o número dos prisioneiros uma mulher formosa e te namorares dela e a queiras
ter por esposa, a tornarás para ti e dormirás com ela e ficará sendo tua mulher. Logo, o mesmo também
é lícito no regime da lei nova.

3. Demais. ─ Os esponsais se ordenam para o matrimônio. Ora, um fiel pode, em certos casos, contrair
esponsais com uma infiel, sob a condição de conversão futura. Logo, sob a mesma condição, podem
contrair matrimônio.

4. Demais. ─ Todo impedimento ao matrimônio é de certo modo contrário ao matrimônio. Ora, a
infidelidade não é contrária ao matrimônio, porque este é uma função da natureza, cujos ditames
ultrapassam o domínio da fé! Logo, a disparidade de fé não impede o matrimônio.

5. Demais. ─ Disparidade de fé pode também haver entre dois batizados, como quando um depois do
batismo cai na heresia. E se contrair casamento com um fiel não deixará ele de ser válido. Logo, a
disparidade de fé não impede o matrimônio.
Mas, em contrário, o Apóstolo: Que comércio pode haver entre a luz e as trevas? Ora, não há mais
estreita união que a entre marido e mulher. Logo, quem vive na luz da fé não pode contrair matrimônio
com quem jaz nas trevas da infidelidade.

2. Demais. ─ A Escritura diz: Judas contaminou a santificação do Senhor, porque amou e se casou com
uma filha de um deus estranho. Ora, tal não se daria se pudessem, contrair um verdadeiro matrimônio.
Logo, a disparidade de culto impede o matrimônio.

SOLUÇÃO. ─ O bem mais principal do matrimônio são os filhos a serem educados no culto de Deus. Ora,
a educação, fazendo-se em comum pelo pai e pela mãe, cada qual entenderá educar os filhos no culto
de Deus, segundo a sua fé. Portanto, sendo de fé diversa, a intenção de um encontrará a do outro. Por
onde, não pode haver entre eles união matrimonial. Por isso a disparidade de culto precedente ao
matrimônio impede-o de ser contraído.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A Lei Velha permitia o casamento dos judeus com certos
infiéis e o proibia com outros. Especialmente lhes era proibido casar com os infiéis habitantes da terra
de Canaan, quer por o Senhor tê-los mandado matar, por causa da sua obstinação; quer porque os filhos
de Israel corriam maior perigo de perverter as mulheres e os filhos, fazendo-os cair na idolatria deles, a
cujos costumes e ritos eram mais inclinados pelas relações que com eles mantinham. Mas permitiu-lhes
casar em outras gentilidades, sobretudo quando não corriam o perigo de serem arrastados à idolatria.
Assim, José, Moisés e Ester contraíram casamento com infiéis. ─ A Lei Nova porem, que devia difundir-se
por todo o mundo, tinha igual razão de proibir os fiéis de casarem, com qualquer infiéis. Por isso a
disparidade de culto precedente ao matrimônio impede-o de ser contraído e o anula quando já o foi.

RESPOSTA À SEGUNDA. ─ Essa lei ou se refere às outras nações nas quais os israelitas podiam
licitamente casar, ou às captivas que queriam converter-se à fé e ao culto de Deus.

RESPOSTA À TERCEIRA. ─ A mesma relação existe entre presente e presente, e futuro e futuro. Por
onde, assim como no momento de se o matrimônio contrair, é necessária a unidade de culto entre os
contraentes, assim também para os esponsais, que são uma promessa de matrimônio futuro, basta a
condição aposta, da futura unidade de culto.

RESPOSTA À QUARTA. ─ Do sobre dito resulta que a disparidade de culto é contrária ao matrimônio em
razão do bem mais principal dele, que são os filhos.

RESPOSTA À QUINTA. ─ O matrimônio é um sacramento. Ora, o sacramento, para sua validade, exige a
pureza quanto ao sacramento da fé, isto é, o batismo, mais que em relação a fé interior. Por isso
também, este impedimento não se chama disparidade de fé, mas, de culto, que respeita o serviço
exterior como dissemos. Por isso, o fiel; que contrair matrimônio com uma herética batizada, contrai
verdadeiro casamento. Embora, sabendo-a herética peque ao fazê-lo, como peca contraindo
matrimônio com uma excomungada. Mas nem por isso o casamento será anulado. E inversamente, o
catecúmeno de fé verdadeira, mas não batizado, que casar com uma fiel batizada, não contrairá
verdadeiro matrimônio.

## Art. 2 — Se o matrimônio dos infiéis é verdadeiro matrimônio.
O segundo discute-se assim. ─ Parece que o matrimônio dos infiéis não é verdadeiro matrimônio.

1. Pois, o matrimônio é um sacramento da Igreja. Ora, o batismo é a porta dos sacramentos. Logo, os
infiéis, que não são batizados, não podem contrair matrimônio, como não podem receber os outros
sacramentos.

2. Demais. ─ Dois males impedem mais um bem do que um só mal. Ora, a infidelidade de um só dos
cônjuges impede o bem do matrimônio. Logo e com maior razão; a infidelidade de ambos. Portanto, o
matrimônio dos infiéis não o é verdadeiramente.

3. Demais. ─ Assim como entre um fiel e um infiel há disparidade de culto, assim entre dois infiéis; por
exemplo, sendo um gentio e outro judeu. Ora, a disparidade de culto impede o matrimônio, como se
disse. Logo, ao menos um caso haverá em que o matrimônio não poderá existir, e é o de dois infiéis
pertencentes a duas religiões diversas.

4. Demais. ─ Ao matrimônio deve presidir um verdadeiro pudor. Ora, como diz Agostinho, citado pelo
Mestre das Sentenças, não há verdadeira pudicícia entre um infiel e sua esposa. Logo, nem verdadeiro
matrimônio.

5. Demais. ─ No verdadeiro matrimônio a cópula carnal é isenta de pecado. Ora tal resultado não pode
produzir o matrimônio contraído entre os infiéis, porque, na frase do Apóstolo, toda a vida dos infiéis é
uma vida de pecado. Logo, entre os infiéis não pode haver verdadeiro matrimônio.
Mas, em contrário, o Apóstolo: Se algum irmão tem esposa infiel e esta consente em coabitar com ele,
não largue a tal o seu marido. Ora, o nome de esposa lhe advém do matrimônio. Logo, o matrimônio
contraído entre infiéis é verdadeiro matrimônio.

2. Demais. ─ Removido o posterior nem por isso o fica o anterior. Ora, o matrimônio constitui uma
função da natureza, que precede o estado da graça, cujo princípio é a fé. Logo, a infidelidade não faz
com que deixe de ser verdadeiro matrimônio o contraído entre infiéis.

SOLUÇÃO. ─ O matrimônio foi sobretudo instituído para o bem da prole. Não tanto para a gerar, porque
isso também se poderia obter sem o matrimônio, mas, além disso, para levá-la ao estado de perfeição,
pois, todo ser busca produzir o seu efeito natural o mais perfeitamente possível. Ora, devemos
considerar na prole uma dupla perfeição: a da natureza não só quanto ao corpo, mas também quanto à
alma, mediante o que é de lei natural; e a perfeição da graça. Ora, a primeira perfeição é material e
imperfeita, em relação à segunda. Por onde, como as coisas existentes em vista de um fim lhe são
proporcionadas a ele, o matrimônio tendente à primeira espécie de perfeição é imperfeito e material
em respeito do tendente à primeira perfeição, podendo ser comum tanto aos infiéis como aos fiéis;
sendo porém a primeira só própria dos fiéis, por isso, entre os infiéis pode haver matrimônio, mas não
perfeito pela perfeição última, como o celebrado entre os fiéis.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O matrimônio não foi instituído só como sacramento,
mas também como função da natureza. Por onde, embora os infiéis não possam contrair matrimônio
como sacramento dispensado pelos ministros da Igreja, podem-no contudo como função da natureza. E
contudo, também esse matrimônio é de certo modo sacramento, em potência, embora não o seja em
ato, porque em ato não no contraem na fé da Igreja.

RESPOSTA À SEGUNDA. ─ A disparidade ele de culto não impede o matrimônio em razão da
infidelidade, mas em razão da disparidade da fé. Pois, a disparidade de culto não só impede a segunda
perfeição dos filhos, mas também a primeira, porque os pais dirigirão os filhos para fins diferentes. O
que não se dá quando os pais são infiéis.

RESPOSTA À TERCEIRA. ─ Os infiéis podem contrair matrimônio, considerado este como função da
natureza, conforme se disso. Ora, o concernente à lei da natureza é da alçada do direito positivo. Por
onde, se fosse proibido por alguma disposição de direito positivo os infiéis contraíram matrimônio com
infiéis de outro rito, a disparidade de culto impedirá o casamento entre eles. Pois, por direito divino não
ficam proibidos de contrair casamento, porque perante Deus pouco importa como alguém se desvia da
fé, desde que esta goza da graça. Semelhantemente, a Igreja não os impede de casarem entre si, porque
não julga os que vivem fora do seu seio.

RESPOSTA À QUARTA. ─ A pudicícia e as outras virtudes dos infiéis não se consideram verdadeiras, por
não poderem atingir o fim da verdadeira virtude, que é a vera felicidade; assim como dissemos não ser
verdadeiro vinho o que não produz o efeito do vinho.

RESPOSTA À QUINTA. ─ O infiel, tendo relação com sua esposa, não peca, se cumprir o dever conjugal
em vista o bem da prole ou da fidelidade que deve guardar para com o mulher. Pois, é isto um ato de
justiça e de temperança, que observa as circunstâncias devidas ao gozo dos prazeres do tato; assim
como não peca praticando os atos das demais virtudes políticas. Nem se diz ser pecado toda a vida dos
infiéis, porque pequem em cada ato que pratiquem, mas porque, pelos seus atos, não podem livrar-se
da escravidão do pecado.

## Art. 3 — Se o esposo convertido à fé pode continuar a viver com a mulher infiel que não quer converter-se, e com a qual, quando infiel ele contraiu, matrimônio.
O terceiro discute-se assim. ─ Parece que o esposo convertido à fé não pode continuar a viver com a
mulher infiel, que não quer converter-se, e com a qual, quando infiel ele contraiu matrimônio.

1. Pois, diante de um mesmo perigo devemos tomar as mesmas precauções. Ora, por causa do perigo da
perversão da fé fica um fiel proibido de casar com infiel. Logo, como existe o mesmo perigo se o esposo
fiel continua a viver com uma infiel, com quem se casara antes; e ainda maior, porque os neófitos se
pervertem mais facilmente que os educados na fé, parece que um fiel convertido não pode continuar a
viver com a esposa infiel.

2. Demais. ─ Uma decretal determina: Não pode um infiel permanecer unido à esposa que já abraçou a
fé cristã. Logo um marido fiel deve separar-se da esposa infiel.

3. Demais. ─ O matrimônio contraído entre fiéis é mais perfeito que o contraído entre infiéis. Ora os fiéis
que o contraírem em grau proibido teriam o seu casamento dissolvido pela Igreja. Logo, também os
infiéis. E assim, um homem fiel não pode continuar a viver com a esposa infiel, ao menos quando como
infiel a desposou, sendo parente em grau proibido.

4. Demais. ─ Um infiel tem às vezes várias mulheres, segundo as disposições da sua lei. Se, pois, pode
continuar a viver com aquelas com quem casou quando infiel, resulta que poderá também, depois de
convertido, conservá-las todas.

5. Demais. ─ Pode acontecer que o marido, depois de repudiada uma mulher, case com outra, e se
converta na vigência desse segundo matrimônio. Parece, pois, que ao menos neste caso, não pode
continuar a viver com a mulher com quem casou por último.
Mas, em contrário, o Apóstolo aconselha que continue a viver com a esposa.

2. Demais. ─ Nenhum impedimento sobreveniente ao matrimônio pode anulá-lo. Ora, o matrimônio era
válido quando ambos os esposos eram infiéis. Logo, o fato de um ter-se convertido não o anula.
Portanto, parece que, nessas condições, pode o marido convertido continuar a viver com a esposa infiel.

SOLUÇÃO. ─ A fé dos cônjuges, longe de dissolver o matrimônio, o consolida. Ora, como entre os infiéis
há verdadeiro matrimônio, conforme do sobredito se colhe, o fato de converter-se um deles à fé não
acarreta a dissolução do vínculo conjugal. Mas pode dar-se que na vigência do vínculo matrimonial,
fique dissolvido o matrimônio quanto à coabitação e o cumprimento do dever conjugal. A esta luz a
infidelidade e o adultério produzem os mesmo efeito, pois, ambos vão contra o bem da prole. Por onde,
assim como o esposo tem a faculdade de repudiar a esposa adúltera ou de continuar a viver com ela,
assim também tem o poder de repudiar a infiel ou de continuar a viver com ela. Pois pode o marido
inocente continuar livremente a viver com a adúltera, na esperança de trazê-la ao bom caminho: não
poderia, se ficar obstinada no pecado do adultério, a fim de que não lhe pareça patrocinar a torpeza da
vida; embora, mesmo com a esperança de trazê-la ao bom caminho, possa repudiá-la.
Semelhantemente, um fiel convertido pode continuar a viver com a esposa infiel, na esperança de a
converter, desde que não a veja obstinada na infidelidade Embora porém proceda com acerto
continuando a viver com ela, não está contudo obrigado a tal. E esse é o conselho do Apóstolo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ É mais fácil impedir uma coisa de fazer-se, que destruir a
que foi convenientemente feita. Por isso muitos obstáculos impedem o matrimônio de ser contraído, se
o precederem, que contudo não no podem dissolver, se lhe foram subsequentes, como o demonstra a
afinidade. E o mesmo devemos dizer, da disparidade de culto.

RESPOSTA À SEGUNDA. ─ Na primitiva Igreja, no tempo dos Apóstolos, frequentemente se convertiam à
fé tanto judeus como gentios. E então um marido fiel podia ter esperança provável na conversão da
esposa, mesmo se esta não prometesse haver de se converter. Depois porém, no decurso do tempo, os
judeus ficaram mais obstinados que os gentios, porque estes continuavam a se converter, como no
tempo dos mártires e do imperador Constantino e nas épocas subsequentes. E então não era acertado a
um fiel permanecer com uma infiel judia, sem esta prometer a sua conversão; nem havia esperança de
se ela converter, como a havia da conversão de uma esposa gentia. Assim, nessa época, um fiel
convertido podia coabitar com uma gentia, mas não com uma judia salvo se esta prometesse converter-
se. E é nesse sentido que dispõe o decreto referido. Hoje, porém judeus e gentios procedem do mesmo
modo, pois ambos são, obstinados nos seus erros. Portanto, se uma esposa infiel não quiser converter-
se, não é permitido ao marido coabitar com ela, quer judia, quer gentia.

RESPOSTA À TERCEIRA. ─ Os infiéis não batizados não estão adstritos às leis da Igreja, mas o estão às do
direito divino. Portanto, os infiéis que contraírem casamento em graus proibidos pela lei divina, quer se
convertam ambos à fé, quer só um deles, não lhes poderá ser válido esse matrimônio. Se o contraíssem
porém em graus proibidos pela legislação eclesiástica, poder-lhes-á sê-lo se ambos se converterem ou,
se convertido um, houver esperança da conversão do outro.

RESPOSTA À QUARTA. ─ Ter várias mulheres é contra a lei da natureza, a que também os infiéis estão
adstritos, Logo, não contrairá o infiel verdadeiro matrimônio, senão com a mulher com quem primeiro o
fez. Portanto, desde que se converte ele com todas as suas mulheres, poderá ficar com a que primeiro
recebeu como esposa despedindo todas as demais. Se porém a primeira não quiser converter-se e uma
das outras se converter, tem o mesmo direito de casar com essa, de novo, que tinha de o haver feito
com a primeira. Do que diremos a seguir.

RESPOSTA À QUINTA. ─ Repudiar a esposa é contra a lei da natureza. Por isso não pode nenhum infiel
fazê-lo. Por onde, convertido depois de ter repudiado uma das suas mulheres, e casado com outra,
devemos julgar o seu caso como idêntico ao do que tinha várias mulheres. Pois, esta obrigado a receber
como esposa a que primeiro repudiou, se esta quiser converter-se, e rejeitar a outra.

## Art. 4 — Se um fiel convertido pode repudiar sua esposa infiel, que quer continuar a coabitar com ele, sem ofender ao Criador.
O quarto discute-se assim. ─ Parece que um fiel convertido não pode repudiar sua esposa infiel, que
quer continuar a coabitar com ele, sem ofender ao Criador.

1. Pois, mais forte é o vínculo a unir marido e mulher que o existente entre um escravo e o senhor. Ora,
um escravo nem por ser convertido fica livre do vínculo da escravidão, como lemos no Apóstolo. Logo,
também um marido fiel não pode repudiar a esposa infiel.

2. Demais. ─ Não podemos prejudicar a ninguém contra a sua vontade. Ora, a esposa infiel tinha direito
sobre o corpo do marido infiel. Se, pois a conversão do marido à fé pudesse causar à mulher o dano de
ser repudiada, não poderia o marido converter-se à fé sem o consentimento da esposa; assim como não
pode ordenar-se nem proferir voto de continência, sem o consentimento dela.

3. Demais. ─ Quem cientemente contrair casamento com uma escrava, quer seja livre, quer escravo, não
pode repudiá-la fundado na diversidade de condições. Logo, quando um homem contraiu casamento
com uma infiel, sabendo que o era, parece que, do mesmo modo, não na pode repudiar por causa da
infidelidade.

4. Demais. ─ O pai tem o dever de velar pela salvação dos seus filhos. Ora, separando-se de uma esposa
infiel, os filhos comuns ficariam com a mãe, porque esta tem o direito ao fruto do seu ventre; e assim
correr-lhes-ia risco a salvação. Logo, não pode o esposo licitamente repudiar a esposa infiel.

5. Demais. ─ Um adúltero não pode repudiar a esposa adúltera, mesmo que tivesse ele feito penitência
pelo seu pecado. Logo, se devemos julgar do adúltero como do infiel, também não poderá um infiel
repudiar a esposa infiel, mesmo depois de convertido à fé.
Mas, em contrário, o ensinamento do Apóstolo.

2. Demais. ─ O adultério espiritual é mais grave que o carnal, por causa do adultério carnal o marido
pode abandonar a esposa e não mais coabitar com ela. Logo, e com maior razão, por causa da
infidelidade, que é o adultério espiritual.

SOLUÇÃO. ─ Os deveres e os direitos nossos variam conforme o gênero de vida que levamos. E assim,
quem renuncia ao seu antigo gênero de vida não mais está obrigado ao que na vigência dela estava. Por
isso, quem, enquanto vivia no século, fez um voto, não mais está obrigado a cumpri-lo quando,
professando a vida religiosa, morreu para o mundo. Ora, quem recebe o batismo fica regenerado em
Cristo e morto à vida anterior, pois a geração de um implica a corrupção de outro. E assim, fica liberado
da obrigação pela qual estava adstrito a cumprir o dever conjugal para com a esposa; e não está
obrigado a coabitar com ela, desde que não queira ela converter- se. Embora haja um caso em que fica
livre de continuar a conviver, como dissemos. Assim como também um religioso pode cumprir
livremente os votos que fez no século, desde que não lhe colidam com a religião, embora não esteja
obrigado a fazê-lo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A condição de escravo em nada repugna à perfeição da
religião cristã, que supõe uma grande humildade. Ao contrário, o estado de casado, ou do matrimônio,
de algum modo contraria à perfeição da vida cristã, na qual vivem os continentes. Logo, não há símile
em um e outro caso. ─ Além disso, um cônjuge não está obrigado para com o outro como sua
propriedade, ao passo que o escravo é propriedade do senhor; mas como formando entre si uma
espécie de sociedade, que não pode convenientemente existir entre infiel e fiel, segundo a doutrina do
Apóstolo. Logo, não há símile entre o escravo e a esposa.

RESPOSTA À SEGUNDA. ─ A mulher não tem direito sobre o corpo do marido, senão enquanto
permanece ele na comunidade de vida que com ela contraiu; pois, se morrer seu marido fica solta da lei
do marido, na frase do Apóstolo. Por onde, depois do marido ter mudado de vida, porque morreu para a
vida anterior, se dela se separar nenhum dano lhe causa. Mas, quando passa a viver em religião, morre
só de morte espiritual e não corporal. Por onde, consumado o matrimônio, não pode entrar em religião
sem o consentimento da mulher. Pode-o porém antes de havê-lo consumado, enquanto a união é
puramente espiritual. Ora, quem recebeu o batismo, ficou também sepultado com Cristo para morrer.
Portanto, fica absolvido do dever conjugal, mesmo depois de o matrimônio consumado. Ou devemos
responder, que por sua culpa a mulher sofre o dano, por não querer converter-se.

RESPOSTA À TERCEIRA. ─ A disparidade de culto torna uma pessoa totalmente inábil a contrair
casamento; não porém a condição de escravo, senão só quando ignorada. Logo, não se pode dizer o
mesmo da infiel e da escrava.

RESPOSTA À QUARTA. ─ Os filhos ou já chegaram à idade de discreção e então podem seguir livremente
do pai fiel ou à mãe infiel; ou são ainda menores, no momento da separação dos pais, e então devem
ser entregues ao pai cristão, embora precisem ainda da cooperação materna para sua educação.

RESPOSTA À QUINTA. ─ Um adúltero penitente não abraça por isso um gênero de vida diferente, ao
contrário do que se dá com um infiel, que foi batizado. Logo, não há semelhança de razão.

## Art. 5 — Se um fiel, depois de repudiada a esposa infiel, pode casar com outra mulher.
O quinto discute-se assim. ─ Parece que um fiel, depois de repudiada a esposa infiel, não pode casar
com outra mulher.

1. Pois, a indissolubilidade é da essência do matrimônio, porque o repúdio da esposa é contra a lei da
natureza. Ora, dois infiéis podem contrair verdadeiro matrimônio, portanto absolutamente indissolúvel.
Por conseguinte, enquanto subsistir o vínculo do matrimônio com uma esposa, não poderá haver
casamento com outra. Logo, o fiel, que repudiou a esposa infiel, não pode casar com outra.

2. Demais. ─ Um crime sobreveniente ao matrimônio não no pode anular. Logo, a mulher, consentindo
em coabitar com o marido, sem ofensa do Criador, não fica dissolvido o vínculo matrimonial, porque
não pode ele casar com outra. Logo, o pecado da esposa, que não quer coabitar com o marido, sem
ofender o Criador, não dissolve o matrimônio, de modo que fique o marido livre de casar com outra.

3. Demais. ─ O vínculo do matrimônio liga igualmente, tanto o marido como a mulher. Logo, desde que a
uma esposa infiel não é lícito, durante a vida do marido, casar com outro homem, também não o é ao
marido cristão.

4. Demais. ─ O direito concede maiores favores ao voto de castidade que ao contrato de matrimônio.
Ora, segundo parece, ao marido cristão de uma esposa infiel não é lícito fazer voto de continência;
porque do contrário, se depois viesse a converter-se, a esposa teria frustrados os seus direitos
conjugais. Logo e com maior razão, não é lícito ao marido tomar outra mulher.

5. Demais. ─ O filho que permanece infiel, depois da conversão do pai, perde o direito à herança
paterna; contudo, se depois se converter, restitui-se-lhe a herança, mesmo que outro tenha entrado na
posse dela. Logo, por semelhança, parece que se uma esposa infiel vier a converter-se, deve-se-lhe
restituir o marido, mesmo que este já tenha contraído casamento com outra. O que não poderia dar-se
se o segundo matrimônio fosse válido. Logo, não pode contrair matrimônio com outra.
Mas, em contrário. ─ O matrimônio não pode ser ratificado sem o sacramento do batismo. Ora, o que
não foi ratificado pode ser dissolvido. Logo, o matrimônio contraído durante a infidelidade pode ser
dissolvido. E assim, dissolvido o vínculo matrimonial, é lícito ao marido tomar outra mulher.

2. Demais. ─ O marido não pode coabitar com a esposa infiel, que não quer fazê-lo sem ofensa do
Criador. Se, pois, não lhe fosse lícito a ele casar com outra, ficará obrigado a guardar continência. O que
parece inadmissível, porque então só dano lhe resultaria da conversão.

SOLUÇÃO. ─ Quando um dos cônjuges se converte à fé e o outro permanece infiel, devemos distinguir.
Assim, se o infiel quiser coabitar, sem ofensa do Criador, isto é, sem o induzir à infidelidade, o fiel pode
separar-se livremente, mas, fazendo-o, não pode casar com outro. Se porém o cônjuge infiel não quiser
coabitar, sem ofensa do Criador, prorrompendo em palavras de blasfêmia e não querendo ouvir o nome
de Cristo, então, se pretender arrastá-lo; à infidelidade, o marido fiel, separando-se, pode unir-se a
outra pelo matrimônio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O matrimônio dos infiéis é imperfeito, do contrário da
dos fieis que sendo perfeito é, por isso, mais estável. Ora, sempre o vínculo mais estável dissolve o
menos estável, se este o contrariar. Por onde, o segundo matrimônio, contraído na fé de Cristo, dissolve
o primeiro, contraído durante a infidelidade. Portanto, o matrimônio dos infiéis de nenhum modo é
estável e ratificado, mas ratificado fica depois, pela fé de Cristo.

RESPOSTA À SEGUNDA. ─ O pecado da esposa, que não quer coabitar com o marido, sem ofensa do
Criador, absolve-o da obrigação de permanecer unido, com ela, de modo que não pudesse, durante a
vida dela, casar com outra. Mas ainda não anula o casamento, porque se ela se arrependesse da sua
blasfêmia, antes de o marido convolar a segundas núpcias, o marido lhe seria restituído. Fica porém
anulado pelo casamento subsequente, que o marido fiel não poderia contrair, senão livre da obrigação
de conviver com a esposa, em razão de culpa dela.

RESPOSTA À TERCEIRA. ─ Depois de o cônjuge fiel ter contraído novo matrimônio, para ambas as partes
fica este dissolvido; porque o casamento não pode ligar apenas uma delas. Mas pode o seu efeito ser
unilateral, por isso, mais como pena, do que em virtude do matrimônio precedente, fica a esposa infiel
proibida de convolar a novas núpcias. Mas, convertida depois, pode-se-lhe conceder a dispensa para de
novo casar, desde que seu marido também casou com outra.

RESPOSTA À QUARTA. ─ Se depois da conversão do marido, houver provável esperança de se a esposa
converter, não deve o marido fazer voto de continência nem convolar a novas núpcias; porque mais
dificilmente se converteria a mulher, sabendo-se privada do marido. Se porém não der esperanças de
conversão, pode o marido entrar nas ordens sagradas ou em religião, depois de instado com a esposa a
que se converte. E então, se depois de haver o marido recebido tais ordens, a esposa se converter, não
deve ser restituída ao marido, mas se lhe deve imputar da sua tardia conversão o ficar privada do
esposo.

RESPOSTA À QUINTA. ─ O vínculo da paternidade não desaparece pela disparidade de culto, como o
vínculo do matrimônio. Logo, não há símile entre uma herança e uma esposa.

## Art. 6 — Se outros vícios rompem, como a infidelidade, o matrimônio.
O sexto discute-se assim. ─ Parece que outros vícios rompem, como a infidelidade, o matrimônio.

1. Pois, o adultério é mais diretamente contra o matrimônio, que a infidelidade. Ora, a infidelidade
dissolve em algum caso o matrimônio, de modo que seja possível contrair novo. Logo, o adultério
produz o mesmo efeito.

2. Demais. ─ Assim como a infidelidade é a fornicação espiritual, assim também qualquer pecado o é. Se,
pois, a infidelidade rompe o matrimônio por ser ela uma fornicação espiritual, pela mesma razão
qualquer pecado deve dissolvê-lo.

3. Demais. ─ A Escritura diz: Se a tua mão direita te serve de escândalo, corta-a e lança-a fora de ti. Ao
que diz a Glosa, que, por essas expressões ─ mão e olho direito ─ podem designar os irmãos, as esposas,
os parentes próximos e os filhos. Ora, todo pecado nos constitui um impedimento. Logo, por qualquer
pecado pode o matrimônio ser voto.

4. Demais. ─ A avareza é uma idolatria, como diz o Apóstolo. Ora, por idolatria pode uma mulher ser
repudiada. Logo, por igual razão, por causa de avareza. E assim, também por outros pecados mais
graves que a avareza.

5. Demais. ─ É essa também a opinião expressa do Mestre das Sentenças.
Mas, em contrário, o Evangelho: Todo o que repudiar a sua mulher, a não ser por causa de fornicação, a
faz adúltera.

2. Demais. ─ Se tal fosse verdade, todos os dias haveria divórcios, pois, é raro um matrimônio onde o
outro cônjuge não cometa pecado.

SOLUÇÃO. ─ A fornicação corporal e a infidelidade tem uma contrariedade especial aos bens do
matrimônio como do sobredito se colhe. Por onde, produzem o efeito especial de separar os cônjuges.
Devemos porém compreender que de dois modos pode o sacramento ser dissolvido. ─ Primeiro, quanto
ao vínculo. E então, não pode, depois de ratificado ficar dissolvido, nem pela infidelidade, nem pelo
adultério. Mas, não sendo ratificado, fica roto o vínculo quando um dos cônjuges persiste na
infidelidade, convertendo-se o outro à fé e convolando a segundas núpcias. Mas o referido vínculo não
se dissolve pelo adultério; do contrário um infiel poderia a seu bel prazer repudiar a esposa adúltera e
depois casar com outra ─ o que é falso. ─ De outro modo, o matrimônio pode ser dissolvido, quanto ao
seu ato. E assim pode ser voto tanto pela infidelidade como pela fornicação. Mas não o pode, por outros
pecados, mesmo quanto ao seu ato; salvo se o marido quiser temporariamente separar-se da
convivência com a esposa, privando-a do benefício na sua presença, para castigá-la.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora o adultério se oponha mais diretamente ao
matrimônio, enquanto função da natureza, que a infidelidade, contudo o contrário se dá, enquanto
sacramento da Igreja, donde tira a sua perfeita estabilidade por significar a indivisível união entre Cristo
e a Igreja. Por onde, o vínculo do matrimônio não ratificado pode ser dissolvido mais pela infidelidade
do que pelo adultério.

RESPOSTA À SEGUNDA. ─ A primeira união da alma com Deus é pela fé. E assim, por ela, a alma é como
unida com Deus, conforme aquilo da Escritura. E me desposarei contigo na fé. Por isso a Sagrada
Escritura especialmente designa pela fornicação a idolatria e a infidelidade. Ao passo que os outros
pecados se chamam fornicações espirituais, numa significação mais remota.

RESPOSTA À TERCEIRA. ─ Devemos assim entendê-lo quando a mulher é para o marido uma ocasião
muito próxima de pecado, a ponto de este temer seriamente riscos à sua salvação. Pois, então poderá
deixar de conviver com ela, como dissemos.

RESPOSTA À QUARTA. ─ A avareza se chama idolatria por uma certa semelhança de escravidão; pois,
tanto o avarento como o idólatra servem antes à criatura, que ao Criador. Mas não por semelhança de
infidelidade, porque a corrupção da infidelidade está no intelecto, ao passo que a da avareza, no afeto.

RESPOSTA À QUINTA. - As palavras do Mestre se entendem dos esponsais; pois, um crime
sobreveniente pode rompê-los. Ou, se referidas ao matrimônio, entendem-se da separação temporária
da vida em comum, como se disse. Ou quando a mulher não quer coabitar senão com a condição de
pecar e quando diz: não serei tua esposa se não me deres riquezas furtadas por ti. Pois, nesse caso,deve
antes repudiá-la, que exercer o latrocínio.