# Questão 73: Dos sinais que precederão ao juízo.
Em seguida, devemos tratar dos sinais que precederão ao juízo.
E nesta questão discutem-se três artigos:

## Art. 1 — Se o advento do Senhor, como juiz, será precedido de alguns sinais.
O primeiro discute-se assim. ─ Parece que o advento do Senhor, como juiz, não será precedido de
nenhuns sinais.

1. ─ Pois, diz o Apóstolo: Porque quando disserem paz e segurança, então lhes sobrevirá uma morte
repentina. Ora, não haveria paz nem segurança se os homens fossem aterrorizados por sinais
precursores. Logo, nenhuns sinais precederão esse advento.

2. Demais. ─ Os sinais servem para manifestar alguma cousa. Ora, o advento do Senhor deve ser oculto,
conforme aquilo do Apóstolo: Assim como costuma vir um ladrão de noite, assim virá o dia do Senhor.
Logo, nenhuns sinais devem preceder-lhe a vinda.

3. Demais. ─ O tempo da primeira vinda do Senhor foi previsto pelos profetas; o que não se dá com o
segundo. Ora, o primeiro advento de Cristo não foi precedido por nenhuma espécie de sinal. Logo, nem
o segundo o será.
Mas, em contrário, o Evangelho: Haverá sinais no sol, na lua e nas estrelas, etc.

2. Demais. ─ Jerônimo diz, que o juízo será precedido dos quinze sinais seguintes. No primeiro dia os
mares subirão quinze côvados acima das montanhas. ─ No segundo, todos os mares recuarão em
profundeza, a ponto de mal se poderem ver. ─ No terceiro, voltarão ao estado primitivo. ─ No quarto,
todos os monstros e mais seres marinhos reunidos levantarão a cabeça fora da água, mugindo como se
lutassem uns com os outros. ─ No quinto, todas as aves do céu se ajuntarão nos campos, soltarão gritos
lamentosos, recusando de todo comer e beber. ─ No sexto, rios de fogo se arrojarão contra a face do
firmamento, desde o ocidente até o oriente. ─ No sétimo, todas as estrelas, errantes e fixas, projetarão
em seu derredor cabeleiras de fogo como os cometas. ─ No oitavo, haverá grandes terremotos, que
lançarão por terra todos os seres vivos. ─ No nono, todas as plantas gotejarão sangue. ─ No décimo,
todas as pedras, grandes e pequenas, se dividirão em quatro partes, chocando-se umas com as outras. ─
No undécimo, todas as colinas, montes e edifícios serão reduzidos a pó. ─ No duodécimo, todos os
animais das florestas e dos montes virão para os campos rugindo e rejeitando toda alimentação. ─ No
décimo terceiro, todos os sepulcros, do oriente até ao ocidente, se abrirão para deixar ressurgirem os
cadáveres. ─ No décimo quarto, todos os homens sairão de suas casas, vagueando às tontas sem nada
compreenderem e sem falarem. ─ No décimo quinto, todos morrerão e ressurgirão com os mortos de há
já muito tempo.

SOLUÇÃO. ─ Cristo aparecerá para julgar os homens, revestido de glória, em virtude da autoridade
própria de juiz. Ora, a dignidade do poder judiciário deve ser precedida de certos sinais que despertem
reverência e sujeição. Por isso, o advento de Cristo, como juiz, será precedido de muitos sinais, que
advertirão os homens a terem os corações dispostos a submeter-se à sentença do juiz prestes a chegar e
a se prepararem para o juízo. Quais sejam porém esses sinais não é fácil sabermos. Pois, como ensina
Agostinho, os sinais dados pelos Evangelhos não se referem só ao advento de Cristo, para julgar, mas
também ao tempo da destruição de Jerusalém e ao advento com que Cristo continuamente visita a sua
Igreja. De modo que, se o advertirmos com diligência, talvez nenhum desses sinais diga respeito ao
advento final futuro. Porque os sinais referidos pelos Evangelhos, como as guerras, os terrores e outros,
existiram desde o princípio do gênero humano. Salvo se se disser que nos últimos tempos serão mais
graves; é porém incerta à medida em que aumentarão para serem anunciadores do advento próximo.
Quanto aos sinais dados por Jerônimo, não os refere afirmativamente como seus, mas diz que os
encontrou escritos nos anais dos Hebreus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Segundo Agostinho, no fim do mundo haverá perseguição
universal dos maus contra os bons. Estes ficarão mirrados de temor, ao passo que aqueles estarão
seguros. Quanto ao lugar citado ─ Quando disserem: paz e segurança, etc. ─ refere-se aos maus, que
desprezarão os sinais precursores do juízo. Mas aos bons se refere o outro lugar do Evangelho:
Mirrando-se os homens de susto, etc. Ou podemos responder que todos esses sinais precursores do
juízo se realizarão durante os dias do juízo que, assim, os conterão a todos. Por onde, embora os bons
fiquem mirrados de susto, quando virem os sinais precursores do juízo, antes contudo de se eles
manifestarem os ímpios se acreditarão em paz e segurança, depois da morte do Anticristo e antes do
advento de Cristo; por não verem, como julgavam, a subversão imediata do mundo.

RESPOSTA À SEGUNDA. ─ A Escritura diz, que o dia do Senhor virá como um ladrão, por lhe ignorarmos
o tempo determinado, que não podemos conhecer pelos sinais precursores. Embora também no dia do
juízo possamos compreender todos aqueles sinais manifestíssimos, imediatamente precedentes ao
juízo, como dissemos.

RESPOSTA À TERCEIRA. ─ No seu primeiro advento Cristo veio ocultamente, embora o tempo
determinado da sua vinda já o tivessem conhecido os profetas. Por isso não tinha a primeira vinda de
Cristo necessidade de ser anunciada pelos referidos sinais, que se realizarão na sua segunda vinda, que
será manifesta, embora oculto o seu tempo determinado.

## Art. 2 — Se no tempo do juízo o sol e a lua realmente se escurecerão.
O segundo discute-se assim. ─ Parece que no tempo do juízo o sol e a lua. realmente se escurecerão.

1. ─ Pois diz Rábão: Nada nos impede pensar, que nesse tempo o sol, a lua e os demais astros ficarão
verdadeiramente privados da sua luz, como sabemos que se deu com o sol no tempo da paixão do
Senhor.

2. Demais. ─ A luz dos corpos celestes se ordena à geração dos corpos inferiores; pois, como explica
Averróes, por meio dela, e não só pelo movimento, é que influem nos corpos terrestres. Ora, no tempo
do juízo cessará a geração. Logo, os corpos celestes ficarão privados da sua luz.

3. Demais. ─ Os corpos inferiores serão privados; como certos pensam, das qualidades pelas quais agem.
Ora, os corpos celestes agem não só pelo movimento, mas também pela luz, como se disse. Logo, assim
como o movimento do céu cessará, assim também a luz dos corpos celestes.
Mas, em contrário, segundo os astrólogos, sol e lua não podem se eclipsar simultaneamente. Ora, a
Escritura diz que, na vinda do Senhor, esses dois astros se eclipsarão simultaneamente. Logo, esse
obscurecimento não será real, como no caso de um eclipse natural.

2. Demais. ─ O aumento e a diminuição de um ser não podem ter a mesma causa. Ora, na vinda do
Senhor, a luz dos astros a Escritura a promete aumentada, quando diz: A luz da lua será como a luz do
sol, e a luz do sol será sete vezes maior. Logo, não há inconveniente em que a luz desses corpos se
escureça, quando vier o Senhor.

SOLUÇÃO. ─ Se nos referimos ao momento mesmo da vinda de Cristo, não é crível que o sol e a lua se
escurecerão, privados da sua luz. Porque quando Cristo vier e os mortos ressurgirem, todo o mundo
será renovado, como dissemos. Mas nos tempos próximos do juízo, bem poderá ser que o sol, a lua e os
demais astros do céu fiquem privados da sua luz, quer em momentos diversos, quer simultaneamente,
por assim o determinar o poder divino, a fim de a terrorizar os homens.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Rábão se refere aos tempos precedentes ao juízo.

RESPOSTA À SEGUNDA. ─ Os corpos celestes tem luz, não só para causarem a geração nos seres
inferiores terrestres, mas também para perfeição e esplendor deles. Por onde, longe de se lhes apagar,
por ter cessado a geração no nosso mundo, a luz dos corpos celestes aumentará.
A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Rábão se refere aos tempos precedentes ao Juízo.

RESPOSTA À TERCEIRA. ─ Não parece provável que os elementos percam as suas qualidades
elementares, embora certos autores tinham assim pensado. Se contudo as perdessem não se daria com
elas o mesmo que com a luz. Porque as qualidades elementares são contrárias umas às outras e por isso
tem um efeito destrutivo; ao passo que a luz é um princípio ativo, não por via de contrariedade, mas
como regulador dos contrários, reduzindo-os à unidade. ─ Nem há símil com o movimento dos corpos
celestes. Pois, o movimento é o ato do imperfeito. Por isso deve desaparecer, desde que desapareça a
imperfeição. O que não se pode dizer da luz.

## Art. 3 — Se as virtudes dos céus se comoverão, quando vier o Senhor.
O terceiro discute-se assim. ─ Parece que as virtudes dos céus não se comoverão quando vier o
Senhor.

1. ─ Pois, virtudes do céu não podem chamar-se senão os anjos bem aventurados. Ora, a beatitude é por
essência imutável. Logo, não podem mudar.

2. Demais. ─ A causa da admiração é a ignorância, como diz Aristóteles, Ora, como os anjos não tem
nenhum temor, não sofrem também nenhuma ignorância; pois, como pergunta Gregório - que não
verão os que vêem tudo? Logo, não poderão sofrer a mudança causada pela admiração, como diz o
Mestre.

3. Demais. ─ Todos os anjos assistirão ao juízo divino; donde o dizer a Escritura ─ Todos os anjos estarão
em pé ao derredor do trono. Ora, Virtudes designam uma ordem especial de anjos. Logo, não se deveria
dizer mais desses anjos, que dos outros, que se comoverão.
Mas, em contrário, a Escritura: As colunas do céu temem-lhe o advento. Ora, não devemos entender por
essas colunas senão as virtudes dos céus. Logo, as virtudes do céus se abalarão.

2. Demais. ─ A Escritura diz: As estrelas cairão do céu e as virtudes dos céus se comoverão.

SOLUÇÃO. ─ A palavra ─ virtudes ─ aplicada aos anjos, é susceptível de duplo sentido como se lê em
Dionísio. Às vezes designa propriamente uma ordem deles, a qual, segundo Dionísio, ocupa a parte
média da hierarquia do meio; segundo Gregório, porém, é o lugar supremo da ínfima hierarquia. Noutro
sentido, e esse geral, designa todos os espíritos celestes. Ora, em ambas essas acepções pode aplicar-se
ao caso vertente. O Mestre toma essa designação no sentido segundo, designativo de todos os anjos.
Diz então que se comoverão atônitos com o novo espetáculo, que oferecerá o mundo. Mas também
podemos, no caso, tomar a palavra ─ Virtudes ─ como nome de uma ordem angélica. E então diremos
que essa ordem se comoverá, antes de tudo, em razão do efeito. Porque a essa ordem segundo
Gregório, competirão os milagres que sobretudo se realizarão no fim do mundo. Ou porque, sendo da
hierarquia média, segundo Dionísio, não terá limitado o seu poder; por isso o seu ministério se exercerá
sobre as causas universais. E assim, o ofício próprio das Virtudes será mover os corpos celestes, causas
dos fenômenos, que se dão na natureza inferior. E o próprio nome o significa, pois, por isso é que se
chamam virtudes dos céus. Porque então se moverão por cessarem o seu efeito, deixando de continuar
a mover os corpos celestes; assim como também os anjos, delegados à guarda dos homens, não mais
terão que exercer esse ofício.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Essa mutação em nada lhes faz variar o estado. Mas se
refere ou aos efeitos que produzem, rapaz de causar mudança sem sofrerem nenhuma alteração; ou ao
novo conhecimento das cousas, que não podiam ter antes, por meio de espécies concriadas. Mas, essa
mudança no seu modo de conhecer não lhes tira a beatitude. Por isso diz Agostinho, que Deus move a
criatura espiritual através do tempo.

RESPOSTA À SEGUNDA. ─ Costumamos admirar o que excede o nosso conhecimento ou a nossa
capacidade. E assim, as virtudes dos céus admirarão o poder divino, antes de obras tais, que não podem
imitar e que lhes ultrapassa a compreensão. Nesse sentido diz S. Inês, que o sol e a lua lhe admiram a
beleza. Por onde, a admiração não implica no anjo nenhuma ignorância, mas apenas mostra que não
têem a compreensão de Deus.

RESPOSTA À TERCEIRA. ─ A solução resulta do que foi dito.