# Questão 49: Dos bens do matrimônio.
Em seguida devemos tratar dos bens do matrimônio.
E nesta questão discutem-se seis artigos:

## Art. 1 — Se certos bens são necessários para justificar o matrimônio.
O primeiro discute-se assim. ─ Parece que não são necessários certos bens para justificar o
matrimônio.

1. Pois, assim como a conservação do indivíduo resultante da função nutritiva é um fim visado pela
natureza, assim a da espécie, resultante do matrimônio. E muito mais o é esta, quanto mais elevado é o
bem da espécie sobre o individual. Ora, a função nutritiva não precisa ser justificada pelos seus bons
efeitos. Logo, nem a do matrimônio.

2. Demais. ─ Segundo o Filósofo, a amizade entre marido e mulher é natural e abrange o bem honesto, o
útil e o deleitável. Ora, o em si mesmo honesto não precisa de nenhuma justificação. Logo, nem o
matrimônio tem necessidade de ser justificado por nenhum bom feito.

3. Demais. ─ O matrimônio foi instituído como remédio e como função natural. Ora, como função
natural não precisa de ser justificado; do contrário também precisava de ser já no paraíso ─ o que é
falso, pois então, era honroso o matrimônio e o leito sem mácula, como diz Agostinho. Do mesmo
modo, nem como remédio, como não o precisam os demais sacramentos, instituídos como remédios do
pecado. Logo, nem o matrimônio precisa de tais justificativas.

4. Demais. ─ Tudo o que podemos honestamente fazer se inspira em alguma virtude. Se, pois, o
matrimônio pode ser virtuoso, de nenhuma outra justificação precisa senão a das virtudes da alma. E
assim não precisa ser justificado por nenhum bem, serão os que justificam os atos virtuosos.
Mas, em contrário, onde há indulgência há necessidade de uma justificativa. Ora, o matrimônio é
justificado por uma indulgência para: com a fraqueza humana, como o diz o Apóstolo. Logo precisa ser
justificado por algum bem.

2. Demais. ─ O concúbito matrimonial e o impuro pertencem à mesma espécie natural. Ora, o concúbito
impuro é de si mesmo desonesto. Logo, para o matrimônio não ser desonesto, são necessários certos
motivos, que o justifiquem e o classifiquem numa categoria moral.

SOLUÇÃO. ─ Nenhum homem prudente deve consentir num mal senão compensado por um bem
igualou melhor. Por onde, a escolha de uma alternativa, que implica um mal necessita a justificativa de
um bem anexo que, por compensação, a torne bem ordenada e honesta, Ora, a conjunção sexual entre
o homem e a mulher implica um certo mal ─ quer seja este a veemência do prazer, que absorve a razão
a ponto de tornar de fato impossível o ato intelectual, como diz o Filósofo; quer também por causa da
tribulação da carne, de que fala o Apóstolo, e que hão de sofrer os casados pela solicitude com os bens
temporais. Por onde, a escolha dessa união não pode ser justificada senão tendo a compensação de
certas vantagens que a tornem virtuosa. E tais são os bons efeitos que o justificam e o tornam legítimo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O prazer, no ato de comer, não é veemente a ponto de,
como no prazer sexual, absorver a razão. Quer por ser instinto sexual, por onde se transmite o pecado
original, degenerado e corrupto, ao passo que a função nutritiva, pela qual ele não se transmite, é
corrupta, mas não degenerada. Quer também por que cada qual sente com mais intensidade em si as
suas necessidades individuais que as da espécie. Por isso para provocar à comida, e obviar à necessidade
individual, basta sentir o desejo de alimentar-se. Mas, para provocar o ato, cujo resultado é a
conservação da espécie, a providência divina lhe acrescentou um prazer, capaz de mover até os brutos,
que não cometeram o pecado original. Logo, o símile não colhe.

RESPOSTA À SEGUNDA. ─ Esses bens justificadores do matrimônio resultam da natureza mesma dele.
Por isso o casamento não precisa de ser justificado por eles como por motivos externos, mas como
sendo a causa da justificação mesma que lhe é natural.

RESPOSTA À TERCEIRA. ─ O matrimônio, pelo fato mesmo de ser uma função natural ou um remédio
contra o pecado, é por natureza um bem útil e honesto; mas essas duas qualidades lhe convém em
virtude dos bens que lhe são inerentes e o tornam uma função natural e um remédio da concupiscência.

RESPOSTA À QUARTA. ─ Um ato virtuoso tem a sua justificativa tanto na virtude, que é o seu princípio
elícito, como nas circunstâncias, seus princípios formais. Ora, os bens do matrimônio estão para ele
como as circunstâncias para os atos virtuosos; donde resulta que o ato conjugal pode ser virtuoso.

## Art. 2 — Se o Mestre das Sentenças determinou com acerto os bens do casamento: a fidelidade, os filhos e o Sacramento.
O segundo discute-se assim. ─ Parece que o Mestre das Sentenças não determinou com acerto os bens
do casamento; a fidelidade, os filhos e o sacramento.

1. Pois, os homens não casam só com o fim de ter filhos e criá-los, mas como um consórcio de toda a
vida, partilhando-lhe os trabalhos como diz Aristóteles. Logo, assim como coloca os filhos entre os bens
do matrimônio, também devia neles incluir a partilha dos trabalhos.

2. Demais. ─ A união entre Cristo e a Igreja, de que o casamento é o símbolo, se perfaz na caridade.
Logo, entre os bens do matrimônio devia incluir, antes, a caridade que a fidelidade.

3. Demais. ─ O matrimônio, assim como proíbe a qualquer dos cônjuges ter relações carnais com outra
pessoa, assim também exige que um pague ao outro o seu débito. Ora, o primeiro dever é imposto pela
fidelidade, no dizer do Mestre. Logo, por causa do pagamento do débito, a justiça devia ser enumerada
entre os bens do matrimônio.

4. Demais. ─ O matrimônio, sendo símbolo da união entre Cristo e a sua Igreja, há de ser indissolúvel e
ter portanto unidade, de modo que seja a união entre um homem e uma mulher. Ora, o sacramento,
computado entre os três bens do casamento, concerne a indissolubilidade. Logo, devia acrescentar um
outro bem, concorrente à unidade.
Mas, em contrário. ─ A enumeração do Mestre parece excessiva. Porque uma só virtude basta a tornar
virtuosa uma só ação. Ora, a fidelidade é uma só virtude. Logo, não devia acrescentar os dois outros
bens para justificar o matrimônio.

2. Demais. ─ O útil e o honesto não tem a mesma razão de ser, pois se dividem um do outro por
contrariedade. Ora, o matrimônio é útil por causa dos filhos que gera. Logo, os filhos não devem ser
contados entre os bens justificativos do matrimônio.

3. Demais. ─ Nada deve ser considerado como propriedade ou condição de si mesmo. Ora, os referidos
bens são aduzidos como umas condições do matrimônio. Logo, sendo o matrimônio um sacramento,
não deve o sacramento ser computado entre os bens do matrimônio.

SOLUÇÃO. ─ O matrimônio é tanto uma função da natureza como um sacramento da Igreja. Ora, como
função da natureza, se ordena para dois fins, como qualquer outro ato de virtude. Desses, um é exigido
do agente, a saber, a intenção posta no fim devido. E então se consideram os filhos como um dos bens
do matrimônio. ─ Outro é o fim a que deve o ato subordinar-se, que deve ser unicamente bom por se
exercer sobre a sua matéria própria. E tal é a fidelidade que adstringe o marido a ter relação com sua
mulher e não com outra. Mas além disso o casamento ainda tem outra bondade como sacramento. E tal
o significa a denominação mesma de sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Por filhos se entende não só a procriação, mas também a
educação deles, para a qual, como para o fim, se ordenam todos os trabalhos partilhados por marido e
mulher, enquanto unidos pelo matrimônio. Pois, os pais naturalmente entesouram para os filhos, na
expressão do Apóstolo. E assim, os filhos são como o fim principal, que inclui o secundário.

RESPOSTA À SEGUNDA. ─ A fidelidade não é tomada aqui como a virtude teologal da fé, mas como
parte da justiça, enquanto significa a realização das coisas ditas, para se ficar fiel às promessas. O
casamento sendo, pois, um contrato, é uma promessa de um determinado homem a se unir com uma
determinada mulher.

RESPOSTA À TERCEIRA. ─ Assim como, pela promessa de casamento, cada um se obriga a não ter
relações com pessoa estranha, assim também a pagar mutuamente o débito. E esta obrigação é até
mais essencial, por ser a consequência do poder que os esposos mutuamente se conferem um sobre o
outro. Por isso esses dois compromissos se incluem na fidelidade. O texto das Sentenças porém
menciona apenas o compromisso menos manifesto.

RESPOSTA À QUARTA. ─ Pela palavra sacramento não devemos entender só a indissolubilidade, mas
também todas as consequências resultantes de significar o casamento a união de Cristo com a sua
Igreja. ─ Ou devemos responder, que a unidade a que a objeção se refere, concerne à fidelidade, como a
indivisão ao sacramento.

RESPOSTA À QUINTA. ─ A fidelidade não é tomada aqui por nenhuma virtude particular, mas por uma
condição da virtude, donde tira ela a sua denominação, considerada como parte da justiça.

RESPOSTA À SEXTA. ─ Assim como o uso moderado de um bem útil assume a natureza de honesto, não
por ser útil, mas pela razão que torna o uso reto, assim também a destinação de uma coisa para um bem
útil pode torná-la boa e virtuosa, em virtude da razão que lhe dá um destino conveniente. E assim o
matrimônio desde que se ordena à procriação de filhos, é um bem ao mesmo passo útil e honesto,
enquanto devidamente ordenado.

RESPOSTA À SÉTIMA. ─ Como ensina o Mestre, sacramento aqui não significa o matrimônio mesmo,
mas a sua indissolubilidade, sinal da mesma realidade que o casamento. ─ Ou devemos responder, que
embora o matrimônio seja um sacramento, uma coisa é ser ele o que é, e outra, ser sacramento; pois
não foi instituído só para ser o sinal de uma coisa sagrada, mas também para ser uma função da
natureza. Por onde, a qualidade de sacramento é uma condição acrescida ao matrimônio em si mesmo
considerado, donde também tira a sua legitimidade. Por isso a sua sacramentalidade para assim
dizermos, se enumera entre os bens que o legitimam. Eis porque pelo terceiro bem do matrimônio ─ o
de ser um sacramento ─ não só se entende a indissolubilidade, mas ainda tudo o que lhe concerne a
significação.

## Art. 3 — Se o sacramento é o mais principal entre os bens do matrimônio.
O terceiro discute-se assim. ─ Parece que o sacramento não é o mais principal entre os bens do
matrimônio.

1. Pois, em tudo o fim é mais importante, como diz Aristóteles. Ora, a procriação é o fim do matrimônio.
Logo, é o fim mais principal dele.

2. Demais. ─ O mais principal para a espécie é a diferença, que a completa, do que o gênero; assim como
a forma também o é mais que a matéria, na constituição de um ser natural. Ora, o sacramento cabe ao
matrimônio em razão do seu gênero; ao passo que a procriação e a fidelidade, em razão da diferença,
enquanto é um determinado sacramento. Logo, esses dois bens são os mais principais no matrimônio,
do que o ser ele um sacramento.

3. Demais. ─ Assim como o matrimônio pode existir sem filhos e sem fidelidade, assim também o pode
sem indissolubilidade. Tal se dá quando um dos cônjuges entra em religião antes de ser o matrimônio
consumado. Logo, também por esta razão o sacramento é o bem mais principal do matrimônio.

4. Demais. ─ O efeito não pode ser mais principal que a sua causa. Ora, o consentimento, que é a causa
do matrimônio, frequentemente se muda. Logo, também o matrimônio pode romper-se. E portanto a
indissolubilidade nem sempre acompanha o matrimônio.

5. Demais. ─ Os sacramentos, que produzem efeito perpétuo, imprimem caráter. Ora, o matrimônio não
imprime caráter. Logo, não é perpetuamente indissolúvel. Portanto, como o matrimônio não deixa de
existir por falta de filhos, assim também pode existir sem o sacramento. Donde a mesma conclusão que
antes.
Mas, em contrário. ─ O que entra na definição de uma coisa é o que ela tem de mais essencial. Ora, a
indivisão, que pertence ao sacramento, entra na definição supra-referida do matrimônio, mas não a
prole nem a fidelidade. Logo, o sacramento é, dentre os outros atributos do matrimônio, o mais
essencial.

2. Demais. - A virtude divina, que obra nos sacramentos, é mais eficaz que a virtude humana. Ora, a
procriação e a fidelidade são bens do matrimônio enquanto função da natureza; mas sacramento,
enquanto instituição divina. Logo, o sacramento é mais principal bem do matrimônio que os outros dois.

SOLUÇÃO. ─ Uma realidade pode ser mais principal que outra de dois modos: ou por mais essencial ou
mais excelente.
Se por mais excelente, então a todos os respeitos o sacramento é mais principal dentre os três bens do
matrimônio. Pois, lhe concerne enquanto sacramento da graça. Ao passo que os outros dois bens lhe
pertencem, enquanto função da natureza. Ora, a perfeição da graça é mais excelente que a da natureza.
Se porém é considerado mais principal o mais essencial, então devemos distinguir, porque a fidelidade e
a prole podem ser consideradas a dupla luz. – Primeiro, em si mesmas. E então implicam o uso do
matrimônio, donde resulta a procriação de filhos e o pacto conjugal. A indissolubilidade, por seu lado,
que implica o sacramento, pertence ao matrimônio em si mesmo considerado; pois do fato mesmo de
os cônjuges, pelo pacto conjugal, conferirem-se mútuo poder, um sobre o outro, e perpetuamente,
resulta que não podem separar-se. Donde vem, que o matrimônio nunca existe sem a indissolubilidade;
ao passo que pode existir sem a fidelidade e sem a prole, pois a existência de uma coisa não depende do
seu uso. E assim, o sacramento é um bem mais essencial ao matrimônio que a fidelidade e a prole. ─
Mas a fidelidade e a prole podem ser vistas à luz dos seus princípios próprios, tomando por prole, a
intenção de procriar, e por fidelidade o dever de a observar; sem o que o matrimônio não pode
subsistir. Pois tudo isso resulta do matrimônio, em virtude do próprio pacto conjugal. E a ponto de, se o
consentimento exprimisse algo de contrário a esses dois bens, que produzem o matrimônio, este
verdadeiramente não existiria. Ora, assim entendendo a fidelidade e a prole, resulta que a prole é o
essencialíssimo no matrimônio; depois vem a fidelidade, e em terceiro lugar, o sacramento. Assim
também ao homem é mais essencial a natureza humana que a graça, embora a graça seja mais
excelente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O fim intencionado é o primeiro existente; mas enquanto
consentido vem em último lugar. O mesmo se dá com a prole entre os bens do matrimônio. Por isso é,
de certo modo necessário, e de certo outro, não.

RESPOSTA À SEGUNDA. ─ O sacramento, mesmo considerado como o terceiro bem do matrimônio,
pertence-lhe como diferença. Pois, chama-se sacramento por exprimir uma realidade sagrada
determinada, que o matrimônio significa.

RESPOSTA À TERCEIRA. ─ As núpcias, segundo Agostinho, são um bem dos mortais. Por isso, na
ressurreição, nem as mulheres terão maridos, nem os maridos mulheres, na expressão do Evangelho.
Por isso, o vínculo do matrimônio não subsiste além do tempo desta vida, em que foi contraído; chama-
se por isso indissolúvel, porque não pode nesta vista ser rompido. Mas pode sê-lo pela morte, quer do
corpo, posterior à conjunção carnal; quer pela morte espiritual tratando-se da união espiritual.

RESPOSTA À QUARTA. ─ O consentimento, que gera o matrimônio, não é materialmente perpétuo, i, é.,
quanto à substância do ato, porque a esse ato cessado pode suceder-lhe o contrário. Contudo,
formalmente falando, é perpétuo, ter por objeto a indissolubilidade do vínculo. Do contrário não geraria
o matrimônio; pois, consentir em casar temporàriamente com uma mulher não gera o matrimônio. E
quando digo formalmente quero significar que o ato se especifica pelo seu objeto. Assim sendo, o
matrimônio haure no consentimento a sua indissolubilidade.

RESPOSTA À QUINTA. ─ Os sacramentos que imprimem caráter conferem o poder de praticar atos
espirituais; mas o matrimônio confere o de praticar atos corporais. Por isso o matrimônio, em razão do
poder que os cônjuges se conferem um sobre o outro, convém com os sacramentos que imprimem
caráter, e daí tira a sua indissolubilidade, como diz o Mestre; mas deles difere, por dar o poder de só
praticar atos corpóreos. Donde vem que não imprime caráter espiritual.

## Art. 4 — Se o ato conjugal pode ser justificado pelos referidos bens, de modo a não ser absolutamente pecado.
O quarto discute-se assim. ─ Parece que o ato conjugal não pode ser justificado pelos referidos bem,
de modo a não ser absolutamente pecado.

1. Pois, quem prefere sofrer a perda de um maior bem, para salvar um menor, peca, porque procede
desordenadamente. Ora, o bem da razão, que sofre detrimento com o ato conjugal, é maior bem que os
três antes referidos. Logo, esses bens referidos não bastam a justificar o concúbito conjugal.

2. Demais, ─ Na ordem moral o bem acrescentado ao mal torna todo o bem mau e não, todo o mal bom;
pois, uma só circunstância má torna o ato mau, ao contrário, uma só circunstância boa não no torna
bom. Ora, o ato conjugal, em si mesmo, é mau, pois se não o fosse não precisaria ser justificado. Logo,
os bens acrescentados ao matrimônio não no podem tornar bom.

3. Demais. ─ Sempre as paixões desregradas causam vícios morais. Ora, os bens do matrimônio não
fazem com que não seja desregrado o prazer do ato conjugal. Logo, não no podem excusar de ser
pecado.

4. Demais. ─ A vergonha só é causada pela turpítude de um ato, segundo Damasceno. Ora, os bens do
matrimônio não tiram ao ato sexual o caráter de vergonha. Logo, não pode ele ser isento de pecado.
Mas, em contrário. ─ O concúbito conjugal não difere da fornicação senão pelos bens do matrimônio. Se
pois, estes não bastassem a escusá-lo, então o matrimônio sempre permaneceria ilícito.

2. Demais. ─ Os bens do matrimônio se comportam, em relação ao ato conjugal, como circunstâncias
próprias conforme se disse. Ora, essas circunstâncias são suficientes a fazer com que um ato não seja
mau. Logo, também os referidos bens podem escusar o matrimônio, de modo que não seja
absolutamente pecado.

SOLUÇÃO. ─ Um ato pode ser escusado de dois modos. ─ Primeiro, em relação a quem praticou de
maneira que lhe não seja imputado como culpa, embora mau; ou, pelo menos, que não lhe o seja, como
tão grande culpa. Assim, dissemos que a ignorância escusa o pecado, total ou parcialmente. ─ Noutro
sentido dissemos que um ato por si mesmo escusado, de modo que não seja mau Ora, neste último
sentido, dissemos que os bens do matrimônio o justificam.
Mas, na ordem moral, desde que um ato não é mau, é bom, pois não há atos indiferentes, como
dissemos no segundo livro. Mas um ato humano pode ser bom a dupla luz. – Primeiro, por ser
virtuosamente bom. E assim um ato é bom pelas causas que o constituem num meio termo. Ora, tal o
resultado, no matrimônio, da fidelidade e da prole, como do sobre dito se colhe ─ De outro modo um
ato é bom pela bondade do sacramento; e então dissemos, não somente que o ato é bom, mas também
que é santo. E essa bondade, pela qual significa a união de Cristo com a Igreja. Donde se conclui
claramente, que os referidos bens bastam suficientemente a justificar o ato conjugal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O ato conjugal não faz o homem perder o bem habitual
da razão, mas só o atual. Nem há mal em um ato, genericamente melhor, sofrer por vezes intercepção,
para dar lugar a um ato menos bom. Isso pode se fazer sem pecado, com no caso de quem deixa
momentaneamente a contemplação para vacar à ação.

RESPOSTA À SEGUNDA. - A objeção procederia se o mal inseparável do concúbito fosse o mal da culpa.
Ora, não é, nas circunstâncias atuais o da culpa, mas só o da pena, consistente na desobediência da
correspondência à razão. Logo, objeção não colhe.

RESPOSTA À TERCEIRA. ─ O excesso da paixão que a torna viciosa, não se funda na intensidade
quantitativa dela, mas sua relação com a razão. Por onde, só então a paixão se reputa desregrada
quando ultrapassa os limites da razão. Ora, o prazer que acompanha o ato conjugal, embora seja
quantitativamente intensíssimo, contudo não excede, antes do seu princípio, os limites prefixos pela
razão, embora, enquanto dura o prazer, a razão não possa fazê-los valer.

RESPOSTA À QUARTA. ─ Essa turpitude inerente ao ato conjugal e que o torna vergonhoso é a turpitude
da pena e não a da culpa; pois, qualquer defeito naturalmente nos causa vergonha.

## Art. 5 — Se o ato conjugal pode ser justificado mesmo sem os bens do matrimônio.
O quinto discute-se assim. ─ Parece que o ato conjugal pode ser justificado mesmo sem os bens do
matrimônio.

1. Pois, quem busca o ato conjugal, apenas levado do instinto, não visa os bens do matrimônio, que
pertencem à graça ou à virtude. Ora, levados à prática desse ato só pelo apetite natural, não
cometemos nenhum pecado. Pois, nada de natural é mau, porque o mal é contrário à natureza e à
ordem, na expressão de Dionísio. Logo, o ato conjugal pode ser justificado mesmo sem os bens do
matrimônio.

2. Demais. ─ Quem pratica o ato conjugal para evitar a fornicação não visa nenhum dos bens do
matrimônio. Ora, segundo parece, esse tal não peca; pois o matrimônio foi concedido à fraqueza
humana, para se evitar a fornicação, como o ensina o Apóstolo. Logo, o ato conjugal pode ser
justificado, mesmo sem os bens do matrimônio.

3. Demais. ─ Quem usa do que é seu como quer, não procede contra a justiça; e assim não peca,
segundo parece. Ora, o matrimônio torna a mulher um bem do seu marido, e ao contrário. Logo, se
usam mutuamente um do outro, levados da concupiscência, parece que não cometem pecado. Donde a
mesma conclusão que antes.

4. Demais. ─ Um ato genericamente bom não se torna mau, senão quando feito com má intenção. Ora,
o ato conjugal, que o marido pratica com sua mulher, é genericamente bom. Logo, não pode ser mau
senão quando praticado com má intenção. Mas pode ser praticado com boa intenção, mesmo não se
tendo em vista nenhum dos bens do matrimônio. p.ex., quando quem o pratica visa conservar a saúde
do corpo ou consegui-la. Logo, parece que esse ato pode justificar-se, mesmo sem se ter em vista os
bens do matrimônio.
Mas, em contrário. ─ Removida a causa, removido fica o efeito. Ora, a causa da legitimidade do ato
conjugal são os bens do matrimônio. Logo, não pode esse ato ser justificado, sem eles.

2. Demais. ─ O ato referido não difere do ato da fornicação, senão pelos bens supra referidos. Ora, o
concúbito fornicário é sempre um mal. ─ Logo, o ato conjugal também será sempre mau, não sendo
justificado pelos referidos bens.

SOLUÇÃO. ─ Assim como os bens do matrimônio, enquanto habituais, tornam-no legítimo e santo,
assim, enquanto atualmente intencionados, tornam legitimo o ato conjugal, no tocante àqueles dois
bem; sempre concernentes a esse ato. Por onde, quando os cônjuges convém na prática da conjunção
carnal, com o fim de terem filhos, o que pertence à fidelidade, ficam totalmente isentos de pecado. O
terceiro bem não concerne porém ao uso do matrimônio, mas à essência dele, como dissemos. Por isso
torna o matrimônio honesto, mas não o seu ato, de modo que este fosse sem pecado; pois os cônjuges
só convêm em lhe dar uma significação espiritual. Por onde, os cônjuges só podem consumar a
conjunção carnal, sem pecado, por duas razões: com o fim de ter filhos e de pagar o débito. Do contrário
sempre é pecado, ao menos venial.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A prole, enquanto bem do sacramento, é mais excelente
que a prole enquanto bem da natureza. Pois, a natureza visa a procriação para se conservar o bem da
espécie; mas o bem do sacramento implica que os filhos serão, além disso, ordenados para o seu fim
último, que é Deus. Por onde, e forçosamente o fim visado pela natureza, que são os filhos, há de
referir-se, atual ou habitualmente, à intenção da procriação, como bem do sacramento. Do contrário se
ficaria no plano da criatura, o que não pode ser sem pecado. Por isso, quem pratica o ato conjugal, só
levado pelo instinto natural, não fica absolutamente isento de pecado, senão ordenando o movimento
da natureza atual ou habitualmente, para o bem ulterior da prole, enquanto bem do sacramento. Nem
daí se segue seja mau o instinto da natureza; mas que é imperfeito, se não se ordena a um bem ulterior
do matrimônio.

RESPOSTA À SEGUNDA. ─ Quem praticar o ato conjugal, com o fim de evitar o outro cônjuge de
fornicar, nenhum pecado comete; pois, é um modo de cumprir o dever, pertencente ao bem da
fidelidade. Praticá-lo porém, para evitar a si próprio cair na fornicação, é fazer uma coisa supérflua e
cometer pecado venial. Nem o matrimônio foi instituído com esse fim senão por indulgência, que supõe
o pecado venial.

RESPOSTA À TERCEIRA. ─ Só uma circunstância boa não basta para tornar um ato bom. Por onde, não
será um uso qualquer do que é nosso que o tornará bom, mas o uso devido, segundo todas as
circunstâncias.

RESPOSTA À QUARTA. ─ Embora a intenção de conservar a saúde não seja má em si mesma, contudo
torna-se má quando pretendemos conservá-la por um meio não ordenado para tal. Assim, o caso de
quem, no sacramento do batismo, só buscasse a saúde do corpo. Ora, o mesmo se dá, no caso vertente,
em relação ao ato matrimonial.

## Art. 6 — Se sempre que o marido tem conjunção com a esposa, não intencionando nenhum dos bens do matrimônio, mas só o prazer, peca mortalmente.
O sexto discute-se assim. ─ Parece que sempre que o marido tem conjunção com a esposa, não
intencionando nenhum dos bens do matrimônio mas só o prazer, peca mortalmente.

1. Pois, diz Jerônimo: Os prazeres que se buscam nos amplexos com mulheres públicas são condenáveis
também, quando procurados na prática do ato conjugal. Ora, nada é condenável senão o pecado mortal.
Logo, buscar o marido a relação conjugal, só por prazer, é sempre pecado mortal.

2. Demais. ─ Consentir no prazer carnal é pecado mortal, como se disse. Ora, quem busca na relação
com a esposa o prazer carnal consente nele. Logo, peca mortalmente.

3. Demais. ─ Quem usa da criatura, sem a referir a Deus, se limita ao gozo dela; o que é pecado mortal.
Ora, quem usa da sua mulher, pelo só prazer, não refere esse uso a Deus. Logo, peca mortalmente.

4. Demais. ─ Ninguém deve ser excomungado, senão por pecado mortal. Ora, quem tiver relação com
sua esposa, só para satisfazer a concupiscência, fica proibido de entrar na Igreja, no dizer do Mestre,
como se tivesse sido excomungado. Logo, todo indivíduo nessas condições peca mortalmente.
Mas, em contrário, tal concúbito, segundo Agostinho, é enumerado entre os pecados quotidianos, pelos
quais se reza o Padre Nosso etc., como diz o Mestre. Ora, esses não são pecados mortais. Logo, etc.

2. Demais. - Quem se alimenta só pelo prazer de comer não peca mortalmente. Logo, pela mesma razão,
quem usa de sua mulher só com o fim de saciar a concupiscência.

SOLUÇÃO. ─ Certos são de opinião, que sempre há pecado mortal quando a razão principal da
conjunção marital é satisfazer a concupiscência. Pecado venial haverá quando o prazer por um motivo
acessório. Quando, enfim, o prazer for totalmente desprezado e causar desagrado, então será o ato por
completo isento de pecado venial. De modo que buscar nesse ato o prazer é pecado mortal; aceitar o
prazer que o acompanha é pecado venial; e desprezá-lo é a perfeição. Mas isto não pode ser. Porque,
segundo o Filósofo, devemos julgar do mesmo modo um prazer e o ato de que ele resulta; pois, de um
bom ato resulta um legítimo prazer, e de uma ação má, um prazer mau. Por onde, o ato do matrimônio,
não sendo em si mesmo mau, também nem sempre será pecado mortal buscar o prazer dele resultante.
E assim, devemos responder, que se se buscar o prazer com desprezo da honorabilidade do matrimônio,
não considerando a esposa como tal, mas apenas como mulher, com a intenção de consumar o ato com
ela, mesmo que não fosse esposa, será pecado mortal. Quem assim procede se chama para isso amante
ardente da esposa, porque esse ardor transborda dos bens do matrimônio. Se porém o prazer for
procurado dentro dos limites do matrimônio, de modo que não se quisesse tê-lo com outra a não ser
com a esposa, então o até é pecado venial.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Um marido buscará na sua esposa o prazer que iria pedir
a uma mulher pública, quando da esposa outra coisa não esperasse senão o que poderia esperar de uma
prostituta.

RESPOSTA À SEGUNDA. ─ Consentir numa relação sexual, que seja pecado mortal, pecado mortal
também será; ora, o prazer do ato conjugal não é dessa natureza.

RESPOSTA À TERCEIRA. ─ Quem não refere a Deus o prazer, no momento mesmo em que o goza, nem
por isso nele coloca o fim último da vontade; do contrário o procuraria indiferentemente em qualquer
parte. Donde pois não se segue, que goze da criatura por ela mesma; mas que dela usa para seu gozo, se
referindo-se a si mesmo a Deus habitualmente, embora não atualmente.

RESPOSTA À QUARTA. ─ Esse modo de falar não significa que o homem merecesse a excomunhão por
causa do seu pecado, mas porque se tornou inepto para a vida espiritual, desde que, por esse ato, se fez
totalmente carne.