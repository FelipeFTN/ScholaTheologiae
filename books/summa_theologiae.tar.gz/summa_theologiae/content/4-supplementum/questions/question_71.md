# Questão 71: Dos sufrágios pelos mortos.
Em seguida devemos tratar dos sufrágios pelos mortos.
E nesta questão discutem-se quatorze artigos:

## Art. 1 — Se os sufrágios feitos por um não podem aproveitar a outro.
O primeiro discute-se assim. ─ Parece que os sufrágios feitos por um não podem aproveitar a outro.

1. ─ Pois, diz o Apóstolo: Aquilo que semear o homem isso também colherá. Ora, se um pudesse colher
fruto dos sufrágios feitos por outro, colheria do que outros semearam. Logo, dos sufrágios feitos por
outros ninguém poderá colher fruto para si.

2. Demais. ─ A justiça de Deus pertence dar a cada um conforme os seus méritos. Donde o dizer a
Escritura: Tu retribuirás a cada um segundo as suas obras. Ora, é impossível a justiça de Deus falhar.
Logo, é impossível aproveitar-se um das obras feitas por outros.

3. Demais. ─ Pela mesma razão é uma obra meritória digna de louvor; i. é, por ser voluntária. Ora, pelas
obras de um não será louvado outro. Logo, nem a obra de um pode ser meritória e frutuosa para outro.

4. Demais. ─ À justiça divina pertence igualmente retribuir o bem pelo bem e o mal pelo mal. Ora,
ninguém é punido pelos maus atos de outrem; antes, como diz a Escritura, a alma que pecar, essa
morrerá. Logo, não pode um aproveitar-se das boas obras de outrem.
Mas, em contrário, a Escritura: Eu sou participante de todos os que te temem, etc.

2. Demais. ─ Todos os fiéis, unidos pela caridade, são membros do corpo único da Igreja. Ora, os
membros mutuamente se ajudam. Logo, pode um aproveitar-se dos méritos de outro.

SOLUÇÃO. ─ Os nossos atos podem ter dupla finalidade: fazer-nos adquirir um estado, como quando
alcançamos o estado da beatitude pelas nossas obras meritórias; segundo, alcançarmos um estado
subsequente, como quando por um ato merecemos um prêmio acidental ou a diminuição da pena. Ora,
ambas essas finalidades um ato pode conseguir de dois modos ─ por via de mérito ou por via de oração.
A diferença entre essas duas vias está em que o mérito se funda na justiça, ao passo que quem ora
impetra o pedido, fundado na só liberalidade daquele a quem ora.
Donde devemos concluir, que as obras de um de nenhum modo podem aproveitar a outro para
conseguir um estado, por via de mérito; p. ex., para, pelos meus atos, merecer outro a vida eterna.
Porque a felicidade da glória é dada segundo a capacidade de quem a recebe; pois, cada qual se dispõe
pelos seus atos e não pelos atos alheios, referindo-me à disposição que torna digno de um prêmio. Mas
por via de oração, mesmo para alcançar um estado, as obras de um podem, durante esta vida,
aproveitar a outrem; assim, quando pedimos para outro a graça inicial. Ora, como a impetração da
oração se funda na liberalidade de Deus, a quem oramos, essa impetração pode abranger tudo o que
ordenadamente depender do poder divino.
Quanto porém ao subsequente ou acessório a um determinado estado, as obras de um podem
aproveitar a outro, não só por via da oração mas também por via do mérito. E isso de dois modos pode
ser. ─ Ou por comunicarem as obras de todos numa raiz comum, que nas obras meritórias é a caridade.
E portanto todos os mutuamente ligados pela caridade tiram proveito recíproco das suas obras mútuas,
contudo, segundo a capacidade do estado de cada um, pois, mesmo na pátria cada qual se regozijará
pelas obras dos outros. É tal o artigo da fé chamado da comunhão dos santos. ─ De outro modo, pela
intenção do autor das obras, pois certas são especialmente feitas para aproveitarem a outro. Por isso
tais obras de certa maneira pertencem àqueles por quem são feitas, quase a eles atribuídas por quem as
fez. Por onde, podem lhes valer para cumprir uma satisfação, ou a causa semelhante que lhes não mude
o estado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A messe aludida é a consecução da vida eterna, como nos
diz o Evangelho: E o que colhe ajunta para a vida eterna. Ora, a felicidade da vida eterna a ninguém é
dada senão pelas suas obras próprias. Porque embora impetrem para que outro alcance a vida eterna,
isso porém não poderá nunca ser feito senão mediante obras próprias dele; i. é, enquanto que, pelas
preces de um a graça é dada a outro: pela qual merecerá a vida eterna.

RESPOSTA À SEGUNDA. ─ As obras feitas em benefício de outrem deste se tornam. Do mesmo modo,
obras de quem constitui comigo uma unidade de certo modo me pertencem. Por onde, não colide com
a justiça divina, se um colhe os frutos de obras feitas por quem lhe está unido na caridade, ou das obras
em seu benefício feitas por outro. Pois isto também a justiça humana o permite, que a satisfação de um
aproveite a outro.

RESPOSTA À TERCEIRA. ─ Louvores a ninguém se dão senão pelo ato que praticou. Por isso o louvor é
relativo a alguma causa, como diz Aristóteles. E como as obras de um não tornam nem mostram
ninguém bem ou mal disposto para alguma causa, daí resulta que ninguém é louvado por obras alheias,
senão acidentalmente, quando for de certo modo a causa dessas obras, por ter dado algum conselho ou
auxílio, induzindo o autor delas a praticá-las ou de qualquer outro modo. Uma obra porém pode ser
meritória para outrem, não só considerada a disposição deste, mas também quanto à alguma
consequência da sua disposição ou do seu estado; como do sobredito se colhe.

RESPOSTA À QUARTA. ─ Privar alguém do que lhe é devido repugna diretamente à justiça. Mas, dar-lhe
o que lhe não é devido, longe de ser contrário à justiça, ultrapassa-lhe os limites e constitui uma
liberalidade. Ora, não podemos sofrer consequências do mal feito por outrem, senão sendo privado do
nosso. Eis porque não pode um ser punido pelo pecado alheio, como pode aproveitar das boas ações de
outrem.

## Art. 2 — Se os defuntos podem ser socorridos pelas obras dos vivos.
O segundo discute-se assim. ─ Parece que os mortos não podem ser socorridos pelas obras dos vivos.

1. - Pois, primeiro, pela razão dada pelo Apóstolo: importa que todos nós compareçamos diante do
tribunal de Cristo, para que cada um receba o galardão segundo o que tem feito, estando no próprio
corpo. Logo, pelo que fizermos depois da morte, quando a nossa alma estiver separada do corpo, mais
obras nenhumas poderão nos aproveitar.

2. Demais. ─ O mesmo resulta de outro lugar da Escritura: Bem-aventurados os mortos que morrem no
Senhor, porque as obras deles os seguem.

3. Demais. ─ Tirar vantagem das obras só é possível aos que vivemos viandantes neste mundo. Ora,
depois da morte, já não são os homens viandantes, pois deles se entende o dito da Escritura: Por todas
as partes fechou o meu caminho e não posso passar. Logo, os mortos não podem ser socorridos pelos
sufrágios de ninguém.

4. Demais. ─ Ninguém pode tirar proveito das obras de outrem, se nenhuma comunicação houver entre
ambos. Ora, nenhuma comunicação há entre os mortos e os vivos, segundo o Filósofo. Logo, os
sufrágios dos vivos não aproveitam aos mortos.
Mas, em contrário, a Escritura: É um santo e saudável pensamento orar pelos mortos, para que sejam,
livres dos seus pecados. Ora, isto não seria útil se não lhes aproveitasse. Logo, os sufrágios dos vivos
aproveitam aos mortos.

2. Demais. ─ Agostinho diz: Não é pequena a autoridade da Igreja, que se manifesta no costume de ter o
seu lugar também o sufrágio pelos mortos, entre as preces que o sacerdote eleva a Deus nos seus
altares. Costume esse que nasceu com os Apóstolos, conforme o ensina Damasceno quando diz:
Instruídos nos divinos mistérios, os discípulos do Salvador e os apóstolos sancionaram o uso de fazer, no
meio do tremendo sacrifício, a comemoração dos fiéis adormecidos no Senhor. O mesmo se lê em
Dionísio, quando relembra o rito da primitiva Igreja, de orar pelos mortos, e onde diz que os sufrágios
dos vivos aproveitam aos mortos. O que, pois, devemos crer sem nenhuma dúvida.

SOLUÇÃO. ─ A caridade, vínculo que une os membros da Igreja, abrange não só os vivos, mas também
os que morrem no amor. Ora, a caridade, que é a vida da alma, como a alma é a vida do corpo, não
acaba; conforme aquilo do Apóstolo: A caridade nunca jamais há de acabar. Semelhantemente, também
os mortos vivem na memória dos vivos; tanto a intenção destes pode tê-los como objeto. Por onde, os
sufrágios dos vivos por duas razões aproveitam aos mortos, como aos próprios vivos: pela união da
caridade e pela intenção a eles aplicada. Não devemos porém crer, que os sufrágios dos vivos lhes
aproveitem por poder fazê-las passar do estado de miséria para o de felicidade ou inversamente. Mas
contribuem para lhes diminuir a pena ou situações tais, que não lhes altere o estado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Nesta vida merecemos que os sufrágios dos fiéis nos
aproveitem, na outra. Por onde, o que na vida futura nos aproveitará será o que tivermos feito quando a
nossa alma estava unida ao corpo. ─ Ou devemos responder, com João Damasceno, no sermão referido,
que o lugar citado deve entender-se da retribuição a ser dada no juízo final, que será a da eterna glória
ou da eterna miséria, quando cada qual receberá só o que pelas obras desta vida mereceu. Mas, até lá,
poderá a alma ser socorrida pelos sufrágios dos vivos.

RESPOSTA À SEGUNDA. ─ A autoridade citada se refere expressamente à sequelas da eterna
retribuição, como se vê das palavras anteriores.
─ Bem aventurados os mortos, etc. ─ Ou devemos responder que as obras pelos defuntos feitas também
de certo modo lhes pertencem, como se disse.

RESPOSTA À TERCEIRA. ─ Embora as almas depois da morte não mais sejam viandantes, contudo e de
certo modo, ainda o são por ainda estarem privadas do galardão eterno. Por isso e absolutamente
falando, o caminho lhes está fechado por todas as partes, a ponto de não mais poderem, seja por que
obras forem, passar de um estado de miséria para o de felicidade; mas não está fechada a ponto de não
poderem, na sua detenção, longe da retribuição final, ser socorridas pelas obras dos vivos, pois, a esta
luz, são ainda viandantes.

RESPOSTA À QUARTA. ─ A comunicação nas obras civis, a que o Filósofo se refere, não pode existir
entre mortos e vivos, porque os mortos estão fora da vida civil. Podem contudo comunicar com os vivos
nas obras da vida espiritual, fundada no amor de Deus, que vivifica as almas dos mortos.

## Art. 3 — Se os sufrágios feitos pelos pecadores aproveitam aos mortos.
O terceiro discute-se assim. ─ Parece que os sufrágios feitos pelos pecadores não aproveitam aos
mortos.

1. ─ Pois, como diz o Evangelho, Deus não escuta aos pecadores. Ora, se as orações deles aproveitassem
àqueles por quem oram, seriam escutados de Deus. Logo, os sufrágios feitos por eles não aproveitam
aos mortos.

2. Demais. ─ Gregório diz: O intercessor que desagrada aumenta as iras de um espírito irritado. Ora,
todo pecador desagrada a Deus. Logo, pelos sufrágios dos pecadores Deus não se dobra à misericórdia.
Portanto, tais sufrágios não aproveitam.

3. Demais. ─ As obras feitas por alguém mais aproveitam ao seu autor que a outrem. Ora, o pecador,
com as suas obras, nada merece para si mesmo. Logo e com maior razão, não podem elas aproveitar a
outrem.

4. Demais. ─ Toda obra meritória há de ser vivificada, i. é, informada pela caridade. Ora, as obras feitas
pelos pecadores são mortas. Logo, não podem os defuntos, por quem forem feitas, tirar delas nenhum
proveito.
Mas, em contrário, ninguém pode saber com certeza se outrem está em pecado ou em graça.
Se portanto, só aproveitassem os sufrágios feitos pelos que estão em graça, não poderíamos saber a
quem pedíssemos sufrágios pelos nossos defuntos. E assim muitos se absteriam de sufragar as almas
dos mortos.

2. Demais. ─ Como diz Agostinho, os mortos são socorridos pelos sufrágios dos vivos, na medida em que,
durante a vida, mereceram sê-lo, depois da morte. Logo, o valor dos sufrágios depende da condição de
aqueles por quem são feitos. Portanto, não importa, segundo parece, por quem sejam feitos ─ por bons
ou por maus.

SOLUÇÃO. ─ Duas cousas podemos considerar nos sufrágios feitos pelos maus.
Primeiro, a obra mesma praticada (opus operatums , como o sacrifício do altar. Ora, os nossos
sacramentos tem uma eficácia própria, independente da qualidade do consagrante, e a realizam sejam
quais forem os ministros. E por aqui os sufrágios feitos pelos maus aproveitam aos mortos. Segundo, a
ação do agente (opus operamtis). E então devemos distinguir. Pois, o ato de um pecador, que faz
sufrágios, pode ser considerado, de um modo, como obra própria dele. Nesse caso, de maneira
nenhuma pode ser meritória, nem para si nem para outrem. De outro modo, enquanto esse ato
pertence a outrem. O que de duas maneiras pode dar-se. ─ Primeiro, quando o pecador, que faz os
sufrágios, representa, como sacerdote, a pessoa da Igreja universal; assim, quando reza na igreja, no
ofício pelos mortos. E como se entende que quem age, em lugar de outrem, no nome deste o faz e o
representa, conforme está claro em Dionísio, daí resulta que os sufrágios de um tal sacerdote, embora
pecador, aproveitam aos defuntos. ─ Segundo, quando o agente procede como instrumento de outrem;
ora, a obra do instrumento pertence, antes, ao agente principal. Por onde, embora quem age como
instrumento de outrem, possa não estar em condições de merecer, a sua ação pode contudo ser
meritória em razão do agente principal. Assim, se um escravo em estado de pecado praticasse obras de
misericórdia por ordem de seu senhor, que tem a caridade. Portanto, quem, morrendo em estado de
caridade, mandasse que se lhe fizessem sufrágios, esses lhe aproveitariam embora aqueles que os
façam estejam em pecado. Mais valeriam porém se tivessem caridade, porque então essas obras seriam
meritórias dos dois lados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ As orações feitas pelos pecadores podem não lhes
pertencer a eles, mas a outros. E então é digna de ser escutada por Deus. ─ Contudo, também às vezes
Deus ouve os pecadores: quando pedem o que é do seu agrado. Pois, Deus dá os seus bens, não só aos
justos, mas também aos pecadores, como lemos no Evangelho; não porém por mérito deles, mas pela
sua clemência. Por isso, ao lugar citado do Apóstolo ─ Deus não escuta aos pecadores ─ diz a Glosa, que
ele ai fala como ungido e não como gozando da visão
plena.

RESPOSTA À SEGUNDA. ─ Embora a oração do pecador não seja ouvida, por vir de um intercessor que
desagrada, contudo Deus pode aceitá-la em razão de outrem, de quem o pecador faz às vezes ou em
nome de quem pede.

RESPOSTA À TERCEIRA. ─ O fato de o pecador não tirar nenhuma vantagem, fazendo tais sufrágios,
resulta de não ser capaz desse proveito, por causa de uma indisposição sua. Mas isso não impede possa
deles valer-se, de algum modo, estando em boa disposição para tal, como dissemos.

RESPOSTA À QUARTA. ─ Embora a obra do pecador, como tal, não seja viva, pode sê-lo porém enquanto
pertencente a outrem, como dissemos. Mas como as objeções em sentido contrário concluem que não
importa quem faz os sufrágios ─ se um bom ou um mau ─ por isso também devemos lhes responder a
elas.
Por onde, RESPOSTA À QUINTA. ─ Embora ninguém possa com certeza saber se outrem está ou não na
graça de Deus, podemos porém julgá-lo com probabilidade pelos atos externos. Pois, a árvore se
conhece pelos seus frutos, como diz o Evangelho.

RESPOSTA À SEXTA. ─ Para os sufrágios aproveitarem a alguém é necessário a capacidade para se valer
deles, pela parte de aqueles por quem são feitos; e esta a alma a adquiriu pelas obras que durante esta
vida praticou. E é nesse sentido que escreve Agostinho. Mas nem por isso deixa de ser necessária a
qualidade da obra, que deve aproveitar. O que porém não depende daquele por quem é feita, mas
antes de quem o faz, quer executando a ordem alheia, quer mandando.

## Art. 4 — Se os sufrágios feitos pelos vivos aos mortos aproveitam a quem os faz.
O quarto discute-se assim. ─ Parece que os sufrágios feitos pelos vivos aos mortos não aproveitam a
quem os faz.

1. ─ Pois, quem pagasse a dívida de outrem não ficaria liberado, segundo a justiça humana, da sua dívida
própria. Portanto, o fato de alguém, fazendo sufrágios, satisfazer pelo débito alheio, não o libera do seu
débito próprio.

2. Demais. ─ Todos devemos fazer os nossos atos de melhor modo possível. Ora, é melhor socorrer a
dois que a um só. Se, portanto, quem sufraga os mortos fica liberado do seu débito próprio, pelos livrar
dos deles, parece que nunca deveríamos satisfazer por nós, mas sempre por outrem.

3. Demais. ─ Se uma satisfação aproveitasse igualmente por outrem, por quem é dada, e ao próprio
autor dela, por igual razão valeria também para um terceiro por quem também fosse feita; e igualmente
a um quarto e assim por diante. Logo, por uma só satisfação poderia um satisfazer por todos. O que é
absurdo.
Mas, em contrário, a Escritura: A minha oração dava voltas no meu seio. Logo e pela mesma razão, os
sufrágios feitos por outrem aproveitam-lhe.

2. Demais. ─ Damasceno diz: Como quem quer ungir um enfermo, com um unguento ou um óleo santo,
primeiro participa ele próprio da unção para depois ungir o doente, assim também quem ora pela
salvação do próximo é útil primeiro a si mesmo e depois ao próximo. E assim fica provado o que
afirmamos.

SOLUÇÃO. ─ Os sufrágios feitos por outrem podem ser considerados a dupla luz. ─ Primeiro, como
expiatívos da pena a modo de recompensa implicada na satisfação. E então os sufrágios, considerados
como de quem os faz, absolve do débito da pena aquele por quem foram feitos, sem absolverem ela
pena própria o autor deles. Porque nessa compensação leva-se em conta a igualdade da justiça. Ora,
uma obra justa satisfatória pode adequar-se a um reato, sem se adequar a outro. Mas, os reatos de dois
pecados exigem maior satisfação que o reato de um só. ─ A outra luz, podem os sufrágios ser
considerados enquanto meritórios para a vida eterna, e isso eles o são enquanto radicados na caridade.
E então aproveitam não só aquele por quem são feitos, mas sobretudo a quem os fez.

DONDE A RESPOSTA ÀS OBJEÇÕES. ─ Pois, as primeiras se fundam na obra dos sufrágios enquanto
satisfatória; e as outras enquanto obra meritória.

## Art. 5 — Se os sufrágios aproveitam aos que estão no inferno.
O quinto discute-se assim. ─ Parece que os sufrágios aproveitam aos que estão no inferno.

1. - Pois, diz a Escritura: Eles acharam debaixo das túnicas dos mortos na batalha algumas das oferendas
consagradas aos ídolos, que a lei proíbe aos Judeus. E pouco depois acrescenta: Judas, tendo ajuntado
uma coleta, mandou doze mil dracmas de prata a Jerusalém para serem oferecidas em sacrifício pelos
pecados dos mortos. Ora, sabemos que pecaram aqueles mortalmente, procedendo contra a lei; que,
além disso, morreram em pecado mortal e, portanto, caíram no inferno. Logo, aos que estão no inferno
os sufrágios aproveitam.

2. Demais. ─ O Mestre cita as seguintes palavras de Agostinho: Aqueles a quem aproveitam os sufrágios,
ou é para a remissão plena dos pecados ou para se lhes tornar mais suportável a condenação. Ora,
condenados são só os do inferno. Logo, também a eles aproveitam os sufrágios.

3. Demais. ─- Dionísio diz: Se as orações dos justos aproveitam já nesta vida. quanto mais depois da
morte não aliviarão as almas merecedoras desse socorro? Donde se pode concluir que os sufrágios mais
aproveitam aos mortos que aos vivos. Ora, aos vivos lhes aproveitam mesmo em estado de pecado
mortal; pois todos os dias a Igreja ora para os pecadores se converterem a Deus. Logo, também aos
mortos em pecado mortal os sufrágios aproveitam.

4. Demais. ─ Nas Vidas dos Padres do deserto se lê e também o refere Damasceno, que Macário, tendo
encontrado num caminho o crânio de um defunto, procurou saber, depois de feita oração, de quem
fosse essa cabeça. E essa respondeu que fora de um sacerdote gentio condenado ao inferno, que
contudo confessou ter-lhe aproveitado a oração de Macário, a si e a outros. Logo, os sufrágios da Igreja
aproveitam mesmo aos que estão no inferno.

5. Demais. - No mesmo sermão Damasceno narra que Gregório, estando a orar por Trajano, ouviu uma
voz do céu que lhe anunciava: Ouvi a tua voz e concedo o perdão a Trajano. E disso, conforme o afirma
Damasceno, testemunha é todo o oriente e o ocidente. Ora, sabemos que estava no inferno Trajano,
causador da morte cruel de muitos mártires, como refere no mesmo lugar Damasceno. Logo, os
sufrágios da Igreja valem mesmo aos que estão no inferno.
Mas, em contrário, Dionísio: O Sumo Sacerdote não ora pelos impuros, porque, se o fizesse encontraria
a ordem divina. E o comentador diz, no mesmo lugar, que o Sumo Sacerdote não pede o perdão dos
pecadores condenados, porque sua oração não lhes aproveitaria. Logo, os sufrágios não valem aos que
estão no inferno.

2. Demais. ─ Gregório diz: A mesma causa pela qual não se orará; então, i. é, depois do dia de juízo,
pelos condenados ao fogo eterno é a pela qual não rezamos agora pelo diabo e pelos seus anjos
condenados ao eterno suplício. E ainda pela mesma causa não oram os santos, nesta vida, pelos infiéis e
ímpios defuntos; por temerem não seja vão o mérito das suas orações, aos olhos do Justo Juiz, por
aqueles que de certo já sabem condenados ao eterno suplício.

3. Demais. ─ O Mestre cita as seguintes palavras de Agostinho: Os mortos sem a fé ativa pelo amor e
sem os sacramentos, a esse é em vão que a piedade filial os recomenda à misericórdia divina. Ora, tais
são todos os condenados. Logo, os sufrágios não lhes aproveitam.

SOLUÇÃO. ─ Há três opiniões sobre a situação dos condenados ao inferno.
Uns dizem que, nesta matéria, devemos fazer uma dupla distinção. ─ Primeiro quanto ao tempo. E então
opinam, que depois do dia de juízo, a nenhum dos condenados do inferno aproveitará qualquer
sufrágio; a certos porém, antes desse dia, aproveitam os sufrágios da Igreja. ─ Segundo, quanto aos
detidos no inferno. Dentre os quais uns, dizem, são a tal ponto maus que morreram sem fé e sem
sacramento. E a esses os sufrágios da Igreja não aproveitam, pois não lhes pertenceram nem ao mérito
nem ao número. Outros, porém, não são tão maus, pois fizeram parte da Igreja, tiveram fé, receberam
os sacramentos e praticaram certas boas obras. E a esses os sufrágios da Igreja devem aproveitar.
Mas uma dúvida ocorre, que não deixava de os perturbar, consequência da opinião que professavam. E
é que, sendo finita a intensidade das penas do inferno, embora de duração infinita, a multiplicação dos
sufrágios haveria de eliminá-las de todo ─ erro de Orígenes.
E assim lançaram mão de muitos recursos para obviarem a essa inconsequência. Prepositivo, um deles,
dizia que os sufrágios pelos condenados podem a ponto multiplicar-se, que fiquem de todo liberados da
pena; não porém absolutamente falando, como ensinou Orígenes, mas só por um tempo, a saber, até o
dia do juízo. E então as almas de novo unidas ao corpo, seriam precipitadas, sem esperança de perdão
nas penas do inferno. ─ Mas esta opinião repugna à providência divina, que nada deixa desordenado.
Ora, nenhuma culpa pode ser expiada, senão pela pena. Portanto, nenhuma pena pode ser perdoada
antes de expiada a culpa. Ora, como a culpa dos condenados permanece inexpíada, de nenhum modo se
lhes poderá ser relevada a pena.
Por isso os discípulos de Porretano recorreram a outro expediente, ensinando que os sufrágios fazem
diminuir a pena do mesmo modo por que a divisão faz diminuírem as linhas. Ora, estas, sendo finitas,
contudo podem ser divididas ao infinito sem nunca se consumirem com a divisão, porque a subtração
que se lhes faz não é sempre da mesma quantidade, mas de uma quantidade proporcional. Assim, se
primeiro se subtraísse a quarta parte do todo; depois a quarta parte dessa quarta parte; e ainda a
quarta desta quarta, e assim por diante ao infinito. Do mesmo modo, ensinam, o primeiro sufrágio
diminui uma parte alíquota da pena; o segundo diminui, da parte restante, uma outra, na mesma
proporção. ─ Mas esta explicação é muito defeituosa. ─ Primeiro, porque a divisão infinita, de que é
quantidade contínua é susceptível, não pode ser aplicada a uma quantidade espiritual. ─ Segundo, por
não haver nenhuma razão por que o segundo sufrágio diminua menos a pena que o primeiro, desde que
tem o mesmo valor. ─ Terceiro, porque uma pena não pode sofrer diminuição sem diminuir a culpa;
nem ser eliminada, sem a eliminação desta. ─ Quarto, porque a divisão de uma linha chegara enfim a
panes imperceptíveis, porque um corpo sensível mio é susceptível de divisão infinita. Donde resultaria
que, depois de muitos sufrágios, a pena remanescente já não seria, pela sua insignificância, sentida; e
assim, deixaria de ser pena.
Por isso outros recorreram a outra explicação. Assim, o autor autossiodorense ensina, que os sufrágios
aproveitam aos condenados, não para lhes minorar as penas nem para as interromper; mas para
confortar o paciente. Tal um homem, que carregasse um pesado fardo e a quem se lhe refrescassem as
faces com água, ficaria confortado para melhor carregá-lo, embora a sua carga não se lhe tornasse com
isso mais leve. ─ Mas ainda, tal explicação é inadmissível. Porque um condenado é mais ou menos,
atormentado pelo fogo, como diz Gregório, conforme lh'o merece a culpa. Donde, pelo mesmo fogo uns
são mais cruciados e outros, menos. Por isso, desde que a culpa dos condenados permaneça sempre a
mesma, não podem vir a sofrer pena mais leve. ─ Além disso essa opinião é pretensiosa como contrária
à doutrina dos Santos Padres; vã, sem nenhuma autoridade que a sustente; e enfim irracional. Primeiro,
porque os condenados ao inferno não os abrange o vínculo da caridade, pela qual as obras dos vivos se
aplicam aos mortos. Segundo, porque os condenados já chegaram ao termo derradeiro da vida e
receberam a última retribuição merecida, como receberam a sua os santos na pátria. Quanto ao que
lhes resta de pena ou de glória para o corpo, não o coloca isso na condição de viandantes; porque tanto
a glória dos eleitos como a miséria dos condenados está essencial e radicalmente na alma. Portanto, não
é susceptível de diminuição nem a pena destes, nem a glória dos santos, quanto ao prêmio essencial.
O modo porém, pelo qual, segundo certos ensinam, os sufrágios podem aproveitar aos condenados,
poderia sustentar-se no sentido seguinte. Que não aproveitam nem para diminuir a pena ou
interrompê-la, nem para lhe minorar a pena do sentido. Mas, por esses sufrágios, de certa maneira se
lhes abrandam os sofrimentos em que ficariam inversos, vendo-se a tal ponto desprezados, que
ninguém se ocuparia com a sua sorte. ─ Mas esse alívio também não no poderiam ter, pela lei comum.
Porque, diz Agostinho, e é sobretudo verdade dos condenados: As almas dos defuntos não sabem, no
seu tenebroso cárcere, de nada do que entre os homens se faz ou se passa. Portanto, não sabem
quando se celebram sufrágios por eles, salvo se, como exceção à lei geral, essa consolação Deus a
conceder a certos deles. O que é opinião absolutamente incerta.
Por onde, mais seguro é concluir simplesmente, que os sufrágios não aproveitam aos condenados, nem
a Igreja tem a intenção de orar por eles, como se colhe das autoridades citadas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Com esses mortos não foram encontradas cousas, que
pudessem ser consagradas aos ídolos, donde se pudesse concluir que consigo as trouxessem em sinal de
reverência para com eles. Mas as tomaram como despojos devidos, por direito de guerra, a vencedores.
Contudo, por avareza pecaram venialmente. Por isso não foram condenados ao inferno. Portanto, os
sufrágios lhes podiam aproveitar. ─ Ou podemos responder, segundo certos, que, vendo-se na batalha
em perigo iminente de morte, arrependeram-se dos seus pecados, segundo aquilo da Escritura: Quando
os fazia morrer os buscavam. O que se pode admitir como provável. Por isso se fez por intenção deles a
oblação.

RESPOSTA À SEGUNDA. ─ Nessas palavras, a condenação é tomada em sentido lato, por qualquer
punição. E assim inclui também as penas do purgatório, que, ora são totalmente expiadas pelos
sufrágios, ora não, mas apenas minoradas.

RESPOSTA À TERCEIRA. ─ De certo modo, os sufrágios são mais aplicáveis aos mortos que aos vivos,
porque aqueles mais necessitam deles, por não poderem, como os vivos, se ajudar a si próprios. Mas, de
outro modo, a condição do vivo é melhor porque pode passar do estado de culpa mortal para o de graça
─ o que dos mortos não se pode dizer. Por onde, não é a mesma a condição dos vivos e a dos mortos,
quanto ao aproveitamento dos sufrágios.

RESPOSTA À QUARTA. ─ As orações de Macário não tiveram como efeito diminuir a pena dos
condenados, mas somente, conforme no mesmo lugar se diz, conceder-lhes o meio de se verem
mutuamente. E com isso tinham uma alegria verdadeira e não imaginária, sendo realizado o que
desejavam. No mesmo sentido em que dizemos que os demônios se alegram quando fazem o homem
cair em pecados, embora isso em nada lhes diminua as penas; assim como nenhuma diminuição sofre a
felicidade dos anjos pelo fato de dizermos que tem compaixão de nós pelos nossos males.

RESPOSTA À QUINTA. ─ Quanto ao fato de Trajano, podemos interpretá-lo com probabilidade do modo
seguinte. Chamado de novo à vida pelas preces de S. Gregório, conseguiu a graça da remissão dos
pecados e, por consequência, a liberação das penas. O que também se deu com todos os
milagrosamente ressuscitados dentre os mortos, dos quais sabemos de muitos, que tinham sido
idólatras e estavam condenados. De todos esses devemos, por semelhança, pensar, que não estavam
condenados ao inferno, por uma sentença definitiva; mas por uma sentença fundada na justiça que lhes
remunerasse os méritos próprios, nesta vida. E que razões superiores exigiam fossem de novo
chamados à ela, fazendo assim exceção à lei comum. ─ Ou devemos concluir, com certos, que a alma de
Trajano não foi, absolutamente falando, absolvida do reato da pena eterna, sendo a sua pena somente
suspensa temporàriamente, até o dia do juízo. Mas dai não se pode concluir que os sufrágios alcancem
sempre esse resultado. Pois, uma cousa são as exigências da lei comum, e outra as concessões
privilegiadas a certos em particular; assim como uns são os limites das causas humanas e outros os
sinais do poder divino, conforme Agostinho.

## Art. 6 — Se os sufrágios aproveitam aos que estão no purgatório.
O sexto discute-se assim. ─ Parece que os sufrágios não aproveitam aos que estão no purgatório.

1. ─ Pois, o purgatório é uma parte do inferno. Ora, no inferno não há nenhuma redenção. E a Escritura
diz: No inferno quem te louvará? Logo, os sufrágios não aproveitam aos do purgatório.

2. Demais. ─ A pena do purgatório é finita. Ora, se os sufrágios fazem-na diminuir, podem multiplicar-se
a ponto de a eliminarem totalmente; e assim os pecados ficarão de todo impunes. O que repugna à
justiça divina.

3. Demais. ─ As almas estão no purgatório para, depois de purificadas, chegarem puras ao Reino. Ora,
nada pode ser purificado sem sofrer uma ação. Logo, os sufrágios feitos pelos vivos não diminuem a
pena do purgatório.

4. Demais. ─ Se os sufrágios aproveitassem às almas do purgatório, mais lhes aproveitariam as que por
ordem delas se fizeram. Ora, essas nem sempre lhes aproveitam. Tal o caso de quem, ao morrer,
ordenasse que tantos sufrágios em seu beneficio se fizessem, que lhe bastassem a eliminar totalmente a
pena. Portanto, se esses sufrágios fossem diferidos até a alma ter cumprido totalmente a sua pena, de
nada lhes aproveitariam eles. Nem se poderia dizer que lhe aproveitariam antes de celebrados. Por
outro lado, depois de celebrados, deles não precisava, por ter já cumprido a sua pena. Logo, os sufrágios
não aproveitam às almas da purgatório.
Mas, em contrário, as palavras de Agostinho citadas pelo Mestre, que dizem aproveitarem os sufrágios
às almas mediocremente boas ou más. Ora, tais são as detidas no purgatório. Logo, etc.

2. Demais. ─ Dionísio diz: Quando o sacerdote de Deus ora pelos mortos, ora pelos que viveram santa
mente, e contudo contraíram certas máculas provenientes da fraqueza humana. Ora, esses são os
detidos no purgatório. Logo, etc.

SOLUÇÃO. ─ As penas do purgatório são infligidas como um suplemento de satisfação ainda não
plenamente dada pelo corpo. Por onde, como do sobre dito resulta, as obras de um podem aproveitar à
satisfação de outro, seja este vivo ou morto. E assim nenhuma dúvida há que os sufrágios feitos pelos
vivos aproveitem às almas do purgatório.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O lugar citado se refere ao inferno dos condenados, onde
não há nenhuma redenção, quanta aos definitivamente sentenciados às penas infernais. ─ Ou devemos
pensar, com Damasceno que essas autoridades devem ser entendidas relativamente às causas
inferiores, i. é, segunda as exigências dos méritos dos sentenciados a essas penas. Mas, a misericórdia
divina, que não depende dos méritos humanos, movida pelas preces dos justos, pode dispor as causas
de modo diverso que o ensinado pelas referidas autoridades. Pois, Deus pode mudar de sentença, mas
não de conselho, como diz Gregório. Por isso Damasceno também aduz em abono do que diz, os
exemplos dos Ninivitas, de Acab e de Ezequias, que bem demonstram que a sentença divina proferida
contra eles a divina misericórdia a alterou.

RESPOSTA À SEGUNDA. ─ Nenhum inconveniente há em a pena das almas do purgatório ficar eliminada
pela multiplicação dos sufrágios. Donde porém se não segue fiquem os pecados impunes; pois, a pena,
que um assume por outro, redunda em favor deste.

RESPOSTA À TERCEIRA. ─ A purificação da alma pelas penas do purgatório outra cousa não é senão a
expiação do reato, que impede a alma de gozar a glória. E como a pena, que um sofre por outro, pode
expiar o reato deste, conforme dissemos, nenhum inconveniente há se a satisfação de um purifica
outro.

RESPOSTA À QUARTA. ─ Os sufrágios podem aproveitar por duas causas: pelo valor do agente (ex opere
operante) ou pelo valor da obra (ex opere operato). Por opus operatum entendo não só os sacramentos
da Igreja, mas qualquer efeito acidental das boas obras; assim quem dá uma esmola alivia a miséria do
pobre e obtém as orações dele a Deus, pelos defuntos. Semelhantemente, o opus operans pode ser
considerado em relação ao agente principal ou ao exequente. ─ Digo pois, que um moribundo, logo ao
ordenar sejam certos sufrágios feitos por si, lhes colhe plenamente o prêmio, mesmo antes de
celebrados, quanto à eficácia deles, resultante da obra praticada (ex opere operante) pelo agente
principal. Mas quanto à eficácia do sufrágio, em virtude do valor mesmo deles (ex opere operato) ou da
obra do agente instrumental (ex opere operante exequentis) não colhe os frutos dos sufrágios antes de
celebrados. Se pois acontecer que a alma fique liberada antes da pena, ficará por aí frustrado o fruto
dos sufrágios, mas redundará em pena daqueles que foram a causa de isso se dar. Nenhuma
contradição há, na verdade, em ficar um, na ordem temporal, defraudado por culpa de outro. Ora, a
pena do purgatório é temporal. Embora, quanto à retribuição eterna, ninguém pode ser prejudicado
senão por culpa própria.

## Art. 7 — Se os sufrágios aproveitam às crianças que estão limbo.
O sétimo discute-se assim. ─ Parece que os sufrágios aproveitam às crianças do limbo.

1. ─ Pois, no limbo só estão pelo pecado alheio. Logo, é da máxima conveniência sejam socorridos pelos
sufrágios alheios.

2. Demais. ─ O Mestre cita as palavras seguintes de Agostinho: Os sufrágios da Igreja são propiciatórios
pelos que não tem grande malícia. Ora, as crianças não são computadas entre os de grande malícia;
pois, brandíssima é a pena delas. Logo, os sufrágios da Igreja lhes aproveitam.
Mas, em contrário, ainda segundo Agostinho, citado pelo Mestre, os sufrágios não aproveitam aqueles
que saíram desta vida sem a fé operante pelo amor. Ora, assim desta vida partiram as crianças. Logo, os
sufrágios não lhes aproveitam.

SOLUÇÃO. ─ As crianças não-batizadas não ficam detidas no limbo senão por não estarem em estado de
graça. Por onde, como as obras dos vivos não podem mudar o estado dos mortos, sobretudo quanto ao
mérito essencial do prêmio ou da pena, os sufrágios dos vivos não podem aproveitar às crianças que
estão no limbo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora o pecado original seja de natureza, que as obras
de um podem fazer com que outro fique livre dele, contudo as almas das crianças no limbo estão em
estado tal, que não podem socorrer-se dos sufrágios; porque depois desta vida não é mais o tempo de
se conseguir a graça.

RESPOSTA À SEGUNDA. ─ Agostinho se refere aos que não são demasiado maus, mas que são batizados.
Isso é claro pelas suas palavras anteriores: Quando se oferece o sacrifício do altar ou o de quaisquer
esmolas por todos os fiéis batizados, etc.

## Art. 8 — Se os sufrágios de algum modo aproveitam aos santos que estão na pátria.
O oitavo discute-se assim. ─ Parece que os sufrágios de algum modo aproveitam aos santos que estão
na pátria.

1. ─ Pois, reza a coleta de uma missa: Assim como os sacramentos aproveitam aos teus santos na glória,
assim também servem de nos curar. Ora, entre os outros sufrágios o principal é o sacramento do Altar.
Logo, os sufrágios aproveitam aos santos que estão na pátria.

2. Demais. ─ Os sacramentos realizam o que figuram. Ora, a terceira parte da hóstia, a colocada no
cálice, significa os que vivem na pátria a vida bem-aventurada. Logo, os sufrágios da Igreja aproveitam
aos que estão na pátria.

3. Demais. ─ Os santos na pátria se comprazem não só nos próprios bens, mas também nos alheios.
Donde o dizer o Evangelho: Haverá júbilo entre os anjos de Deus por um pecador que faz penitência.
Logo, as boas obras dos vivos farão aumentar a felicidade dos santos do céu; e assim, também os nossos
sufrágios lhes aproveitarão.

4. Demais. ─ Damasceno escreve, citando palavras de Crisóstomo: Se, pois os pagãos ─ diz ─ queimam
com os mortos os objetos que lhe pertenceram, quanto mais não deves tu, fiel, deixar partir os fiéis com
as cousas que lhes pertenceram. Não reduzindo-as a cinzas, como fazem os pagãos, mas para que lhes
aumentes a glória. E se pecador foi o que morreu, para o livrares dos seus pecados; se, ao contrário,
justo, para lhes aumentares a recompensa e a retribuição. Donde a mesma conclusão que antes.
Mas, em contrário, as palavras de Agostinho citadas pelo Mestre: É injuriar a Igreja orar por um mártir;
do contrário, devemos nós nos recomendar às suas orações.

2. Demais. ─ Deve ser socorrido quem tem necessidade. Ora, os santos na pátria não sofrem nenhuma
necessidade. Logo, não precisam ser socorridos pelas preces da Igreja.

SOLUÇÃO. ─ Os sufrágios, por natureza, requerem um socorro, Ora, deste não precisa quem não sofre
nenhuma necessidade; pois, só precisa de socorro quem padece indigência. Por onde, como os santos
na pátria estão livres de qualquer necessidade, embriagados na abundância da casa do Senhor, na frase
da Escritura, nenhum socorro lhes pode advir dos sufrágios.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Essas expressões não devem entender-se como
significando que os santos na glória tirem algum proveito de lhes celebrarmos nós a festa. Antes, a nós é
que nos aproveita celebrarmos com solenidade a glória deles. Do mesmo modo que, conhecendo ou
louvando a Deus, de certo modo aumentamos-lhe a glória, em nós, e isso nos aproveita a nós e não a
ele.

RESPOSTA À SEGUNDA. ─ Embora os sacramentos realizem o que figuram, contudo não produzem esse
efeito em relação a tudo o que figuram. Aliás, figurando a Cristo, como figuram, produziriam algum
efeito em Cristo ─ o que é absurdo. Produzem porém o seu efeito em quem os recebe, em virtude do
que significam. Donde pois não se segue que os sacrifícios oferecidos pelos fiéis defuntos aproveitem
aos santos; mas que, pelos méritos deles, celebrados ou significados no sacramento, aproveitam
aqueles por quem são oferecidos.

RESPOSTA À TERCEIRA. ─ Embora os santos no céu se regozijem com os nossos bens, daí porém não
resulta que a multiplicação das nossas felicidades aumente também formalmente a deles: senão só
materialmente. Porque toda paixão aumenta formalmente conforme a natureza do seu objeto. Ora, a
razão de todos os regozijos que possam ter os santos é Deus, de quem não podem gozar mais ou menos,
porque então lhes variaria o prêmio essencial, consistente em terem de Deus a sua felicidade. Por onde,
a multiplicação dos bens, cujo gozo tem em Deus a sua razão de ser, não leva à consequência que os
santos gozem mais intensamente, senão só que gozam de um maior número de bens. Donde, pois, não
se segue que possam ser socorridos pelas nossas obras.

RESPOSTA À QUARTA. ─ Dessas palavras não devemos concluir que os sufrágios dos fiéis aumentem a
recompensa ou a retribuição dos santos, em honra dos quais são celebrados, mas que aproveitam a
quem os faz. ─ Ou devemos pensar que os sufrágios podem aumentar a recompensa do fiel defunto,
quando este ainda em vida ordenou os que lhe devessem ser feitos; o que lhe foi meritório.

## Art. 9 — Se as almas dos mortos podem ser socorridas só, ou sobretudo, pelas orações da Igreja, pelo sacrifício do altar e pelas esmolas.
O nono discute-se assim. ─ Parece que não só, nem sobretudo, as almas dos mortos podem ser
socorridas pelas orações da Igreja, pelo sacrifício do altar e pelas esmolas.

1. ─ Pois, uma pena deve ser compensada por outra. Ora, o jejum é maior pena que a esmola ou a
oração. Logo, mais aproveita o jejum, como sufrágio, que qualquer das obras referidas.

2. Demais. ─ Gregório enumera o jejum entre os outros sufrágios, quando diz: As almas dos mortos
podem ser livradas pelos quatro modos seguintes ─ as oblações dos sacerdotes; a esmola dos amigos, as
preces dos santos e o jejum dos parentes. Logo, a tríplice enumeração referida, de Agostinho, é
insuficiente.

3. Demais. ─ O batismo é o principalíssimo dos sacramentos, sobretudo pelo seu efeito. Logo, o batismo
ou os outros sacramentos deveriam, ser celebrados pelos defuntos, como o sacramento do Altar, ou
mesmo de preferência.

4. Demais. ─ Isto se conclui das palavras do Evangelho: Que farão os que se batizam pelos mortos se
absolutamente os mortos não ressurgem? Logo, também o batismo vale como sufrágio pelos defuntos.

5. Demais. ─ O sacrifício do Altar é o mesmo em qualquer missa. Se, pois, o sacrifício é o enumerado
entre os sufrágios e não a missa, parece que tem o mesmo valor qualquer missa dita por um defunto,
quer a da Santa Virgem, quer a do Espírito Santo, quer outra qualquer. O que vai contra a disposição da
Igreja, que instituiu uma missa especial pelos defuntos.

6. Demais. ─ Damasceno diz que se oferecem pelos defuntos cera, óleo e cousas semelhantes. Logo, não
só na oblação do sacrifício do Altar mas também as demais oblações devem ser contadas entre os
sufrágios pelos mortos.

SOLUÇÃO. ─ Os sufrágios dos vivos aproveitam aos mortos, primeiro, por estarem estes unidos pela
caridade, e, segundo, por serem os mortos o objeto da intenção dos vivos. Por onde, são por excelência
próprias a sufragar os mortos aquelas obras que supõem a comunicação da caridade ou a direção da
intenção para terceiros. ─ Ora, a Eucaristia é por excelência o sacramento da caridade, pois, o
sacramento da união eclesiástica; porque contém Cristo princípio da união e da consolidação da Igreja
universal. Por isso a Eucaristia é como a origem ou o vínculo da caridade. Ora, entre os efeitos desta o
mais principal é a obra da esmola. Por isso, quanto à caridade, servem sobretudo para sufragar os
mortos as duas obras seguintes: o sufrágio da Igreja e a esmola. Quanto à intenção aplicada aos mortos,
vale sobretudo a oração; porque esta, por natureza, não só respeita a quem ora, como as demais obras,
mas e mais diretamente àquele por quem é feita. ─ Por isso, essas três obras se consideram como os
principais socorros que os vivos podem prestar aos mortos; embora quaisquer outras boas obras feitas
com caridade pelos defuntos, devemos crer que lhes aproveitem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Em quem satisfaz por outro devemos considerar ─ para
que o efeito da satisfação a este aproveite ─ antes, o meio pelo qual ela se aplica de um para outro, que
a pena mesma da satisfação. Embora a pena em si mesma sirva mais de expiar o reato do satisfaciente,
como remédio que é. Por isso as três obras referidas aproveitam aos defuntos, mais que o jejum.

RESPOSTA À SEGUNDA. ─ Também o Jejum pode aproveitar aos defuntos em razão da caridade, e da
intenção a eles aplicada. Mas o jejum nada contém, por natureza, que diga respeito à caridade ou à
direção da intenção, cousas que lhe concernem apenas extrinsecamente. Por isso Agostinho não
enumerou, ao contrário de Gregório, o jejum entre os sufrágios dos mortos.

RESPOSTA À TERCEIRA. ─ O batismo é uma regeneração espiritual. Por onde, assim como pela geração
só adquire a existência o ser gerado, assim o batismo não produz a sua eficácia senão no batizado,
enquanto obra de valor próprio (ex opere operato). Embora enquanto obra feita por um determinado
agente (ex opere operantes) , quer este seja o batizante, quer o batizado, possa aproveitar a outrem,
como o podem as demais obras meritórias. Quanto à Eucaristia, é um sinal da união eclesiástica. Por
isso, considerada como obra de valor próprio (ex ipso opere operato) , a sua eficácia pode aproveitar a
outrem. O que não se dá com os outros sacramentos.

RESPOSTA À QUARTA. ─ A Glosa expõe a autoridade citada em dois sentidos. Um sentido é o seguinte:
Se os mortos não ressurgem nem ressurgiu Cristo, que farão os que batizam pelos mortos, i. é, pelos
pecados; pois que estes não são perdoados se Cristo não ressurgiu. Porque no batismo opera não só a
paixão mas também a ressurreição de Cristo, causa, de certo modo, da nossa ressurreição espiritual. ─
Outro sentido: Houve certos que, por ignorância, se faziam batizar por aqueles que partiram desta vida
sem batismo, pensando que isso lhes aproveitasse. E, de conformidade com este sentido, as palavras
citadas do Apóstolo se referem ao erro desses tais.

RESPOSTA À QUINTA. ─ O ofício da missa não é só um sacrifício mas também encerra orações; e satisfaz
assim as duas condições exigidas por Agostinho. Como sacrifício oferecido, qualquer missa, p. ex. das
referidas, aproveita igualmente aos defuntos, pois, o sacrifício é na missa o principal. Quanto às orações,
as missas onde se rezam orações particulares pelos mortos mais lhes aproveitam. A falta de orações
particulares pode entretanto ser compensada pela maior devoção do celebrante, ou de quem mandou
celebrar, ou ainda pela intercessão do santo cujo sufrágio é implorado na missa.

RESPOSTA À SEXTA. ─ A oblação de candeias, óleo ou cousas semelhantes pode aproveitar ao defunto,
consideradas como esmola; pois, oferecem-se para o culto da igreja ou também para uso dos fiéis.

## Art. 10 — Se também as indulgências concedidas pela Igreja aproveitam aos mortos.
O décimo discute-se assim. ─ Parece que também as indulgências concedidas pela Igreja aproveitam
aos mortos.

1. ─ Pois, é costume da Igreja, quando manda pregar a cruzada, conceder indulgências, que os fiéis
podem ganhar para si mesmos, ou por duas, três e às vezes dez almas, tanto de vivos como de mortos.
Ora, a Igreja enganaria, se tais indulgências não aproveitassem aos mortos. Logo, elas lhes aproveitam.

2. Demais. ─ O mérito da Igreja universal é mais eficaz que o de um particular. Ora, pelo mérito pessoal
podemos sufragar os defuntos; assim, quando damos esmolas. Logo e com muito maior razão, a Igreja o
pode com os seus méritos, em que se as indulgências fundam.

3. Demais. ─ As indulgências aproveitam aos que lhe pertencem à jurisdição da Igreja. Ora, as almas do
purgatório lhe pertencem à jurisdição; do contrário, os seus sufrágios não lhes aproveitariam. Logo,
parece que as indulgências aproveitam aos defuntos.
Mas, em contrário. ─ Para a indulgência aproveitar é preciso uma causa justificativa da sua concessão.
Ora, essa causa não pode estar do lado do morto, que nada pode fazer em utilidade da Igreja, causa
principal da concessão de indulgências. Logo, parece que as indulgências não aproveitam aos defuntos.

2. Demais. ─ As indulgências se determinam ao arbítrio de quem as concede. Se, portanto, pudessem
aproveitar aos defuntos, no poder de quem as concedesse estaria liberá-los totalmente da pena. O que
é absurdo.

SOLUÇÃO. ─ As indulgências podem aproveitar principal ou secundariamente. Principalmente
aproveitam a quem a ganha, i. é, quem pratica o ato por causa do qual ela é dada, p. ex., a visita do
túmulo de um santo. Ora, os mortos, não podendo praticar nenhum desses atos por causa dos quais a
indulgência foi dada, a eles não lhes pode ela diretamente aproveitar. Secundária e indiretamente,
porém, aproveitam aquele por quem satisfazemos as condições delas. ─ O que umas vezes é possível e
outras, não, conforme as diversas formas delas. ─ Assim, sendo a forma da indulgência a seguinte ─
Quem fizer isto ou aquilo terá tanto de indulgência ─ quem o fizer não pode transferir para outro o fruto
da indulgência ganha; porque não tem o poder de aplicar em favor de ninguém a intenção da Igreja, que
é quem comunica os sufrágios comuns, causa de as indulgências valerem. ─ Mas concedida uma
indulgência sob a forma. ─ Quem fizer isto ou aquilo, ganhará, essa própria pessoa, ou o pai ou qualquer
parente detido no purgatório, tanto de indulgência ─ esta aproveitará não só ao vivo, mas também ao
morto. Pois, não há nenhuma razão pela qual a Igreja possa aplicar os seus méritos comuns,
fundamento das indulgências, aos vivos e não no possa aos mortos.
Mas de aqui se não segue possa um prelado da Igreja, ao seu arbítrio, livrar as almas do purgatório. Pois,
para valerem, é necessário tenham as indulgências uma causa justificativa da sua concessão, como
dissemos.

## Art. 11 — Se as exéquias fúnebres aproveitam aos defuntos.
O undécimo discute-se assim. ─ Parece que as exéquias fúnebres aproveitam aos defuntos.
1 ─ Pois, diz Damasceno, citando palavras de Atanásio: Embora as cinzas do defunto, morto na fé cristã,
se tenham dispersado nos ares, não lhe recuses, invocando a Deus, queimar no sepulcro óleo e cera.
Pois, Deus se compraz com essas práticas e as paga com múltiplas retribuições. Ora, essas práticas são
exéquias fúnebres. Logo, estas aproveitam aos defuntos.

2. Demais. ─ Segundo Agostinho, aos justos dos tempos antigos cumpriam-se solenemente os deveres
de piedade fúnebre, celebravam─se─lhes exéquias, cuidava-se-lhes da sepultura; e eles próprios, em
vida, dispunham o modo como devessem ser sepultados e os seus restos transferidos. Ora, tal não
fariam se as exéquias fúnebres e cousas semelhantes em nada aproveitassem aos defuntos. Logo, algo
lhe aproveitam.

3. Demais. ─ Ninguém faz esmola sem tirar disso nenhum proveito. Ora, sepultar os mortos é prática
considerada como esmola. Donde o dizer Agostinho: Como o atestou o anjo, Tobias, sepultando os
mortos, bem mereceu de Deus. Logo, sepultar os mortos é prática que lhes aproveita.

4. Demais. ─ É absurdo afirmar que a devoção dos fiéis ficará frustrada. ─ Ora, muitos manifestam a
verdade de ser enterrados em lugares sagrados. Logo, o culto da sepultura aproveita aos mortos.

5. Demais. ─ Deus é mais inclinado a ter misericórdia que a condenar. Ora, a sepultura em lugar sagrado
é prejudicial aos mortos indignos dela. Por isso diz Gregório: Os culpados de pecados graves, tendo os
seus corpos sepultados numa Igreja, em lugar de serem perdoados desses pecados, sofrem as
consequências de uma condenação mais severa. Logo e com maior razão, devemos concluir, que o culto
da sepultura aproveita aos bons.
Mas, em contrário, Agostinho: Todas as honras fúnebres prestadas ao corpo humano são apenas
deveres de humanidade e em nada aproveitam à vida eterna.

2. Demais. ─ Gregório diz: A prestação de honras fúnebres, escolha da sepultura, pompa das exéquias
servem antes de consolar os vivos que de proveito para os mortos.

3. Demais. - O Senhor diz: Não tem ais aos que matam o corpo e não podem matar a alma. Ora, depois
da morte, o corpo dos santos pode ficar privado de sepultura; assim se passou, como o refere a História
Eclesiástica, com certos mártires de Lião, na Gália. Logo, nenhum dano causa aos mortos o lhes ficarem
os corpos insepultos. Portanto, em nada lhes aproveita também o culto da sepultura.

SOLUÇÃO. ─ A sepultura beneficia tanto os vivos como os mortos. ─ Os vivos, livrando-lhes a vista da
corrupção cadavérica, e a saúde do corpo que poderia ficar prejudicada pelo mau odor exalado pelo
cadáver. Isto quanto ao corpo. ─ Beneficia ainda espiritualmente aos vivos, fortificando-lhes a fé na
ressurreição. ─ Aos mortos, porque a vista do sepulcro desperta nos vivos a memória dos defuntos e os
incita a orar por estes. Por isso a palavra monumento implica a idéia de memória: monumentum, em
latim é como monens mentem, como explica Agostinho. Os pagãos erraram nesta matéria pensando
que da sepultura tirava a alma do morto a vantagem do repouso; pois, estavam crentes que neste não
entrava a alma, antes de ser dado o corpo à sepultura. Crença absolutamente ridícula e absurda.
Quanto à sepultura em lugar sagrado, aproveita ao morto, não certo ex opere operato, mas ex opere
operante. Quando o moribundo, ou outro por ele, dispõe que o seu corpo, depois de morto, seja sepulto
num lugar sagrado, comete-o ao patrocínio de um santo, por cujas preces crê será socorrido; e também
ao patrocínio dos que servem no templo, que mais frequente e especialmente oram pelos que estão
neles sepultos. Quanto aos ornatos colocados na sepultura, são úteis aos vivos, por lhes servir de
consolação. Podem porém servir também aos mortos, não em si mesmos, mas por acidente,
despertando nos vivos a comiseração e levando-os a orar pelos defuntos. Ou ainda porque os gastos
com esses ornatos vão aproveitar aos pobres ou à decoração das igrejas; assim, a sepultura é
considerada como esmola.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O óleo e a cera colocados nos túmulos dos defuntos só
acidentalmente lhes aproveitam. Ou quando oferecidos à igrejas dados aos pobres; ou quando servem
tais práticas para reverenciar a Deus. Por isso às palavras citadas se acrescenta: O óleo e a cera como
holocausto.

RESPOSTA À SEGUNDA. ─ Os santos Patriarcas dispunham como queriam ser sepultados, para mostrar
que Deus vela com a sua providência sobre os corpos dos mortos; não que conservem ainda qualquer
sensibilidade depois da morte, mas para fortificar a fé na ressurreição, como o diz Agostinho. Por isso
quiseram ser sepultados na terra da promissão, onde acreditavam que Cristo havia de nascer e morrer,
cuja ressurreição é a causa da nossa.

RESPOSTA À TERCEIRA. ─ Fazendo a carne naturalmente parte do homem, naturalmente ele a ama,
conforme aquilo do Apóstolo: Ninguém aborreceu jamais à sua própria carne. E assim, esse amor
natural explica a solicitude com que, vivos, cuidamos da sepultura a ser dada ao nosso corpo, e
sofreríamos pressentindo que ele viesse a sofrer qualquer profanação. Por isso, como a amizade é uma
conformidade de afetos, ela nos leva a prestar ao amigo morto os deveres de humanidade para com o
seu cadáver. Por isso, diz Agostinho: Se as roupas, um anel ou cousas semelhantes, de nossos pais
defuntos, tanto mais as queremos quanto mais intenso o afeto que neles depositávamos, com maior
razão não lhes devemos desprezar os corpos; pois, mais familiar e íntima é a nossa união com o corpo
do que com quaisquer vestuários que usemos. Ora, sepultando um cadáver satisfazemos um afeto e
assim cumprimos um dever que não poderia o morto cumprir para consigo próprio; razão por que se
considera o sepultamento como uma esmola.

RESPOSTA À QUARTA. ─ A devoção dos fiéis não fica frustrada, como diz Agostinho, quando dá a
sepultura a um ente querido, em lugar sagrado; pois, assim procedendo comete-o ao sufrágio dos
santos, como se disse.

RESPOSTA À QUINTA. ─ A sepultura de um ímpio em lugar sagrado não lhe causa nenhum dano, senão
por ter buscado, por glória humana, um lugar de que é de todo indigno.

## Art. 12 — Se os sufrágios feitos por um defunto mais lhe aproveitam, que aos outros, por quem não o foram.
O duodécimo discute-se assim. ─ Parece que os sufrágios feitos por um defunto não mais lhe
aproveitam, que aos outros, por quem não o foram.

1. ─ Pois, a luz espiritual mais facilmente se comunica que a material. Ora, a luz material, p. ex., de uma
candeia, embora acesa para alumiar um só, serve contudo para iluminar igualmente todos os habitantes
de um mesmo aposento, embora não fosse acesa para eles. Logo, os sufrágios, que são por assim dizer
uma luz espiritual, embora feitos especialmente por uma alma, não mais valem para essa que para
todas as demais almas do purgatório.

2. Demais. ─ Como diz o Mestre, os sufrágios aproveitam aos mortos na medida em que mereceram,
durante a vida, colher o fruto deles. Ora, certos podiam ter merecido colher esses frutos, mais que
aqueles por quem foram feitos. Logo, mais lhes aproveitam; do contrário o mérito lhes ficaria frustrado.

3. Demais. ─ Pelos pobres não se fazem tantos sufrágios como pelos ricos Se, pois, os sufrágios feitos por
uns só a eles aproveitassem, ou a eles mais que aos outros, os pobres estariam em pior condição. O que
vai contra a sentença do Senhor: Bem-aventurados vós os pobres porque vosso é o reino de Deus.
Mas, em contrário. ─ A justiça humana tem o seu exemplar na justiça divina. Ora, a justiça humana,
quando um paga a dívida de outro, só a este absolve. Logo, como quem faz os sufrágios pelos mortos de
certo modo lhes solve o débito, esses sufrágios só a eles lhe aproveitam.

2. Demais. ─ Assim como quem faz os sufrágios de certo modo satisfaz pelo morto, assim também
podemos satisfazer pelos vivos. Ora, quando satisfazemos pelos vivos, essa satisfação não aproveita
senão àquele por quem é feita. Logo, os sufrágios só aproveitam aqueles por quem são feitos.

SOLUÇÃO. ─ Nesta matéria há duas opiniões.
Uns, como Prepositivo, disseram, que os sufrágios celebrados por um defunto aproveitam mais, não
aquele por quem são feitos, senão aos mais dignos. E davam o exemplo de uma candeia que, acesa para
alumiar um rico, não aproveita menos, aos que com ele estão, mas talvez mais, se tiverem vista melhor.
E também o de uma lição, que não aproveita mais aquele a quem é dada do que aos outros
participantes dela, mas talvez mais, se tiverem inteligência mais capaz. ─ E a quem lhes objetasse, nesse
caso, a vanidade da ordenação da Igreja, ao instituir orações especiais por certas almas, davam a
resposta seguinte. Que isso o fez a Igreja para despertar a devoção dos fiéis, mais inclinados a fazer
sufrágios especiais que sufrágios comuns, e a orarem mais fervorosamente pelos parentes que pelos
estranhos.
Outros porém ensinaram que os sufrágios valem mais para aqueles por quem são feitos. Ora, ambas as
opiniões encerram uma parte de verdade. Pois, o valor dos sufrágios pode ser considerado a dupla luz. A
uma luz, valem em virtude da caridade, que torna todos os bens comuns. E então, mais aproveitam a
quem maior plenitude tem de caridade, embora não tenham sido especialmente feitos. Assim, o valor
dos sufrágios se funda, antes, numa certa consolação interior, pela qual uma alma, depois da morte, se
alegra na caridade com o bem de outra ─ do que na diminuição da pena. Pois, após a morte, já não é o
tempo de adquirir nem de aumentar a graça, para o que, durante a vida, nos valem as obras alheias, em
virtude da caridade. A outra luz os sufrágios valem enquanto aplicados pela intenção de um, a outro.
Assim, a satisfação de um se aplica em favor de outro. E então dúvida não há que mais aproveitam
aqueles por quem são feitos, Antes mesmo, só a eles aproveitam. Pois, a satisfação propriamente se
ordena à remissão da pena. Por onde, quanto à remissão da pena, os sufrágios sobretudo aproveitam
aquele por quem são feitos. E a esta luz a segunda opinião é mais verdadeira que a primeira.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Os sufrágios aproveitam ao modo da luz; os mortos,
recebendo-lhes os efeitos, ficam de certa maneira consolados; e tanto mais quanto maior caridade
tiverem. Mas, enquanto os sufrágios constituem uma satisfação aplicada a outrem por intenção de
quem os faz, não se assemelham à luz, mas à solução de um débito. Ora, o pagamento da dívida de um
não implica na solução dos débitos dos outros.

RESPOSTA À SEGUNDA. ─ Esse mérito é condicional. Pois, mereceram que os sufrágios lhes houvessem
de aproveitar no caso de lh'os serem feitos. O que nada mais foi senão tornarem-se capazes de o
receber. Por onde é claro, que não mereceram diretamente o socorro dos sufrágios; mas, por méritos
precedentes, habilitaram-se a lhes colher os frutos. Donde pois não se segue, que tivessem o seu mérito
frustrado.

RESPOSTA À TERCEIRA. ─ Nada impede os ricos de serem, em si mesmos, de melhor condição que os
pobres, assim como quanto à expiação da pena. Mas isso é quase nada comparado à posse do reino dos
céus, onde, conforme a autoridade citada, os pobres aparecerão em melhor situação.

## Art. 13 — Se os sufrágios feitos por muitos valem tanto para cada um como se fossem feitos a cada um singularmente.
O décimo terceiro discute-se assim. ─ Parece que os sufrágios feitos por muitos valem tanto para cada
um como se fossem feitos a cada um singularmente.

1. ─ Pois, a experiência nos ensina que a leitura feita a um não na perdem os outros, que também a
ouvirem. Logo e pela mesma razão, os sufrágios feitos por um morto nada perdem do seu valor se
aplicados ao mesmo tempo a outros. E assim, quando feitos por muitos, tanto aproveitam a cada um
como se fossem singularmente feito por cada um.

2. Demais. ─ Como vemos pelo uso comum da Igreja, à missa celebrada por um defunto se acrescentam
também orações pelos demais. Ora, tal não se faria se daí resultasse algum detrimento ao morto por
quem a missa é celebrada. Logo, a mesma conclusão anterior.

3. Demais. ─ Os sufrágios, sobretudo das orações, se fundam no poder divino. Ora, perante Deus, assim
como tanto faz sermos socorridos por muitos ou por poucos, assim o mesmo é socorrermos muitos ou
poucos. Logo, tanto aproveitaria a oração feita a um só, quanto a muitos, sendo feita em benefício de
muitos.
Mas, em contrário. ─ É mais meritório socorrermos a vários que a um só. Portanto, se o sufrágio
celebrado por muitos vale para cada um como se fosse por cada um singularmente feito, parece que a
Igreja não devia instituir que se dissesse missa ou se orasse por ninguém em particular, mas que sempre
se celebrassem sufrágios simultaneamente por todos os fiéis defuntos. O que é evidentemente falso.

2. Demais. ─ Um sufrágio tem eficácia finita. Logo, aplicado a muitos, menos aproveita a cada um em
particular, que aproveitaria se por cada um singularmente fosse feito.

SOLUÇÃO. ─ Considerado o valor dos sufrágios enquanto fundados na virtude da caridade, que une
todos os membros da Igreja, os sufrágios feitos por muitos tanto aproveitam a cada um como se por
cada um singularmente fossem feitos. Pois, a caridade não diminui por se aplicar a muitos os seus
efeitos; ao contrário, mais aumenta. Semelhantemente, também a alegria torna-se maior quanto mais
são os participantes dela, como diz Agostinho. E assim, com uma boa ação não menos se alegram muitas
almas do purgatório, que uma só em particular. ─ Considerado porém o valor dos sufrágios enquanto
satisfação transferida aos mortos pela intenção de quem os faz, então mais aproveitam a uma alma,
quando por ela particularmente feitos, que quando a ela feito juntamente com outras muitas. Pois, o
efeito dos sufrágios a divina justiça os divide entre aqueles por quem são celebrados. ─ Por onde é claro
que esta questão depende da primeira. Donde também se deduz, porque a Igreja instituiu que se
fizessem sufrágios especiais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Os sufrágios, como satisfações que são, não agem ao
modo por que o faz o ensino, que como qualquer outra atividade, tem o seu efeito dependente da
disposição de quem o recebe. Mas valem a modo de solução de uma dívida, como se disse. Por isso não
colhe o símile.

RESPOSTA À SEGUNDA. ─ Os sufrágios feitos por um só de certo modo também aproveitam aos outros,
como do sobredito resulta. Por onde, nenhum inconveniente há em se rezarem, na missa celebrada por
uma alma, orações também pelas demais almas. Pois, essas orações não são rezadas para que a
satisfação do sufrágio se aplique às outras principalmente, mas com a intenção de lhes valer por meio
de orações especiais feitas particularmente por elas.

RESPOSTA À TERCEIRA. ─ A oração pode ser considerada relativamente a quem ora e aquele por quem
é feita; e de ambos depende o seu efeito Por onde, embora ao poder divino não seja mais difícil
absolver a muitos, que a um só morto, contudo, relativamente a quem ora, a oração é mais satisfatória
quando feita por uma só alma, que quando aplicada a muitas.

## Art. 14 — Se os sufrágios comuns valem por aqueles por quem não foram especialmente feitos, quanto por aqueles por quem foram feitos valem simultaneamente os sufrágios especiais e os comuns.
O décimo quarto discute-se assim. ─ Parece que os sufrágios comuns valem por aqueles por quem não
foram especialmente feitos, quanto por aqueles por quem foram feitos valem simultaneamente os
sufrágios especiais e os comuns.

1. - Pois, cada um receberá na vida futura o prêmio relativo aos seus méritos próprios. Ora, as almas por
quem não se fazem sufrágios mereceram ser sufragadas depois da morte, tanto quanto aquela por
quem se celebram sufrágios especiais. Logo, tanto lhes aproveitarão os sufrágios comuns, quanto, às
outras os especiais e os comuns.

2. Demais. - Entre os sufrágios da Igreja o principal é a Eucaristia. Ora, a Eucaristia, contendo
integralmente Cristo, tem de certo modo uma eficácia infinita. Logo, uma só oblação da Eucaristia feita
em comum por todas as almas é suficiente a livrá-las todas do purgatório. Portanto, os sufrágios comuns
só por si valem tanto quanto eles e os especiais simultaneamente.
Mas, em contrário, dois bens são preferíveis a um só. Logo, os sufrágios especiais e os comuns mais
aproveitam à alma por quem são feitos, que só os comuns.

SOLUÇÃO. ─ A solução desta questão depende da solução da primeira. Se, pois, os sufrágios feitos por
um defunto especialmente aproveitassem por igual a todos os mais, então comuns seriam todos os
sufrágios. Portanto, tanto aproveitaria à alma pela qual não se fizessem sufrágios especiais, quanto
àquela por quem se fizessem, desde que se mostrasse igualmente digna deles. Se, pelo contrário, os
sufrágios feitos por um morto não aproveitam igualmente a todos, mas aproveitam em especial só
aquele por quem foram oferecidos, então nenhuma dúvida há que os sufrágios comuns e os especiais,
simultaneamente, mais aproveitam a um defunto, que só os comuns. Por isso o Mestre alude a essas
duas opiniões. Uma, quando diz que igualmente aproveitam ao rico os sufrágios comuns e os especiais,
quanto ao pobre só os comuns; embora pois, o rico seja sufragado mais que o pobre, não fica por isso
mais beneficiado que este. A outra opinião alude quando diz, que o morto, por quem se fazem sufrágios
especiais, alcança uma absolvição mais rápida, mas não mais plena; porque ambos serão finalmente
liberados de toda pena.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O socorro dos sufrágios não no mereceram os mortos
direta e absolutamente, mas sob condição. Por onde, a objeção não colhe.

RESPOSTA À SEGUNDA. ─ Embora o poder de Cristo, contido na Eucaristia, seja infinito, contudo o
efeito do sacramento do altar depende da alma por quem é celebrado. Donde, pois, não se pode
concluir que um único sacrifício do altar baste à expiação total da pena das almas do purgatório; assim
como não fica totalmente liberado da satisfação devida pelos pecados quem oferece uma única missa.
Por isso é que muitas vezes se oferecem muitas missas em satisfação de um só pecado. ─ Podemos
contudo crer, que a divina misericórdia, quando os sufrágios feitos por um morto lhe excedem às
necessidades, aplica esse excesso às almas não sufragadas e que precisam de o ser. Assim o diz
Damasceno: Deus, na sua justiça, concede ao incapaz de agir a possibilidade de o fazer; e compensa, na
sua sabedoria, as necessidades de um com o supérfluo dos outros. Isto é, o que sobra a um dá a outro.