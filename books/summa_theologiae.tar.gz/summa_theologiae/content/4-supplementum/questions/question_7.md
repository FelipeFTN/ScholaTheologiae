# Questão 7: Da quididade da confissão.
Em seguida devemos tratar da quididade da confissão.
E nesta questão se discutem três artigos:

## Art. 1 — Se Agostinho define bem a confissão dizendo: A confissão é a que faz descobrir a doença latente, pela esperança do perdão.
O primeiro discute-se assim. ─ Parece que Agostinho define mal a confissão, quando diz: A confissão é
a que faz descobrir a doença latente, pela esperança do perdão. Ora, a doença contra a qual se ordena
a confissão é o pecado. Ora, o pecado às vezes já está descoberto. Logo, não se devia dizer que a
confissão é o remédio de uma doença latente.

2. Demais. ─ O princípio da penitência é o temor. Ora, a confissão faz parte da penitência. Logo, não
devia pôr a esperança como causa da penitência, mas antes, o temor.

3. Demais. ─ O que está posto sob sigilo não está descoberto, mas antes oculto. Ora, o pecado que
confessamos o é sob o sigilo da confissão. Logo, não é descoberto o pecado na confissão, mas antes, é
oculto.

4. Demais. ─ Há outras definições diferentes dessa. Assim Gregório diz, que a confissão é a revelação dos
pecados e a abertura violenta das chagas da alma. Outros dizem que a confissão é a declaração dos
pecados a um sacerdote aprovado. Outros ainda dizem assim: A confissão é a acusação sacramental do
delinquente, satisfatória em virtude do pejo e do poder das chaves da Igreja, e que obriga a cumprir a
penitência anexa. Logo, parece que a referida definição, não contendo tudo quanto as outras contém, é
insuficiente.

SOLUÇÃO. ─ Várias coisas devemos considerar no mesmo ato da confissão. Primeiro, a substância
mesma do ato ou o seu gênero, que é uma certa manifestação; segundo, a sua matéria, a saber, o
pecado; terceiro, a quem é feita, isto é, o sacerdote; quarto, a sua causa, a saber, a esperança do
perdão; quinto, o seu efeito, a absolvição de uma parte da pena e a obrigação a solver a outra parte.
Ora, a primeira definição, a de Agostinho, toca na substância do ato quando se refere ao
descobrimento; e na matéria da confissão, quando diz - doença latente; e na causa, quando diz - pela
esperança do perdão. E as outras definições se referem a algum dos outros pontos assinalados, como o
poderá ver quem quiser nisso atentar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora o sacerdote às vezes saiba como homem o
pecado do penitente, contudo não o conhece como Vigário de Cristo; como também o juiz sabe às vezes
de certas coisas como homem, que ignora como juiz. E nesse ponto, o sacerdote fica informado pela
confissão. - Ou devemos responder, que embora o ato exterior esteja descoberto, contudo o ato
interior, que é o mais principal, está oculto. E por isso é necessário seja revelado pela confissão.

RESPOSTA À SEGUNDA. ─ A confissão pressupõe a caridade, que dá a vida ao pecador, como diz à letra
o Mestre das Sentenças. Ao passo que na contrição é que é dada a caridade. Quanto ao temor servil e
desacompanhado da esperança, é condição prévia para a caridade. Mas quem tem a caridade é movido
antes da esperança que do temor. Por onde causa da confissão é considerada antes a esperança que o
temor.

RESPOSTA À TERCEIRA. ─ O pecado, em qualquer confissão, é descoberto ao sacerdote e oculto aos
outros pelo sigilo da confissão.

RESPOSTA À QUARTA. ─ Não é preciso que toda definição abranja tudo o que implica a coisa definida.
Por isso há certas definições ou atribuições que encaram uma coisa e outras, outra.

## Art. 2 — Se a confissão é um ato de virtude.
O segundo discute-se assim. ─ Parece que a confissão não é um ato de virtude.

1. ─ Pois, todo ato de virtude é de direito natural, porque por natureza somos aptos para a virtude,
como diz o Filósofo. Ora, a confissão não é de direito natural. Logo, não é ato de virtude.

2. Demais. ─ Um ato de virtude pode ser próprio, antes do inocente, que de quem pecou. Ora, a
confissão do pecado, de que falamos, não pode convir ao inocente. Logo, não é um ato de virtude.

3. Demais. ─ A graça dos sacramentos de certo modo difere da graça das virtudes e dos dons. Ora, a
confissão é um dos sacramentos. Logo, não é ato de virtude.
Mas, em contrário. ─ Os preceitos da lei têm por matéria os atos de virtude. Ora, a confissão constitui
objeto de preceito. Logo, é ato de virtude.

2. Demais. ─ Não merecemos senão pelos atos de virtude. Ora, a confissão é meritória, porque abre o
céu, como diz à letra o Mestre das Sentenças. Logo, parece que é ato de virtude.

SOLUÇÃO. ─ Para um ato ser considerado virtuoso basta, como dissemos, implique por natureza alguma
condição pertencente à virtude. Embora, porém, nem tudo o necessário à virtude importe a confissão,
esta importa entretanto, como o seu próprio nome o indica, a manifestação do que temos em
consciência; e assim a boca e o coração convêm simultaneamente no mesmo. Por onde, o proferir com
a boca o que não está no coração não é confissão, mas ficção. Pois, é condição da virtude falarmos com
a boca o que temos no coração. Por onde, a confissão é genericamente um bem e é um ato de virtude.
Pode porém ser mal feita se não for acompanhada das circunstâncias devidas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─A fazer uma confissão verdadeira, ao modo devido, a
quem deve fazê-lo e quando o deve, em geral inclina a razão natural. E assim, a confissão é de direito
natural. Mas a determinação das circunstâncias de tempo, de modo, da matéria da confissão e da
pessoa a quem devemos fazê-la, tudo isso e instituição do direito divino, na confissão de que tratamos.
E assim é claro que direito natural inclina à confissão, mediante direito divino, pelo qual as
circunstâncias são determinadas; assim se dá também em tudo o que é de direito positivo.

RESPOSTA À SEGUNDA. ─ Embora o inocente possa ter habitualmente aquela virtude cujo objeto é o
pecado cometido, não a tem contudo atualmente, no estado de inocência. Por isso, também a confissão
dos pecados, da qual agora tratamos, não cabe ao inocente, embora seja ato de virtude.

RESPOSTA À TERCEIRA. ─ Embora a graça dos sacramentos e a graça das virtudes sejam diferentes, não
são contudo contrárias, mas dispares. Por isso não há inconveniente em o mesmo que é ato de virtude,
enquanto procedente do livre arbítrio informado pela graça, seja também sacramento ou parte do
sacramento, enquanto remédio ordenado contra o pecado.

## Art. 3 — Se a confissão é ato da virtude de penitência.
O terceiro discute-se assim. ─ Parece que a confissão não é ato da virtude de penitência.

1. ─ Pois, o ato dessa virtude é a sua causa. Ora, a causa da confissão é a esperança do perdão, como
resulta da definição dada. Logo, parece que é ato da esperança e não da penitência.

2. Demais. ─ A vergonha de acusar os pecados é parte da temperança. Ora, a confissão tem a sua
eficácia desse pejo de nos acusarmos, como resulta da definição dada antes. Logo, é ato de temperança
e não de penitência.

3. Demais. ─ O ato de penitência se funda na misericórdia divina. Ora, a confissão se funda, antes, na
sabedoria de Deus, por causa da veracidade que nela deve existir. Logo, não é ato de penitência.

4. Demais. ── A penitência tem por motivo determinante o artigo do símbolo que trata do juízo, pois,
tem ela no temor a sua origem. Ora, o artigo determinante da confissão é a vida eterna, pois, tem ela a
sua causa na esperança do perdão. Logo, não é um ato de penitência.

5. Demais. ─ A virtude da veracidade exige nos mostremos tal como somos. Ora, isso o confitente o faz.
Logo, a confissão é ato da virtude chamada veracidade e não da penitência.
Mas, em contrário. ─ A penitência se ordena à destruição do pecado. Ora, a isso mesmo também se
ordena a confissão. Logo, é um ato de penitência.

SOLUÇÃO. ─ Em matéria de virtude devemos considerar que, quando ao objeto de uma virtude se
acrescenta a noção especial de bondade e de dificuldade, é necessário uma virtude especial. Assim,
dispender suntuosamente constitui a magnificência, embora os gastos medíocres e os presentes
geralmente pertençam à liberalidade, como está claro em Aristóteles. E o mesmo se dá com a confissão
da verdade, a qual, embora, absolutamente falando, pertença à virtude
da veracidade, contudo, enquanto se lhe acrescenta uma certa razão de bondade, entra a pertencer a
outra virtude. Por isso diz o Filósofo, que a confissão feita em juízo não pertence à virtude da
veracidade, mas antes, à justiça. E semelhantemente, a confissão dos benefícios de Deus, para louvor
divino, não pertence à virtude da veracidade, mas à de latria. E assim também a confissão dos pecados
para conseguir o perdão deles não pertence, de modo elicíto, à virtude da
veracidade, como certos dizem, mas à virtude da penitência. Mas, de modo imperativo, pode pertencer
a muitas virtudes, enquanto o ato da confissão pode ser reduzido ao fim de muitas virtudes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A esperança é a causa da confissão, não como dela elicíta,
mas como sendo ela imperante.

RESPOSTA À SEGUNDA. ─ A vergonha de acusarmos os pecados, na referida definição, não é posta
como causa da confissão, pois, é antes de natureza a impedir o ato da confissão. Mas é antes concausa
para libertar da pena, enquanto essa vergonha já é por si mesma uma certa pena; assim como também
o poder das chaves da Igreja é concausa da confissão para o referido fim.

RESPOSTA À TERCEIRA. ─ Por uma certa adaptação, as partes da penitência podem adaptar-se aos três
atributos das pessoas. Assim, a contrição responderá à misericórdia ou à bondade, por causa da dor do
mal; a confissão, à sabedoria, por causa de manifestação de verdade; a satisfação, ao poder por causa
do trabalho em satisfazer. E como a contrição é a primeira parte da penitência, e dá a eficácia às outras
partes, por isso julgamos do mesmo modo, de toda a penitência, como da contrição.

RESPOSTA À QUARTA. ─ Como a confissão procede, antes, da esperança que do temor, por isso se
funda, antes, no artigo da vida eterna, a que respeita a esperança, que no artigo do juízo, a que respeita
o temor; embora a penitência, em razão da contrição se comporte de maneira inversa.

RESPOSTA À QUINTA. ─ A resposta resulta clara do que foi dito.