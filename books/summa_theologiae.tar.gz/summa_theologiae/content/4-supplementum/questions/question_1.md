# Questão 1: Das partes da penitência em especial, e primeiro, da contrição.
Em seguida devemos tratar de cada uma das partes da penitência. E primeiro, da contrição. Segundo, da
confissão. Terceiro, da satisfação. Sobre a contrição devemos considerar cinco questões. Primeiro, o que
é. Segundo, o seu objeto. Terceiro, a sua extensão. Quarto, a sua duração. Quinto, o seu efeito.
Na primeira, discutem-se três artigos:

## Art. 1 — Se a contrição é a dor dos pecados assumida com o propósito de confessar e satisfazer.
O primeiro discute-se assim. ─ Parece que a contrição não é a dor dos pecados assumida com o
propósito de confessar e satisfazer, como certos definem.

1. Pois, como diz Agostinho, temos dor do que nos sucede contra a vontade. Ora, tal não se dá com os
pecados. Logo, a contrição não é a dor dos pecados.

2. Demais. ─ A contrição nos é dada por Deus. Ora, o dado não é assumido. Logo, a contrição não é a dor
assumida.

3. Demais. ─ A satisfação e a confissão são necessárias para ser remetida a pena que não o for na
contrição. Ora, às vezes essa pena é totalmente remitida na confissão. Logo, nem sempre é necessário
tenha o contrito o propósito de confessar e de satisfazer.

SOLUÇÃO. ─ No dizer da Escritura, o princípio de todo pecado é a soberba, que nos torna aferrados às
nossas opiniões próprias e nos afasta dos mandamentos divinos. Por onde, o que destrói o pecado
necessàriamente nos leva a abandonar as nossas opiniões. Ora, quem persevera nas suas opiniões
próprias é chamado, por semelhança, rígido e duro; donde o dizermos que se quebra quando abandona
tais opiniões. Ora, entre a fração e a trituração ou contrição. na ordem material ─ donde esses nomes
forem derivados para a ordem espiritual há a diferença seguinte, como o ensina Aristóteles. Dizemos
que sofre fração uma causa quando dividida em grandes partes; e triturado ou esmagado quando o que
em si mesmo era sólido é reduzido a partes mínimas. E como, para nos serem perdoados, é necessário
deixarmos totalmente o afeto aos pecados, o que nos dava uma certa continuidade e a ferramenta ao
nosso sentir próprio, por isso o ato pelo qual o pecado é perdoado se chama, por semelhança,
contrição.
Em cuja contrição, podemos distinguir vários elementos, a saber: a substância mesma do ato, o modo
de agir, o princípio e o efeito. E por isso se encontram várias definições dadas da contrição.
Relativamente à substância mesma do ato, foi dada a definição referida. E sendo o ato de contrição um
ato de virtude e parte do sacramento da penitência, por isso a referida definição a põe de manifesto,
como ato de virtude, quando lhe indica o gênero, é a dor; e o objeto, quando diz ─ dos pecados; e a
eleição, que implica todo ato de virtude, quando diz - assumida. E a revela como parte do sacramento,
ordenando-a relativamente às outras partes, quando diz: com o propósito de confessar e satisfazer.
Encontra-se, porém, outra definição, que define a contrição somente como ato de virtude; mas
acrescenta à definição referida a diferença que a limita à virtude especial da penitência. Diz, pois, essa
definição, que a contrição é uma dor voluntária do pecado, punitiva do que temos dor de haver
praticado. Assim, acrescentando a idéia de punir, reduz a penitência a uma virtude especial.
Outra é a definição de Isidoro, e é a seguinte: A contrição é a compunção e a humilhação da alma,
acompanhada de lágrimas, proveniente da recordação do pecado e do temor do juízo. E esta leva em
conta a significação do nome quando diz: humilhação da alma; pois, assim como o orgulho nos enrijece
no nosso modo próprio de sentir, assim, quando, contritos, abandonamos o nosso modo próprio de
pensar, humilhamo-nos. E também lhe abrange a expressão exterior, quando diz: proveniente da
recordação do pecado, etc.
Outra definição é a tomada das palavras de Agostinho, que leva em conta o efeito da contrição e é a
seguinte: a contrição é a dor, que perdoa os pecados.
Outra é deduzida das palavras de Gregório e é a seguinte: a contrição é a humildade do espírito, que
aniquila pecado, causada da esperança e do temor. E essa leva em conta a significação da palavra,
quando diz ser a contrição a humildade do espírito; e o seu efeito, quando diz - que aniquila o pecado; e
a origem, ao afirmar - causada da esperança e do temor. Não só enuncia a causa principal - o temor;
mas também dá a causalidade da esperança, sem a qual o temor podia levar ao desespero.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora quando cometemos os pecados voluntàriamente
o tivéssemos feito, contudo já não são voluntários quando deles temos contrição. Por isso, neles caímos
involuntàriamente; não, certo, segundo a vontade, que então tínhamos quando os quisemos; mas,
segundo a que então temos, pela qual quiséramos nunca os ter cometido.

RESPOSTA À SEGUNDA. ─ A contrição procede de Deus só, quanto à forma que a informa; mas a
substância do ato resulta do livre arbítrio e de Deus, que atua em todas as obras, tanto da natureza
como da vontade.

RESPOSTA À TERCEIRA. ─ Embora a pena possa ser totalmente perdoada pela contrição, contudo
continua ainda necessária a confissão e a satisfação. - Quer por não podermos ter certeza da nossa
contrição, que seria a necessária para eliminar totalmente o pecado; quer também por serem de
preceito a confissão e a satisfação. Por isso em transgressão incorreria quem não confessasse e
satisfizesse.

## Art. 2 — Se a contrição é ato de virtude.
O segundo discute-se assim. ─ Parece que a contrição não é um ato de virtude.

1. ─ Pois, as paixões não são atos de virtudes, porque por elas não somos louvados nem censurados,
como diz Aristóteles. Ora, a dor é uma paixão. Logo, sendo a contrição dor, parece que não é ato de
virtude.

2. Demais. ─ Assim como a contrição, também a atrição deriva de triturar (tero), Ora, a atrição não é um
ato de virtude, como dizem todos. Logo, nem a contrição.
Mas, em contrário. ─ Só o ato de virtude é meritório. Ora, a contrição é um ato meritório. Logo, é ato de
virtude.

SOLUÇÃO. ─ A contrição, de significado próprio, não designa um ato de virtude, mas antes, uma certa
paixão do corpo. Mas não é neste sentido que agora tratamos da contrição; mas naquele em que tem
significação figurada, por semelhança. Pois, assim como a inflação da nossa vontade própria a fazer o
mal implica, por si mesma, genericamente o mal, assim essa aniquilação e contrição da vontade implica
por si mesma um bem genérico; pois, isso é detestar a vontade própria pela qual cometemos o pecado.
Por onde, a contrição, que o significa, importa numa certa retidão da vontade. Daí o ser ato de virtude
próprio da penitência, que nos leva a detestar e destruir o pecado passado, conforme resulta do que foi
dito na distinção XIV.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Na contrição há uma dupla dor do pecado. ─ Uma na
parte sensitiva e é a paixão. E esta não é essencialmente contrição, como ato de virtude, mas antes,
efeito dela. Pois, assim como a virtude da penitência inflige uma pena externa do corpo para reparar a
ofensa feita a Deus pelos membros corpóreos, assim também à parte concupiscível inflige a pena da
referida dor, porque também essa parte cooperou no pecado. Essa dor contudo pode pertencer à
contrição, enquanto parte do sacramento; porque os sacramentos não só consistem nos atos internos,
mas também nos externos e nas cousas sensíveis. ─ Outra é a dor de vontade, que não é senão a
displicência de um determinado mal; segundo o que o efeito da vontade tira a sua denominação dos
nomes das paixões, como se disse na Terceira Parte. E assim, a contrição é dor por essência e ato da
virtude da penitência.

RESPOSTA À SEGUNDA. ─ Atrição diz acesso à perfeita contrição; por isso, na ordem material chamamos
torturadas (attrita) às cousas de certo modo esmagadas, mas não perfeitamente; ao passo que
contrição (contrito) se deveria dizer para significar que todas as partes trituradas foram
simultaneamente reduzidas ao mínimo pela divisão. Por isso, no plano espiritual, a atrição significa uma
certa displicência dos pecados, permitidos, mas não perfeita; ao passo que a contrição o é
perfeitamente.

## Art. 3 — Se a atrição pode se tornar contrição.
O terceiro discute-se assim. ─ Parece que a atrição pode se tornar contrição.

1. ─ Pois, a contrição difere da atrição, como o informado, do informe. Ora, a fé informe se torna
informada. Logo, a atrição pode tornar-se contrição.

2. Demais. ─A matéria recebe a perfeição quando removida a privação. Ora, a dor está para a graça
como a matéria para a forma; pois, a graça informa a dor. Logo, a dor, de primeiro informe, quando
existia a culpa, que é privação da graça, recebe, removida a culpa, a perfeição que dá a informação da
graça. Donde, pois, se conclui o mesmo que antes.
Mas, em contrário. ─ Coisas cujos princípios são absolutamente diversos, não pode uma transformar-se
na outra. Ora, o princípio da atrição é o temor servil; ao passo que o da contrição é o temor filial. Logo, a
atrição não pode transformar-se em contrição.

SOLUÇÃO. ─ Nesta matéria há duas opiniões. ─ Uns dizem que a atrição se torna contrição, como a fé
informe, fé informada. - Mas isto, como vemos, não pode ser. Porque embora o hábito da fé informe
seja informado, contudo nunca o ato de fé informe se torna ato de fé informada; pois, esse ato informe
passa e não permanece com a sobreveniência da caridade. Ora, a atrição e a contrição não significam
hábitos, mas somente atos. Mas os hábitos das virtudes infusas, atinentes à vontade, não podem ser
informes, pois, resultam da caridade, como dissemos no Terceiro Livro. Por onde, antes de a graça ser
infundida, não há nenhum hábito do qual venha depois a ser elícito o ato de contrição. E assim, de
nenhum modo pode a atrição tornar-se contrição. E é o que diz a outra opinião.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Não há símile entre a fé e a contrição, como se disse.

RESPOSTA À SEGUNDA. ─ A matéria, que permanece, quando recebe a perfeição adveniente, fica
informada, removida a sua privação. Mas a referida dor, que era informe, não permanece, advindo-lhe a
caridade. E portanto não pode ser informada. ─ Ou devemos responder que a matéria, na sua essência,
não se origina da forma, assim como o ato se origina do hábito que o informa. Por onde, nenhum
inconveniente há em a matéria ser informada por uma outra forma, que antes não a informava.
Mas é impossível dar-se isto com o ato, assim como é impossível um ser, numericamente o mesmo,
proceder de um princípio, donde antes não procedia, pois, as coisas vêm à existência só uma vez.
