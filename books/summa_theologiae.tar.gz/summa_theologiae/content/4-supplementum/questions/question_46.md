# Questão 46: Do consentimento seguido de um juramento ou da conjunção carnal.
Em seguida devemos tratar do consentimento seguido de um juramento ou da conjunção carnal.
Sobre cuja questão discutem-se dois artigos:

## Art. 1 — Se o juramento adjunto ao consentimento num casamento futuro, implica o matrimônio.
O primeiro discute-se assim. ─ Parece que o juramento, adjunto ao consentimento num casamento
futuro, implica o matrimônio.

1. Pois, ninguém pode obrigar-se a praticar um ato contrário ao direito divino. Ora, cumprir o juramento
é exigido pelo direito divino, conforme aquilo do Evangelho: Cumprirás ao Senhor os teus juramentos.
Logo, nenhuma obrigação subsequente pode autorizar o não cumprimento de um juramento
anteriormente feito. Portanto, quem, depois de ter consentido em casar com uma mulher, futuramente,
obrigar-se com outra, por palavras de presente, fica contudo adstrito ao dever de cumprir o juramento
anterior. Ora, isto não se daria se esse juramento não obrigasse ao matrimônio prometido. Logo, o
juramento adjunto ao consentimento num matrimônio futuro, obriga ao matrimônio.

2. Demais. ─ A verdade divina tem mais força que a humana. Ora, pelo juramento, fundamos o valor da
nossa palavra na veracidade divina. Por onde, como as palavras de presente, expressivas do matrimônio,
e só fundadas na veracidade humana implicam o matrimônio, parece que com muito maior razão pode
produzir esse efeito a promessa de um matrimônio futuro feita sob juramento.

3. Demais. ─ Segundo o Apóstolo, o juramento é a maior segurança para terminar todas as contendas.
Logo, ao menos num futuro, devemos dar maior valor a um juramento que a uma simples palavra.
Depois, se alguém consentir na promessa, por palavras de presente a se casar com uma mulher, depois
de ter consentido verbalmente num casamento futuro com outra, por juramento, deve, por juízo da
Igreja, ser compelido a casar com a primeira e não com a segunda.

4. Demais. ─ O simples fato de pronunciar as palavras, que comprometem a um matrimônio futuro, tem
como efeito os esponsais. Ora, para estes também o juramento produz o seu efeito. Logo, tem maior
alcance que os esponsais. Ora, além dos esponsais só há, o matrimônio. Logo, o juramento tem o
matrimônio como feito.
Mas, em contrário. ─ O que há de ser ainda não é. Ora, um juramento acrescentado não pode fazer com
que a promessa verbal de um matrimônio futuro deixe de exprimir um acontecimento futuro. Logo,
ainda não haverá então o matrimônio.

2. Demais. ─ Depois de o matrimônio perfeito, não há necessidade de nenhum outro consentimento
para a existência dele. Ora depois do juramento ainda há necessidade de outro consentimento para
haver matrimônio; do contrário seria inútil jurar, que o casamento haveria de se realizar. Logo, não
produz o matrimônio.

SOLUÇÃO. ─ Recorremos ao juramento para confirmar as nossas palavras. Por onde, o juramento só
confirma o que foi dito, nem lhe muda o significado. Ora, palavras que exprimem um matrimônio futuro
não tem, pela sua significação mesma como deito, o matrimônio, porque o prometido como futuro
ainda não é. E assim, mesmo acrescentando-se o juramento, ainda não está perfeito o matrimônio como
o diz o Mestre das Sentenças.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Cumprir um juramento lícito nos é imposto por direito
divino; não porém cumprir um juramento ilícito. Por onde, se uma obrigação subsequente ao juramento
o tornar ilícito de lícito que antes era, não encontrará o direito divino quem não cumprir o juramento
anteriormente feito. Ora, tal o que se dá no caso vertente. Pois, jura ilicitamente quem ilicitamente
promete. Ora, prometer o alheio é ilícito. Por onde, o consentimento subsequente por palavras de
presente, pelo qual alguém transfere o domínio do seu corpo a outrem, torna ilícito o juramento, de
antes lícito.

RESPOSTA À SEGUNDA. ─ A verdade divina é eficacíssima para confirmar aquilo para o que a tomamos
como testemunho.

DONDE SE DEDUZ A RESPOSTA À TERCEIRA OBJEÇÃO.

RESPOSTA À QUARTA. ─ O efeito produzido pelo juramento é não criar uma nova obrigação, mas
confirmar a já feita. E assim mais gravemente peca quem a viola.

## Art. 2 — Se a conjunção carnal, depois das palavras que exprimem o consentimento num matrimônio, tem o matrimônio como efeito.
O segundo discute-se assim. ─ Parece que a conjunção carnal, depois das palavras. que exprimem o
consentimento num matrimônio futuro, tem o matrimônio como efeito.

1. Pois, consentir por atos é mais do que o fazer por palavras. Ora, consentir no comércio sexual é
consentir por atos numa promessa anteriormente feita. Logo, parece que desse modo muito mais se
conserva o matrimônio, que se nele fosse consentido apenas por palavras de presente.

2. Demais. ─ O consentimento, não só expresso, mas também interpretativo, tem como efeito o
matrimônio. Ora, nenhuma interpretação do consentimento é mais indubitável que a conjunção carnal.
Logo, desse modo se perfaz o matrimônio.

3. Demais. ─ Toda conjunção carnal fora dos limites do matrimônio é pecado. Ora, não peca a mulher
que admite o marido à conjunção carnal. Logo, por esta se perfaz o matrimônio.

4. Demais. ─ Não se perdoa o pecado senão com a restituição do que foi furtado. Ora, ninguém pode
restituir à mulher que deflorou, com promessa de matrimônio, o bem da sua virgindade, senão unindo-
se com ela pelo matrimônio. Logo, parece que não obstante depois da conjunção carnal, contrair
matrimônio com outra por palavras de presente, está obrigado a voltar a viver com a primeira. Ora, isso
não se daria se entre eles não existisse o matrimônio. Logo, a cópula carnal, depois do consentimento
num matrimônio futuro, produz o matrimônio.
Mas, em contrário, diz Nicolau I Papa: Faltando o consentimento para o casamento, tudo o mais que se
faça, mesmo a conjunção carnal, é nulo.

2. Demais. ─ O que resulta de uma coisa não na produz. Ora, a conjunção carnal resulta do matrimônio,
como o efeito, da causa. Logo, não pode ser causa do matrimônio.

SOLUÇÃO. ─ Podemos considerar o matrimônio a dupla luz. Primeiro, relativamente ao foro da
consciência. E então, na verdade das coisas, a conjunção carnal não pode consumar um matrimônio, já
precedido de esponsais, que o prometiam como futuro, desde que faltou o consentimento interior. Pois,
as palavras de presente, mesmo expressivas de consentimento, não teriam o matrimônio como efeito,
se faltasse o consentimento interior. Em segundo lugar, podemos considerar o matrimônio quanto ao
juízo da Igreja. E então, como no juízo externo se julga pelo exteriormente manifesto, e nada podendo
mais expressamente significar que a conjunção carnal o consentimento, por isso, segundo o juízo da
Igreja, essa conjunção, subsequente aos esponsais, consuma o matrimônio; salvo se se descobrirem
sinais expressos de dolo e de fraude.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Quem conserva a conjunção carnal, é que nela realmente
consentiu. Mas daí não se deduz que consentisse no matrimônio, senão por uma presunção de direito.

RESPOSTA À SEGUNDA. ─ Essa interpretação não altera a realidade das coisas, mas o juízo, fundado no
que se manifesta exteriormente.

RESPOSTA À TERCEIRA. ─ A noiva que admitir o noivo, crendo que este quer consumar o matrimônio,
fica escusada do pecado, salvo provas de fraude manifesta, como condições muito desiguais quanto à
nobreza ou quanto à fortuna, ou sinais semelhantes. Mas o noivo, além do pecado de fornicação,
comete o da fraude.

RESPOSTA À QUARTA. ─ Em tal caso o noivo está obrigado a abster-se de outra, e casar com a mulher
que deflorou, se forem da mesma condição ou se for a noiva de condição superior. Mas, casando com
outra, já fica incapaz de cumprir a promessa a que estava adstrito. Por isso cumpre o seu dever se
providenciar sobre o casamento dela. Mas a isto também não está obrigado, na opinião de certos, se for
de condição muito superior à dela ou se houver algum sinal evidente de fraude. Pois, pode-se presumir
com probabilidade, que a noiva não foi enganada, mas finge sê-lo.
