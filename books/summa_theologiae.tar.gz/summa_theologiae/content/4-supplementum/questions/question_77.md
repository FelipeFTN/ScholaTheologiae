# Questão 77: Do tempo e do modo da ressurreição.
Em seguida devemos tratar do tempo e do modo da ressurreição.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se o tempo da ressurreição deve ser diferido até ao fim do mundo, para todos ressurgirem simultaneamente.
O primeiro discute-se assim. ─ Parece que o tempo da ressurreição não deve ser diferido até ao fim do
mundo, para todos ressurgirem simultaneamente.

1. ─ Pois, maior é a conveniência entre a cabeça e os membros que dos membros entre si; como
também maior é a conveniência entre a causa e o efeito que a dos efeitos entre si. Ora, Cristo, que é a
nossa cabeça, não diferiu a sua ressurreição até ao fim do mundo para que ressurgisse juntamente com
todos. Logo, não é forçoso que a ressurreição dos santos primitivos seja diferida até ao fim do mundo, a
fim de ressurgirem junto com todos os mais.

2. Demais. ─ A ressurreição da cabeça é a causa da ressurreição dos membros. Ora, a ressurreição de
certos membros mais nobres, por causa da sua vizinhança com a cabeça, não foi dilatada até ao fim do
mundo, mas se seguiu logo à ressurreição de Cristo. Assim, como piamente se crê, a da SS. Virgem e a
de João Evangelista. Portanto, também a ressurreição dos demais tanto estará mais próxima à de Cristo
quanto mais lhe foram conformes pela graça e pelo mérito.

3. Demais. ─ O estado do homem é mais perfeito e mais conforme à imagem de Cristo no Novo que no
Velho Testamento. Ora, certos Patriarcas do Testamento Velho ressurgiram depois da ressurreição de
Cristo, segundo aquilo do Evangelho: Muitos corpos de santos, que eram mortos, ressurgiram. Logo,
parece que nem a ressurreição dos santos do Novo Testamento deve ser diferida até o fim do mundo,
para ressurgirem com os demais.

4. Demais. ─ Depois do fim do mundo não haverá mais contagem de anos. Ora, a Escritura conta ainda
muitos anos desde a ressurreição de vários mortos até a ressurreição dos outros. Assim, diz num passo:
Vi as almas dos decapitados pelo testemunho de Jesus e pela palavra de Deus. E mais adiante: E viveram
e reinaram com Cristo mil anos; e os outros mortos não tornaram à vida até que sejam contados mil
anos. Logo, a ressurreição de todos não será diferida até o fim do mundo, para todos ressurgirem
simultaneamente.
Mas, em contrário, a Escritura: O homem, quando dormir, não ressurgirá, a menos que o céu não seja
consumido, não se levantará nem despertará do seu sono; e se refere ao sono da morte. Logo, até o fim
do mundo, quando o céu for consumido, será diferida a ressurreição dos homens.

2. Demais. ─ O Apóstolo diz: Todos estes provados pelo testemunho da fé não receberam a recompensa
prometida, i. é, a plena beatitude da alma e do corpo; tendo disposto Deus alguma causa melhor a
nosso favor, para que eles, sem nós, não fossem consumados, i. é, aperfeiçoados; para que a glória de
cada um se tornasse maior com a glória de todos. Ora, a ressurreição não será antes da glorificação dos
corpos; porque Cristo reformará o nosso corpo abatido para o fazer conforme ao seu corpo glorioso; e
os filhos da ressurreição serão como os anjos no céu. Logo, a ressurreição será diferida até o fim do
mundo, quando todos ressurgirão ao mesmo tempo.

SOLUÇÃO. ─ Como diz Agostinho, a divina providência estatuiu que os corpos mais grosseiros e
inferiores fossem governados numa certa ordem pelos mais subtis e potentes. Por isso toda a matéria
dos corpos inferiores depende da variação do movimento dos corpos celestes. Seria, pois, contra a
ordem, que a divina providência estabeleceu para o universo, se a matéria dos corpos inferiores caísse
num estado de incorrupção, enquanto permanecesse o movimento dos corpos superiores. E como,
segundo os ensinamentos da fé, a ressurreição será para uma vida imortal semelhante à de Cristo, que
tendo ressurgido dos mortos já não morre, na frase do Apóstolo, por isso a ressurreição dos corpos
humanos será dilatada até o fim do mundo, quando cessará o movimento do céu. E por isso também
certos filósofos, ensinando que o movimento dos céus não cessará nunca, ensinaram também a volta
das almas humanas a corpos mortais, como os nossos. Uns, como Empédocles, eram de opinião que as
almas voltarão a se unirem aos mesmos corpos, no fim do grande ano; a corpos diferentes, outros,
como Pitágoras, para quem qualquer alma pode unir-se a qualquer corpo, como refere Aristóteles.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora a cabeça mais convenha com os membros ─ do
que os membros entre si ─ por uma conveniência de proporção, necessária para poder influir neles,
contudo exerce a cabeça uma certa causalidade sobre os membros, de que estes carecem; e por isso
diferem eles da cabeça e convêm entre si. Por onde, a ressurreição de Cristo é o exemplar da nossa; e é
na fé dessa ressurreição que se funda a esperança de também ressurgirmos. Mas, a ressurreição de
qualquer dos membros de Cristo não é a causa da ressurreição dos outros membros. Por isso a
ressurreição de Cristo devia preceder a ressurreição dos demais, que todos deverão simultaneamente
ressurgir na consumação dos séculos.

RESPOSTA À SEGUNDA. ─ Embora dentre os membros uns sejam mais dignos que os outros e mais
conformes à cabeça, não vão porém até exercer a função de cabeça de modo a serem a causa dos
outros. Por onde, pelo fato de serem mais conformes a Cristo não lhes é devido que a sua ressurreição
preceda à dos outros, como o exemplar precede o exemplado, segundo dissemos da ressurreição de
Cristo. E se a certos foi concedido que a sua ressurreição não se dilatasse até a ressurreição universal,
foi isso por privilégio de uma graça especial, e não como devido pela conformidade com Cristo.

RESPOSTA À TERCEIRA. ─ Jerônimo levanta a seguinte dúvida acerca da ressurreição dos santos com
Cristo. Se, depois de terem dado testemunho da ressurreição, de novo morreram, de modo que a
ressurreição deles foi, antes, como a de Lázaro, que de novo morreu, do que a verdadeira, que se dará
no fim do mundo; ou se verdadeiramente ressurgiram para uma vida imortal, de que o corpo
participasse, subindo corporalmente ao céu com Cristo, como diz a Glosa. E isto parece mais provável.
Porque, para darem testemunho da verdadeira ressurreição de Cristo, era conveniente que
verdadeiramente ressurgissem, como diz Jerônimo no mesmo lugar. Nem por causa deles é que a
ressurreição se lhes apressou, mas para testificarem a de Cristo; testemunho esse necessário para
fundar a fé do Novo Testamento. Por isso mais convenientemente seria dado pelos Padres do Velho
Testamento do que pelos mortos depois da fundação do Novo. Contudo, não devemos esquecer que
embora o Evangelho lhes mencione a ressurreição, antes da de Cristo, todavia, como o demonstra o
texto, devemos entender que o faz por antecipação, como frequentemente o fazem os hagiógrafos. Pois
ninguém ressuscitou verdadeiramente antes da ressurreição de Cristo; porque Cristo é as primícias dos
que dormem, na frase do Apóstolo. Embora certos, como Lázaro, ressuscitassem antes da ressurreição
de Cristo.

RESPOSTA À QUARTA. ─ Como refere Agostinho, as palavras citadas deram ocasião a certos heréticos
de ensinar que os mortos ressuscitariam, na primeira ressurreição, para reinarem mil anos na terra com
Cristo. Donde o serem chamados Quiliastas ou Milenários. Por isso Agostinho, no mesmo lugar, que o
lugar citado deve, noutro sentido, ser entendido da ressurreição espiritual, pela qual os homens
ressurgem dos pecados, ajudados do dom da graça. E quanto à segunda ressurreição, será a dos corpos.
─ Além disso, o que se entende pelo reino de Cristo é a Igreja, na qual reinam com Cristo não só os
mártires, mas também os outros eleitos, entendendo-se pela parte o todo. Ou todos reinam com Cristo
na glória; fazendo-se menção especial dos mártires, porque sobretudo aqueles reinam mortos, que até a
morte combateram pela verdade. Quanto ao número milenário de anos, não designa nenhum número
certo, mas todo o decurso do tempo atual, em que os santos reinam com Cristo. Porque o número
milenário, mais que o centenário, designa a universalidade; porque o número cem é o quadrado de dez,
ao passo que mil é um cubo resultante de uma dupla multiplicação de dez por si mesmo, pois, dez vezes
dez são cem e cem vezes dez são mil. E nesse sentido é aquele lugar da Escritura: Da palavra que enviou
para mil gerações, i. é, para todas.

## Art. 2 — Se esse tempo é oculto.
O segundo discute-se assim. ─ Parece que esse tempo não é oculto.

1. ─ Pois, daquilo cujo princípio é determinadamente conhecido podemos também conhecer
determinadamente o fim; porque tudo se mede por um certo período, na expressão de Aristóteles. Ora,
conhecemos determinadamente o princípio do mundo. Logo, também lhe podemos conhecer
determinadamente o fim. Pois, será então o tempo da ressurreição e do juízo. Portanto, esse tempo não
será oculto.

2. Demais. ─ A Escritura diz que a mulher, símbolo da Igreja, tem um retiro, que Deus lhe preparou, para
nele sustentar-se por mil duzentos e sessenta dias. E Daniel também conta um número determinado de
dias, que parece significarem anos, segundo aquele passo: Um dia que eu te dei por cada ano. Logo, pela
leitura da Sagrada Escritura podemos saber com precisão o tempo do fim do mundo e da ressurreição.

3. Demais. ─ A duração do Testamento Novo foi prefigurada no Velho. Ora, sabemos com precisão o
tempo que durou o Testamento Velho. Logo, com a mesma precisão podemos saber o tempo que há de
durar o Novo. Ora, Novo há de durar até o fim do mundo; donde dizer o Evangelho: Estai certos de que
eu estou convosco até a consumação do século. Portanto, podemos saber com certeza o tempo do fim
do mundo e da ressurreição.
Mas, em contrário. ─ O que os anjos ignoram há de com maioria de razão ser oculto aos homens. Pois,
aquilo que os homens podem alcançar com a razão natural muito mais clara e certamente podem saber
os anjos com o seu conhecimento natural. Além disso, revelações não se fazem aos homens senão
mediante os anjos, como está claro em Dionísio. Ora, os anjos não conhecem o tempo exato do fim do
mundo, conforme àquilo do Evangelho: De aquele dia nem de aquela hora ninguém sabe, nem os anjos
do céu. Logo, esse tempo será oculto aos homens.

2. Demais. ─ Os Apóstolos conheceram melhor os segredos de Deus, que os homens que lhes
sucederam. Pois, como diz o Apóstolo, eles tiveram as primícias do espírito. O que a Glosa explica: Mais
cedo no tempo e mais abundantemente que os outros homens. Ora, o Senhor lhes respondeu, quando
lhe perguntavam sobre o fim do mundo: Não é da vossa conta saber os tempos nem momentos que o
Pai reservou ao seu poder. Logo e com maior razão, tal tempo será oculto aos outros homens.

SOLUÇÃO. ─ Como ensina Agostinho, os últimos tempos do gênero humano, que medeiam entre o
advento do Senhor, e o fim do século, é incerta quantas gerações abrangerá; do mesmo modo que a
velhice, última idade do homem, não tem tempo determinado, medido segundo os outros períodos da
vida, pois pode abranger ela só tanto tempo quanto todas as outras idades juntas. E a razão disso é que
o tempo exato das idades futuras não no podemos saber senão pela revelação ou pela razão natural.
Ora, o tempo que decorrerá até a ressurreição não pode ser computado pela razão natural. Porque a
ressurreição e a cessação do movimento do céu se darão simultaneamente, como dissemos. Ora, do
movimento deriva o número de todos os acontecimentos futuros susceptíveis de serem previstos pela
razão natural como havendo de suceder-se num tempo determinado. Pelo movimento do céu porém
não lhe podemos prever o fim; porque, sendo circular, pode pela sua natureza mesma durar
perpetuamente. Por onde, não podemos, pela razão natural, fazer o computo do tempo que decorrerá
até a ressurreição. Nem o podemos saber pela revelação; e Deus assim o quis para estarmos sempre
prontos e preparados para a vinda de Cristo. Por isso, aos próprios Apóstolos, que lh'o perguntavam,
Cristo lhes respondeu: Não é da vossa conta saber os tempos nem os momentos que o Pai reservou ao
seu poder. Ao que diz Agostinho: Essas palavras impõem silêncio aos temerários, que contam como nos
dedos os anos que nos separam do fim do mundo. Ora, o que Cristo não quis revelar aos Apóstolos, que
lh'o inquiriam, também não revelará aos mais. Por isso todos os que pretenderam fazer o computo
desses tempos a experiência até agora os convenceu de falsiloquos. Assim, como o refere Agostinho no
mesmo lugar, certos calcularam que poderiam completar-se quatrocentos anos desde a ascensão do
Senhor até ao seu último advento; outros quinhentos; outros mil. E é patente o erro de todos. Sê-lo-á
também o de todos os que ainda persistem nesse computo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Daquilo de que sabemos o fim por um princípio
conhecido, também havemos por força de lhe conhecer a medida. Por onde, conhecido o princípio de
um fenômeno cuja duração se mede pelo movimento do céu, podemos lhe conhecer o fim, porque o
movimento do céu nos é conhecido. Mas a medida da duração do movimento do céu é somente a
disposição divina, que nos é oculta. Portanto, por mais que lhe conheçamos o princípio, não lhe
podemos saber o fim.

RESPOSTA À SEGUNDA. ─ Os mil duzentos e sessenta dias, mencionados pela Escritura, significam o
tempo total da duração da Igreja, sem determinação de nenhum número de anos. E isto porque a
predicação de Cristo, sobre a qual, está fundada a Igreja, durou três anos e meio, tempo quase igual ao
número de dias dado pelo profeta. Semelhantemente, o número de dias dado por Daniel não se refere a
nenhum número determinado de anos que hão de decorrer até o fim do mundo, ou até a pregação do
anticristo; mas deve referir-se ao tempo durante o qual pregará o anticristo e que durará a sua
perseguição.

RESPOSTA À TERCEIRA. ─ Embora o estado do Novo Testamento fosse prefigurado em geral pelo estado
do Velho, não é forçoso porém que todas as particularidades de um e de outro entre si se
correspondam. Sobretudo que em Cristo se completaram todas as figuras do Velho Testamento. Por isso
Agostinho, respondendo a certos, que queriam deduzir do número das pragas do Egito e das
perseguições que a Igreja sofreu e há de sofrer, diz: Quanto a mim, não penso que as pragas sofridas no
Egito signifiquem profeticamente as perseguições que deve padecer a Igreja. Sem dúvida os de opinião
contrária descobrem, com rebuscadas e engenhosas comparações, correspondências entre os fatos,
num e noutro caso. Mas não há aí nenhum espírito profético, senão simples conjecturas da mente
humana, umas vezes verdadeiras, falsas outras. ─ E do mesmo modo devemos julgar as predições do
Abade Joaquim, que por meio de tais conjecturas, fez certas predições, verdadeiras umas e outras
falsas.

## Art. 3 — Se a ressurreição terá lugar de noite.
O terceiro discute-se assim. ─ Parece que a ressurreição não será durante a noite.

1. ─ Porque não haverá ressurreição, a menos que o céu não seja consumido, como diz a Escritura. Ora,
cessado o movimento do céu, que é ser consumido, não haverá mais tempo, nem noite, nem dia. Logo,
a ressurreição não terá lugar de noite.

2. Demais. ─ O fim é o que de mais perfeito devem ter as cousas. Ora, com a ressurreição terá fim o
tempo; por isso diz a Escritura que então não haverá mais tempo. Portanto existirá o tempo na sua
perfeição. Logo, haverá dias.

3. Demais. ─ A qualidade do tempo deve ser apropriada ao que nele se faz; por isso o Evangelho refere
que Judas se separou de noite da convivência com Cristo, luz eterna. Ora na ressurreição todas as
cousas agora ocultas terão a sua completa manifestação; porque quando vier o Senhor não só porá às
claras o que se acha escondido nas mais profundas trevas, mas descobrirá ainda o que há de mais
secreto nos corações, como diz o Apóstolo. Logo, a ressurreição deverá ser de dia.
Mas, em contrário. ─ A ressurreição de Cristo é o modelo da nossa. Ora, teve lugar de noite, como diz
Gregório. Logo, também de noite será a nossa.

2. Demais. ─ O advento do Senhor é comparado pelo Evangelho à entrada de um ladrão numa casa. Ora,
o ladrão penetra nas casas de noite. Logo de noite é que o Senhor virá. Ora, desde que venha terá lugar
a ressurreição. Logo, esta se dará de noite.

SOLUÇÃO. ─ A hora exata da ressurreição não pode ser conhecida com certeza como diz o Mestre.
Contudo dizem certos com alguma probabilidade que será no crepúsculo da manhã estando o sol no
oriente e a lua a ocidente. Pois, é crença que o sol e a lua foram criados nessa disposição; de modo que
o seu movimento circular se perfará pela volta completa ao ponto de partida. Por isso se diz que Cristo
ressurgiu nessa hora.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A ressurreição não terá lugar no tempo, mas no termo do
tempo; pois, no mesmo instante em que cessar o movimento do céu se dará a ressurreição dos mortos.
Entretanto, os astros ocuparão então o mesmo lugar que ocupam através das idades num momento
dado. E nesse sentido se diz que a ressurreição se dará em tal hora ou em tal outra.

RESPOSTA À SEGUNDA. ─ O momento mais perfeito do tempo é o do meio dia, por causa da maior
intensidade da luz solar. Mas, na ressurreição a cidade de Deus não terá necessidade da luz da lua nem
da do sol, porque o Senhor Deus a alumiará. Portanto, sob este aspecto, não importa que a ressurreição
seja de dia ou de noite.

RESPOSTA À TERCEIRA. ─ O tempo da ressurreição convém que seja manifesto, quanto às causas que
nele se realizarão; e o oculto quanto à sua determinação. Por isso pode muito bem convir que a
ressurreição se dê tanto de dia como de noite.

## Art. 4 — Se a ressurreição se dará súbita ou sucessivamente.
O quarto discute-se assim. ─ Parece que a ressurreição não se dará de súbito, mas sucessivamente.

1. ─ Porque a Escritura prediz a ressurreição dos mortos quando diz: Os ossos se chegaram uns para os
outros; e olhei, e eis que vieram sobre os tais ossos nervos e carnes para os revestir e neles foi estendida
a pele por cima, mas eles ainda não tinham o espírito. Logo, a restauração dos corpos precederá no
tempo a sua união com a alma. Portanto, a ressurreição não se dará de súbito.

2. Demais. ─ O que depende de vários atos sucessivos não pode fazer-se subitamente. Ora, a
ressurreição depende dos seguintes atos sucessivos: a reunião das cinzas, a reconstituição do corpo e a
infusão da alma. Logo, não poderá fazer-se subitamente.

3. Demais. ─ Todo som se mede pelo tempo. Ora, o som da trombeta será a causa da ressurreição, como
se disse. Logo, a ressurreição se realizará num certo tempo e não subitamente.

4. Demais. ─ Nenhum movimento local pode ser súbito, como ensina Aristóteles. Ora, a ressurreição
supõe o movimento local necessário à reunião das cinzas. Logo, não se dará subitamente.
Mas, em contrário, o Apóstolo: Todos certamente ressuscitaremos num momento, num abrir e fechar
de olhos. Logo, a ressurreição será súbita.

2. Demais. ─ Um poder infinito obra subitamente. Ora, Damasceno diz que a ressurreição será um efeito
do poder divino, que sabemos ser infinito. Logo, a ressurreição será súbita.

SOLUÇÃO. ─ Para a ressurreição contribuirá em parte o ministério angélico e, em parte, o poder divino,
como se disse. Ora, a obra do ministério angélico não será instantâneo, tomando-se o instante como um
tempo imperceptível. O poder divino porém obrará subitamente, i. é, ao termo do tempo em que os
anjos terminarem a sua obra; porque o poder superior torna perfeita a do inferior.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Ezequiel, como Moisés, falava a um povo rude. Ora,
Moisés dividiu em seis dias a obra da criação, para poder a sua linguagem ser entendida de um povo
rude, embora toda ela fosse feita simultaneamente, como ensina Agostinho. Assim também Ezequiel
exprimiu como diversas as fases da futura ressurreição, embora todas hajam de realizar-se
instantaneamente.

RESPOSTA À SEGUNDA. ─ Embora as operações referidas sejam naturalmente sucessivas umas às
outras, são porém temporalmente simultâneas; porque ou se realizam num só instante, ou uma será no
instante em que a outra terminar.

RESPOSTA À TERCEIRA. ─ O mesmo se deve dizer desse som, que das formas dos sacramentos; i. é, que
o som produzirá o seu efeito no seu último instante.

RESPOSTA À QUARTA. ─ A congregação das cinzas, que não poderá realizar-se sem o movimento local,
se fará pelo ministério dos anjos. Por isso se dará num tempo, mas imperceptível, por causa da
facilidade de obrar própria dos anjos.