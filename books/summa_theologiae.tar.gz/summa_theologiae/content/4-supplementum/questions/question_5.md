# Questão 5: Do efeito da contrição.
Em seguida devemos tratar do efeito da contrição.
Nesta questão discutem-se três artigos:

## Art. 1 — Se a remissão do pecado é efeito da contrição.
O primeiro discute-se assim. ─ Parece que a remissão do pecado não é efeito da contrição.

1. ─ Pois, só Deus pode perdoar os pecados. Ora, da contrição nós somos de certo modo a causa, porque
é um ato nosso. Logo, a contrição não é a causa da remissão.

2. Demais. ─ A contrição é um ato de virtude. Ora, a virtude resulta da remissão do pecado, porque
virtude e culpa não podem coexistir na alma. Logo, a contrição não é a causa da remissão da culpa.

3. Demais. ─ Só a culpa nos impede de receber a Eucaristia. Ora, o contrito não deve, antes da contrição,
achegar-se à Eucaristia. Logo, ainda não recebeu a remissão da culpa.
Mas, em contrário, àquilo da Escritura Sacrifício para Deus é o espírito atribulado, etc. diz a Glosa: a
contrição do coração é o sacrifício pelo qual são perdoados os pecados.

2. Demais. ─ A virtude e o vício corrompem-se e geram-se pelas mesmas causas, como diz Aristóteles.
Ora, o pecado é cometido pelo amor desordenado do coração. Logo, pela dor causada e pelo amor
ordenado da caridade, é perdoado. E assim a contrição dele o pecado.

SOLUÇÃO. ─ A contrição pode ser considerada à dupla luz: como parte do sacramento ou como ato de
virtude. E de ambos os modos é causa da remissão do pecado, mas diversamente. Pois, como parte do
sacramento, primeiro contribui para a remissão dos pecados instrumentalmente, como se dá com os
outros sacramentos, segundo estabelecemos. Mas como ato de virtude, então, é a quase causa material
da remissão do pecado, pois, a disposição é de certo modo necessária à justificação; ora, a disposição se
reduz à causa material, entendendo-se por disposição a que dispõe a receber a matéria. Mas diferente é
a disposição do agente a agir, pois essa se reduz ao gênero da causa eficiente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Só Deus é a causa eficiente principal da remissão do
pecado; mas a causa dispositiva pode também estar em nós. E semelhantemente, a causa sacramental;
porque as formas dos sacramentos são as palavras por nós pronunciadas, que têm a virtude
instrumental de produzir a graça, pela qual são perdoados os pecados.

RESPOSTA À SEGUNDA. ─ A remissão do pecado a uma luz precede a virtude e a infusão da graça e, a
outra, é-lhes consecutiva. E enquanto consecutivo, o ato ilícito da virtude pode ser causa da remissão do
pecado.

RESPOSTA À TERCEIRA. ─ Dispensar a Eucaristia pertence aos ministros da Igreja. E portanto, antes da
remissão dos pecados pelos ministros da Igreja, ninguém deve se aproximar da Eucaristia, embora tenha
a sua culpa perdoada da parte de Deus.

## Art. 2 — Se a contrição pode delir totalmente o reato da pena.
O segundo discute-se assim. ─ Parece que a contrição não pode delir totalmente o reato da pena.

1. ─ Pois, a satisfação e a confissão se ordenam a liberar do reato da pena, ora, ninguém é de tal modo
contrito que não deva confessar e satisfazer. Logo, a contrição nunca é tanta que possa delir totalmente
o reato.

2. Demais. ─ Na penitência deve haver uma certa compensação entre a pena e a culpa. Ora, certas
culpas provêm dos membros do corpo. Logo, sendo necessário, para haver a recompensa devida à pena,
que, pelas causas em que alguém peca, por essas seja também atormentado, parece que nunca poderá
a pena de tal pecado ser absolvida pela contrição.

3. Demais. ─ A dor da contrição é finita. Ora, há certos pecados, como os mortais, merecedores de pena
infinita. Logo, de nenhum modo pode ser tão grande a contrição que possa apagar totalmente a pena.
Mas, em contrário, Deus aceita de preferência o afeto do coração, ao ato externo. Ora, pelos atos
externos somos absolvidos tanto da pena como da culpa. Logo e semelhantemente, pelo afeto do
coração, que é a contrição.

2. Demais. ─ Um exemplo para o caso em discussão nos é dado pelo ladrão, a quem foi dito: Hoje
estarás comigo no Paraíso, por causa de um único ato de penitência.
Quanto a saber se o reato é totalmente e sempre apagado pela contrição, já indagamos antes, quando
isso mesmo tratamos, a respeito da penitência.

SOLUÇÃO. ─ A intensidade da contrição pode ser considerada à dupla luz. ─ Primeiro, relativamente à
caridade, causa da displicência. ─ E assim pode ter o ato de caridade tal intensidade, que a contrição daí
resultante merecerá não só a remoção da culpa, mas também a absolvição de toda pena. ─ De outro
modo, relativamente à dor sensível, que a vontade excita na contrição. E sendo também essa e de certo
modo uma pena, pode ter uma intensidade tal que baste a apagar tanto a culpa como a pena.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Ninguém pode estar certo de ter uma contrição suficiente
a delir tanto a pena como a culpa Por isso estamos todos obrigados a confessar e a satisfazer; sobretudo
que a contrição não seria verdadeira sem ser acompanhada do propósito de confessar. O que deve ser
efetivado, mesmo por causa do preceito dado sobre a confissão.

RESPOSTA À SEGUNDA. ─ Assim como a alegria interior redunda também para as partes exteriores do
corpo, assim também a dor interior deriva para os membros exteriores. Donde dizer a Escritura: o
espírito triste seca os ossos.

RESPOSTA À TERCEIRA. ─ A dor da contrição embora finita quanto à intensidade ─ como também é
finita a pena devida ao pecado mortal ─ contudo tem virtude infinita, pela caridade que a informa. E
assim, pode contribuir para apagar a culpa e a pena.

## Art. 3 — Se uma pequena contrição basta para apagar grandes pecados.
O terceiro discute-se assim. ─ Parece que não basta uma pequena contrição para apagar grandes
pecados.

1. ─ Pois, a contrição é um remédio do pecado. Ora, um remédio material, suficiente para curar um mal
corpóreo menor, não basta para curar um maior. Logo, uma contrição mínima não basta para apagar
pecados máximos.

2. Demais. ─ Como se disse acima, e necessário termos contrição maior dos pecados maiores. Ora, a
contrição não apaga o pecado senão nas condições exigidas. Logo, uma contrição mínima não apaga
todos os pecados.
Mas em contrário. ─ Qualquer graça santificante dele totalmente a culpa mortal, que com ela não pode
coexistir. Ora, qualquer contrição é uma graça santificante informada. Logo, por pequena que seja, dele
todas as culpas.

SOLUÇÃO. ─ A contrição, como se disse muitas vezes, implica dupla dor. ─ Uma racional que é a
displicência do pecado cometido. E essa pode ser de tal modo pequena que não baste a ser o que por
natureza é a contrição; como p. ex, se desagradasse o pecado menos do que deve desagradar a
separação do fim. Assim, também o amor pode ser a tal ponto remisso que não baste a constituir a
caridade. ─ Outra é a dor sensível. E a fraqueza dessa não impede a existência da contrição; porque não
tem uma relação essencial com a contrição, mas lhe está anexa quase acidentalmente. E além disso, não
depende de nós. ─ Donde, pois, devemos concluir que por pequena que seja a dor, contanto que seja
suficiente a constituir a contrição, dele totalmente a culpa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Os remédios espirituais têm uma eficácia infinita por
causa da virtude infinita que neles opera. Por isso o remédio que basta a sanar um pequeno pecado
basta também a sanar um grande; talo batismo, que desata os grandes e os pequenos pecados. E o
mesmo se dá com a contrição, contanto que esta essencialmente exista.

RESPOSTA À SEGUNDA. ─ É consequêncía necessária tenhamos maior dor do pecado maior, que do
menor, pois aquele mais repugna ao amor, causa da dor. Mas quem tivesse de um pecado maior uma
dor tão grande quanto a nossa, de um pecado menor, isso lhe bastaria à remissão da culpa.