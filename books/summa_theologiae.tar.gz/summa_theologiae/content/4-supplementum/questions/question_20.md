# Questão 20: Daqueles sobre quem pode exercer-se o poder das chaves.
Em seguida devemos tratar daqueles sobre quem pode exercer-se o poder das chaves.
Nesta questão discutem-se três artigos:

## Art. 1 — Se o sacerdote pode exercer o seu poder das chaves sobre qualquer.
O primeiro discute-se assim. — Parece que o sacerdote pode exercer o seu poder das chaves sobre
qualquer.

1. Pois, o poder das chaves o sacerdote o tem daquela autoridade divina que disse: Recebei o Espírito
Santo; aos que vós perdoardes os pecados ser-lhes-ão perdoados. Ora, isso o disse
indeterminadamente, de todos. Logo, quem tem o poder das chaves pode usar dele
indeterminadamente sobre qualquer.

2. Demais. — Uma chave material que abre uma fechadura abre todas as da mesma forma. Ora, todos
os nossos pecados são, pela mesma razão, obstáculos para a nossa entrada no céu. Logo, podendo o
sacerdote absolver a um, em virtude do seu poder das chaves, poderá também absolver qualquer outro.

3. Demais. — O sacerdócio do Novo Testamento é mais perfeito que o do Antigo. Ora, o sacerdote do
Antigo Testamento podia exercer o poder de discernir entre lepra e lepra, indiferentemente em relação
a todos. Logo e com maior razão o sacerdote evangélico pode exercer o seu poder sobre todos.
Mas, em contrário, um cânone: A nenhum sacerdote é permitido ligar ou absolver o paroquiano de
outro. Logo, qualquer sacerdote não pode absolver a qualquer.

2. Demais. — O juízo espiritual deve ser mais ordenado que o temporal. Ora, no juízo temporal não
pode qualquer juiz julgar a qualquer. Ora, o uso do poder das chaves sendo o exercício de um juízo, não
pode um sacerdote qualquer exercer o seu poder das chaves sobre qualquer.

SOLUÇÃO. — O que deve ser aplicado a casos particulares não compete a todos do mesmo modo. Por
isso, assim como os médicos devem conhecer o meio de aplicar os preceitos gerais da medicina a cada
doente em particular, assim em qualquer governo é necessário haver quem aplique os preceitos
universais da lei a cada caso concreto. Eis porque a hierarquia celeste, abaixo das Potestades, que
governam indistintamente, vem os Principados, atribuídos a cada província em particular, e abaixo deles
os anjos, destinados à guarda de cada homem, conforme resulta do que dissemos no segundo livro. E o
mesmo deve passar no governo da Igreja militante, de modo que a certos caiba governar
indistintamente a todos; e abaixo desses exerçam outros um poder distinto sobre diversos. E como o
uso das chaves exige um poder superior, em virtude do qual aquele a quem é comunicado o uso delas
seja a matéria própria do ato do primeiro, por isso, quem tem indistintamente o poder sobre todos
pode exercer o das chaves sobre qualquer. Aqueles porém que, em dependência desse receberam
poderes distintos, não podem exercê-los sobre quaisquer, mas só sobre os que lhes caíram por sorte;
salvo em artigo de necessidade, quando a ninguém se devem negar os sacramentos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Para absolver do pecado é necessário um duplo poder: o
da ordem e o da jurisdição. O primeiro todos os sacerdotes o tem igualmente; mas não o segundo. Por
isso quando o Senhor deu em geral a todos os Apóstolos o poder de perdoar os pecados, entende-se por
esse poder o resultante da ordem. Daí aos sacerdotes se lhes dizerem as referidas palavras, quando se
ordenam. Mas a Pedro em particular deu o poder de perdoar os pecados; entendendo-se que tem ele,
de preferência aos outros, o poder de jurisdição. Quanto ao poder da ordem, dá por si mesmo a
faculdade de absolver a todos. Por isso o Senhor disse indeterminadamente — Aos que vós perdoardes
os pecados, entendendo contudo que o uso desse poder devia ser em dependência do que antes foi
conferido a Pedro, quando o Senhor mesmo o ordenou.

RESPOSTA À SEGUNDA. — Uma chave material não pode abrir senão a fechadura para a qual foi feita;
nem nenhuma virtude ativa pode agir senão sobre a matéria própria. Ora, uma pessoa se torna a
matéria própria do poder da ordem, pela jurisdição. Por isso ninguém pode exercer o poder das chaves
sobre quem não lhe foi dada jurisdição.

RESPOSTA À TERCEIRA. — O povo de Israel era um povo único e tinha um só templo. Por isso não era
necessário distinguir as jurisdições dos sacerdotes, como agora na Igreja, na qual se congregam diversos
povos e nações.

## Art. 2 — Se um sacerdote pode sempre absolver o seu súbdito.
O segundo discute-se assim. — Parece que um sacerdote nem sempre pode absolver um seu súbdito.

1. — Pois, como diz Agostinho, conforme a letra do Mestre, ninguém deve exercer as funções de
sacerdote se não estiver isento das faltas que censurar nos outros. Ora, pode acontecer ao sacerdote ser
cúmplice do crime praticado pelo súbdito; assim quando conheceu a mulher que lhe está subordinada.
Logo, parece que nem sempre pode exercer o poder das chaves sobre os seus súbditos.

2. Demais. — Pelo poder das chaves o homem é curado de todos os seus defeitos. Ora, às vezes a um
pecado vai anexo um defeito de irregularidade, ou uma sentença de excomunhão, de que o simples
sacerdote não pode absolver. Logo, parece que não pode exercer o poder das chaves sobre os que
andam enredados em tais irregularidades.

3. Demais. — O poder e o juízo do nosso sacerdócio foram figurados pelo juízo exercido pelo antigo
sacerdócio. Ora, aos juízos menores não compete resolver todos os casos, mas devem recorrer aos
superiores, conforme o determina a lei: Se sobrevier alguma disputa entre vós consultá-los-eis, Logo,
parece que também o sacerdote não pode absolver ao seu súdito, de pecados mais graves; mas deve
recorrer ao superior.
Mas, em contrário. — A quem é cometido o principal também o é o acessório. Ora, aos sacerdotes foi
cometido dispensar a Eucaristia aos seus súditos, e a isso se ordena a absolvição, que dão aos pecados, a
quem lhes pede. Logo, o sacerdote pode absolver o seu súdito, de todos os pecados, pelo poder das
chaves.

2. Demais. — A graça apaga todos os pecados, por pequena que seja. Ora, o sacerdote ministra os
sacramentos, mediante os quais é conferida a graça. Logo, pelo poder das chaves pode absolver de
todos os pecados.

SOLUÇÃO. — O poder da ordem, em si mesmo considerado, se estende à remissão de todos os pecados.
Mas como para o exercício desse poder é necessária a jurisdição, que desce do superior para o inferior,
por isso pode o superior reservar certos casos para si, que não confia ao juízo do seu inferior. Do
contrário, um simples sacerdote com a jurisdição de absolver poderia julgar de tudo.
Ora, há cinco casos em que está obrigado o simples sacerdote a remeter o penitente ao superior. —
Primeiro, quando é necessário impor uma penitência solene, porque o ministro próprio dela é o bispo.
— Segundo, quando se trata de excomungados, caso em que o sacerdote inferior não pode absolver. —
Terceiro, quando se acha em face de uma irregularidade, para cuja dispensa deve remeter o penitente
ao superior. — Quarto, em se tratando de incendiários. — Quinto, quando é costume, em certos
bispados reservar ao bispo os crimes de maior gravidade, para incutir medo; pois o costume dá ou tira
em tais casos o poder.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Em tal caso, não deve o sacerdote ouvir da mulher, com
quem pecou, a confissão do pecado dela, mas deve remetê-la a outro sacerdote. Nem deve ela lhe
confessar, mas pedir licença para fazê-lo com outro; ou recorrer ao superior, se lhe ele negar a licença
— quer por causa do perigo, quer pela menor vergonha que terá em confessar. Se porém esse sacerdote
a absolvesse, estaria absolvida. Quanto ao dito de Agostinho, que o sacerdote não o deve fazer, em se
tratando de crime em que é cúmplice, entende-se por conveniência e não corno de uma condição de
que dependa a validade do sacramento.

RESPOSTA À SEGUNDA. — A penitência remedeia a todas as misérias do pecado, não porém a todos os
sofrimentos da pena; pois, ainda depois de feita a penitência por um homicídio; permanece uma
irregularidade. Por isso o sacerdote pode absolver do crime, devendo porém remeter o penitente ao
superior, para perdoar a pena. Salvo na excomunhão, por que a absolvição dela deve preceder à do
pecado, pois, o ex-comungado não pode receber nenhum sacramento da Igreja.

RESPOSTA À TERCEIRA. — A objeção colhe quanto ao que os superiores tem o poder de reservar para si
à jurisdição.

## Art. 3 — Se pode alguém exercer o poder das chaves relativamente ao seu superior.
O terceiro discute-se assim. — Parece que ninguém pode exercer o poder das chaves relativamente ao
seu superior.

1. — Pois, qualquer ato sacramental supõe a matéria própria. Ora, a matéria própria do exercício das
chaves é a pessoa sujeita, como se disse. Logo, sobre quem não é súbdito não pode o sacerdote exercer
o poder das chaves.

2. Demais. — A Igreja militante imita a triunfante. Ora, na Igreja celeste o anjo inferior nunca purifica,
ilumina ou aperfeiçoa o superior. Logo, também nenhum sacerdote inferior pode exercer sobre o
superior a função hierárquica de absolver.

3. Demais. — O juízo da penitência deve ser mais ordenado do que o do foro externo. Ora, no foro
externo o inferior não pode excomungar ou absolver o superior. Logo, parece que nem no foro da
penitência.
Mas, em contrário. — O prelado superior também está cercado de enfermidade e sujeito ao pecado.
Ora, o remédio contra os pecados é o poder das chaves. Logo, não podendo ele exercer esse poder
sobre si mesmo, porque não pode ser simultaneamente juiz e réu, parece que pode o inferior exercer
sobre ele o poder das chaves.

2. Demais. — A absolvição feita pelo poder das chaves se ordena ao recebimento da Eucaristia. Ora, o
inferior pode dispensar a Eucaristia ao superior, se este a pedir. Logo, pode também exercer sobre ele o
poder das chaves, se se lhe submeter.

SOLUÇÃO. — O poder das chaves, em si mesmo considerado, se estende a todos, como se disse. Ora, o
não poder o sacerdote exercer o poder das chaves sobre uma determinada pessoa, resulta de ser o seu
poder especialmente limitado a certos. Por onde, quem o limitou pode estendê-lo sobre quem quiser.
Por isso também lhe pode dar o poder das chaves e a ele se submeter, embora ninguém possa exercer
sobre si mesmo esse poder; porque tal poder exige como matéria alguém que lhe esteja sujeito e assim,
uma pessoa diversa; pois, a si mesmo ninguém pode estar sujeito.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora o bispo, a quem o simples sacerdote absolve,
lhe seja superior, absolutamente falando, é-lhe contudo inferior enquanto se lhe submeteu como
pecador.

RESPOSTA À SEGUNDA. — Nos anjos não pode haver nenhum defeito em razão do qual os superiores
venham a sujeitar-se aos inferiores, como acontece com os homens. Por onde, o símile não colhe.

RESPOSTA À TERCEIRA. — O juízo exterior é estabelecido pelos homens; mas o da confissão concerne a
Deus, perante quem se torna menor quem peca, o que não se dá na hierarquia da justiça humana. Por
isso, no juízo exterior, como ninguém pode proferir contra si mesmo sentença de excomunhão, também
não pode fazer-se ex-comungado por outro. Mas no foro da consciência pode confiar a outro a sua
absolvição, pela não poder a si mesmo se dar. — Ou devemos dizer que a absolvição no foro da
confissão pertence principalmente ao poder das chaves e, por conseqüência, respeita a jurisdição; ao
passo que a excomunhão respeita totalmente a jurisdição. Quanto porém ao poder da ordem, todos são
iguais, mas não quanto à jurisdição. Logo, a comparação não colhe.