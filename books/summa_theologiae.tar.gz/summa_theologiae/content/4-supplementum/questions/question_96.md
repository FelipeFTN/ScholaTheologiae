# Questão 96: Das auréolas.
Em seguida devemos tratar das auréolas.
E nesta questão discutem-se treze artigos:

## Art. 1 — Se a auréola é um prêmio diferente do prêmio essencial chamado coroa de ouro.
O primeiro discute-se assim. ─ Parece que a auréola não é nada de diferente do prêmio essencial
chamado coroa de ouro.

1. Pois, o prêmio essencial é a própria beatitude. Ora, a felicidade, segundo Boécio, é o estado perfeito
pela reunião de todos os bens. Logo, o prêmio essencial inclui todos os bens possuídos na pátria. E
assim, a auréola está incluída na coroa de ouro.

2. Demais. ─ O mais e o menos não diversificam a espécie. Ora, os que observam os conselhos e os
preceitos são mais premiados que os que só observam os preceitos; nem em nada lhes difere o prêmio,
senão por maior um que o outro. Logo, como já a auréola designa o prêmio devido às obras de
perfeição, parece que ela nada tem de distinto da coroa de ouro.

3. Demais. ─ O prêmio corresponde ao mérito. Ora, a raiz de todo mérito é a caridade. Logo, como à
caridade corresponde a coroa de ouro, parece que na pátria não haverá outro prêmio distinto deste.

4. Demais. ─ Todos os bem-aventurados são admitidos nas ordens dos anjos, como diz Gregório. Ora,
entre os anjos, embora alguns possuam certos dons de um modo eminente, nada há porém que não
seja comum a todos; pois tudo existe em todos, embora não igualmente, porque os dons que todos têm
uns os tem de modo mais sublime que os outros, como também diz Gregório. Logo, todos os bem-
aventurados outro prêmio não terão além do comum a todos. Portanto, a auréola não é um prêmio
distinto da coroa de ouro.

5. Demais. ─ A um mérito mais excelente mais excelente prêmio é devido. Se, pois, uma coroa de ouro é
devida às obras de preceito, e uma auréola às de conselho, a auréola será mais perfeita que a coroa de
ouro e, portanto, esta não devia ter uma significação diminutiva. Logo, parece que a auréola não é um
prêmio distinto da coroa de ouro.
Mas, em contrário, àquilo da Escritura ─ Farás sobre esta outra pequena coroa de ouro, diz a Glosa: A
essa coroa cabe a honra do cântico novo, que só as virgens cantam na presença do Cordeiro. Donde se
conclui que a auréola é uma coroa concedida, não a todos, mas a certos em especial. Ao passo que a
coroa de ouro é concedida a todos os bem-aventurados. Logo, a auréola difere da coroa de ouro.

2. Demais. ─ A luta sucedida da vitória é devida uma coroa de ouro; pois, conforme aquilo do Apóstolo,
não será coroado senão quem combateu conforme à lei. Logo, a luta que se reveste de um caráter
particular merece uma coroa especial. Logo, devem receber uma coroa diferente da das outras, e a essa
chamamos auréola.

3. Demais. ─ A Igreja militante descende da triunfante, conforme àquilo do Apocalipse: Vi a cidade santa,
a nova Jerusalém, descendo do céu, etc. Ora, na Igreja militante aos que praticam obras especiais dão-se
prêmios especiais; ao passo que aos vencedores se confere a coroa, prêmio dos que correm. Logo, o
mesmo deve dar-se na Igreja triunfante.

SOLUÇÃO. ─ O prêmio essencial do homem, que é a sua felicidade, consiste na perfeita união da alma
com Deus, pelo : gozar perfeitamente contemplando-o e amando-o. E este prêmio se chama, em
sentido metafórico coroa ou coroa de ouro. Quer por causa do mérito, que se ganha depois de uma
certa luta, conforme aquilo da Escritura ─ A vida do homem sobre a terra é uma guerra; quer também
por causa do prêmio, que nos torna de certo modo participantes da divindade e, por consequência, do
poder real, segundo o Apocalipse: Tem-nos feito para o nosso Deus reino etc. Ora, á coroa é o sinal
próprio do poder real. E pela mesma razão o prêmio acidental, acrescentado ao essencial, deve ser uma
espécie de coroa. Pois, a coroa significa uma perfeição por causa da sua natureza circular; sendo por isso
também apropriada à perfeição dos bem-aventurados. Mas, como ao essencial nada se lhe pode
acrescentar, que não lhe seja inferior, por isso o prêmio acrescentado se chama auréola. Ora, ao prêmio
essencial chamado coroa de ouro pode se fazer duplo acréscimo: um fundado na condição da natureza
do premiado, e assim à felicidade da alma se lhe acrescenta a glória do corpo, donde o chamar-se às
vezes auréola a glória do corpo. Por isso aquilo da Escritura ─ Farás sobre esta outra pequena coroa de
ouro, diz uma Glosa que ao fim se superpõe a auréola, pois, conforme a Escritura, os eleitos terão uma
glória mais sublime quando reassumirem o corpo. Mas não é neste sentido que agora tratamos da
auréola. ─ De outro modo pode a coroa de ouro receber um acréscimo em razão da obra meritória. Esse
mérito tem uma dupla raiz donde também lhe procede a sua bondade. Uma é a caridade, porque
concerne ao fim último, sendo-lhe por isso devido o prêmio essencial, i. é, a consecução do fim último,
chamado coroa de ouro. Outra é o gênero mesmo do ato, digno de um certo louvor pelas circunstâncias
que o rodeiam, pelo hábito donde nasce e pelo fim próximo: e por isso lhe é devido o prêmio acidental
chamado auréola. E é neste sentido que agora tratamos da auréola. Donde, pois, devemos concluir que
a auréola significa algo de acrescentado à coroa de ouro, i. é, certa alegria pelas obras que praticamos, e
que se revestem do aspecto de uma vitória excelente; alegria diversa da pela qual nos comprazemos da
união com Deus, gáudio esse que se chama coroa de ouro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A felicidade inclui em si todos os bens necessários à
perfeita vida do homem, consistente na sua atividade perfeita. Mas é susceptível de certos acréscimos,
não quase necessários a essa atividade perfeita, como se sem eles não pudesse ela existir; mas por lhe
concorrerem para o maior esplendor. Constituem, assim, a felicidade na sua essência plena e um como
ornato dela. Do mesmo modo que a beatitude temporal se adorna com a nobreza do nascimento, a
beleza do corpo e dotes semelhantes, sem os quais não pode existir, como diz Aristóteles. E assim está a
auréola para a beatitude da pátria.

RESPOSTA À SEGUNDA. ─ Quem observa os conselhos e os preceitos sempre merece mais que quem só
observa os preceitos, desde que se considere a razão do mérito relativamente no gênero das obras. Mas
nem sempre, se se atende à razão do mérito relativamente à caridade em que se ele radica; pois, pode
um observar somente os preceitos mas com caridade maior que a de outro que, além deles, observa
também os conselhos. No mais das vezes porém se dá o contrário, porque a prova do amor é a obra
feita, como diz Gregório. Não é, logo, o prêmio essencial mesmo, mas mais intenso, que se chama
auréola, mas o que se acrescenta ao prêmio essencial, sendo indiferente se o prêmio essencial de quem
recebe a auréola é maior, menor ou igual ao prêmio essencial de quem não na tem.

RESPOSTA À TERCEIRA. ─ A caridade é o princípio primeiro do mérito; mas os nossos atos são como os
instrumentos pelos quais merecemos. Ora, para conseguirmos um efeito, não só é necessário tenha o
motor primeiro a disposição devida, mas também que o instrumento esteja bem disposto. Por isso, todo
efeito implica dois elementos ─ a parte do princípio primeiro, que é a principal; e o que provém do
instrumento, que é o elemento secundário. Assim, também no prêmio: uma é a parte da caridade ─ a
coroa de ouro; outra, a do gênero da obra ─ a auréola.

RESPOSTA À QUARTA. ─ Todos os anjos mereceram a sua beatitude por atos do mesmo gênero, i. é, por
se terem convertido para Deus; por isso não tem nenhum qualquer prêmio particular que de certo
modo também não tenham os outros. Ao passo que os homens merecem a felicidade por atos de
diversos gêneros; e portanto não há símil. ─ Contudo, o que um dentre os homens tem de maneira
especial, de certo modo também todos o tem em comum, enquanto que, pela caridade perfeita, cada
qual considera seu o bem de outrem. Entretanto, esse gáudio pelo qual um se alegra com os outros, não
pode chamar-se auréola; porque não lhe é dado como prêmio de vitória sua, mas antes, da vitória
alheia. Assim também a coroa é dada aos vitoriosos, e não aos que se comprazem com a vitória.

RESPOSTA À QUINTA. ─ Maior é a excelência do mérito resultante da caridade, que a procedente do
gênero do ato. Assim, o fim, a que se a caridade ordena, prevalece sobre os meios, que são o objeto
próprio dos nossos atos. Por onde, o prêmio correspondente ao mérito fundado na caridade, por
pequeno que seja, é maior que qualquer prêmio correspondente a um ato em razão do seu gênero. Por
isso a auréola se diz como um diminutivo de áurea coroa.

## Art. 2 — Se a auréola difere do fruto.
O segundo discute-se assim. ─ Parece que a auréola não difere do fruto.

1. ─ Pois, ao mesmo mérito não podem ser devidos prêmios diversos. Ora, ao mesmo mérito
corresponde a auréola e o fruto do cêntuplo, i. é, o da virgindade, como o diz a Giosa a um lugar do
Evangelho. Logo, a auréola é o mesmo que o fruto.

2. Demais. ─ Agostinho diz, que o fruto centuplicado é o devido ao mártir. Ora, também esse mesmo
fruto é devido à virgem. Logo, o fruto é um prêmio comum às virgens e aos mártires. Mas também a
eles lhes é devida a auréola. Logo, a auréola é o mesmo que o fruto.

3. Demais. ─ Na beatitude só há dois prêmios ─ o essencial e o acidental, acrescentado ao essencial. Ora,
esse prêmio acrescentado ao essencial é o que se chama auréola, como se conclui de um lugar da
Escritura onde se fala da auréola acrescentada à coroa de ouro. Ora, o fruto não é um prêmio essencial,
porque, se o fosse, seria devido a todos os bem-aventurados. Logo, é o mesmo que a auréola.
Mas, em contrário, ─ Coisas que não tem a mesma divisão também não têem a mesma razão de ser.
Ora, o fruto e a auréola não tem a mesma divisão; pois, aquela se divide em auréola das virgens, dos
mártires e dos doutores; ao passo que os frutos são os dos casados, das viúvas e das virgens. Logo, o
fruto e a auréola não são idênticos.

2. Demais. ─ Se fruto e auréola fossem o mesmo, a quem fosse devido o fruto sê-lo-ia também a
auréola. Ora, isto é evidentemente falso, pois, o fruto é devido à viuvez, mas não a auréola. Logo, etc.

SOLUÇÃO. ─ Palavras tomadas em sentido metafórico são susceptíveis de várias acepções, conforme as
suas aplicações às diversas propriedades do objeto onde essas palavras derivaram. Ora, na ordem
natural, fruto propriamente é o que nasce da terra. Donde, segundo as diversas condições em que
possam encontrar-se os frutos da terra, assim as diversas acepções dos frutos espirituais. Ora, o fruto da
terra tem uma doçura nutritiva, e por isso os homens usam dele. E também a produção última a que
chega a obra da natureza. E é enfim o que o agricultor espera pelo semear ou de quaisquer outros
modos.
Outras vezes, porém, o fruto é tomado em sentido espiritual, pelo último fim, em que descansamos.
Assim, dizemos ─ fruir de Deus ─ perfeitamente, na pátria; imperfeitamente, neste mundo. Desse
sentido, deriva a fruição, que é um dote. Mas não é neste sentido que agora tratamos dos frutos.
Outras vezes ainda, o fruto é tomado em sentido espiritual, para significar que refazem a alma com a
pureza da sua doçura, na expressão de Ambrósio. Tal o sentido dessa palavra no lugar seguinte do
Apóstolo: Mas o fruto do espírito é a caridade, o gozo, etc. E neste sentido também tratamos aqui dos
frutos.
Mas podemos também tomar a palavra fruto em sentido espiritual, por semelhança com os frutos da
terra. E assim como estes são o proveito esperado do trabalho da agricultura, fruto também se chama o
prêmio que o homem colhe dos seus trabalhos nesta vida. E então todo o prêmio que recebermos na
vida futura, dos nossos trabalhos, chama-se fruto. Tal o sentido desse vocábulo no lugar seguinte do
Apóstolo: Tendes o vosso fruto em santificação e por fim a vida eterna. E ainda este não é o sentido em
que agora empregamos a palavra fruto.
Mas do fruto tratamos como significando o que nasce da semente; é assim que o Senhor entende o
fruto, quando se refere à semente que produz trinta, sessenta e cem por um. Ora, nesta acepção, o
fruto pode provir da semente, porque tem ela uma virtude eficaz para converter os humores da terra na
sua natureza; e quanto mais eficiente for essa virtude e a terra melhor amanhada, tanto mais rica será a
frutificação. Ora, a semente espiritual semeada em nós é a palavra de Deus. Por onde, quanto mais
espiritual e afastada da carne for a vida que vivermos, tanto mais frutos produzirá em nós a palavra
divina. Neste sentido, pois, o fruto difere da coroa de ouro e da auréola, porque a coroa de ouro
consiste na alegria com a posse de Deus; a auréola no gáudio com as obras de perfeição; mas os frutos,
o gáudio que tem o agente com o seu próprio ato, conforme o grau de espiritualidade a que ascendeu
por virtude da semente da palavra de Deus.
Certos porém distinguem entre a auréola e o fruto, dizendo que a auréola é devida ao lutador, segundo
aquilo do Apóstolo: Não será coroado senão quem combater conforme à lei. Ao passo que o fruto é o
resultado de quem trabalha, segundo o lugar da Escritura: O fruto dos bons trabalhos é glorioso. Mas
outros pretendem que a coroa de ouro respeita a conversão para Deus; ao passo que a auréola e o fruto
são meios para a consecução do fim, mas de modo que o fruto respeita mais principalmente a vontade,
enquanto que a auréola concerne antes o corpo.
Mas como o trabalho e o combate tem um só e mesmo objeto e são considerados na mesma relação, e
o prêmio do corpo depende do da alma, de acordo com a opinião supra-referida não haveria distinção,
entre fruto, coroa de ouro e auréola, senão lógica. O que não pode ser, pois, a certos se atribuem frutos,
a que não se atribui a auréola.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Não há inconveniente em atribuir prêmios diversos a um
mesmo mérito, conforme os elementos diversos que ele encerra. Assim, à virgindade corresponde a
coroa de ouro, quando conservada por amor de Deus e sob o império da caridade; a auréola porém,
enquanto obra de perfeição equiparável a uma vitória excelente; o fruto enfim, porque a virgindade alça
o homem a um como estado espiritual, afastando-o da carnalidade.

RESPOSTA À SEGUNDA. ─ O fruto, na sua acepção própria, em que agora o tomamos, não significa um
prêmio comum ao martírio e à virgindade, mas aos três graus de continência. Quanto à Glosa citada,
que considera o fruto centuplicado como devido aos mártires, toma o fruto em sentido lato, em que a
toda remuneração se dá esse nome. Assim, o fruto centuplicado designa a remuneração devida a
quaisquer obras de perfeição.

RESPOSTA À TERCEIRA. ─ Embora a auréola seja um prêmio acidental acrescentado ao essencial,
contudo nem todo prêmio acidental é auréola; mas só o prêmio devido às obras de perfeição, pelas
quais o homem se conforma soberanamente com Cristo, pela vitória perfeita. Não há, pois, nenhum
inconveniente em que possa merecer um prêmio acidental quem se absteve da vida carnal, prêmio que
se chama fruto.

## Art. 3 — Se o fruto é devido à só virtude da continência.
O terceiro discute-se assim. ─ Parece que o fruto não é devido à só virtude da continência.

1. ─ Pois, aquilo do Apóstolo ─ Uma é a claridade do sol, etc., diz a Glosa: A claridade do sol é
comparável a dignidade dos que receberam sessenta vezes mais; e enfim à das estrelas a dos que
receberam trinta vezes mais. Mas, essas diversas claridades, no pensamento do Apóstolo, se referem a
todos os graus de beatitude. Logo, os diversos frutos não devem corresponder à só virtude da
continência.

2. Demais. ─ Fruto vem de fruição. Ora; à fruição concerne ao prêmio essencial, correspondente a todas
as virtudes. Logo, etc.

3. Demais. ─ O fruto é devido ao trabalho, segundo aquilo da Escritura: O fruto dos bons trabalhos é
glorioso. Ora, maior trabalho custa a fortaleza que a temperança ou a continência. Logo, o fruto não
corresponde só à continência.

4. Demais. ─ É mais difícil não exceder no uso dos alimentos, que são necessários à vida, do que no das
relações sexuais, sem o que não pode conservar-se a vida. Portanto, maior esforço exige a parcimônia
que a continência. Logo, à parcimônia corresponde, mais que à continência, o fruto.

5. Demais. ─ Fruto implica a idéia de repouso. Ora, o repouso é no fim que se perfaz. Logo, como as
virtudes teologais tem como objeto o fim, que é o próprio Deus, parece que a eles devem sobretudo
corresponder os frutos.
Mas, em contrário, a Glosa a um lugar do Evangelho, atribui os frutos à virgindade, à viuvez e à
continência conjugal, que são partes da continência.

SOLUÇÃO. ─ O fruto é um prêmio devido ao homem quando deixa a vida carnal pela espiritual. Por isso
aquela virtude sobretudo corresponde o fruto, que principalmente livra a alma da sujeição à carne. Ora,
tal é o efeito da continência porque é sobretudo pelos prazeres sensuais que a alma se escraviza à
carne; a ponto de, conforme Jerônimo, no ato carnal o Espírito de profecia não tocar o coração dos
profetas, nem, como o ensina o Filósofo, ser possível, sob o império do prazer venéreo, exercer-se a
inteligência. Por onde à continência mais responde o fruto que às outras virtudes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A Glosa citada toma a palavra fruto na sua acepção lata,
pela qual toda remuneração se chama fruto.

RESPOSTA À SEGUNDA. ─ Fruição não deriva de fruto, por aquela semelhança fundada no fruto na
acepção em que ora o consideramos.

RESPOSTA À TERCEIRA. ─ O fruto, na acepção em que agora o tomamos, não corresponde ao trabalho,
em razão da fadiga que ele causa, mas por ser o meio pelo qual as sementes frutificam. Donde o chamar
o Evangelho trabalhos às próprias sementeiras, porque são elas o alvo do trabalho ou são conseguidas
pelo trabalho. Quanto à semelhança do fruto, enquanto nascido da semente, mais se aplica à
continência que à fortaleza, porque as paixões, sobre as quais a fortaleza se exerce, não escravizam o
homem à carne, como as sobre que versa a continência.

RESPOSTA À QUARTA. ─ Embora os prazeres da mesa sejam mais necessários que os venéreos, não são
contudo igualmente veementes. Por isso não escravizam o homem à carne.

RESPOSTA À QUINTA. ─ Fruto aí não se toma no sentido em que se diz que quem frui repousa no fim,
mas noutro sentido referido. Por isso a objeção não colhe.

## Art. 4 — Se acertadamente se atribuem três frutos às três partes da continência.
O quarto discute-se assim. ─ Parece que não se atribuem acertadamente três frutos às três partes da
continência.

1. ─ Pois, o Apóstolo enumera doze frutos do espírito: A caridade, a alegria, a paz, etc. Logo, não se
devem enumerar só três.

2. Demais. ─ Fruto designa um prêmio especial. Ora, o prêmio atribuído às virgens, às viúvas e aos
casados não é um prêmio especial. Pois, todos os que hão de salvar-se estão incluídos numa dessas três
classes; porque ninguém se salva sem ter praticado a continência, e esta se divide suficientemente pelas
três classes referidas. Logo, não se atribuem com acerto três frutos a essas três classes.

3. Demais. ─ Assim como a viuvez excede à continência conjugal, assim a virgindade à viuvez. Ora, quem
recebeu o fruto centuplicado não excede quem o recebeu trinta vezes mais, como o que o recebeu
centuplicado excede o que recebem sessenta vezes mais. Nem por proporção aritmética, porque
sessenta excede a trinta em trinta, e cem excede em quarenta a sessenta. Nem por proporção
geométrica, porque sessenta excede a trinta na proporção de dois para quatro, ao passo que cem está
para sessenta como cinco para dois, porque contém sessenta mais duas terças partes deste número.
Logo, não é acertado fazer corresponder os frutos aos três graus de continência.

4. Demais. ─ O que está dito na Sagrada Escritura deve durar sempre, conforme aquilo do Evangelho:
Passará o céu e a terra, mas as minhas palavras não passarão. Ao contrário, todas as obras feitas pelo
homem podem mudar a cada passo. Logo, nas obras humanas não devemos buscar um critério para
apreciar os ditos da Sagrada Escritura. E assim parece inadmissível o fundamento dado por Beda aos
referidos frutos, dizendo que o fruto de trinta por um é devido aos casados, porque na representação
do ábaco, trinta é expresso pelo contato das pontas do polegar e do índex, que por assim dizer se
beijam. E assim o número trinta significa os ósculos dos casados. Ao passo que o número sessenta é
expresso pelo contato do índex com a articulação média do polegar; e assim o índex, sobre o polegar e
apertando-o, significa a opressão que as viúvas sofrem neste mundo. Mas, quando na numeração
chegamos ao número cem, passamos do lado direito para o esquerdo; por isso o número cem designa a
virgindade, porque participa da dignidade dos anjos, que estão à direita, i. é, na glória; enquanto que
nós outros estamos à esquerda, por causa da imperfeição desta vida.

SOLUÇÃO. ─ Pela continência, a que corresponde um fruto, o homem, desprezando os prazeres da
carne, eleva-se a um estado de espiritualidade. Por onde, conforme os diversos graus de espiritualidade
produzidos pela continência, assim se distinguem os diversos frutos. Ora, há uma espiritualidade
necessária e outra superabundante. ─ A espiritualidade necessária consiste em a retidão do espírito não
ser pervertida pelos prazeres carnais; e isso se dá quando buscamos os prazeres da carne segundo a
ordem reta da razão. E esta é a espiritualidade dos casados. ─ A espiritualidade superabundante é a pela
qual o homem se abstém completamente de todos os prazeres carnais, que impedem a liberdade do
espírito. O que de dois modos pode ser. ─ Ou absolutamente, em qualquer tempo ─ passado, presente
ou futuro; e esta é a espiritualidade das virgens. ─ Ou num tempo determinado e essa é a das viúvas.
Assim, pois, os que observam à continência conjugal é dado o fruto de trinta por um: à da viuvez, o de
sessenta por um; e à virginal, o de cem por um, pela razão que dá Beda, supra-referida.
Embora possamos ainda dar a razão seguinte, fundada em a natureza dos números. ─ Pois, o número
trinta resulta da multiplicação de três por dez. Ora, o número três é o número de todas as cousas, diz
Aristóteles; e tem em si a perfeição de princípio, de meio e de fim, comum a todos os seres. Por isso o
número trinta é acertadamente atribuído aos casados, que, além da observação do Decálogo,
significado pelo número dez, não tem nenhuma outra perfeição senão a comum, sem a qual não pode
haver salvação. ─ O número seis, que multiplicado por dez produz cem, tem uma perfeição resultante
das suas partes, pois, as tem todas simultaneamente unidas. Por isso corresponde com conveniência à
viuvez, que implica a completa abstenção dos prazeres da carne com todas as suas circunstâncias, que
são como partes do ato virtuoso. Pois, a viuvez se opõe ao gozo do prazer carnal, seja com que pessoa
for e em qualquer lugar que seja; e assim quanto às outras circunstâncias. O que não se dá com a
continência conjugal. ─ Mas o número cem convém convenientemente à virgindade; porque o número
dez, de cuja multiplicação resulta o número cem, é o limite da espiritualidade, porque nada mais de
espiritual se lhe pode acrescentar. Pois, o número cem, como número quadrado, é, pela sua figura, um
número perfeito. Porque a figura do quadrado é perfeita por, sendo igual de todos os lados, ter uma
igualdade total. Por isso corresponde à virgindade, que permanece incorrupta igualmente em todo
tempo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ No lugar citado a palavra fruto não tem o mesmo sentido
no em que agora dele nos ocupamos.

RESPOSTA À SEGUNDA. ─ Nada obriga a admitir o fruto como um prêmio não comum a todos os que se
salvam. Pois, não só o prêmio essencial é comum a todos, mas também certas recompensas acidentais,
como a alegria resultante das obras sem as quais não pode haver salvação. ─ Pode-se porém dizer que
os frutos não convém a todos os que devem salvar-se, como o demonstram os que, depois de terem
vivido na incontinência; fizeram penitência no fim da vida; pois a esses não é devido o fruto, mas só o
prêmio essencial.

RESPOSTA À TERCEIRA. ─ A distinção dos frutos se funda, antes, nas espécies e nas figuras dos números,
que nas quantidades que representam. Contudo, mesmo considerando-lhes essas quantidades é
possível descobrir uma razão de excesso entre eles. Assim o casado só se abstém da mulher que não é a
sua; a viúva, porém, do seu marido e do que não é seu; e assim há aí um certo excesso em dobro, como
sessenta é o dobro de trinta. Quanto ao número cem, excede a sessenta em quarenta, resultando este
da multiplicação de quatro por trinta. Ora, o número quatro é o primeiro número sólido e cúbico. E
assim, uma tal adição convém à virgindade, que acrescenta à perfeição da viuvez a perpétua
incorrupção.

RESPOSTA À QUARTA. ─ Embora esse modo referido de representar os números seja de instituição
humana, contudo se funda de certo modo em a natureza das cousas, pois os números são designados
gradualmente pela ordem dos dedos, das articulações.

## Art. 5 — Se a auréola é devida à virgindade.
Parece que a auréola não é devida à virgindade.

1. ─ Pois, quanto mais difícil é uma obra tanto maior prêmio merece. Ora, maior dificuldade têem as
viúvas em se absterem dos prazeres carnais, que as virgens; e Jerônimo diz, que quanto maiores
dificuldades sofre um em se abster de prazeres ilícitos, tanto maior é o prêmio, e isso o diz quando faz o
elogio da viuvez. E o Filósofo também ensina, que a mulher que já não é virgem tem mais veemente
desejo carnal pela imaginação do prazer gozado. Logo, a auréola, que é o máximo dos prêmios, é devido
antes às viúvas que às virgens.

2. Demais. ─ Se à virgindade fosse devida a auréola, à perfeitíssima das virgindades seria devida a
máxima das auréolas. Ora, a virgindade da S.S. Virgem é de todas a mais excelente, sendo por isso
chamada a Virgem das virgens. E contudo não lhe é devida nenhuma auréola, porque não lhe custou
nenhuma luta a continência, pois não foi contaminada pela corrupção da concupiscência. Logo, à
virgindade nenhuma auréola é devida.

3. Demais. ─ O que não é digno, em todo tempo, de louvor não lhe é devido um prêmio excelente. Ora,
não seria digno de louvor conservar a virgindade no estado da inocência primitiva, porque então era de
preceito o crescei e multiplicai-vos e enchei a terra. Mas também não o seria sob a vigência da Lei, que
amaldiçoava as estéreis. Logo, nenhuma auréola é devida à virgindade.

4. Demais. ─ Não é devido o mesmo prêmio à virgindade conservada e à perdida. Ora, à virgindade
perdida é às vezes devida uma auréola; assim, se uma virgem foi, contra a sua vontade, prostituída por
um tirano, por ter confessado o nome de Cristo. Logo, nenhuma auréola é devida à virgindade.

5. Demais. ─ Prêmio excelente não é devido ao que por natureza o temos. Ora, virgem todo indivíduo o
é quando nasce, bom ou mau. Logo, a auréola não é devida à virgindade.

6. Demais. ─ Assim está a viuvez para o fruto de sessenta por um, como a virgindade para o de cem por
um e para a auréola. Ora, não a qualquer viúva é devido o fruto de sessenta por um, mas só a que fez
voto de viuvez, como certos dizem. Logo, parece que também não é devida a auréola a qualquer virgem,
mas só à virgindade observada por voto.

7. Demais. ─ Um prêmio não pode ser necessariamente conferido porque todo mérito depende da
vontade. Ora, alguns são necessariamente virgens, como os impotentes e os eunucos. Logo, nem
sempre é devida a auréola à virgindade.
Mas, em contrário, aquilo da Escritura ─ Farás sobre esta outra pequena coroa de ouro ─ diz a Glosa: A
essa coroa concerne o cântico novo que as Virgens cantam na presença do Cordeiro, i. é, os que seguem
o Cordeiro para onde quer que ele vá. Logo, o prêmio devido à virgindade se chama auréola.

2. Demais. ─ A Escritura diz: Eis aqui o que diz o Senhor aos eunucos. E acrescenta: Dar-lhe-eis um nome
ainda melhor do que o que dão os filhos e as filhas. Ao que diz a Glosa: Significa uma glória própria e
excelente. Ora, os eunucos, que a si mesmo se castraram por amor do reino dos céus, designam as
virgens. Donde portanto se colhe que à virgindade é devido um prêmio excelente, e chamado auréola.

SOLUÇÃO. ─ A quem ganhou uma vitória sobreexcelente lhe é devida uma coroa especial. Ora, pela
virgindade ganhamos uma vitória excepcional sobre a carne, contra a qual temos luta constante,
conforme aquilo do Apóstolo ─ o espírito deseja contra a carne, etc. Por isso à virgindade é devida uma
coroa especial chamada auréola. E isto todos em geral admitem. Mas a que espécie de virgindade seja
devida a auréola, nem todos o explicam do mesmo modo.
Assim, uns dizem que a auréola é devida à virgindade atualmente observada. Por onde, aquela que
atualmente observa a virgindade terá uma auréola, se for do número dos que hão de salvar-se. ─ Mas
isto não é admissível. Porque então as que tinham vontade de casar, mas morreram antes de o poder
fazer, teriam auréola.
Por isso dizem outros que a auréola é devida ao estado e não ao ato; de modo que só merecem a
auréola de virgem as que se comprometeram por voto a viver em estado de perpétua virgindade. ─ Mas
também isto não é admissível, porque por um mesmo ato de vontade pode um conservar a virgindade
sem fazer voto dela e outra, tendo-o feito.
Por onde podemos, de outro modo, dizer que o mérito a todo ato de virtude é devido quando praticado
sob o império da caridade. Ora, a virgindade constitui genericamente um ato de virtude, enquanto
resulta de uma eleição a incorrupção perpétua da alma e do corpo, como se colhe do sobre dito. Por
onde, só aqueles propriamente é devida a auréola de virgem que tiveram o propósito de conservar
perpetuamente a virgindade, quer confirmassem esse propósito por voto, quer não. E isto digo,
considerando-se a auréola no seu sentido próprio, como um prêmio retribuído ao mérito; embora esse
propósito ter sido quebrado, contanto que a integridade do corpo perdure até o fim da vida, porque se
a virgindade da alma pode separar-se, não o pode a do corpo.
Se porém tomarmos a virgindade em sentido lato, por qualquer prêmio que na pátria tenhamos, além
do prêmio essencial, então aos de corpo incorrupto será devida a auréola, mesmo se não formaram o
propósito de viver em perpétua virgindade. Pois, não há nenhuma dúvida que os virgens se alegrarão
por ter conservado um corpo incorrupto, assim como os inocentes por terem sido imunes do pecado,
embora pudessem não ter a oportunidade de o cometer, como no caso das crianças batizadas. Esta não
é porém a acepção própria, mas a comum da auréola.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Praticando a continência sustentam luta maior, de certo
modo, as virgens, e de certo outro, as viúvas, em igualdade de condições. Assim, as virgens a
concupiscência as inflama bem como o desejo da experiência, que procede de uma certa curiosidade,
que nos leva a ver de melhor grado o que nunca vimos. Além disso, aumenta-lhes a concupiscência o
imaginar um prazer maior que o da realidade, sem levar em conta os incômodos que acompanham ao
prazer da carne. E por aí as viúvas sustêm luta menor; maior, porém, pela lembrança dos prazeres que já
gozaram. Demais, nos diversos indivíduos, essas cousas podem se neutralizar umas às outras, segundo
as diversas disposições e condições de cada um. Assim, uns são movidos de preferência por uma causa e
outros, por outra. Seja porém o que for da intensidade da luta, uma cousa é certa: mais perfeita é a
vitória das virgens que a das viúvas; pois, o perfeitíssimo gênero de vitória e o mais belo é nunca ter
cedido ao inimigo. Ora, a coroa não é devida à luta, mas à vitória depois da luta.

RESPOSTA À SEGUNDA. ─ Há, nesta matéria, dupla opinião. ─ Uns dizem que a S.S. Virgem não tem
auréola, como prêmio da virgindade, tomando-se auréola no sentido próprio, no qual supõe a luta. Tem
contudo mais que a auréola, pelo seu perfeitíssimo propósito de conservar a virgindade. ─ Outros porém
dizem que tem uma auréola, e excelentíssima, mesmo considerando a auréola no seu sentido próprio.
Pois, embora não experimentasse nenhuma luta, teve contudo alguma luta da carne, mas a grandeza da
sua virtude trazia-lhe a carne de tal modo submissa, que era insensível a tais lutas. Mas esta opinião é
inadmissível. Porque, crendo que a S.S. Virgem foi totalmente imune da inclinação da concupiscência,
pela sua santidade perfeita, encontra a piedade admitir que tivesse qualquer luta com a carne; pois,
essa luta não é senão por causa da inclinação da concupiscência de um lado, e, de outro, pode a
tentação da carne ser desacompanhada de pecado, como se vê pela Glosa aquilo do Apóstolo ─ Permitiu
Deus que eu sentisse na carne um estímulo, etc. ─ Por onde, devemos responder que a S.S. Virgem tem
propriamente uma auréola, conformando-se assim a todos os outros membros da Igreja, que foram
virgens. E embora não tivesse de sustentar nenhuma luta contra as tentações da carne, teve porém de
lutar contra as tentações do inimigo, que não respeitou nem ao próprio Cristo, como o refere o
Evangelho.

RESPOSTA À TERCEIRA. ─ A virgindade não é devida a auréola, senão enquanto acrescenta uma
excelência aos outros graus de continência. Assim, se não tivesse Adão pecado, a virgindade não
acrescentaria nenhuma perfeição à continência conjugal, porque então seria por todos tratados com,
honra o matrimônio e o leito sem mácula, por não implicar a mácula da concupiscência. E então não
haveria necessidade de conservar a virgindade, nem lhe seria devida nenhuma auréola. Mas, uma vez
mudada a condição da natureza humana, a virgindade tem uma honra especial. Por isso recebe um
prêmio especial. ─ Mas no tempo da lei de Moisés, quando o ato carnal tinha por fim procriar filhos, que
perpetuassem o culto divino, não era de nenhum modo louvável a abstenção da união sexual. Nem ao
propósito da virgindade será conferido um prêmio social, senão o tivesse sugerido uma inspiração
divina. Como o cremos de Jeremias e de Elias, dos quais a Escritura não refere que tivessem casado.

RESPOSTA À QUARTA. ─ A virgem vítima de uma violência nem por isso perde a sua auréola, contanto
que conserve inviolável o propósito de permanecer sempre virgem, de nenhum modo consentindo na
violência que lhe foi feita. Pois, assim, não perde a sua virgindade. E isto digo, quer tenha sido
violentada como castigo à sua constância na fé, ou por qualquer outra causa. Se porém o foi por
defender a sua fé, isso lhe redundará em mérito e constituirá um gênero especial de martírio. Assim se
explica o dito de Lúcia: Se me fizeres violência à vontade, dupla coroa receberá a minha castidade. Não
que viesse a receber duas auréolas de virgindade, mas porque ganharia duplo prêmio ─ um por ter
guardado a virgindade, outro pela violência sofrida. ─ E dado que uma virgem assim violentada viesse a
conceber, nenhum detrimento Isso lhe causaria à virgindade. Mas nem por isso se equipararia à Mãe de
Cristo, que teve com a integridade da alma também a do corpo.

RESPOSTA À QUINTA. ─ Todos nascemos virgens pelo que a virgindade tem de material. Mas o
propósito de a conservar perpetuamente, donde lhe nasce o mérito, não é inato em nós, mas é um dom
da graça divina.

RESPOSTA À SEXTA. ─ Não a qualquer viúva é devido o fruto de sessenta por um, mas só à que conserva
o propósito de permanecer viúva, embora de viuvez não tenha feito voto, como já o dissemos a respeito
da virgindade.

RESPOSTA À SÉTIMA. ─ Os impotentes e os eunucos que tiverem a vontade de conservar virgindade
perpétua, mesmo se pudessem realizar a conjunção carnal, devem considerar-se como virgens e
merecem a auréola; fazem assim da necessidade virtude. Mas se tivessem a vontade de casar, se o
pudessem, já não merecem a auréola, Por isso diz Agostinho: Aqueles que, como os eunucos, tem a
faculdade genésica debilitada e não podem gerar, desde que se tornem cristãos e guardem os preceitos
de Deus, embora tenham o propósito de casar, se o pudessem, devem ser considerados como fiéis
casados.

## Art. 6 — Se aos mártires é devida a auréola.
O sexto discute-se assim. ─ Parece que nenhuma auréola é devida aos mártires.

1. ─ Pois, a auréola é um prêmio merecido pelas obras superrogatórias. Por isso aquilo da Escritura ─
Farás sobre esta outra pequena coroa de ouro ─ diz Beda: pode-se entender esse lugar, e bem, daqueles
que, por eleição espontânea de uma vida mais perfeita, observam além dos mandamentos comuns a
todos. Ora, morrer para confessar a fé é às vezes obra de necessidade e não superrogatória, como se
conclui daquilo do Apóstolo: Com o coração crê para alcançar a justiça, mas com a boca se faz a
confissão para alcançar a salvação. Logo, ao martírio nem sempre é devida a auréola.

2. Demais. ─ Segundo Gregório, quanto mais livres os serviços tanto mais gratos são ora, o martírio nada
tem de livre, por ser um castigo aplicado violentamente por outrem. Logo, ao martírio não é devida a
auréola, que corresponde a um mérito excelente.

3. Demais. ─ O martírio não só consiste no sofrimento exterior da morte, mas também na aceitação
interior da vontade. Donde o distinguir Bernardo três gêneros de martírio: o de vontade, não
acompanhada de morte, como o de João: o de vontade, acompanhada de morte, com o de Estevam; e o
nem de morte nem de vontade, como o dos Inocentes. Se, portanto, ao martírio fosse devida a auréola,
mais seria ao martírio de vontade que o de simples sofrimento externo, pois, o mérito procede da
vontade. Ora, tal não se dá. Logo, ao martírio não é devida a auréola.

4. Demais. ─ O sofrimento do corpo é menor que o do espírito, constituído de dores internas e
padecimento da alma. Ora, o sofrimento interior é uma espécie de martírio. Donde o dizer Jerônimo:
Posso dizer sem engano, que a Mãe de Deus foi Virgem e mártir, embora em paz tivesse acabado a vida.
Por isso diz o Evangelho: Uma espada te transpassou a alma, i. é, a da dor pela morte do Filho. Logo,
como à dor externa nenhuma auréola é atribuída, também nenhuma deve sê-la à dor externa.

5. Demais. ─ A penitência é em si mesma um martírio. Por isso diz Gregório: Embora não haja ocasião de
sofrermos perseguição, contudo também a nossa paz tem o seu martírio; pois, apesar de não termos
que sofrer no pescoço, a crueldade do ferro, entretanto, dentro em nossa alma, traspassamos, com o
gládio espiritual, os desejos carnais. Ora, a penitência sofrida exteriormente, não merece nenhuma
auréola. Logo, também não é devida auréola a todo martírio exterior.

6. Demais. ─ A uma obra ilícita não é devida a auréola. Ora, é ilícito atentarmos contra a nossa própria
vida, como está claro em Agostinho. E contudo celebra a Igreja certos mártires que se suicidaram para
escapar à cólera do tirano, como o refere a História Eclesiástica de certas mulheres em Antióquia. Logo,
nem sempre ao martírio é devida a auréola.

7. Demais. ─ Pode acontecer seja um torturado por causa da sua fé e sobreviver depois de algum tempo.
E contudo esse tal é mártir. Todavia, segundo parece, não lhe é devida a auréola, porque a sua luta não
durou até a morte. Logo, nem sempre ao martírio é devida a auréola.

8. Demais. ─ Certos sofrem mais com a perda dos bens temporais que com os sofrimentos no próprio
corpo; como o mostra o fato de enfrentarem muitos padecimentos para adquirirem ganhos. Se,
portanto, fossem privados dos seus bens temporais, pelo amor que tivessem a Cristo, parece que seriam
mártires. E contudo, segundo parece, nenhuma auréola lhes é devida. Logo, a mesma conclusão que
antes.

9. Demais. ─ Mártir parece que só é quem foi imolado por amor à fé. Por isso diz Isidoro: Mártires em
grego, significa, em latim, testemunhas; porque, para dar testemunho de Cristo padeceram tormentos e
até à morte pugnaram pela verdade. Ora, certas virtudes são mais excelentes que a fé, como a justiça, a
caridade e outras, que não podem existir sem a graça; e contudo não lhes é devido a elas nenhuma
auréola. Logo, parece que também ao mártir não é devida a auréola.
10. Demais. ─ Assim como as verdades da fé vêem de Deus, assim, qualquer outra verdade, como diz
Ambrósio; porque toda verdade, seja dita por quem for, vem do Espírito Santo. Logo, se a quem sofre a
morte pela fé é devida a auréola, pela mesma razão também o é aos que a sofrem por amor a qualquer
outra verdade. O que contudo não é exato.
11: Demais. ─ O bem comum tem prioridade sobre o particular. Ora, quem pela salvação da república
morrer numa guerra justa, não lhe é devida a auréola. Logo, também se morrer para conservar a fé no
seu coração. Portanto, aos mártires não é devida a auréola.
12. Demais. ─ Todo mérito procede do livre arbítrio. Ora, a Igreja celebra o martírio de certos que não
tinham livre arbítrio. Logo, não mereceram a auréola. Portanto, nem a todos os mártires é devida a
auréola.
Mas, em contrário. ─ Agostinho diz: Ninguém, que eu saiba, ousou jamais preferir a virgindade ao
martírio. Ora, à virgindade é devida a auréola. Logo, também ao martírio.

2. Demais. ─ Coroa é devida ao combatente. Ora, o martírio é uma luta especialmente difícil. Logo, é lhe
devida uma auréola especial.

SOLUÇÃO. ─ Assim como vivemos numa luta interior do espírito contra as concupiscências, assim
também, contra os sofrimentos provindos do exterior. Por onde, assim como é devida uma coroa
especial, chamada auréola, a perfeitíssima das vitórias ─ a virgindade, com que triunfamos das paixões
da carne, assim também à perfeitíssima das vitórias contra os ataques externos é devida a auréola.
Ora, a perfeitíssima vitória contra os ataques externos podemos considerá-la à dupla luz. ─ Primeiro,
pela magnitude do ataque. Ora, dentre todos os sofrimentos que nos vêm do exterior, o principal é o da
morte; assim como das paixões interiores as principais são as concupiscências venéreas. Por onde,
vence perfeitissimamente quem ganha a vitória sobre a morte e tudo quanto a ela se ordena. ─ Em
segundo lugar, a perfeição da vitória pode ser considerada em relação à causa da luta, i. é, quando
pugnamos por Cristo, a honrosissima das causas.
E esses dois aspectos se devem considerar no martírio, que é a morte sofrida por amor de Cristo; pois, o
mártir não são os suplícios que o fazem, mas a causa por que é sofrido. Portanto, ao martírio, como à
virgindade, é devida a auréola.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Sofrer a morte por Cristo é, em si mesma considerada,
uma obra superrogatória; pois, nem todos estão obrigados a confessar a sua fé em face do
perseguidor.Mas pode se dar o caso de o ser necessário para conseguir a salvação; assim quando
alguém, tendo caído nas mãos do perseguidor, é interrogado sobre a sua fé, está obrigado a confessá-la.
Dai porém não se conclui que não mereça a auréola. Pois, a auréola não é devida à obra de
superrogação como tal, mas enquanto implica uma certa perfeição. Por onde, merecerá a auréola quem
praticar uma obra assim perfeita, embora não superrogatória.

RESPOSTA À SEGUNDA. ─ Ao martírio é devido um prêmio, não por ser infligido por um agente externo,
mas enquanto voluntariamente sofrido; pois, não o mesmo; como diz o Filósofo. Logo, a Cristo não é
devida a auréola.

2. Demais. ─ O prêmio de Cristo nunca recebeu acréscimo. Ora, Cristo não teve auréola, desde o
primeiro instante da sua concepção, porque então ainda não tinha sustentado nenhuma luta. Logo,
depois, não teve nunca auréola.

SOLUÇÃO. ─ Uns dizem que Cristo tem auréola, na significação própria desta; pois, tendo sido vitorioso
na luta, merece por consequência a coroa, na acepção própria desta. Mas quem refletir com diligência
verá que, embora a Cristo convenha a coroa de ouro ou simplesmente a coroa como tal, não lhe cabe a
auréola na sua acepção própria. Pois, a auréola, por isso mesmo que é um diminutivo, implica um
prêmio recebido por participação e não na sua plenitude. Por onde, cabe ter auréola aqueles que
participaram da vitória perfeita por comparação com aquele que a alcançou na sua plenitude. Ora,
Cristo ganhou a vitória na sua acepção principal e plena, por participação de cuja vitória é que todos os
mais são vitoriosos, conforme aquilo do Evangelho ─ Tende confiança, eu venci o mundo; e aquele lugar
do Apocalipse: Eis aqui o leão da tribo de Judá, que pela; sua vitória. Por isso não cabe a Cristo ter
auréola, mas algo de superior donde derivam todas as auréolas. Donde o dizer a Escritura: Aquele que
vencer eu o farei assentar comigo no meu trono, assim como eu mesmo, também depois que venci, me
assentei igualmente com meu Pai no seu trono.
Por isso, segundo outros, devemos dizer que embora Cristo não tenha propriamente auréola, tem
contudo o que é mais excelente que toda auréola.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Cristo foi mui verdadeiramente virgem, mártir e doutor.
O prêmio acidental porém correspondente a esses três títulos, não é nada, por assim dizer, em
comparação com a magnitude do seu prêmio essencial. Por isso não tem auréola, na sua acepção
própria.

RESPOSTA À SEGUNDA. ─ Embora a auréola seja devida a uma obra perfeitíssima que pratiquemos,
contudo, considerada como um diminutivo, significa uma certa perfeição participada de quem
plenariamente a possui. E assim, é um como prêmio menor. Mas nesse sentido não é que a tem Cristo,
que possui a plenitude de toda perfeição.

RESPOSTA À TERCEIRA. ─ Embora a virgindade tenha de certo modo em Deus o seu modelo, não o tem
porém de modo a poder reproduzi-lo fielmente. Pois, a incorrupção de Deus, que a virgindade imita, não
tem a mesma essência em Deus e em quem é virgem.

## Art. 7 — Se aos doutores é devida a auréola.
O sétimo discute-se assim. ─ Parece que os doutores não terão auréola.

1. ─ Pois, todo prêmio recebido na vida futura corresponde a algum ato de virtude. Ora, nem pregar
nem ensinar são atos de virtude. Logo, nem à doutrina, nem à pregação é devida a auréola.

2. Demais. ─ Ensinar e pregar supõem estudo e doutrina. Ora, nenhum prêmio da vida futura é adquirido
por estudo humano, pois, não podemos merecer pelos nos dons naturais e adquiridos. Logo, por
doutrina e pregação ninguém merecerá auréola na vida futura.

3. Demais. ─ A exaltação na vida futura corresponde à humilhação nesta; pois, quem se humilha será
exaltado. Ora, nenhuma humilhação há em ensinar e pregar; ao contrário, são ocasiões de soberba,
sendo por isso que uma glosa diz que o diabo engana a muitos, entumescidos pela honra do magistério.
Logo, parece que nem à pregação nem à doutrina é vida a auréola.
Mas, em contrário. ─ Àquilo do Apóstolo ─ Em ordem a que vós conheçais qual é a suprema, etc, diz a
Glosa: Os santos doutores terão um acréscimo de glória sobre glória comum dos demais. Logo, etc.

2. Demais. ─ Àquilo da Escritura: A minha vinha está diante de mim ─ Diz a Glosa: Mostra o prêmio
singular que prepara aos seus doutores. Logo, os doutores terão um prêmio singular. E a esse
chamamos auréola.

SOLUÇÃO. ─ Assim como pelo martírio e pela virgindade alcançamos uma vitória perfeitíssima sobre a
carne e sobre o mundo; assim também alcançamos uma vitória perfeitíssima sobre o diabo, quando não
somente não lhe cedemos aos ataques, mas ainda o expulsamos, não só de nós, mas também dos
outros. Ora, isto se faz pela pregação e pela doutrina. Por onde, à pregação e à doutrina é devida a
auréola como o é à virgindade e ao martírio. Nem devemos acompanhar a opinião dos que dizem que é
devida só aos prelados, a quem compete por ofício pregar e ensinar; mas a todos os que licitamente
praticam esse ato. Quanto aos prelados, não lhes é devida, embora tenham o ofício de pregar, senão se
realmente o fizerem; pois, a coroa não é devida ao hábito, mas à luta atual, segundo aquilo do Apóstolo:
Não será coroado senão quem combater conforme à lei.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Pregar e ensinar são atos de uma virtude determinada ─ a
misericórdia. Por isso são contados entre as esmolas espirituais.

RESPOSTA À SEGUNDA. ─ Embora a faculdade de pregar e ensinar possam provir do estudo, contudo a
aplicação da doutrina provém da vontade, informada pela caridade infundida por Deus. E assim, o seu
exercício pode ser meritório.

RESPOSTA À TERCEIRA. ─ A exaltação nesta vida não diminui o prêmio da outra, salvo àquele que nessa
exaltação busca a glória própria. Mas quem a converte em utilidade dos outros, receberá por ela uma
recompensa. E quando se diz que à doutrina é devida a auréola, devemos entendê-lo da doutrina do
que concerne à salvação, pela qual, como por umas armas espirituais, o diabo é expulso do coração dos
homens, de cujas armas diz o Apóstolo: As armas com que combatemos não são carnais, mas espirituais.

## Art. 8 — Se a Cristo é devida a auréola.
O oitavo discute-se assim. ─ Parece que a Cristo é devida a auréola.

1. ─ Pois, a auréola é devida à virgindade, ao martírio e à doutrina. Ora, essas três coisas as exerceu
Cristo de modo eminente. Logo, a ele principalmente cabe a auréola.

2. Demais. ─ Tudo o perfeitíssimo nas coisas humanas deve ser atribuído sobretudo a Cristo. Ora, o
prêmio da auréola é devida aos méritos mais excelentes. Logo, também é devido a Cristo.

3. Demais. ─ Cipriano diz que a virgnidade é a imagem de Deus. Logo, o exemplar da virgindade está em
Deus. Logo, parece que a Cristo, mesmo enquanto Deus, é devida a auréola.
Mas, em contrário, a auréola é a alegria por nos conformarmos a Cristo, como se disse. Ora, ninguém se
conforma ou assemelha-se a si mesmo, como diz o Filósofo. Logo, a Cristo não é devida a auréola.

2. Demais ─ O prêmio de Cristo nunca recebeu acréscimo. Ora, Cristo não teve auréola, desde o primeiro
instante da sua concepção, porque então ainda não tinha sustentado nenhuma luta. Logo, depois, não
teve nunca auréola.

SOLUÇÃO. ─ Uns dizem que Cristo em auréola, na significação própria desta; pois, tendo sido vitorioso
na luta, merece por conseqüência a coroa, na acepção própria desta. ─ Mas quem refletir com diligência
verá que, embora a Cristo convenha a coroa de ouro ou simplesmente a coroa como tal, não lhe cabe a
auréola na sua acepção própria. Pois, a auréola, por isso mesmo que é um diminutivo, implica um
prêmio na participação e não na sua plenitude. Por onde, cabe ter auréola àqueles que participaram da
vitória perfeita por comparação com aquele que a alcançou na sua plenitude. Ora, Cristo ganhou a
vitória na sua acepção principal e plena, por participação de cuja vitória e que todos os mais são
vitoriosos, conforme àquilo do Evangelho ─ Tende confiança, eu venci o mundo; e àquele lugar do
Apocalipse: Eis aqui o leão da tribo de Judá, que pela sua vitória. Por isso não cabe a Cristo ter auréola,
mas algo de superior donde derivam todas as auréolas. Donde o dizer da Escritura: Aquele que vencer
eu o farei assentar comigo no meu trono, assim como eu mesmo, também depois que venci, me
assentei igualmente com meu Pai no seu trono.
Por isso, segundo outros, devemos dizer que embora Cristo não tenha propriamente auréola, tem
contudo o que é mais excelente que toda auréola.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Cristo foi mui verdadeiramente virgem, mártir e doutor.
O prêmio acidental porém correspondente a esses três títulos, não é nada, por assim dizer, em
comparação com a magnitude do seu prêmio essencial. Por isso não tem auréola, na sua acepção
própria.

RESPOSTA À SEGUNDA. ─ Embora a auréola seja devida a uma obra perfeitíssima que pratiquemos,
contudo considerada como um diminutivo, significa uma certa perfeição participada de quem
plenariamente a possui. E assim, é um como prêmio menor. Mas nesse sentido não é que a tem Cristo,
que possui a plenitude de toda perfeição.

RESPOSTA À TERCEIRA. ─ Embora a virgindade tenha de certo modo em Deus o seu modelo, não o tem
porém de modo a poder reproduzi-lo fielmente. Pois, a incorrupção de Deus, que a virgindade imita, não
tem a mesma essência em Deus e em quem é virgem.

## Art. 9 — Se os anjos devem ter auréola.
O nono discute-se assim. ─ Parece que os anjos devem ter auréola.

1. ─ Pois, diz Jerônimo, referindo-se à virgindade: Viver na carne, mas separado dela, é viver uma vida
antes angélica que humana. E a um lugar do Apóstolo diz a Glosa que a virgindade é uma como porção
angélica. Logo, como à virgindade corresponde a auréola, parece que os anjos a devem ter.

2. Demais. ─ Mais nobre é a integridade do espírito que a do corpo. Ora, os anjos, não tendo pecado
nunca, tem a integridade do espírito. Logo, mais a eles lhes é devida a auréola, que aos íntegros na
carne, mas que pecaram.

3. Demais. ─ À doutrina é devida a auréola. Ora, os anjos nos ensinam, purificando, iluminando e
aperfeiçoando, como diz Dionísio. Logo, é-lhes devida pelo menos a auréola dos doutores.
Mas, em contrário. ─ Diz o Apóstolo: Não será coroado senão quem combater conforme à lei. Ora, os
anjos não sustentam nenhum combate. Logo, não lhes é devida a auréola.

2. Demais. ─ A auréola não é devida a um ato exercido sem a cooperação do corpo; por isso os que
apenas amam a virgindade, o martírio e a doutrina, se não o praticarem por atos externos, não
merecem a auréola. Ora, os anjos são espíritos incorpóreos. Logo, não tem auréola.

SOLUÇÃO. ─ Aos anjos não é devida auréola. E a razão é que a auréola corresponde propriamente a uma
perfeição de mérito excelente. Ora, o que para nós constitui perfeição meritória é conatural aos anjos;
ou lhes concerne ao estado comum deles ou lhes está incluído no prêmio essencial. E assim, pela mesma
razão por que aos homens é devida a auréola, os anjos não na tem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Quando se diz que a virgindade é uma vida angélica,
significa isso que as virgens imitam por graça o que os homens tem por natureza. Assim, não é uma
virtude para os anjos se absterem de todo dos prazeres carnais, de que não são susceptíveis.

RESPOSTA À SEGUNDA. ─ A integridade perpétua de espírito nos anjos merece o prêmio essencial. Pois,
é-lhes de necessidade para a salvação, a eles que não podem reparar a queda.

RESPOSTA À TERCEIRA. ─ Esses atos pelos quais os anjos nos ensinam fazem-lhes parte da glória e do
estado com um. Por isso, mediante esses atos não merecem a auréola.

## Art. 10 — Se a auréola é devida também ao corpo.
O décimo discute-se assim. ─ Parece que a auréola é devida também ao corpo.

1. - Pois, o prêmio essencial é mais nobre que o acidental. Ora, o dote, que faz parte do prêmio
essencial, não só o tem a alma, mas também o corpo. Logo, também ao mérito adquirido com a
cooperação do corpo é devido um prêmio, tanto para a alma como para o corpo. Ora, o mérito da
auréola foi ganho com a cooperação do corpo. Logo, ao corpo também é devida a auréola.

2. Demais. ─ Ao pecado praticado com a cooperação do corpo corresponde uma pena tanto da alma,
como do corpo. Logo, também ao mérito alcançado com a cooperação do corpo é devido um prêmio
tanto à alma como ao corpo. Ora, o mérito da auréola é alcançado com a cooperação do corpo.
Portanto, é ela devida também ao corpo.

3. Demais. ─ Nos corpos dos mártires, as suas cicatrizes brilharão na plenitude de um brilho especial. Por
isso diz Agostinho: Não sei que amor nos invade o coração pelos santos mártires, que queiramos, no
reino celeste, ver-lhes nos corpos as cicatrizes dos ferimentos que sofreram pelo nome de Cristo. E
talvez as vejamos. Pois, não constituirão neles uma deformidade, mas uma dignidade; e lhes há de
refulgir a beleza da virtude que, embora no corpo, não será do corpo. Logo, parece que a auréola dos
mártires será também do corpo; e isso se diga também dos outros santos.
Mas, em contrário. ─ As almas atualmente no paraíso têem uma auréola e contudo não tem corpo. Logo,
o sujeito próprio da auréola não é o corpo, mas a alma.

2. Demais. ─ Todo mérito vem da alma. Logo, todo o prêmio deve também ser da alma.

SOLUÇÃO. ─ A auréola, propriamente, será da alma; pois, é a alegria pelas obras que a mereceram. Ora,
assim como do gáudio pelo prêmio essencial, que é a coroa de ouro, redunda uma certa beleza para o
corpo, que lhe constitui a glória, assim do gáudio pela auréola resulta uma certa beleza para o corpo. De
modo que, principalmente, a auréola estará na alma, mas por uma certa redundância refulgirá também
na carne.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Devemos contudo saber que a refulgência das cicatrizes,
que ornamentará os corpos dos mártires, não pode chamar-se auréola. Pois, certos mártires terão
auréola, que não terão essas cicatrizes; assim os que morreram submersos ou pereceram consumidos
pela fome ou na escuridão dos cárceres.

## Art. 11 — Se se distinguem acertadamente três auréolas: a das virgens, a dos mártires e a dos pregadores.
O undécimo discute-se assim. ─ Parece que não se distinguem acertadamente três auréolas ─ a das
virgens, a dos mártires e a dos pregadores.

1. ─ Pois, a auréola dos mártires corresponde à fortaleza de que deram provas; a auréola das virgens, à
virtude da temperança; a auréola enfim dos doutores, à virtude da prudência. Parece, portanto, que
deve haver uma quarta auréola, correspondente à virtude da justiça.

2. Demais. ─ Uma Glosa diz: É acrescentada a coroa de ouro quando o Evangelho promete a vida eterna
aos que guardarem os mandamentos, naquelas palavras ─ Se tu queres entrar na vida, guarda os
mandamentos. E a essa coroa de ouro superpõe a auréola quando diz: se queres ser perfeito, vai, vende
tudo o que tens e dá-o aos pobres. Logo, à pobreza é devida a auréola.

3. Demais. ─ Quem faz voto de obediência se submete a Deus totalmente. Logo, no voto de obediência
consiste o máximo de perfeição. Portanto, parece que lhe é devida a auréola.

4. Demais. ─ Há ainda muitas outras obras superrogatórias de que teremos na vida futura uma alegria
especial. Logo, há ainda muitas outras auréolas além das três enumeradas.

5. Demais. ─ Tanto podemos divulgar a fé pregando e ensinando, como escrevendo. Logo, também aos
escritores é devida uma quarta auréola.

SOLUÇÃO. ─ A auréola é um prêmio privilegiado devido a uma vitória privilegiada. Por onde, conforme
as vitórias privilegiadas, nos três combates que todo homem deve sustentar, assim se discriminam as
três auréolas. ─ Nos combates contra a carne, ganha a mais excelente das vitórias quem se abstém
totalmente dos prazeres venéreos, que são nesse gênero os mais violentos. E assim procedem as
virgens. Por isso à virgindade é devida uma auréola. ─ Em seguida, nas lutas contra o mundo, a vitória
principal consiste em sustentar a perseguição do mundo até à morte. Por onde, uma segunda auréola é
devida aos mártires, vitoriosos nesses combates. ─ Enfim, no combate travado contra o diabo, a vitória
completa consiste em expulsar cada um, o inimigo não só de si próprio, mas também do coração dos
outros; e tal é o efeito da doutrina e da predicação. Donde uma terceira auréola devida aos doutores e
aos pregadores.
Outros porém distinguem três auréolas relativas às três faculdades da alma; e assim três auréolas
correspondem aos principais atos dessas três faculdades. ─ Ora, o ato principal da potência racional é
difundir entre os homens as verdades da fé. E a esse ato é devida a auréola dos doutores. ─ Em segundo
lugar, o ato principal da potência irascível é enfrentar mesmo a morte por amor de Cristo. E a esse é
devida a auréola dos mártires. ─ Enfim, o ato principal da potência concupiscível é a abstenção total dos
mais deleitáveis dos prazeres da carne. E a esse é devida a auréola das virgens.
Outros ainda distinguem três auréolas segundo as mais eminentes relações de conformidade que temos
com Cristo. Assim, ele foi o mediador entre seu Pai e o mundo. Foi portanto doutor enquanto
manifestou ao mundo a verdade que do Pai recebeu. Foi também mártir pela perseguição que sofreu do
mundo. Foi enfim Virgem pela pureza que em si conservou. Por isso, os doutores, os mártires e as
virgens têem com Cristo perfeitíssima relação de conformidade, daí o lhes ser devida a auréola.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O ato de justiça não supõe nenhuma luta como os atos
das outras virtudes. ─ Além disso não é verdade que ensinar seja um ato de prudência. Antes, é um ato
de caridade ou de misericórdia, pois, é principalmente o hábito dessas virtudes que nos inclina ao ato do
ensino. Ou ainda o hábito da sabedoria, como dirigente. ─ Ou podemos responder, com outros, que a
justiça abrange todas as virtudes; por isso não lhe é devida uma auréola especial.

RESPOSTA À SEGUNDA. ─ A pobreza, embora seja um ato de perfeição, não ocupa contudo o lugar
supremo em nenhum dos combates espirituais. Porque o amor dos bens temporais nos tenta menos
que a concupiscência da carne, ou as perseguições contra o nosso corpo. Por isso à pobreza não é
devida a auréola. Mas lhe é devido o poder judiciário em razão da humilhação que a acompanha.
Quanto à Glosa citada, considera a auréola em sentido lato, na acepção de qualquer prêmio dado a um
mérito excelente.
E o mesmo devemos responder à terceira e quarta objeções.

RESPOSTA À QUINTA. ─ Também aos que divulgam por escrito a doutrina sagrada é devida a auréola.
Mas não é distinta da auréola dos doutores, porque compor escritos é um modo de ensinar.

## Art. 12 — Se a auréola das virgens é a mais excelente de todas.
O duodécimo discute-se assim. ─ Parece que a auréola das virgens é a mais excelente de todas.

1. ─ Pois, o Apocalipse diz, que as virgens seguem o Cordeiro para onde quer que ele vá; e que ninguém
mais podia cantar o cântico que as virgens cantavam. Logo, as virgens terão uma auréola mais
excelente.

2. Demais. ─ Cipriano diz que as virgens são a porção mais ilustre da grei de Cristo. Logo, é-lhes devida
maior auréola.

3. Ainda. ─ Parece que a mais excelente é a auréola dos mártires. Assim, diz Haymo: Nem todas as
virgens terão procedência sobre as casadas; mais só e em especial aquelas que a um tempo sofreram os
suplícios do martírio e guardaram a virgindade, equiparando-se assim aos mártires. Logo, o martírio é
que dá à virgindade preeminência sobre os outros estados. Portanto, é devida ao martírio uma auréola
mais excelente.

4. Ainda. ─ Parece que a auréola mais excelente é a devida aos doutores. Porque a Igreja militante tem o
seu modelo na triunfante. Ora, na Igreja militante a honra máxima é a devida aos doutores, segundo
aquilo do Apóstolo: Os presbíteros que governam bem sejam honrados com estipêndio dobrado,
principalmente os que trabalham em pregar e ensinar, Logo, os doutores é que terão na Igreja
triunfante a auréola mais excelente.

SOLUÇÃO. ─ A preeminência de uma sobre outra auréola pode ser considerada à dupla luz. ─ Primeiro,
em relação ao combate; sendo então a auréola mais excelente a devida a um combate mais violento. E,
a esta luz, a auréola dos mártires de certo modo é mais excelente que as outras; e de certo modo, a das
virgens. Pois, o combate dos mártires, em si mesmo considerado, é mais violento e causa sofrimentos
mais veementes. Ao passo que o combate contra a carne é mais perigoso, por ser mais diuturno e mais
íntimo o inimigo a combater. ─ Segundo, quanto ao objeto do combate. ─ E a esta luz, a auréola dos
doutores é de todas a mais excelente. Porque os combates que travam versam sobre os bens
inteligíveis, ao passo que os outros, sobre as paixões sensíveis. ─ Aquela excelência porém fundada no
combate mesmo, é mais essencial a auréola, que, na sua noção própria, respeita a vitória e a luta. ─ A
dificuldade, porém, oriunda da luta como tal, é maior que a que nasce de nós mesmos, de um inimigo
mais íntimo. Por isso, absolutamente falando, a auréola dos mártires tem excelência sobre as outras.
Por isso diz a Glosa a um lugar do Evangelho, que a oitava bem-aventurança, atinente aos mártires, ─
bem-aventurados os que sofrem perseguição ─ conduz outras todas à perfeição. E também por isso a
Igreja, na lista dos santos mártires, dá-lhes a preeminência sobre os doutores e as virgens. ─ Mas, num
ponto de vista relativo, nada impede sejam as outras auréolas mais excelentes.
Donde se deduzem as respostas às objeções.

## Art. 13 — Se um pode ter a auréola da virgindade, do martírio ou de doutor, de modo mais excelente que outro.
O décimo terceiro discute-se assim. ─ Parece que um não pode ter a auréola da virgindade, do
martírio ou de doutor, de modo mais excelente que outro.

1. ─ Pois, as cousas chegadas ao termo não são susceptíveis de maior intensidade nem de remissão. Ora,
a auréola é devida às obras chegadas ao termo da perfeição. Logo, não são susceptíveis de maior
intensidade nem de remissão.

2. Demais. ─ A virgindade não é susceptível de mais nem de menos, pois, importa uma privação e as
privações e as negações não são susceptíveis de maior intensidade nem de remissão. Logo, susceptível
de aumento e de diminuição também não é a auréola das virgens, prêmio da virgindade.
Mas, em contrário. ─ A auréola superpõe-se à coroa de ouro. Ora, a coroa de ouro é mais excelente em
um que em outro. Logo, também a auréola.

SOLUÇÃO. ─ Sendo o mérito de certo modo a causa do prêmio, hão de diversificar-se eles com a
diversidade dos méritos. Pois, todo efeito sofre alteração na sua intensidade e na sua remissão
conforme sofre a intensidade e a remissão da sua causa. Ora, o mérito da auréola pode ser maior e
menor. Portanto, também maior e menor pode ser a auréola. ─ Não devemos porém esquecer que o
mérito da auréola pode ser considerado à dupla luz: na sua raiz e em relação à obra. Pois, pode se dar
que um, mais que outro, sofra, com tormentos maiores no martírio, ou inste mais na predicação, ou se
prive mais dos prazeres da carne, mas tudo com menor caridade. Por onde, a intensidade do mérito,
fundado na sua raiz, não corresponde a uma intensidade maior na auréola, mas na coroa de ouro. A
intensidade do mérito, porém, derivada do gênero do ato, corresponde a intensidade da auréola. E
assim pode um, que menos mereceu no martírio, quanto ao prêmio essencial, receba por esse martírio
uma auréola maior.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Os méritos a que são devidas as auréolas, não chegaram
ao termo da perfeição, absolutamente falando, mas só especificamente considerados; assim o fogo é,
na sua espécie, o subtilíssimo dos corpos. Por onde, nada impede uma auréola ser mais excelente que
outra, assim como um fogo mais subtíl que outro.

RESPOSTA À SEGUNDA. ─ Uma virgindade pode ser mais excelente que outra, por mais coitar o
obstáculo à virgindade; dizemos então que tem mais excelente virgindade a virgem que mais se
acautelou contra as ocasiões de a perder. Neste sentido, pois, as privações podem ser susceptíveis de
maior intensidade; assim, dizemos que é mais cego o homem que mais profunda privação da vista
sofreu.