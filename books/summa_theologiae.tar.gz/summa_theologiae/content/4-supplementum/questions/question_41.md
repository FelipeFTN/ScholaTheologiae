# Questão 41: Do sacramento do matrimônio como instituição natural.
Em seguida devemos tratar do matrimônio. Primeiro, como instituição natural. Segundo, como
sacramento. Terceiro, considerado absolutamente e em si mesmo.
Na primeira questão discutem-se quatro artigos:

## Art. 1 — Se o matrimônio é natural.
O primeiro discute-se assim. ─ Parece que o matrimônio não é natural.

1. Pois, o direito natural é o que a natureza ensinou a todos os animais. Ora, nos brutos há a conjunção
dos sexos, mas não o matrimônio. Logo, o matrimônio não é de direito natural.

2. Demais. ─ O que é de direito natural se manifesta em todos os homens, em qualquer estado em que
eles se encontrem. Ora, o matrimônio não existiu sempre entre os homens; pois, como diz Túlio, os
homens a princípio viviam em estado selvagem sem que ninguém tivesse filhos como próprios,
ignorando a estabilidade das núpcias ─ no que consiste o matrimônio. Logo este não é natural.

3. Demais. ─ O natural é o mesmo para todos. Ora, o matrimônio não é o mesmo para todos, pois,
celebra-se diversamente entre os diversos povos. Logo, não é natural.

4. Demais. ─ Aquilo, sem o que os fins da natureza podem cumprir-se não é natural. Ora, a natureza visa
a conservação da espécie pela geração, que pode existir sem o matrimônio, como na geração ilegítima.
Logo, o matrimônio não é natural.
Mas, em contrário, diz o Digesto, no princípio: O direito natural é a união do varão e da mulher, o que
nós chamamos matrimônio.

2. Demais. ─ O Filósofo diz, que o homem é mais naturalmente feito para o casamento que para a
sociedade civil. Ora, o homem é um animal naturalmente político e gregário, como também ele o diz.
Logo, é naturalmente feito para o matrimônio. Por onde, o casamento ou matrimônio é natural.

SOLUÇÃO. ─ A palavra natural é susceptível de duplo sentido. Num, é natural o necessariamente
causado por princípios naturais e assim, mover-se para o alto é natural do fogo. Ora, neste sentido o
matrimônio não é natural, como natural não é o que resulte da mediação ou da noção do livre arbítrio.
Noutro sentido, chamamos natural aquilo a que a natureza inclina, mas que se realiza como um ato
livre; assim se chamam naturais os atos das virtudes Ora, neste sentido o matrimônio é natural, porque
a razão natural duplamente nos inclina para ele. ─ Primeiro, quanto ao seu fim principal, que é o bem da
prole. Pois, a natureza não visa só a geração dos filhos, mas, a criação deles e a sua educação até o
estado de homem perfeito, como tal, que é o estado de homem virtuoso. Donde, segundo o Filósofo, os
três benefícios que dos nossos pais recebemos: a existência, a nutrição e a disciplina. Ora, o filho sem
pais determinados e certos não poderia ser por eles educado e instruído. E essa certeza não existiria
sem a obrigação de unir-se um homem a uma mulher determinada, sendo isso o que constitui o
matrimônio. ─ Segundo, quanto ao fim secundário do matrimônio, que é o obséquio mútuo que os
cônjuges mutuamente se dispensam, na vida doméstica. Pois, assim como a razão natural dita, que os
homens vivam em sociedade, porque cada um isolado não é capaz de obter tudo o necessário à vida,
razão pela qual o homem foi chamado naturalmente social, assim também das atividades necessárias à
vida humana, umas competem ao homem e outras, à mulher. Pois isso a natureza induz a uma
associação entre o homem e a mulher; e nisso consiste o matrimônio. E essas duas causas o Filósofo as
assinala.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A natureza humana é susceptível de dupla inclinação. Ao
que convém à natureza genérica ─ e isto é comum a todos os animais. Ou ao que convém ao homem
pelo que lhe diferencia a natureza; pois, a natureza humana extraia-a do gênero, enquanto racional,
assim se dá com os atos de prudência ou de temperança. E como a natureza genérica, embora a mesma
em todos os animais. não existe contudo do mesmo modo em todos, assim também não inclina do
mesmo modo em todos, mas do modo conveniente a cada um. ─ Assim, ao matrimônio a natureza do
homem o inclina pela diferença, que acabamos de assinalar na segunda razão. Por isso o Filósofo, ao dar
essa razão, coloca o homem acima de todos os animais. Mas ao casamento, considerado no seu
primeiro aspecto, o homem será atraído, enquanto pertencente ao, gênero animal. Por isso o Filósofo
diz que a procriação dos filhos é comum a todos os animais. Mas essa inclinação natural não se
manifesta igualmente em todos os animais. Pois, de certos animais os filhos recém-nascidos podem logo
buscar o seu próprio sustento, ou basta-lhes para tal o auxílio materno. E nesse caso não há necessidade
da união de um macho com uma determinada fêmea. Quanto a outros animais, cujos filhos precisam do
sustento dos pais, mas por pouco tempo, como certas aves o demonstram, vivem macho e fêmea numa
união temporária. Na espécie humana enfim, porque o filho precisa muito tempo do socorro dos pais,
há maior determinação, que prende o homem à mulher, ao que também inclina a natureza mesma do
gênero humano.

RESPOSTA À SEGUNDA. ─ As palavras de Túlio podem ser verdadeiras de um povo dado se
considerarmos o princípio próprio dele, que o diferença dos outros; pois, nem em todos a inclinação
natural produz os seus efeitos próprios. Mas não se pode exigir tal fato em verdade universal, pois,
como o narra a Sagrada Escritura, desde o princípio do gênero humano existiu o casamento.

RESPOSTA À TERCEIRA. ─ Segundo o Filósofo, a natureza humana não é imutável, como a divina. Por
isso o que é de direito natural varia conforme os diversos estados e condições humanas, embora o que é
de direito divino não seja naturalmente susceptível de variação.

RESPOSTA À QUARTA. ─ A natureza não visa somente a prole, mas também a sua perfeição, para o que
é necessário o matrimônio, como do sobredito se colhe.

## Art. 2 — Se o matrimônio ainda é de preceito.
O segundo discute-se assim. ─ Parece que o matrimônio ainda é de preceito.

1. Pois, um preceito obriga enquanto não revogado. Ora, o matrimônio quando foi instituído era de
preceito, como diz a letra do Mestre; e em nenhum lugar lemos que esse preceito foi revogado; pelo
contrário, foi confirmado, segundo lemos no Evangelho: O que Deus uniu o homem não separe. Logo, o
matrimônio ainda é de preceito.

2. Demais. ─ Os preceitos de direito natural obrigam em todo tempo. Ora, o matrimônio é de direito
natural, como se disse. Logo, etc.

3. Demais. ─ O bem da espécie é melhor que o do indivíduo: pois, o bem comum é mais divino que o
particular, como diz Aristóteles. Ora, o preceito dado ao primeiro homem de conservar, pela
alimentação, a sua própria existência, ainda vigora. Logo, e com maior razão o preceito sobre o
matrimônio, que concerne à conservação da espécie.

4. Demais. ─ Enquanto subsiste a razão de uma obrigação esta permanece a mesma. Ora: os homens
estavam antigamente obrigados ao matrimônio, a fim de não cessar a multiplicação do gênero humano.
Portanto como isto se daria se todos se abstivessem do matrimônio, parece que este continua a ser de
preceito.
Mas, em contrário, o Apóstolo: O que não casa a sua filha donzela faz melhor, isto é, que quem na casa.
Logo. já não é de preceito o contrato de matrimônio.

2. Demais - Ninguém que transgrida um preceito, merece um prêmio. Ora, às virgens é devido o prêmio
de uma auréola especial. Logo o matrimônio não é de preceito.

SOLUÇÃO. ─ A natureza nos inclina para duas espécies de bens. ─ Uns necessários à perfeição individual.
E tal inclinação obriga a cada um, porque as perfeições naturais são comuns a todos. ─ Outra inclinação
natural é ao necessário ao bem comum E como esses bens são variados e contrariam um aos outros, tal
inclinação não nos obriga como preceito; do contrário cada um estaria obrigado a ser agricultor,
construtor e a ofícios semelhantes necessários à comunidade humana. A
inclinação da natureza fica porém satisfeita, quando esses diversos ofícios são exercidos por diversos. ─
Ora, a perfeição da sociedade humana necessariamente requer que haja quem viva uma vida
contemplativa ao que o matrimônio opõe um grande obstáculo. Por isso a inclinação da natureza ao
matrimônio não obriga sob forma de preceito, mesmo segundo os Filósofos. Assim, Teofrasto prova que
o sábio não deve casar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Esse preceito não foi revogado. Nem obriga a cada um
em particular pela razão já aduzida; salvo quando o pouco número dos homens exigia que cada um
contribuísse para a procriação.

RESPOSTA À SEGUNDA E À TERCEIRA. ─ A resposta se deduz do que foi dito.

RESPOSTA À QUARTA. ─ A natureza humana em geral inclina a funções e atos diversos, como já se disse.
Mas como se manifesta diversamente nos diversos indivíduos, enquanto individuada por um ou por
outro, inclina a um sobretudo para uma função, e outro para outra. E desta diversidade, em cooperação
com a providência divina, moderadora de todas as coisas, resulta que um escolhe um ofício, como a
agricultura, e outro, outro. Donde também resulta que uns escolhem a vida matrimonial e outros a
contemplativa. E disso não advém nenhum perigo.

## Art. 3 — Se o ato matrimonial é sempre pecado.
O terceiro discute-se assim. ─ Parece que o ato matrimonial sempre é pecado.

1. Pois, diz o Apóstolo: Os que têm mulheres sejam como se as não tivessem. Ora. os que não tem
mulheres não praticam o ato matrimonial. Logo nem os que as tem pecam praticando esse ato.

2. Demais. ─ Diz a Escritura: as nossas iniquidades são as que fizeram uma separação entre vós e o vosso
Deus. Ora, o ato matrimonial separa o homem de Deus; por isso a Lei ordenava ao povo que devia ver a
Deus, que não se chegassem as suas mulheres. E Jerônimo afirma que no ato matrimonial o Espírito
Santo não toca o coração dos profetas. Logo é pecaminoso.

3. Demais. ─ O que é em si mesmo mau de nenhum modo pode dar lugar a urna prática virtuosa. Ora, o
ato matrimonial e inseparável da concupiscência que é sempre má. Logo, sempre é pecado.

4. Demais. ─ Só o pecado é que precisa de escusas. Ora, o ato matrimonial precisa ser escusado pelos
bens do matrimônio. Logo, é pecado.

5. Demais. ─ Coisas especificamente e semelhantes são objeto de um mesmo juízo. Ora, o concúbito
matrimonial é da mesma espécie que o ato do adultério, porque produz o mesmo efeito ─ a espécie
humana. Logo, sendo o ato do adultério pecado, o do matrimônio também o é.

6. Demais. ─ O excesso nas paixões destrói a virtude. Ora, sempre há no ato matrimonial excesso de
prazer, a ponto de absorver a razão, principal bem do homem. Por isso o Filósofo diz que é impossível o
homem ter qualquer compreensão durante tal prazer. Logo, o ato matrimonial sempre é pecado.
Mas, em contrário, ─ O Apóstolo diz: A donzela não peca, se casar. E ainda: Quero pois que as que são
moças se casem, criem filhos. Ora, a procriação de filhos não é possível sem a conjunção carnal. Logo, o
ato matrimonial não é pecado; do contrário o Apóstolo não o quereria.

2. Demais. ─ Nenhum pecado pode ser objeto de preceito. Ora, o ato matrimonial é objeto de preceito
como diz o Apóstolo: O marido pague à sua mulher o que lhe deve. Logo, não é pecado.

SOLUÇÃO. ─ Suposto que a natureza corpórea foi instituída por um Deus bom, é impossível afirmar que
o concernente à conservação dessa natureza e aquilo a que a natureza inclina sejam males,
universalmente falando. Por isso, sendo a procriação de filhos uma inclinação natural, pela qual se
conserva a natureza da espécie, é impossível considerar como universalmente ilícito o ato da procriação
de filhos, de modo que não possa realizar a mediedade da virtude. Salvo se admitirmos a insânia dos
que dizem, que as coisas corruptíveis foram criadas por um Deus mau. Donde talvez deriva a opinião a
que alude o Mestre, a qual é por isso uma péssima heresia.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Com essas palavras o Apóstolos não quis proibir o ato
matrimonial; nem a posse de bens materiais, quando disse: Os que usam deste mundo sejam como se
dele não usassem; mas o que pretendeu, em ambos os casos, foi proibir o prazer. O que resulta das suas
próprias expressões. Assim, não disse ─ não usem, ou, não tenham; mas ─ como se não usassem, ou,
como se não a tivessem.

RESPOSTA À SEGUNDA. ─ Nós nos unimos com Deus pelo hábito da graça e pelo ato da contemplação e
do amor. Por onde, tudo o que impede a primeira união é sempre pecado. Mas nem sempre o é o que
impede a segunda; pois qualquer ocupação lícita com as coisas inferiores dissipa a alma e a torna
incapaz de se unir atualmente com Deus. O que sobretudo se dá com a conjunção carnal que trava a
mente por causa da intensidade do prazer. Por isso, os que se deram à contemplação das coisas divinas
ou ao trato dos sacramentos se lhes impôs que quando a isso se entreguem, se abstenham das suas
mulheres. E é também essa a razão por que Escritura diz, que o Espírito Santo, quanto ao ato da
revelação dos seus segredos não tocava a mente dos profetas no uso do matrimônio.

RESPOSTA À TERCEIRA. ─ Esse mal da concupiscência do qual é inseparável o ato matrimonial não é o
mal da culpa, mas o da pena, procedente do pecado original, e que consiste em as potências inferiores e
os membros do corpo não obedecerem à razão. Por isso a objeção não colhe.

RESPOSTA À QUARTA. ─ Dizemos em sentido próprio que é escusado o que tem alguma semelhança de
mal, sem contudo o ser, ou não o ser tanto quanto parece. E então há lugar para uma escusa total ou
somente parcial. Ora, o ato matrimonial tendo por causa da corrupção da concupiscência, a semelhança
de um ato desordenado, é por isso escusado pelos bens do matrimônio, de todo mal, de modo a não ser
pecado.

RESPOSTA À QUINTA. ─ Embora os atos referidos tenham a mesma espécie natural diferem contudo de
espécie moral, que faz variar a circunstância de ser a conjugação com a mulher própria ou alheia. Assim
também o homicídio por violência ou por justiça diversifica a espécie moral, embora sejam atos da
mesma espécie natural. E contudo um é lícito e o outro ilícito.

RESPOSTA À SEXTA. ─ O excesso da paixão, que corrompe a virtude, não só impede ato da razão, mas
ainda subverte a ordem racional. O que não produz a intensidade do prazer no ato matrimonial, porque
embora durante ele haja desordem no homem, é contudo preordenado pela razão.

## Art. 4 — Se o ato matrimonial é meritório.
O quarto discute-se assim. - Parece que o ato matrimonial não é meritório.

1. Pois, Crisóstomo diz: O Matrimônio, embora não seja causa de pena para quem dele usa, contudo não
dá lugar a nenhuma recompensa. Ora, o mérito supõe a recompensa, Logo, o ato matrimonial não é
meritório.

2. Demais. ─ Não é louvável deixar de praticar o que é meritório. Ora a virgindade pela qual não
abraçamos o matrimônio, é louvável. Logo, o ato matrimonial não é meritório.

3. Demais.-- Quem usa de uma indulgência que é feita usa do benefício recebido. Ora, ninguém merece
pelo só fato de prestar a outrem um benefício. Logo, o ato matrimonial não é meritório.

4. Demais. ─ O mérito, como a virtude, supõe uma dificuldade. Ora, o ato matrimonial não implica
nenhuma dificuldade, mas antes, é acompanhado de prazer. Logo, não é meritório.

5. Demais. ─ O que não se pode fazer sem pecado venial nunca é meritório; pois, não podemos ao
mesmo tempo merecer e desmerecer. Ora, no ato matrimonial há sempre pecado venial, porque já o
primeiro movimento que eleva seu prazer, é pecado venial. Logo, o referido ato não pode ser meritório.
Mas, em contrário. ─ Todo ato praticado para cumprir um preceito é meritório, quando feito com
caridade, Ora, tal é o ato matrimonial, conforme o dito do Apóstolo: o marido pague à sua mulher o que
lhe deve. Logo, etc.

2. Demais ─ Todo ato de virtude é meritório. Ora, o referido ato é de justiça, pois o Apóstolo diz:
Pagamento do débito. Logo, é meritório.

SOLUÇÃO. ─ Como nenhum ato vindo da vontade deliberada é indiferente, como dissemos no livro 2, o
ato matrimonial é sempre pecado, ou meritório em quem tem a graça. Por onde, se o que induz ao ato
matrimonial é a virtude ─ da justiça, para pagar o débito; ou da religião, para procriar filhos, que sirvam
ao culto de Deus é meritório. Mas praticar esse ato só por prazer, apesar de ser no regime do
matrimônio e de não se desejar outra mulher senão a legítima, seria pecado venial. Se porém se
propusesse praticá-la com qualquer mulher, mesmo fora do matrimônio, seria pecado mortal. Pois a
natureza não pode mover senão do ordenado pela razão, sendo nesse caso o ato virtuoso; ou do não-
ordenado por ela, e então o movimento será para um ato libidinoso.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A raiz do mérito, quanto ao prêmio substancial, é a
caridade mesmo. Mas, quanto ao prêmio acidental a razão do mérito esta na dificuldade do ato. Ora,
não neste último sentido, mas no primeiro, é que o ato do matrimônio é meritório.

RESPOSTA À SEGUNDA. ─ Podemos merecer tanto por bens menores que por maiores. Por onde,
quando deixamos de praticar um bem menor, para fazermos o maior, merecemos louvor, por termos
deixado de praticar o ato menos meritório.

RESPOSTA À TERCEIRA. ─ A indulgência às vezes recai sobre os males menores. Assim, permite-se o ato
do matrimônio quando a, ele conduz a concupiscência, contanto que fique nos limites do matrimônio,
sendo então pecado venial. Mas cumprir o ato matrimonial por virtude é meritório; e neste caso não se
trata propriamente de indulgência, salvo se se entender por indulgência a permissão de praticar uma
ação menos boa, o que seria antes uma concessão. Nem há inconveniente em que mereça quem usa
dessa concessão; porque o bom uso dos benefícios de Deus é meritório.

RESPOSTA À QUARTA. ─ A dificuldade dos trabalhos é necessária para ganharmos o mérito do prêmio
acidental. Mas, o mérito do prêmio essencial exige antes a dificuldade consistente em manter na ordem
o meio que conduz ao fim. Tal o que se dá com o mérito do ato matrimonial.

RESPOSTA À QUINTA. ─ O primeiro movimento, enquanto chamado pecado venial, é o do apetite para
algum prazer desordenado, O que não se dá com o ato matrimonial. Logo, a objeção não colhe.