# Questão 36: Da qualidade dos que recebem este sacramento.
Em seguida devemos tratar da qualidade dos que recebem este sacramento.
Sobre o que cinco artigos se discutem:

## Art. 1 — Se os que recebem a ordem devem viver uma vida santa.
O primeiro discute-se assim. ─ Parece que os que recebem a ordem não precisam de viver uma vida
santa.

1. ─ Pois, a ordem dá o poder de dispensar os sacramentos. Ora, os sacramentos podem ser dispensados
tanto pelos bons como pelos maus. Logo, não é necessário a santidade da vida.

2. Demais. ─ Não é maior o ministério, que desempenhar para com Deus quem confere os sacramentos,
que o que tivesse por objeto a própria pessoa divina. Ora, de lhe prestar um ministério material Deus
não impediu a mulher pecadora e infame, como lemos no Evangelho. Logo, tais pessoas como essa não
devem ser impedidas de ministrar os seus sacramentos.

3. Demais. ─ Toda graça é um remédio contra o pecado. Ora, a quem esta em pecado não se lhe deve
negar remédio que lhe possa valer. Logo, como o sacramento da ordem confere a graça, parece que
deve ser conferido também aos pecadores.
Mas, em contrário. ─ A Escritura diz: Um homem da linhagem de Arão, que tiver deformidade, não
oferecerá pães ao seu Deus, nem se chegará ao seu ministério. Ora, por deformidade, segundo a Glosa,
se entende qualquer vício. Logo, quem anda enredado em algum vício não deve ser admitido ao
ministério da ordem.

2. Demais. ─ Jerônimo diz: Não somente os bispos, os presbíteros e os diáconos devem pôr grande
estudo em ser modelos, por palavras e obras, do rebanho que dirigem, mas devem ainda vigiar que
assim também sejam os de ordens inferiores e que desempenham o serviço de Deus. Porque é um
enorme mal para a Igreja o fato de serem os leigos melhores que os clérigos. Logo, todas as ordens
requerem a santidade de vida.

SOLUÇÃO. ─ Diz Dionísio: As essências mais subtis e mais puras, quando imbuídas das emanações dos
raios solares, derramam como outros tantos sóis sobre os corpos circunjacentes o esplendor da luz, que
em grau eminente receberam. Assim, em todo ministério divino não nutra ninguém a presunção de se
arvorar em guia dos outros, que não se tenha tornado o mais possível conforme e semelhante a Deus,
pelo conjunto da sua vida. Por onde, como qualquer ordem constitui quem a recebe chefe dos outros,
em matéria religiosa, por presunçoso pecaria mortalmente quem fosse recebê-las com a consciência de
pecado mortal. Por isso, a santidade da vida a ordem a exige como necessidade de preceito. Mas não
para a validade do sacramento. Portanto, quem recebeu a ordem com más disposições não deixa por
isso de a ter, embora pecaminosamente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Assim como verdadeiros sacramentos são os que o
pecador dispensa, assim também recebe verdadeiramente o sacramento da ordem.

RESPOSTA À SEGUNDA. ─ O ministério referido consistia na prestação de serviços materiais, que
também os pecadores podem licitamente prestar. Diferente porém é o que se passa com o ministério
espiritual, a que se aplicam os ordenados; porque esse os torna medianeiros entre Deus e o povo, e por
isso devem brilhar pela boa consciência na presença de Deus, e pela boa fama, no meio dos homens.

RESPOSTA À TERCEIRA. ─ Certos remédios exigem uma robustez natural, do contrário seriam tomados
com perigo da vida. Outros porém podem ser dados aos fracos. Assim também na ordem espiritual,
certos sacramentos são ordenados como remédio do pecado; e esses devem ser ministrados aos
pecadores, como o batismo e a penitência. Mas os que conferem uma perfeição supõem que quem a
recebe é confirmado pela graça.

## Art. 2 — Se deve o ordenando ter ciência perfeita da Escritura.
O segundo discute-se assim. ─ Parece que é preciso o ordenando ter ciência perfeita da Escritura.

1. Pois, deve ter a ciência da lei quem deve responder sobre toda ela. Ora, os leigos interrogam o
sacerdote sobre disposições da lei, como lemos na Escritura. Logo, deve ele ter ciência de toda a lei.

2. Demais. ─ A Escritura diz: Aparelhados sempre para responder a todo o que vos pedir razão da fé e da
esperança que há em vós. Ora, dar razão das coisas da fé e da esperança só o podem os que tem ciência
perfeita das Sagradas Escrituras. Logo, tal ciência devem tê-la os que receberam as ordens, a quem
foram ditas as referidas palavras.

3. Demais. ─ Ninguém que leia como deve deixará de entender, porque ler e não entender é ler com
negligência, como diz Catão. Ora, a obrigação dos leitores, que por assim dizer pertencem à ordem
ínfima, é ler o Velho Testamento, como diz a letra do Mestre. Logo, devem conhecer todo esse
testamento. E, com maior razão, os que tem ordens superiores.
Mas, em contrário, muitos mesmo nas religiões, são promovidos ao sacerdócio, que absolutamente
nada disso sabem. Logo, parece não ser necessária tal ciência.
Demais ─ Nas Vidas dos Padres se lê que alguns simples monges, de vida santíssima, foram promovidos
ao sacerdócio. Logo, não devem os ordenandos ter a referida ciência.

SOLUÇÃO. ─ Todo ato humano, para ser ordenado. Há de subordinar-se à direção da razão. Por onde,
para exercer as obrigações da ordem há de o ordenando ter a ciência suficiente para bem se dirigir
nesse exercício. Eis porque tal ciência deve ter quem vai ser promovido às ordens, não havendo
necessidade de conhecer perfeitamente toda a Sagrada Escritura, bastando conhecê-la mais ou menos
segundo o exigirem as suas obrigações. De modo que aqueles que receberam a obrigação de tomar a
cura de almas saibam o concernente à doutrina da fé e dos bons costumes; e saibam os outros o
atinente ao exercício da sua ordem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O sacerdote pratica funções de duas espécies uma
principal, concernente ao verdadeiro corpo de Cristo; outra secundária, concernente ao corpo místico
de Cristo. Ora, a segunda depende da primeira, mas não ao contrário. Por isso, certos são promovidos
ao sacerdócio que só devem exercer a primeira função; assim os religiosos não são incumbidos da cura
de almas. E esses não têm a obrigação de ensinar a lei, mas só de consagrar os sacramentos. Por onde,
basta a esses terem uma ciência suficiente a poderem observar o rito atinente à celebração do
sacramento. Outros porém são promovidos ao exercício de funções cujo objeto é o corpo místico de
Cristo. E desses os fiéis esperam a explicação oral da lei. E portanto devem ter conhecimento da lei; não
que devam saber solver todas as dificuldades que elas suscitam, podendo para isso recorrer aos
superiores; devem porém saber dela o que os fiéis precisam conhecer e observar. Os bispos porém, que
são os sacerdotes superiores, devem saber resolver as dificuldades da lei, e tanto mais quanto mais
superior lhes for a posição.

RESPOSTA À SEGUNDA. ─ Quando o texto fala da razão a ser dada, da fé e da esperança, não se deve
entender por ela uma razão tal bastante a elucidar o objeto da fé e o da esperança, pois ambas
concernem ao mundo invisível. Mas, que os sacerdotes saibam mostrar em geral a probabilidade de
ambas, para o que não é necessário uma grande ciência.

RESPOSTA À TERCEIRA. ─ Ao leitor não incumbe dar ao povo a inteligência da Sagrada Escritura, porque
isso pertence às ordens superiores: mas só publicá-las. Por isso não se exige dele que tenha uma ciência
tão alta que baste à inteligência da Sagrada Escritura, mas é suficiente que saiba ler com clareza. E como
essa ciência muitos a podem facilmente adquirir, pode-se estimar com probabilidade que o ordenando a
adquirira, se ainda não na tem; sobretudo se já esteja em via de a adquirir.

## Art. 3 — Se só pelo mérito da vida pode alguém adquirir o poder das ordens.
O terceiro discute-se assim. ─ Parece que só pelo mérito da vida pode-se adquirir o poder da ordem.

1. Pois, como diz Crisóstomo, nem todo sacerdote é santo, mas todo santo é sacerdote. Ora, é pelos
méritos da nossa vida que nos tornamos santos. Logo, também o sacerdote. E com muito maior razão os
que tem outras ordens.

2. Demais. ─ Na ordem natural estão colocados em grau superior os que mais próximos estão de Deus e
mais lhe participam da bondade, como diz Dionísio. Ora, quem tem o mérito da santidade e da ciência
por isso mesmo se torna mais próximo de Deus mais lhe participa da bondade. Logo, por isso mesmo
recebe um grau da ordem.
Mas, em contrário. ─ A santidade pode ser perdida depois de adquirida. Ora, a ordem, uma vez recebida,
não pode mais ser perdida. Logo, a ordem não consiste no mérito mesmo da santidade.

SOLUÇÃO. ─ A causa deve ser proporcionada ao seu efeito. Por onde, assim como Cristo, de quem mana
a graça para todos os homens, há de ter a plenitude dela, assim os ministros da Igreja, a quem não
incumbe dar a graça, mas só os sacramentos dela, não são constituídos em nenhum grau da ordem só
pelo fato de terem a graça, mas por participarem de algum sacramento dela.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Crisóstomo toma a palavra sacerdote no seu sentido
etimológico, como significando o que dá o sagrado. Ora, assim, qualquer justo pode ser chamado
sacerdote, por dar a outrem o socorro dos sacramentos. Mas, no caso vertente não tomamos esse
vocábulo no seu sentido etimológico. Pois, essa palavra sacerdote foi aplicada a significar quem confere
os dons sagrados na dispensa dos sacramentos.

RESPOSTA À SEGUNDA. - Na ordem natural uns seres se tornam superiores a outros em grau quando,
pela sua forma, podem agir sobre estes. E assim, por isso mesmo que tem uma forma de maior nobreza,
são constituídos em grau mais elevado. Ora, os ministros não são prepostos aos fiéis afim de lhes
conferir seja o que for por santidade própria, porque isso só Deus pode fazer; mas como ministros e
como uns instrumentos desse efluxo, que vem da cabeça para os membros. Por isso o símile não colhe
quanto à dignidade da ordem, embora seja exato quanto à conveniência dela.

## Art. 4 — Se peca quem promove indignos à ordem.
O quarto discute-se assim. ─ Parece que não peca quem promove indignos à ordem.

1. ─ Pois, o bispo precisa de coadjutores investidos de ordens menores. Ora, não podiam ser
encontrados em número suficiente se se exigisse deles uma tal idoneidade que só os santos a tem. Logo,
promover à ordem quem não seja digno dela parece que é excusável.

2. Demais. ─ A Igreja precisa de ministros não só para comunicar os dons espirituais, mas também para o
governo dos temporais. Ora, às vezes os que não tem ciência nem santidade de vida podem ser útil no
governo temporal ─ ou pelo poder secular ou por industria natural, Logo, parece que esses tais podem
ser promovidos sem pecado.

3. Demais. ─ Todos estamos obrigados a evitar o pecado o quanto podemos. Se, pois, o bispo peca
promovendo indignos à ordem, deve aplicar diligência máxima em saber se os que a ela se achegam são
dignos, afim de fazer-se uma diligente indagação sobre os costumes e a ciência deles. O que não se
poderá praticar em lugar nenhum.
Mas, em contrário. ─ Pior é promover os maus aos ministérios sagrados, que não corrigir os já
promovidos. Ora, Heli pecou mortalmente não corrigindo a malícia dos seus filhos; por isso, caindo para
trás expirou, como o relata a Escritura. Logo, não vai sem pecado quem promove um indigno.

2. Demais. ─ Na Igreja os bens espirituais tem preferência sobre os temporais. Ora, pecaria mortalmente
quem cientemente pusesse em perigo os bens temporais eclesiásticos. Logo, com maior razão, quem
fizesse correr riscos os bens espirituais. Ora, fá-los correr risco quem promove indignos, à ordem; pois
como diz Gregório, de quem se despreza a vida há se também de lhe desprezar a pregação e, pela
mesma razão, todos os bens espirituais por ele conferidos. Logo, quem promove indignos à ordem peca
mortalmente.

SOLUÇÃO. ─ O Senhor descreve o dispenseiro fiel, que faz o senhor sobre a sua família para dar a cada
um a seu tempo a ração de trigo. Logo, réu é de infidelidade quem dá os bens divinos acima de medida
conveniente a cada um. Ora, tal faz quem promove indignos à ordem. Portanto, comete o pecado
mortal de, por assim dizer, infidelidade ao Senhor supremo; e sobretudo que isso redunda em
detrimento da Igreja e da honra divina, promovida pelos bons ministros. E também seria infiel ao senhor
temporal quem escolhesse inúteis para o seu serviço.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Deus nunca abandonou a sua Igreja a ponto de se não
encontrarem ministros idôneos em número suficiente às necessidades do povo, promovidos os dignos e
excluídos os indignos. E se não se pudesse ter tantos ministros quantos os que agora existem, melhor
seria tê-los poucos e bons, que muitos e maus, como diz S. Clemente.

RESPOSTA À SEGUNDA. ─ Os bens temporais não os devemos buscar senão em vista dos espirituais. Por
isso, deve ser desprezada toda vantagem material e todo lucro, a fim de se promover o bem espiritual.

RESPOSTA À TERCEIRA. ─ Pelo menos é necessário o bispo, que ordena, ignorar que há no ordenando
obstáculos contrários à santidade. Mas além disso dele se exige que, na medida da ordem ou do ofício
que vai conferir, ponha mais diligente cuidado a fim de ter certeza das qualidades daqueles a quem vai
ministrar a ordem, ao menos pelo testemunho de outrem. Tal o diz o Apóstolo: A ninguém imponhas
ligeiramente as mãos.

## Art. 5 — Se quem está em pecado mortal pode, sem pecado, exercer a ordem recebida.
O quinto discute-se assim. Parece que quem está em pecado mortal pode, sem pecado, exercer a
ordem recebida.

1. ─ Pois, estando obrigado a exercê-la, peca se não o fizer. Se, pois, exercendo-a peca, não pode evitar
o pecado. O que é inadmissível.

2. Demais. ─ Dispensar é temperar o rigor do direito. Logo, embora lhe fosse ilícito por direito exercer a
ordem recebida, contudo lícito lh’o seria, obtendo dispensa.

3. Demais. ─ Quem comunica a outrem um bem espiritual, estando em pecado mortal, peca
mortalmente. Se, pois, o pecador no uso da ordem peca mortalmente, também assim quem dele recebe
ou a ele pede qualquer bem espiritual. O que é absurdo.

4. Demais. ─ Quem, exercendo a sua ordem, peca, também todo ato que praticar, nesse ministério, será
pecado mortal. Por onde, como para o exercício da ordem concorrem muitos atos, resulta que cometerá
muitos pecados mortais. O que é excessivamente rigoroso.
Mas, em contrário, diz Dionísio: Esse temerário, isto é, o que não é iluminado, ousa atentar contra as
funções sacerdotais, e não tem temor nem vergonha de tratar os mistérios sagrados com indignidade,
julgando que Deus ignora as misérias de que tem ele próprio consciência, ou que poderá enganá-lo
dando-lhe falsamente o nome de pai e pronunciando sobre os divinos mistérios, na forma ensinada por
Jesus Cristo, as repugnantes blasfêmias ─ não direis orações ─ da sua boca sacrílega. Logo, o sacerdote,
que exerce indignamente a sua ordem, é um como blasfemo e enganador. Peca, pois, mortalmente; e,
pela mesma razão, qualquer outro ordenado.

2. Demais. ─ Quem receber a ordem há de ter uma vida santa, para poder exercê-la dignamente. Ora,
peca mortalmente quem recebe as ordens em pecado mortal. Logo, e com maior razão peca
mortalmente no exercício dela, seja ele qual for.

SOLUÇÃO. ─ A Lei dispõe que administremos a justiça com retidão. Logo, quem exerce indignamente os
deveres de que a ordem o revestiu, não administra a justiça com retidão, procede contra os preceitos da
lei e portanto peca mortalmente. Ora, quem exerce uma função sagrada em pecado mortal sem dúvida
que o faz indignamente. Por onde é claro que peca mortalmente.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Quem se encontra no caso imaginado não fica por isso
adstrito à necessidade de pecar; pois, pode escolher entre ser perdoado do pecado ou resignar o seu
ofício, que o obriga ao exercício da ordem.

RESPOSTA À SEGUNDA. - Não pode haver dispensa em matéria de direito natural. Ora, o direito natural
exige tratemos como santo o que é santo. Logo, nesta matéria nenhuma dispensa pode haver.

RESPOSTA À TERCEIRA. ─ Enquanto o ministro da Igreja em pecado mortal é mantido por ela, os súditos
devem receber dele os sacramentos, pois a isso estão obrigados. Contudo, salvo em artigo de
necessidade, não seria acertado induzi-lo ao exercício da sua ordem, enquanto se tivesse a consciência
que o fazia em estado de pecado mortal, consciência que poderia modificar-se, porque basta um
instante para um homem recuperar a graça, perante Deus.

RESPOSTA À QUARTA. ─ Sempre que quem pratica um ato como ministro da Igreja o faz em pecado
mortal, peca mortalmente, e tantas vezes quantas assim proceder. Porque, como diz Dionísio, aos
impuros não lhes seja permitido nem sequer tocar os símbolos sagrados, isto é, os símbolos
sacramentais. Por isso, sempre que no exercício do seu ofício, tocam as coisas sagradas, pecam
mortalmente. ─ Isso porém não se daria, se sob o império da necessidade tocassem o que é sagrado ou
exercessem o seu ofício num caso em que um leigo pudesse fazer o mesmo; assim, se batizasse, em
artigo de necessidade, ou se apanhasse o corpo de Cristo lançado por terra.