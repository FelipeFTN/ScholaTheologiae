# Questão 48: Do objeto do consentimento.
Em seguida devemos tratar do objeto do consentimento. E nesta questão discutem-se dois artigos:

## Art. 1 — Se o consentimento gerador do matrimônio é o consentimento na conjunção carnal.
O primeiro discute-se assim. ─ Parece que o consentimento gerador do matrimônio é o consentimento
na conjunção carnal.

1. Pois, diz Jerônimo: Aos que fizeram voto de virgindade não somente é condenável casar, mas ainda o
querer fazê-lo. Ora, não o seria se não fosse contrário à virgindade, à qual o casamento não se opõe
senão por causa da conjunção carnal. Logo, o consentimento da vontade, no casamento, não o é senão
à conjunção carnal.

2. Demais. ─ Tudo o lícito, no matrimônio, entre marido e mulher, pode sê-lo também entre irmão e
irmã, menos a conjunção carnal. Ora, não podem irmão e irmã licitamente consentir no matrimônio.
Logo, o consentimento matrimonial é o consentimento na conjunção carnal.

3. Demais. ─ Se a mulher der ao varão o consentimento assim ─ consinto em casar contigo, com, a
condição de não teres relação comigo, não consentiria no matrimônio, porque encontraria a substância
mesma desse consentimento matrimonial. Ora, tal não se daria se este não tivesse como objeto a
conjunção carnal.

4. Demais. ─ Em todas as coisas a ação inicial corresponde à final. Ora, o matrimônio se consuma pela
conjunção carnal. Logo, como se iniciou pelo consentimento, parece que este tem por objeto conjunção
carnal.
Mas, em contrário. ─ Ninguém, que consinta na conjunção carnal, é virgem de alma e corpo. Ora, S. João
Evangelista, depois de ter consentido no casamento, foi virgem de alma e de corpo. Logo, não consentiu
na conjunção carnal.

2. Demais. ─ O efeito corresponde à causa. Ora, o consentimento é a causa do matrimônio. Não sendo,
pois, a conjunção carnal da essência do matrimônio, resulta, que nem o consentimento, que o causa,
tem por objeto a conjunção carnal.

SOLUÇÃO. ─ O consentimento gerador do matrimônio é o que tem por objeto, porque o efeito próprio
da vontade e a coisa mesma querida. Por onde, assim está a conjunção carnal para o matrimônio, como
o consentimento, que o gera, para essa mesma conjunção. Ora, o matrimônio, como se disse, não é
essencialmente a conjunção carnal em si mesma, mas uma associação do homem e da mulher tendo em
vista a união carnal, além do mais que por via de consequência lhes resulta, por onde lhes é dado um
direito mútuo ao exercício do ato conjugal. Essa associação se chama união conjugal. Por onde é claro
que bem pensavam os que disseram que consentir no matrimônio é consentir na conjunção carnal
implicitamente, mas não explicitamente. O que só se pode entender como significando, que o eleito
implicitamente contido na causa; porque a faculdade da conjunção sexual, em que se consentiu, é a
causa da conjunção carnal, como faculdade de usar do que é nosso é a causa do uso.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O consentimento no matrimônio, depois do voto de
virgindade, é condenável porque esse consentimento da faculdade de praticar um ato ilícito. Assim
também pecaria quem desse a outrem o poder de tomar um depósito confiado, e não somente se lhes
entregasse o depósito. Quanto ao consentimento da Santíssima Virgem diremos a seguir.

RESPOSTA À SEGUNDA. ─ Entre irmão e irmã não pode haver o direito à conjunção carnal, nem esta se
pode licitamente realizar. Por onde, a objeção não colhe.

RESPOSTA À TERCEIRA. ─ Essa condição explícita não só ao ato do casamento é oposta, mas também à
possibilidade de se realizar a conjunção carnal. E portanto contrária ao casamento.

RESPOSTA À QUARTA. ─ O matrimônio inicial corresponde ao consumado, como o hábito ou a potência
ao ato, que é a operação.
Quanto às objeções em contrário, elas mostram que não há consentimento explícito na conjunção
carnal. E isso é verdade.

## Art. 2 — Se pode haver matrimônio quando alguém consente em casar com uma mulher por causa desonesta.
O segundo discute-se assim. ─ Parece que não pode haver matrimônio quando alguém consente em
casar com uma mulher por causa desonesta.

1. Pois, cada coisa tem a sua razão de ser. Ora, o matrimônio é um sacramento. Logo, não pode ser feito
com a intenção de outro fim senão de aquele pelo qual foi instituído por Deus, a saber, a procriação da
prole.

2. Demais. ─ A união matrimonial vem de Deus, como está claro no Evangelho. O que Deus uniu o
homem não separe. Ora, uma união feita com fim desonesto não vem de Deus. Logo, não é matrimônio.
3 . Demais. ─ Os outros sacramentos não são válidos se não se observar o ato da Igreja. Ora, no
sacramento do matrimônio a intenção da Igreja não é nenhum fim desonesto. Logo, o matrimônio
contraído por uma causa desonesta não será verdadeiro casamento.

4. Demais. ─ Segundo Boécio, o que tende para um bom fim também é bom. Ora, o matrimônio é
sempre um bem. Logo, não será matrimônio quando contraído em vista de um mau fim.

5. Demais. ─ O matrimônio significa a união entre Cristo e a Igreja. Ora, não pode haver aí nenhuma
desonestidade. Logo, nem o matrimônio pode ser contraído por uma causa desonesta.
Mas, em contrário, quem batiza com a intenção de ganhar dinheiro verdadeiramente batiza. Logo, quem
contrai matrimônio com uma mulher com essa mesma intenção, contrai um verdadeiro matrimônio.

2. Demais. ─ Isso mesmo o provam os exemplos e as autoridades citadas pelo Mestre.

SOLUÇÃO. ─ A causa final do matrimônio pode ser apreciada a dupla luz: essencial e acidentalmente.
Essencialmente, a causa do matrimônio é aquela para qual ele é ordenado; e essa ─ procriar a prole e
evitar a fornicação ─ é sempre boa. Quanto à causa acidental, pode ser a que os nubentes tinham em
vista quando o contraíram. Ora, o que buscam no matrimônio não pode ser senão o que dele resulta; e
além disso, não é a causa a modificada pelos efeitos, mas ao inverso. Por onde, bondade ou a malícia do
matrimônio não resultarão do fim acidental, que os cônjuges se propuseram, mas estes é que serão
bons ou maus, por terem feito desse fim o fim essencial do casamento. E como as causas acidentais são
infinitas, por isso pode haver infinitas causas acidentais no matrimônio, umas honestas e outras
desonestas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O princípio alegado é verdadeiro quando se trata de uma
causa essencial e principal. Mas o que tem um fim essencial e principal pode ter vários fins secundários
essenciais e infinitos acidentais.

RESPOSTA À SEGUNDA. ─ A união conjugal pode ser entendida pela relação mesma resultante do
matrimônio, a qual é sempre boa e procedente de Deus, seja qual for a sua causa. ─ Ou pelo ato dos que
se casam; e então pode ser má e não procedente de Deus, absolutamente falando, nem repugna que
um efeito provenha de Deus embora tenha uma causa má, como no caso de filhos adulterinos; pois tal
efeito não provém da sua causa como sendo má, mas por ser parcialmente boa, enquanto dependente
de Deus; embora dele não proceda, absolutamente falando.

RESPOSTA À TERCEIRA. ─ A intenção da Igreja, de ministrar o sacramento, é necessária à validade de
qualquer deles, de modo que não havendo intenção, não haverá sacramento. Mas a intenção da Igreja,
quando tem em vista a vantagem resultante do sacramento, se refere à exata administração dele e não
à sua validade. Por isso, não observadas as formalidades externas, nem por isso deixa ele de ser válido.
Mas quem se omitir peca; assim quem, ao administrar o batismo, não tivesse em intenção a purificação
da alma, que a Igreja tem em vista. Do mesmo modo, quem tem a intenção de contrair o matrimônio,
embora não o ordene ao fim que a Igreja tem em vista, nem por isso deixa de realmente contrai-lo.

RESPOSTA À QUARTA. ─ O mal intencionado, não é o fim do matrimônio, mas dos contraentes.

RESPOSTA À QUINTA. ─ Essa união mesma é sinal da união entre Cristo e a Igreja e não obra dos que se
unem. Por isso a objeção não colhe.