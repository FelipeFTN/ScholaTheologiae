# Questão 30: Do efeito do sacramento da extrema unção.
Em seguida devemos considerar o efeito deste sacramento.
Sobre o que, discutem-se três artigos:

## Art. 1 — Se a extrema unção tem o poder de perdoar os pecados.
O primeiro discute-se assim. ─ Parece que a extrema unção não tem o poder de perdoar os pecados.

1. Pois, o que se pode fazer por um meio não há necessidade de se empregar outro. Ora quem recebe a
extrema unção teve necessidade de recorrer, antes, à penitência, para alcançar perdão dos pecados.
Logo, pela extrema unção não se perdoam os pecados.

2. Demais. ─ Nos pecados só há três elementos: a mácula, o reato da pena e as relíquias do pecado. Ora,
a extrema unção não apaga a mácula do pecado, sem a contrição; esta a apaga, mesmo sem a unção.
Nem tão a pena pois, mesmo depois de convalescido o doente, estaria obrigado a cumprir a satisfação
imposta. Nem, ainda, as relíquias da culpa; porque, depois dela, perduram as disposições resultantes
dos atos precedentes, como o demonstra a convalescência da doença. Logo, de nenhum modo, a
extrema unção produz a remissão dos pecados.

2. Demais. ─ A remissão dos pecados não acontece sucessiva, mas instantaneamente. A extrema unção,
porém, não é toda simultânea, pois requerem-se inúmeras unções. Logo, seu efeito não é a remissão
dos pecados.
Mas, em contrário, a Escritura: Se estiver em alguns pecados, ser-lhes-ão perdoados.

2. Demais. ─ Todo sacramento da lei nova confere a graça. Ora, a graça produz a remissão dos pecados.
Logo, a extrema unção, sendo sacramento da Lei Nova, contribui para a remissão do pecado.

SOLUÇÃO. ─ Cada sacramento foi instituído principalmente para um efeito, embora possa também
produzir outros por consequência. E como um sacramento realiza o que figura, por isso, da significação
mesma dele se deve deduzir o seu efeito principal. Ora, este sacramento é aplicado a modo de remédio,
como o batismo a modo de oblução. E o fim de um remédio é curar da doença. Por onde, este
sacramento foi principalmente instituído para curar a doença do pecado. E assim como o batismo é uma
regeneração espiritual e a penitência, uma ressurreição da mesma natureza, assim também a extrema
unção é uma cura ou medicação espiritual. Ora, assim como a medicação corporal pressupõe a vida do
corpo no medicado, assim a espiritual pressupõe a vida espiritual. Por isso este sacramento não é
aplicado contra os defeitos que excluem a vida espiritual, isto é, contra o pecado original ou mortal; mas
contra aqueles defeitos que nos enfermam espiritualmente, privando-nos do perfeito vigor para os atos
da vida da graça ou da glória. E essa deficiência outra coisa não é senão uma debilidade ou ineptidão,
herança do pecado atual ou original. Contra essa debilidade é que nos fortificamos por este sacramento.
Mas, como essa fortificação resulta da graça, incompatível com o pecado, por isso e consequentemente,
encontrando um pecado mortal ou venial, apaga-lhe a culpa, contanto que lhe não oponha óbice quem
recebe tal sacramento, como o dissemos da Eucaristia e da confirmação. Por isso, Tiago também se
refere condicionalmente à remissão do pecado, dizendo: Se estiver em alguns pecados, ser-lhes-ão
perdoados, quanto à culpa. Mas nem sempre dele o pecado, pelo não encontrar sempre; mas sempre o
perdoa, no concernente à referida debilidade, a que certos chamam relíquias do pecado.
Outros porém dizem, que a extrema unção foi principalmente instituída contra o pecado venial, que não
podemos durante esta vida curar perfeitamente; por isso, o sacramento dos que dela se vão se ordena
em especial contra o pecado venial. ─ Mas esta opinião não é verdadeira. Pois, também a penitência
apaga suficientemente nesta vida a culpa dos pecados veniais. O não podermos porém evitá-los, depois
de cumprida a penitência, não exclui o efeito da penitência precedente. O que, demais, concerne à
debilidade referida.
Por onde, devemos pensar que o efeito principal deste sacramento é a remissão das relíquias do
pecado; e por consequência, também a culpa deles, quando existir.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora possamos colher o efeito principal de um
sacramento sem o recebermos a este atualmente, ou sem o sacramento, ou por outro sacramento e por
via de consequência, nunca porém o poderemos colher sem a intenção de receber o referido
sacramento. Por onde, como a penitência foi principalmente instituída contra a culpa atual, qualquer
outro sacramento, que apague por via de consequência a culpa atual, não exclui a necessidade da
penitência.

RESPOSTA À SEGUNDA. ─ A extrema unção perdoa de certo modo o pecado, nos seus três elementos
referidos. ─ Pois, embora a mácula da culpa não possa ser perdoada sem a contrição, contudo este
sacramento, pela graça que infunde, faz com que esse ato do livre arbítrio contra o pecado seja a
contrição; como também pode se dar com a Eucaristia e a confirmação. ─ Semelhantemente, também
diminui o reato da pena temporal; mas, por via de consequência, por eliminar a debilidade, pois, uma
mesma pena mais levemente a suporta um forte que um fracasso. Por onde, não é necessário seja por
isso diminuída a medida da satisfação. ─Quanto ao que aqui se entende pelas relíquias do pecado não
são as disposições como consequências dos atos, que são uns hábitos incoativos; mas uma certa
debilidade espiritual existente na alma mesma; eliminada a qual, ainda que perdurem os mesmos
hábitos ou disposições, não pode contudo inclinar-se do mesmo modo a alma para os pecados.

RESPOSTA À TERCEIRA. ─Sendo muitas as ações ordenadas a um só efeito, a ultima é formal em relação
a todas as precedentes e age em virtude delas. Por onde, a graça se infunde pela última unção, que
confere o efeito do sacramento.

## Art. 2 — Se a saúde do corpo é efeito deste sacramento.
O segundo discute-se assim. ─ Parece que a saúde do corpo não é efeito deste sacramento.

1. ─ Pois, todo sacramento é um remédio espiritual. Ora, o remédio espiritual se ordena à saúde
espiritual, como o material, à saúde do corpo. Logo, a saúde do corpo não é efeito deste sacramento.

2. Demais. ─ O sacramento produz sempre o seu efeito em quem não o recebe dissimuladamente. Ora,
às vezes não recobra a saúde do corpo quem recebe este sacramento, por mais devotamente que o
faça. Logo, a saúde do corpo não é efeito seu.

3. Demais. ─ A Escritura nos mostra a eficácia deste sacramento. Ora, nela não se atribui o efeito da cura
à unção, mas à oração, pois diz: A oração da fé salvará o enfermo. Logo, a saúde do corpo não é efeito
deste sacramento.
Mas, em contrário. ─ A operação da Igreja tem maior eficácia depois da paixão de Cristo, que antes. Ora,
antes, os ungidos com óleo pelos Apóstolos saravam, como o refere o Evangelho. Logo, também agora
produz o efeito de dar saúde ao corpo.

2. Demais. ─ Os sacramentos produzem efeito pela sua significação. Ora, o batismo, pela ablução
exterior do corpo, tem um significado e um efeito espiritual. Logo, também a extrema unção, pela saúde
do corpo, que exteriormente produz, significa e causa a saúde espiritual.

SOLUÇÃO. ─ Assim como o batismo, pela ablução do corpo, causa a purificação espiritual das máculas
espirituais, assim também este sacramento, pela medicação sacramental exterior, produz a cura
interior; e assim como a ablução do batismo produz o efeito da ablução corporal, porque também
produz a purificação do corpo, assim, a extrema unção produz o efeito de uma medicação corporal, isto
é, a saúde do corpo. Mas com a diferença, que a ablução corporal, pela propriedade mesma natural do
elemento, produz a purificação do corpo e por isso sempre a produz. Ao passo que a extrema unção não
causa a saúde do corpo por propriedade natural da matéria, mas por virtude divina, que obra
racionalmente. E como um princípio operativo não produz nunca um efeito secundário, senão enquanto
este importa ao principal, por isso este sacramento não causa nunca a saúde do corpo senão enquanto
esta importa a saúde espiritual. - E então a produz sempre, contanto que não haja impedimento por
parte de quem a recebe.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A objeção prova que a saúde do corpo não é o efeito
principal deste sacramento. O que é verdade.

RESPOSTA À SEGUNDA. ─ Deduz-se clara do que foi dito.

RESPOSTA À TERCEIRA. ─ A referida oração é a forma deste sacramento, como se disse. Por onde, tem
ele da sua forma a eficácia, por si mesma, para produzir a saúde do corpo.

## Art. 3 — Se este sacramento imprime caráter.
O terceiro discute-se assim. ─ Parece que este sacramento imprime caráter.

1. Pois, o caráter é um sinal distintivo. Ora, assim como o batizado se distingue do não batizado, assim o
ungido do não ungido. Logo, assim como o batismo imprime caráter, assim também a extrema unção.

2. Demais. ─ Nos sacramentos da ordem e da confirmação também se faz unção, como neste
sacramento. Ora, naqueles imprime caráter. Logo, também neste.

3. Demais. ─ Todo sacramento inclui os seguintes elementos: o que é só realidade, o que é só
sacramento, e o que é realidade e sacramento. Ora, nada podemos distinguir, neste sacramento, que
seja realidade e sacramento, senão o caráter. Logo, este sacramento também imprime caráter.
Mas, em contrário. ─ Nenhum sacramento, que imprima caráter, pode ser renovado. Ora, este o pode,
como diremos. Logo, não imprime caráter.

2. Demais. ─ A diferença fundada no caráter sacramental é a que se faz entre os fiéis da Igreja militante.
Ora, a extrema unção é conferida a quem deixa, pela morte, de fazer parte dessa Igreja. Logo, não
imprime caráter.

SOLUÇÃO. ─ Só imprimem caráter aqueles sacramentos que nos destinam a um fim sagrado. Ora, este
sacramento serve apenas de remédio; nem destina ninguém a fazer ou a receber nada de sagrado. Logo,
não imprime caráter.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O caráter produz a distinção dos estados, quanto à
atividades de cada um dentro da Igreja; mas uma unção não estabelece nenhuma diferença de estado
entre os fiéis.

RESPOSTA À SEGUNDA. ─ A unção feita na ordem e na confirmação é a da consagração, que destina o
homem a um estado sagrado. Ora, a unção de que tratamos, é para curar. Logo, o símile não colhe.

RESPOSTA À TERCEIRA. ─ A realidade e o sacramento da extrema unção não é o caráter, mas uma
devoção interior, que é a unção espiritual.