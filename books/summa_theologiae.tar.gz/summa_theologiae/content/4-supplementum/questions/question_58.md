# Questão 58: Do impedimento da impotência, do malefício, da loucura ou demência, do incesto e da falta de idade.
Em seguida devemos tratar de cinco impedimentos do matrimônio, a saber: a impotência, o malefício, a
loucura ou demência, o incesto e a falta de idade.
E nesta questão discutem-se cinco artigos:

## Art. 1 — Se a impotência impede de se contrair matrimônio.
O primeiro discute-se assim. ─ Parece que a impotência não impede de se contrair matrimônio.

1. Pois, a conjunção carnal não é da essência do matrimônio; assim, é mais perfeito quando ambos os
cônjuges fazem voto de continência. Ora, a impotência não impede senão a conjunção carnal. Logo, não
é impedimento dirimente do matrimônio já contraído.

2. Demais. ─ Assim como a impotência impede a conjunção carnal, assim, também a demasiada paixão,
que é exsecante. Ora, a paixão não é considerada impedimento ao matrimônio. Logo, nem a impotência
deve sê-lo.

3. Demais. ─ Todos os velhos são impotentes. Ora, os velhos podem contrair matrimônio. Logo, a
impotência não impede o matrimônio.

4. Demais. ─ A mulher que contrai matrimônio com um homem que sabe ser impotente, contrai com ele
matrimônio válido. Logo, a impotência, em si mesma, não impede o matrimônio.

5. Demais. ─ Pode um, excitado pelo ardor da concupiscência, ser capaz de conjunção carnal com uma
mulher deflorada, não porém com uma virgem; pois, a chama da concupiscência logo se apaga, em
razão da sua debilidade, de modo que pode não tornar capaz da conjunção com uma virgem.
Semelhantemente, pode um ser inflamado de paixão por uma mulher bela, que mais provoca a
concupiscência, e contudo ser impotente em relação a uma prostituta. Donde, se conclui que a
impotência, embora impida a cópula com uma, não impede contudo, absolutamente falando.

6. Demais. ─ A mulher é em geral mais fria que o homem Ora, as mulheres não são impedidas de casar.
Logo, nem os impotentes.
Mas, em contrário, determina o direito: Assim como a criança, incapaz do dever conjugal, não é apta
para o casamento, assim também os impotentes são considerados ineptos a contrair matrimônio. Ora,
entram nesta classe os impotentes de toda espécie. Logo, etc.

2. Demais. ─ Ninguém pode obrigar-se ao impossível. Ora, pelo matrimônio, o homem se obriga à cópula
carnal, pois para tal dá à sua mulher poder sobre o seu corpo. Logo, o impotente, incapaz da cópula
carnal, não pode contrair matrimônio.

SOLUÇÃO. ─ O matrimônio é um contrato pelo qual um dos cônjuges se obriga a cumprir para com o
outro o dever conjugal. Por onde, assim como os outros contratos não obrigam legalmente quando uma
das partes se compromete ao que não pode dar ou fazer, assim não há contrato legal de matrimônio,
quando feito por quem não pode cumprir o dever da conjunção carnal. E esse impedimento se chama
impotência física, de sua denominação geral. A qual pode provir de uma causa intrínseca e natural, ou
de uma causa intrínseca e acidental, como no caso do malefício, segundo depois diremos. Se por causa
natural, de dois modos pode sê-lo. Ou é temporal, podendo então desaparecer pela aplicação de um
remédio ou pelo desenvolvimento da idade. Ou é perpétua. E então dissolve o matrimônio de modo que
o marido, contra quem a mulher alegue esse impedimento, fica perpetuamente sem esperança de
poder casar; a mulher, porém, poderá casar com quem quiser, no Senhor.
Mas, para se saber se o impedimento é perpétuo ou não, a Igreja estabeleceu um determinado tempo,
o de um triênio, em que é possível experimentá-lo. Assim, depois de passado um triênio, durante o qual
ambas as partes, apesar de procurarem praticar o dever conjugal, não conseguiram consumar o
matrimônio, fica ele dissolvido por juízo da Igreja. Contudo, neste ponto às vezes a Igreja erra, porque a
perpetuidade da impotência pode não ficar provada suficientemente durante esse lapso de tempo. Por
isso, a Igreja, se vir que se enganou, pelo fato de ter o marido, contra quem se articulava esse
impedimento, realizado a cópula carnal com outra ou com a sua mulher própria, revalida o matrimônio
precedente e dirime o segundo, embora tivesse este sido celebrado com a sua anuência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora, o ato da cópula carnal não seja da essência do
matrimônio, contudo a capacidade para praticar o é; pois o matrimônio dá a cada um dos, cônjuges
poder sobre o corpo do outro, em respeito à cópula carnal.

RESPOSTA À SEGUNDA. ─ A demasiada paixão será dificilmente um impedimento perpétuo. Seria
porém, julgado tal se verificasse, que por um triênio impediu a cópula carnal. Contudo, é a impotência,
de ordinário e mais frequentemente, um impedimento, não somente permitindo a mixtão das matérias
seminais, mas também privando do vigor dos membros, que torna possível a união dos corpos. Por isso,
no caso vertente, é antes a impotência, que o ardor da concupiscência, que se considera como
impedimento, pois, todos os defeitos naturais se reduzem à impotência.

RESPOSTA À TERCEIRA. ─ Os velhos, embora não tenham o ardor bastante para engendrar, tem-no
contudo suficiente para a conjunção carnal. Por isso, se lhes permite o matrimônio como remédio à
concupiscência, embora já não o possam tornar eficiente como função da natureza.

RESPOSTA À QUARTA. ─ É regra universal para todo contrato, que quem não pode pagar uma
determinada coisa, não é idôneo para fazer o contrato pelo qual se obriga ao referido pagamento. Ora,
de dois modos pode ser inidôneo. ─ Primeiro, por incapaz, de direito, de fazer o pagamento. E então,
essa incapacidade de todos os modos torna o contrato nulo, quer o outro paciente saiba dela, quer não.
─ Noutro sentido, a incapacidade resulta de não poder, de fato fazer o pagamento. Então, se o outro
paciente o sabia, e contudo fez o contrato, mostrou por aí que buscava com esse contrato outro fim; e
portanto é ele válido. Mas, se não o sabia, nulo é o contrato.
Por onde, a impotência, que torna o homem incapaz, de fato do dever conjugal; e a condição de
escravo, que o torna incapaz de o cumprir livremente, impedem o matrimônio. quando o outro cônjuge
ignora essa incapacidade de cumprir tal dever. Quanto ao impedimento jurídico de cumprir o dever
conjugal, como a consangüinidade, anula o casamento contraído, quer o outro conjugue o saiba, quer
não, Por isso, o Mestre declara que a impotência e a escravidão tornam as pessoas não absolutamente
incapazes de se casar.

RESPOSTA À QUINTA. ─ Não pode ser um impedimento natural perpétuo o que torna um homem
impotente em relação a uma mulher e não, a outra. Dado porém que não possa realizar a cópula carnal
com uma virgem, mas o possa com uma deflorada, então pode-se apelar para uma intervenção cirúrgica
e tornar assim possível o ato conjugal. Nem iria isso contra a natureza, pois se trata de uma enfermidade
a curar e não do prazer. Quanto à repugnância por uma determinada mulher, não é uma causa natural
de impotência, mas causa acidental extrínseca. Por isso, devemos julgar dela como do malefício, de que
mais adiante trataremos.

RESPOSTA À SEXTA. ─ O homem é ativo na geração, e a mulher passiva, Por isso, maior ardência deve
ter o homem, que a mulher, na obra da geração. Por onde, a impotência, que torna o homem incapaz de
gerar, pode não tornar incapaz a mulher. Mas, a mulher pode sofrer um impedimento de outra causa, a
saber, o estreitamento vaginal, Então, devemos julgar desse impedimento como da impotência
masculina.

## Art. 2 — Se um malefício pode impedir o matrimônio.
O segundo discute-se assim. ─ Parece que nenhum malefício pode impedir o matrimônio.

1. Pois, tais malefícios são obra do demônio. Ora, os demônios não tem o direito de impedir o ato do
matrimônio, como também não podem impedir os demais atos corporais. Do contrário, perturbariam
todo o mundo, impedindo de comer, de andar e de atos semelhantes. Logo, os malefícios não podem
impedir o casamento.

2. Demais. ─ A obra de Deus é mais forte que a do diabo. Ora, o malefício é obra do diabo. Logo, não
pode impedir o matrimônio, que é obra de Deus.

3. Demais. ─ Só um impedimento perpétuo pode dirimir um matrimônio já contraído. Ora, um malefício
não pode ser impedimento perpétuo, porque o demônio, não tendo poder senão sobre os pecadores,
uma vez delido o pecado, desaparece o malefício; ou pode ainda desaparecer por força de outro
malefício, ou pelos exorcismos da Igreja, ordenadas a reprimir o poder dos demônios. Logo, um
malefício não pode impedir o matrimônio.

4. Demais. ─ A cópula carnal não pode ser impedida senão por impedida a potência geratriz, que é o
princípio dela. Ora, um mesmo homem é capaz de exercer o ato da geração quase igualmente com
todas as mulheres. Logo, um malefício não pode ser impedimento em relação a uma, senão sendo
também em relação a todas.
Mas, em contrário, uma decretal: As sortes do malefício impedem o casamento. E ainda: Se não
puderem sarar, poderão ser separados.

2. Demais. ─ O poder dos demônios é maior que o dos homens, segundo aquilo da Escritura: Não há
poder sobre a terra que se lhe compare. Ora, por obra humana pode um tornar-se incapaz da cópula
carnal ─ assim, por uma bebida, pela castração ─ ficando pois, impedido o matrimônio. Logo, e com
maior razão, esse resultado pode ser alcançado pelo poder do demônio.

SOLUÇÃO. ─ Certos disseram que o malefício só existe no mundo pela opinião dos homens, que
atribuíam aos malefícios os efeitos naturais, cujas causas são ocultas. ─ Mas, isto encontra a autoridade
dos Santos, que ensinam terem os demônios poder sobre os corpos e sobre a imaginação dos homens,
quando lhes permite Deus. E assim, por meio deles os mágicos podem operar certos prodígios.
Ora, esta opinião tem a sua raiz na infidelidade ou na incredulidade. Pois, os que a professam não crêem
na existência dos demônios, a qual atribuem só à opinião vulgar. Assim, os terrores que os homens a si
mesmo se criam ao demônio os atribuem. E como também uma veemente imaginação faz aparecerem
aos sentidos figuras, tais como as que imaginamos, cremos então ver demônios. ─ Mas, este sentir a
verdadeira fé o repudia, fundados na qual, cremos que certos anjos foram precipitados do céu, e na
existência dos demônios, que pela subtilidade da sua natureza, podem fazer muitas coisas que nós não
podemos. E aqueles que os induzem a produzir tais efeitos se chamam mágicos.
Por isso, opinaram outros, que um malefício pode causar impedimento à cópula carnal, mas não de
natureza perpétua; o que pois, não dirime o matrimônio já contraído. E afirmam estar revogado o
direito que assim o determinava. ─ Mas, isto encontra a experiência e o direito novo que concorda com
o antigo.
Por isso é mister distinguir. Pois, a impotência física causada pelo malefício ou é perpétua, e então anula
o casamento; ou não o é, e não o anula então. E é para experimentá-lo que a Igreja prefixou o período
de um triênio, do mesmo modo por que o fez com a impotência, como dissemos.
Há porém, a diferença seguinte entre o malefício e a impotência. O impotente ou frio o é tanto em
relação a uma mulher como a qualquer outra; por isso, se lhe foi anulado o matrimônio, não lhe é dada
licença de casar com outra. Ao passo que o malefício pode tornar o homem impotente em relação a
uma, mas não em relação a outra; por isso, quando por juízo da Igreja o casamento é anulado, a ambas
as partes é dada licença de buscar outro cônjuge.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A corrupção do pecado original, que tornou o homem
escravo do diabo, se nos transmitiu a nós pelo ato da potência geradora. Por isso Deus permite ao diabo
um poder sobre esse ato, mais do que sobre os outros. Assim como o poder malfazejo deles se revela
sobretudo nas serpentes que nos outros animais, porque foi por meio de uma serpente que o diabo
tentou a mulher, como refere a Escritura.

RESPOSTA À SEGUNDA. ─ Uma obra de Deus pode ficar impedida por outra, do diabo, por permissão
divina; o que não significa seja o diabo mais forte que Deus, a ponto de poder violentamente destruir as
obras divinas.

RESPOSTA À TERCEIRA. ─ Um malefício é perpétuo quando nenhum remédio humano se lhe pode dar,
embora Deus lh'o pudesse dar reprimindo o demônio, ou o demônio deixando de continuá-lo, Por outro
lado, como bem o sabem os mágicos, nem sempre é possível destruir o efeito de um malefício por outro
malefício. Contudo, mesmo que se pudesse achar remédio em outro malefício, nem por isso deixaria o
malefício de ser perpétuo, porque de nenhum modo devemos invocar o auxílio do demônio, mediante
outro malefício. ─ Semelhantemente, quem, pelo pecado cometido, veio a cair sob o poder permitido a
um demônio, não fica necessariamente livre desse poder, uma vez delido o pecado; pois, pode a pena
subsistir, mesmo depois de desaparecida a culpa. ─ Semelhantemente, os exorcismos da Igreja não
valem sempre para afastar os demônios e livrar dos vexames que causam ao corpo, por assim o dispor o
juízo divino. Mas sempre valem contra os ataques dos demônios para que foram instituídos.

RESPOSTA À QUARTA. ─ Um malefício pode umas vezes causar impedimento à conjunção carnal com
todas as mulheres, outras, só com uma. Porque o diabo é uma causa voluntária e não um agente que
produza o seu efeito por um impulso fatal da natureza. Além disso, o impedimento do malefício pode
provir da impressão do demônio na imaginação de um homem, de modo que este não sinta nenhum
movimento da concupiscência para com uma determinada mulher, mas sim para com outra.

## Art. 3 — Se a loucura impede o matrimônio.
O terceiro discute-se assim. ─ Parece que a loucura não impede o matrimônio.
1 . Pois, o matrimônio espiritual, contraído no batismo, é mais digno que o carnal. Ora, os loucos podem
ser batizados. Logo, também podem contrair matrimônio.

2. Demais. ─ A impotência impede o matrimônio por impedir a cópula carnal. A qual não fica impedida
pela loucura. Logo, nem o matrimônio.

3. Demais. - O matrimônio não fica impedido senão por um impedimento perpétuo. Ora, da loucura não
podemos saber se é impedimento perpétuo. Logo, não dirime o matrimônio.

4. Demais. ─ Nos versos supra-citados estão suficientemente contidos os impedimentos impedientes do
matrimônio. Ora, neles nenhuma menção se faz da loucura. Logo, etc.
Mas, em contrário. ─ A loucura, mais que o erro, priva, do uso da razão. Ora, o erro impede o
matrimônio. Logo, também a loucura.

2. Demais. ─ Os loucos não são capazes de fazer nenhum contrato. Ora, o matrimônio é um contrato.
Logo, etc.

SOLUÇÃO. ─ A loucura é precedente ou subsequente ao matrimônio. Se subsequente, de nenhum modo
o dirime. Se precedente, então ou o louco tem intervalo lúcidos ou não. Se tem nesse caso, embora não
lhe seja acertado contrair matrimônio num desses intervalos lúcidos, contudo, se o fizer, o casamento é
válido. Mas se não o tem, ou se o contrai no estado de loucura, então, como não pode haver
consentimento onde não há uso de razão, o matrimônio contraído não será válido.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O uso da razão não é necessário para receber o batismo,
como causa dele, ao passo que o é para contrair matrimônio. Por onde, não há simile na objeção.
Contudo, sobre o batismo dos loucos já dissemos antes.

RESPOSTA À SEGUNDA. ─ A loucura impede o matrimônio em razão da sua causa, que é o
consentimento, mas não por impedir, como a impotência, o ato matrimonial. Contudo, o Mestre das
Sentenças trata desses dois impedimentos no mesmo lugar, por serem ambos defeitos naturais.

RESPOSTA À TERCEIRA. - Um impedimento momentâneo, que ponha obstáculo ao consentimento,
causa do matrimônio, impede-o totalmente de ser contraído. Mas um impedimento apenas ao ato
matrimonial, há de ser perpétuo para anular o casamento.

RESPOSTA À QUARTA. - Esse impedimento reduz-se ao erro, porque em ambos os casos há falta de
consentimento racional.

## Art. 4 — Se o incesto cometido com a irmã da esposa anula o matrimônio.
O quarto discute-se assim. ─ Parece que o incesto cometido com a irmã da esposa não anula o
matrimônio.

1. Pois, a mulher não deve ser punida pelo pecado do marido. Ora, se fosse punida, o casamento seria
dissolvido. Logo, etc.

2. Demais. ─ Mais peca quem teve relações carnais com uma parenta, que quem a teve com uma
parenta de sua mulher. Ora, o primeiro desses pecados não impede o matrimônio. Logo, nem o
segundo.

3. Demais. ─ Se o casamento devesse ser dissolvido em punição do pecado, parece que também devia
ser anulado o matrimônio do incestuoso viúvo com uma outra mulher. O que não se dá.

4. Demais. ─ Este impedimento não figura entre os outros supra-numerados. Logo, não dirime o
matrimônio contraído.
Mas, em contrário, o cônjuge que tiver relações carnais com a irmã da esposa contrai afinidade com a
esposa. Ora, a afinidade anula o matrimônio contraído. Logo, também o referido incesto.

2. Demais. ─ Pelas coisas em que alguém peca, por essas é também atormentado, diz a Escritura. Ora, a
pessoa de quem tratamos peca contra o matrimônio. Logo, deve ser punida ficando privada dele.

SOLUÇÃO. ─ O homem que tiver relações carnais com a irmã ou outra consangüínea de sua esposa,
antes de contraído o seu matrimônio, mesmo depois dos esponsais, deve ser separado da esposa em
razão da afinidade contraída. ─ Se porém o fez depois do matrimônio contraído e consumado, os
esposos não devem ser separados; mas o marido perde o direito de pedir o cumprimento do dever
conjugal, nem o pode fazer sem pecado. Contudo deve cumpri-lo quando a esposa o pedir, porque esta
não deve ser punida pelo pecado do marido. ─ Mas depois da morte da esposa não deve mais pensar
em casar, de modo nenhum, salvo se por causa da sua fraqueza lhe for concedida dispensa, por se
temer que caia em relações ilícitas. Se porém, sem dispensa, casar-se de novo, peca por proceder contra
a determinação da Igreja; mas nem por isso o seu casamento deve ser anulado. Donde se deduzem
claras as respostas às objeções. Porque o incesto é considerado impedimento ao matrimônio, não tanto
em razão da culpa, como da afinidade que causa. Por isso também não é enumerado entre os outros
impedimentos; mas fica incluso no da afinidade.

## Art. 5 — Se a falta de idade impede o matrimônio.
O quinto discute-se assim. ─ Parece que a falta de idade não impede o matrimônio.
1 . Pois, segundo as leis, os menores estão sob a guarda de um tutor, até aos vinte e cinco anos. Por
onde se vê, que até essa idade não têm a razão suficientemente desenvolvida para poderem consentir.
Donde se conclui que essa deve ser a idade determinada para contraírem matrimônio. Ora, antes desse
tempo podem contraí-lo. Logo, a falta da idade legal não impede o matrimônio.

2. Demais. ─ Como o vínculo de religião é perpétuo, assim também o do matrimônio. Ora, segundo a
nova constituição, ninguém pode fazer profissão antes dos quatorze anos. Logo, nem contrair
matrimônio, se houvesse o impedimento da falta de idade.

3. Demais. ─ O consentimento para o matrimônio é necessário, tanto da parte do homem como da
mulher. Ora, a mulher pode contrair matrimônio antes dos quatorze anos. Logo, também o homem.

4. Demais. ─ A impotência física, não sendo perpétua e ignorada, não impede o matrimônio. Ora, a falta
de idade não é perpétua nem ignorada. Logo, não impede o matrimônio.

5. Demais. ─ A falta de idade não está contida em nenhum dos efeitos supra-referidos. Logo, parece não
ser impedimento ao matrimônio.
Mas, em contrário. ─ Uma decretal determina, que a criança não podendo cumprir o dever conjugal, não
é apta para o matrimônio, Ora, no mais das vezes, antes dos quatorze anos não pode um menor cumprir
esse dever, como o ensina Aristóteles. Logo, etc.

2. Demais. ─ Todas as coisas naturais tem limites, tanto de grandeza como de crescimento. Donde se
conclui que, sendo o matrimônio natural, deve haver um tempo determinado, antes do qual não seja
permitido contraí-lo.

SOLUÇÃO. ─ O matrimônio, sendo uma espécie de contrato, depende, como os outros contratos, das
disposições da lei positiva. Por isso, pelo direito, tanto civil como canônico, foi proibido contrair
casamento antes da idade de discernimento, quando cada uma das partes é capaz de deliberar
suficientemente sobre ele e sobre o dever que deve um cumprir para com o outro. E se assim não for, o
casamento será nulo. Ora, no mais das vezes essa idade é para o homem a dos quatorze anos e, para a
mulher, a dos doze; o que já ficou fundamentado antes. ─ Mas como os preceitos do direito positivo se
aplicam só na maior parte dos casos, não fica nulo o matrimônio de quem, antes da idade legal, tiver um
desenvolvimento suficiente, de modo que o vigor da natureza e da razão supra a falta de idade.
Portanto, o matrimônio daqueles será perpetuamente indissolúvel, que o tiverem contraído antes da
puberdade, tendo-o já consumado antes da referida idade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Em matéria a que a natureza inclina, não é necessário um
tão grande desenvolvimento da razão para deliberar, como o é em casos diferentes. Por isso pode, antes
da idade legal, suficientemente deliberar e consentir no matrimônio, quem, em matéria de outros
contratos, não poderia dirigir bem os seus negócios, sem a assistência de um tutor. E o mesmo devemos
responder à segunda objeção. ─ Pois, o voto de religião não pertence ao domínio das inclinações
naturais que implicam maiores dificuldades que o matrimônio.

RESPOSTA À TERCEIRA. ─ A mulher chega mais cedo que o homem à idade da puberdade, como ensina
Aristóteles. Logo, o símile não colhe.

RESPOSTA À QUARTA. ─ Encarada a esta luz, a falta de idade é um impedimento, não só pela
impotência física que implica, mas também pela falta ele discernimento racional, que torna incapaz do
consentimento necessário para um contrato de natureza perpétuo.

RESPOSTA À QUINTA. ─ Assim como o impedimento da loucura se reduz ao do erro, assim também o
resultante da falta de idade; pois, nos dois casos o homem não tem o uso pleno do livre arbítrio.
