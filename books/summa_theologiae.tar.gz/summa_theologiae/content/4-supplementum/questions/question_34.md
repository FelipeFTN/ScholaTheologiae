# Questão 34: Do sacramento da ordem.
Em seguida devemos tratar do sacramento da ordem. E primeiro, da ordem em geral. Segundo, das
diferentes ordens. Terceiro, dos que conferem a ordem. Quarto, dos impedimentos dos ordenados.
Quinto, dos anexos da ordem.
Quanto à ordem em geral, três questões temos a estudar. Primeiro, da sua entidade e quididade, e das
suas partes. Segundo, dos seus efeitos. Terceiro, dos que a recebem.
Na primeira questão discutem-se cinco artigos:

## Art. 1 — Se deve haver a ordem na Igreja.
O primeiro discute-se assim. - Parece que a ordem não deve existir na Igreja.

1. ─ Pois, a ordem supõe uma distinção entre inferior e superior. Ora, a sujeição repugna à liberdade à
qual fomos chamados por Cristo. Logo, não deve haver a ordem na Igreja.

2. Demais. ─ Quem está constituído na ordem se torna superior a quem não o está. Ora, na Igreja todos
nos devemos considerar inferiores um aos outros, conforme àquilo do Apóstolo: Tendo cada um aos
outros por superiores. Logo, não deve na Igreja haver a ordem.

3. Demais. ─ Há ordem entre os anjos por causa da distinção que há neles entre bens naturais e da
graça. Ora, todos os homens tem a mesma natureza; e quanto aos dons da graça, ninguém sabe quem
os tem mais eminentes. Logo, na Igreja não deve haver a ordem.
Mas, em contrário. ─ O Apóstolo diz: As causas de Deus são ordenadas. Ora, a Igreja é de Deus, pois ele
próprio a edificou com o seu sangue. Logo, deve haver a ordem na Igreja.

2. Demais. ─ O estado eclesiástico é um meio termo entre o estado da natureza e o da glória. Ora, há em
a natureza uma ordem, pela qual uns seres são superiores aos outros; e do mesmo modo na glória,
como se dá com os anjos. Logo, na Igreja deve haver a ordem.

SOLUÇÃO. ─ Deus quis fazer as suas obras semelhantes a si, na medida do possível, para que fossem
perfeitas e pudesse ser ele conhecido por meio delas. Por isso, a fim de que as suas obras o
representassem, não só como ele em si mesmo é, mas também enquanto influi nos outros seres, impôs
a todos a lei natural de serem os últimos dirigidos e aperfeiçoados pelos médios, e os médios pelos
primeiros, como diz Dionísio. Por onde, a fim de que essa beleza não faltasse à Igreja, introduziu nelas a
ordem, de modo que uns ministrassem os sacramentos aos outros, assemelhando-se assim a Deus a seu
modo, quase cooperadores dele, assim como na ordem natural certos membros influem nos outros.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A sujeição de escravidão repugna à liberdade, e consiste
no domínio de alguém, que usa dos súditos para a sua utilidade. E tal sujeição não é a que a ordem
exige, pela qual os superiores devem buscar a salvação dos seus subordinados e não a utilidade própria.

RESPOSTA À SEGUNDA. ─ Cada um deve reputar-se interior pelo mérito e não pelo oficio. Ora, as ordens
são uns ofícios.

RESPOSTA À TERCEIRA. ─ A ordem, nos anjos não se funda em nenhuma distinção natural, senão por
acidente, enquanto da distinção de natureza resulta neles a distinção da graça. Porque as ordens deles
dependem da participação das perfeições divinas e da função do mesmo estado da glória, fundada na
medida da graça e que é como um fim e de certo modo efeito da graça. Ao passo que as ordens da
Igreja militante concernem à participação dos sacramentos e a comunicação deles, que são a causa da
graça e de certo modo a precedem. E assim a graça necessariamente ligada à recepção dessas ordens
não é precisamente a graça santificante, mas apenas o poder de dispensar os sacramentos. Por isso, a
ordem não se funda nas distinções da graça santificante, mas na do poder.

## Art. 2 — Se a ordem foi convenientemente definida assim: A ordem é como um selo da Igreja pelo qual o poder espiritual é comunicado ao ordenado.
O segundo discute-se assim. ─ Não parece boa a definição da ordem dada pelo Mestre das Sentenças,
quando diz: A ordem é como um selo da Igreja pelo qual o poder espiritual é comunicado ao
ordenado.

1. ─ Pois, a parte não deve ser posta como gênero do lado. Ora, o caráter, designado pela palavra selo
na explicação da definição, que se lhe segue, é parte da ordem; porque se divide por oposição com o
que é só realidade, ou só sacramento, por ser realidade ao mesmo tempo que sacramento. Logo, o selo
não pode ser considerado como gênero da ordem.

2. Demais. ─ Assim como o sacramento da ordem imprime caráter, assim também o do batismo. Ora, na
definição do batismo não se incluiu o caráter. Logo, também não deve ser incluído na da ordem.

3. Demais, ─ O batismo também confere um certo poder espiritual de nos achegarmos aos sacramentos;
e além disso, sendo sacramento, é um selo. Logo, esta definição convém ao batismo. E assim, não
convém à ordem.

4. Demais. ─ A ordem é uma relação, que deve aparecer nos seus dois extremos. Ora, os extremos da
relação da ordem são o superior e o inferior. Logo, os inferiores tem a ordem do mesmo modo que os
superiores. Ora, nenhum poder de preeminência tem eles, como o introduzido aqui na definição da
ordem, conforme o demonstra a sequência de exposição, quando diz ─ promoção a um poder. Logo, a
definição de que tratamos não é boa.

SOLUÇÃO. ─ A definição da ordem, que o Mestre dá, convém-lhe enquanto sacramento da Igreja. Por
isso dois elementos nela inclui: o sinal exterior, quando diz - um selo, isto é, um certo sinal; e o efeito
interior, quando diz pelo qual o poder espiritual, etc.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O selo não é aqui considerado como caráter interior, mas
pela prática exterior, sinal e causa do poder interior. E assim também é tomado o caráter na outra
definição. ─ Mas ainda que o tomássemos pelo caráter interior nenhum inconveniente haveria. Porque
essas três divisões do sacramento referidas não constituem partes integrantes dele, propriamente
falando. Pois, que só é realidade não é da essência do sacramento. Também o que é só sacramento é
transitório ; mas do sacramento dizemos que permanece. Donde se conclui, que o caráter interior é
essencial, e principalmente o sacramento mesmo da ordem.

RESPOSTA À SEGUNDA. ─ Embora o batismo confira um certo poder espiritual para receber os outros
sacramentos, razão pela qual imprime caráter, contudo não é esse o seu efeito principal, mas sim, a
ablução interior, que daria existência ao batismo, mesmo sem a outra causa alegada, Ao passo que a
ordem implica principalmente um poder. Por onde, o caráter, que é um poder espiritual, é posto na
definição da ordem, mas não na do batismo.

RESPOSTA À TERCEIRA. ─ O batismo confere um certo poder espiritual para receber, e assim, de certo
modo, passivo. Ora, a palavra poder designa propriamente uma potência ativa com certa preeminência.
Por onde, essa definição não convém ao batismo.

RESPOSTA À QUARTA. ─ A palavra ordem é susceptível de duplo sentido. Assim, às vezes significa a
relação mesma. E então podem-na receber tanto o inferior como o superior, conforme o diz a objeção.
Mas não é esse o sentido de que se trata. Noutro sentido significa o grau mesmo resultante da ordem,
no primeiro sentido. E como a ordem, enquanto relação, existe sempre que há um superior e um
inferior, por isso esse grau eminente de poder espiritual se chama ordem.

## Art. 3 — Se a ordem é sacramento.
O terceiro discute-se assim. ─ Parece que a ordem não é sacramento.

1. ─ Pois, o sacramento, no dizer de Hugo Vitorino, é um elemento material. Ora, a ordem não designa
nada de tal, mas antes, uma relação ou um poder; porque ela supõe um poder, segundo Isidoro. Logo,
não é sacramento.

2. Demais. ─ Os sacramentos não existem na Igreja triunfante. Ora, nela há ordem, como o demonstram
os anjos. Logo, a ordem não é sacramento.

3. Demais. ─ Assim como a prelatura especial da ordem é conferida junto com uma certa consagração,
assim também a prelatura secular; pois, os reis também são ungidos, como se disse. Ora, o poder real
não é um sacramento. Logo, nem a ordem, da qual se trata.
Mas, em contrário, todos a enumeram entre os sete sacramentos da Igreja.

2. Demais. - Toda causa contém em grau eminente o seu efeito. Ora, a ordem é a que dá a faculdade de
dispensar os outros sacramentos. Logo, mais que os outros, é o sacramento por excelência.

SOLUÇÃO. ─ O sacramento, como do sobredito se colhe, não é senão uma santificação, que nos é
conferida, sob um sinal visível. Por onde, como quando alguém recebe a ordem recebe também uma
consagração por meio de sinais visíveis, resulta ser ela um sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora a ordem, pela sua denominação mesma, não
exprima nenhum elemento material, contudo não pode ser conferida sem um elemento dessa natureza.

RESPOSTA À SEGUNDA. ─ Um poder deve ser proporcionado ao seu sujeito. Ora, a comunicação dos
dons divinos, em vista da qual é conferido o poder espiritual, não se opera nos anjos mediante nenhuns
sinais sensíveis, como o é aos homens. Por onde, a ordem é um sacramento para nós, mas não para o
anjo.

RESPOSTA À TERCEIRA. ─ Nem toda bênção dada aos homens ou consagração é um sacramento. Assim,
os monges e os abades recebem bênçãos e contudo sacramentos não são elas. O mesmo se dá com a
unção real. Porque tais bênçãos não tornam ninguém apto a dispensar os divinos sacramentos, como
pela bênção da ordem.

## Art. 4 — Se a forma deste sacramento esta bem expressa na letra do Mestre.
O quarto discute-se assim. ─ Parece que a forma deste sacramento esta mal expressa pelo Mestre.

1. ─ Pois, os sacramentos são eficazes em virtude da sua forma. Ora, a eficácia dos sacramentos resulta
do poder divino, que obra neles mais secretamente a salvação. Logo, na forma deste sacramento deve-
se fazer menção do poder divino, pela invocação da Trindade, como nos outros sacramentos.

2. Demais. ─ Mandar é próprio de quem tem autoridade. Ora, a autoridade não reside em quem
dispensa os sacramentos, que só tem o ministro. Logo, não se devia usar na forma o verbo no modo
imperativo, dizendo: Fazei ou recebei isto ou aquilo, ou formas semelhantes.

3. Demais. ─ Na forma sacramental não se deve fazer menção senão do que é essencial ao sacramento.
Ora, o uso do poder recebido não é da essência deste sacramento, mas resulta dele. Logo, não se deve
fazer menção dele na forma sacramental.

4. Demais. ─ Todos os sacramentos tem por alvo a remuneração eterna. Ora, nas formas dos outros
sacramentos não se faz menção da remuneração. Logo, nem na forma deste deveria ela ser
mencionada, como se faz quando se diz: Terá parte, se fielmente etc.

SOLUÇÃO. ─ Este sacramento consiste principalmente no poder conferido. Ora, um poder é conferido
por outro, como o semelhante pelo semelhante. Além disso, um poder se revela pelo uso dele feito,
porque as potências se notificam pelos seus atos. Por isso, a forma da ordem exprime-lhe o uso, por um
ato imperado; e exprime a transmissão do poder, no modo imperativo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Os outros sacramentos não se ordenam principalmente,
como este sacramento, a efeito, semelhantes ao poder pelo qual são dispensados. Por isso, há neles
uma comunicação por assim dizer unívoca. Por onde, nos outros sacramentos, mas não neste, se
exprime em parte o poder divino.

RESPOSTA À SEGUNDA. ─ Embora o bispo, que é o ministro deste sacramento, não tenha autoridade
quanto à colação dele, contudo a tem quanto ao poder da ordem, que confere, pois esse poder deriva
do seu.

RESPOSTA À TERCEIRA. ─ O uso do poder é o efeito deste no gênero da causa eficiente; e por isso não
há razão para ser incluído na definição da ordem. Mas é de certo modo causa, no gênero da causa final.
Por isso, a esta luz, pode ser incluído na definição da ordem.

RESPOSTA À QUARTA. ─ Os outros sacramentos não ordenam à remuneração eterna, mediante o
exercício de uma função, como se dá com a ordem. Logo, o símile não colhe.

## Art. 5 — Se este sacramento tem matéria.
O quinto discute-se assim. ─ Parece que este sacramento não tem matéria.

1. ─ Pois, todo sacramento, que tem matéria, a virtude operativa dele está na matéria. Ora, as causas
materiais aqui usadas, como as chaves, os candelabros e outras semelhantes, nenhuma virtude tem
para santificar. Logo, este sacramento não tem matéria.

2. Demais. ─ Este sacramento confere como a confirmação a plenitude da graça dos sete dons do
Espírito Santo, na expressão do Mestre. Ora, a matéria da confirmação pressupõe a sua santificação.
Logo, como os elementos materiais usados neste sacramento não são pressantificados, parece que não
podem ser a matéria dele.

3. Demais. ─ Em todos os sacramentos que tem matéria, é necessário o contacto dela com quem recebe
o sacramento. Ora, como certos dizem, o contato desses elementos materiais com quem recebe o
sacramento não é necessário para a validade deste; mas basta sejam apresentados ao ordenando. Logo,
as referidas coisas materiais não são a matéria deste sacramento.
Mas, em contrário, todo sacramento supõe realidades e palavras. Ora, a realidade de um sacramento é a
sua matéria. Logo, também as coisas usadas neste sacramento são a matéria dele,

2. Demais. ─ Há mais exigências para dispensar os sacramentos do que para os receber. Ora, o batismo,
que confere o poder de receber os sacramentos, precisa de matéria. Logo, também a ordem, que dá o
poder de dispensá-los.

SOLUÇÃO. ─ A matéria exterior, de que usam sacramentos, significa que a virtude neles operante é de
origem totalmente externa. Por onde, como o caráter, efeito próprio deste sacramento, não é recebido
por nenhum ato de quem a ele se achega ─ como se dá com a penitência, mas tem origem de todo
externa, cabe-lhe ter uma determinada matéria. Embora porém de modo diverso dos outros
sacramentos que a tem. Porque o conferido nos outros deriva só de Deus, e não do ministro do
sacramento, ao passo que o poder espiritual, conferido pela ordem, deriva também do ministro dela,
como o poder imperfeito. Por isso, a eficácia dos outros sacramentos consiste principalmente na
matéria, que significa e contém uma virtude divina, pela santificação recebida pelo ministro. Ao passo
que a eficácia deste sacramento principalmente reside em quem o ministra; enquanto que a matéria é
usada, antes, para mostrar o poder, transmitido particularmente por quem o tem de maneira completa,
do que para causá-lo. O que resulta de a matéria ser necessária ao uso do poder.
Donde se deduz a resposta à primeira objeção.

RESPOSTA À SEGUNDA. ─ A matéria dos outros sacramentos precisa de ser santificada por causa da
virtude que contém. Mas isto não se dá no caso vertente.

RESPOSTA À TERCEIRA. ─ Se quisermos manter essa opinião, poderemos justificá-la pelo que dissemos.
Pois, o poder da ordem é recebido do ministro, mas não da matéria. Por isso, a apresentação desta é,
mais que o contato, da essência do sacramento. Contudo, essas palavras da forma mostram, que o
contato da matéria é da essência do sacramento; pois nela se diz ─ Recebei isto ou aquilo.