# Questão 56: Do impedimento de parentesco espiritual.
Em seguida devemos tratar do impedimento de parentesco espiritual.
Nesta questão discutem -se cinco artigos:

## Art. 1 — Se o parentesco espiritual impede o matrimônio.
O primeiro discute-se assim. ─ Parece que o parentesco espiritual não impede o matrimônio.

1. Pois, só impede o matrimônio o que contraria um de seus bens. Ora, o parentesco espiritual não
contraria nenhum bem do matrimônio. Logo, não no impede.

2. Demais. ─ Um impedimento perpétuo ao matrimônio não pode coexistir com este. Ora, o parentesco
espiritual pode coexistir com o matrimônio, como diz a Letra do Mestre. Tal o caso de quem batiza o
próprio filho, urgindo a necessidade; embora fique então ligado à esposa por parentesco espiritual, o
matrimônio nem por isso se dissolve. Logo, o parentesco espiritual não impede o matrimônio.

3. Demais. ─ A união espiritual não se transmite à carne. Ora, o matrimônio é uma união carnal. Logo,
sendo o parentesco espiritual uma união espiritual, não pode causar impedimento ao matrimônio.

4. Demais. - Os contrários não podem produzir o mesmo efeito. Ora, o parentesco espiritual parece
contrário à disparidade de cultos; pois, o parentesco espiritual é um laço resultante da administração do
sacramento, ou da participação intencional do mesmo; ao passo que a disparidade de culto consiste na
carência do sacramento, como se disse antes. Logo, como a disparidade de culto impede o matrimônio,
parece que o parentesco espiritual não produz esse efeito.
Mas, em contrário. ─ Quanto mais sagrado for um vínculo espiritual é mais sagrado que o corporal. Logo,
como o vínculo do parentesco corporal impede o matrimônio, parece que o parentesco espiritual há de
ter o mesmo resultado.

2. Demais. ─ No matrimônio a união das almas é mais principal que a dos corpos, pois, a precede. Logo,
o parentesco espiritual pode impedir o matrimônio, muito mais que o parentesco carnal.

SOLUÇÃO. ─ Como pela geração carnal recebemos a vida natural, assim pelos sacramentos recebemos a
vida espiritual da graça. Por onde, assim como o vínculo contraído pela geração carnal é natural, por ser
efeito da natureza, assim também o vínculo contraído pela recepção dos sacramentos é nos de certo
modo natural, como membros que somos da Igreja. Portanto, assim como o parentesco carnal impede o
matrimônio, assim também o espiritual, por determinação da Igreja.
Contudo devemos distinguir, em matéria de parentesco espiritual. Pois, é precedente ou consequente
ao matrimônio. Precedente, impede-o de ser contraído e o dirime se já o foi: mas se é consequente, não
rompe o vínculo matrimonial. Devemos porém distinguir; quanto ao ato conjugal. Quando o parentesco
espiritual nasceu da urgência da necessidade, como no caso de o pai batizar o filho em artigo de morte,
o ato matrimonial não fica impedido para nenhum dos cônjuges. Quando porém não foi a urgência da
necessidade a causa do parentesco espiritual e os esposos ignoravam esse efeito, então o resultado é o
mesmo que no caso antecedente, com a condição que quem é responsável tenha procedido com toda a
atenção necessária.
Quando enfim o parentesco espiritual não teve como causa a necessidade, mas nasceu de um ato
plenamente deliberado, então o seu autor perde o direito de pedir o cumprimento do dever conjugal,
devendo contudo cumpri-lo quando pedido pelo outro cônjuge, pois não deve este ficar prejudicado
pelo ato culposo alheio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora o parentesco espiritual não impida nenhum dos
bens principais do matrimônio, impede contudo a multiplicação da amizade, que é um dos seus bens
secundários. Pois, o parentesco espiritual é por si mesmo uma razão suficiente de amizade. Mas deve o
matrimônio ser uma fonte de relações familiares e amigáveis com outrem.

RESPOSTA À SEGUNDA. ─ O matrimônio é um vínculo perpétuo. Portanto nenhum impedimento
sobreveniente pode dirimí-lo. Por isso acontece às vezes coexistir o matrimônio com o seu
impedimento. Mas isso não se dá se o impedimento era precedente.

RESPOSTA À TERCEIRA. ─ A união matrimonial não é só corporal, mas também espiritual. Por isso, o
parentesco espiritual causa-lhe impedimento, sem que deva por isso transformar-se em parentesco
carnal.

RESPOSTA À QUARTA. ─ Nenhum inconveniente há em dois contrários se oporem a um terceiro; assim,
o grande e o pequeno igualmente se opõem ao igual. Ora, assim, a disparidade de culto e o parentesco
espiritual se opõem ao matrimônio; porque o primeiro põe entre os esposos uma distância maior, e o
segundo um maior parentesco, que o permitido pelo matrimônio. Por isso de ambos os lados fica
impedido o casamento.

## Art. 2 — Se só pelo batismo se contrai o parentesco espiritual.
O segundo discute-se assim. ─ Parece que só pelo batismo se contrai o parentesco espiritual.

1. Pois, assim está o parentesco carnal para a geração carnal, como o espiritual para a espiritual. Ora, só
o batismo é considerado geração espiritual. Logo, só pelo batismo se contrai o parentesco espiritual,
assim como pela só geração carnal se contrai o parentesco carnal.

2. Demais. ─ Assim a confirmação como a ordem imprimem caráter. Ora, o recebimento de ordem não
gera nenhum parentesco espiritual. Logo, nem o da confirmação, E portanto, só o batismo dá lugar a
esse parentesco.

3. Demais. ─ Os sacramentos, tem maior dignidade que os sacramentais. Ora, certos sacramentos como
a extrema unção, não geram nenhum parentesco espiritual. Logo, e muito menos, a instrução
catequética como querem alguns.

4. Demais. - Entre os sacramentais do batismo muitas outras coisas se contam além do catecismo. Logo,
o catecismo não gera, mais do que os outros sacramentais, o parentesco espiritual.

5. Demais. ─ A oração não é menos eficaz para nos fazer progredir no bem do que a instrução ou a
catequese. Ora, pela oração não contraímos nenhum parentesco espiritual. Logo, nem pelo catecismo.

6. Demais. ─ A instrução dada aos batizados, pela pregação, não vale menos que a dada aos não
batizados. Ora, a pregação não gera nenhum parentesco espiritual. Logo, nem o catecismo.
Mas, em contrário, o Apóstolo: Eu vos gerei em Jesus Cristo pelo Evangelho. Ora, a geração espiritual
gera o parentesco espiritual. Logo, a pregação do Evangelho e a instrução geram o parentesco espiritual,
e não só o batismo.

2. Demais. ─ Assim como o batismo dele o pecado original, assim a penitência, o atual. Logo assim como
o batismo causa um parentesco espiritual, assim também a penitência.

3. Demais. ─ Pai é nome designativo de parentesco. Ora, a penitência, a doutrina, a cura pastoral e
coisas semelhantes fazem com que seja um, pai espiritual do outro. Logo, muitas outras coisas, além do
batismo e da confirmação, geram o parentesco espiritual.

SOLUÇÃO. ─ Nesta matéria há tríplice opinião. Certos dizem que a regeneração espiritual, efeito da
graça septiforme do Espírito Santo, é também produzida por sete cerimônias, começando pela absorção
do sal bento, e acabando pela confirmação feita pelo bispo; e cada uma dessas sete cerimônias gera,
dizem, o parentesco espiritual. ─ Mas, essa opinião não é racional. Porque, o parentesco carnal não se
contrai senão pelo ato completo da geração. Por isso, também a afinidade não se contrai senão pela
mixtão seminal, donde pode resultar a geração carnal. Ora, a geração espiritual não se contrai senão por
algum sacramento. Por onde, não é possível contrair-se o parentesco espiritual senão mediante algum
sacramento. Por isso, outros opinam que o parentesco espiritual se contrai mediante três sacramentos:
o catecismo, o batismo e a confirmação. ─ Mas estes parece ignorarem o sentido das palavras. Pois, o
catecismo não é um sacramento, mas um sacramental. Donde o sentirem outros que só dois
sacramentos geram o parentesco espiritual: a confirmação e o batismo. E esta é a opinião mais comum.
─ Contudo, a respeito do catecismo, certos deles dizem que é um fraco impedimento, por impedir de se
contrair o matrimônio mas não dirimir o matrimônio já contraído.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A natividade carnal abrange duas fases. - A primeira, no
ventre materno, onde vive o ser concebido, de tal modo débil, que não pode viver fora, sem perigo. ─ E
a essa natividade se assimila a regeneração pelo batismo, depois da qual o regenerado ainda deve ser
protegido no seio da Igreja. ─ A segunda natividade começa quando o recém-nascido sai do ventre
materno, por já se lhe haverem aumentado as forças a ponto de poder sem perigo viver no exterior,
vencendo os perigos que poderiam aniquilá-lo. E a essa é comparável a confirmação, fortificado pela
qual o homem confirmado expõe-se a confessar em público o nome de Cristo. ─ Por isso e bem, esses
dois sacramentos são causa do parentesco espiritual.

RESPOSTA À SEGUNDA. ─ O sacramento da ordem não causa nenhuma regeneração, mas só um
aumento de poder; por isso, a mulher não a pode receber. E assim, não pode daí, resultar nenhum
impedimento ao matrimônio. Razão pela qual esse parentesco não é levado em consideração.

RESPOSTA À TERCEIRA. ─ A obra da catequese equivale a uma profissão de batismo futuro; assim como
os esponsais são uma promessa de casamento futuro. Por onde, assim como os esponsais produzem um
certo modo de parentesco, assim também o catecismo, ao menos para impedir o matrimônio de ser
contraído, como certos dizem. O que não se dá com os outros sacramentos.

RESPOSTA À QUARTA. ─ Essa profissão de fé não se faz nos outros sacramentais do batismo, como se
faz na catequese. Logo, não há semelhança de razão.
O mesmo devemos responder à quinta objeção, no tocante à oração, e à sexta, sobre a pregação.

RESPOSTA À SÉTIMA. ─ O Apóstolo ensinava aos Coríntios o modo de catequese, E assim, de certa
maneira, essa pregação mantinha estreita relação com o sacramento da geração espiritual.

RESPOSTA À OITAVA. ─ Pelo sacramento da penitência não se contrai; propriamente falando,
parentesco espiritual. Por isso, o filho de um sacerdote pode casar com aquela que esse sacerdote ouviu
em confissão; do contrário não acharia em toda a paróquia mulher com quem pudesse casar. Nem obsta
que pela penitência fique apagado o pecado atual, pois isso não se dá a modo de geração, mas de cura.
Contudo pela penitência a mulher confitente e o sacerdote contraem uma certa aliança semelhante ao
parentesco espiritual, de modo que ele pecará, tendo relação carnal com ela, tanto como se o fizesse
com a filha espiritual. E isto é assim, por haver uma grande familiaridade entre o sacerdote e a
confitente. ─ Razão pela qual foi feita a proibição referida, para afastar a ocasião de pecado.

RESPOSTA À NONA. ─ O pai espiritual é chamado por semelhança com o carnal. Ora, o pai carnal, como
diz o Filósofo, três coisas dá ao filho: a vida, a nutrição e a instrução. Por isso se chama a um, pai
espiritual de alguém, em razão dessas três funções. Todavia, pelo só fato de ser pai espiritual não tem
parentesco espiritual senão na medida em que se assemelha ao pai carnal, quanto à geração, que dá o
ser. E assim também se pode considerar esta uma resposta à oitava objeção, precedente.

## Art. 3 — Se o parentesco espiritual se contrai entre o batizado e quem o recebe ao sair da fonte batismal.
O terceiro discute-se assim. ─ Parece que não se contrai nenhum parentesco espiritual entre o
batizado e quem o recebe ao sair da fonte batismal.

1. Pois, a geração só é causa de parentesco por parte de quem engendrou carnalmente o filho, e não por
parte de quem o recebeu no momento de nascer. Logo, também nenhum parentesco espiritual se
contrai entre quem recebe o batizado, ao sair da fonte batismal, e o batizado, que é recebido.

2. Demais. ─ Quem recebe o batizado ao sair da fonte batismal, Dionísio lhe chama anadoco, e a ele lhe
compete instruir a criança. Ora, a instrução não é causa suficiente de parentesco espiritual, como se
disse. Logo, nenhum parentesco é contraído pelo batizado e quem o recebe da fonte batismal.

3. Demais. ─ Pode se dar que o batizando seja tirado da fonte batismal antes de ser batizado. Ora, daí
não provém nenhum parentesco espiritual, por não ser capaz de nenhum laço espiritual quem não é
batizado. Logo, receber alguém da fonte batismal não basta para se contrair parentesco espiritual.
Mas, em contrário, a definição do parentesco espiritual supra citada e as autoridades citadas pelo
Mestre.

SOLUÇÃO. ─ Assim como, pela geração carnal, nascemos de uma mãe e de um pai, assim pela geração
espiritual renascemos filho de Deus, como pai, e da Igreja, como mãe. Ora, assim como aquele que
administra o sacramento representa a pessoa de Deus, de quem é instrumento e ministro, assim quem
recebe o batizado ao sair da fonte sagrada, ou assiste o confirmando, representa a pessoa da Igreja. Por
onde, de ambas essas formas se contrai o parentesco espiritual.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Não somente o pai, que gerou carnalmente o filho, fica-
lhe ligado por um parentesco carnal, mas também a mãe, que subministra a matéria da geração, em
cujo ventre foi o filho gerado. E assim, também o anadoco, que em nome de toda a Igreja oferece e
recebe o batizando, e assiste o confirmando, contrai com eles um parentesco espiritual.

RESPOSTA À SEGUNDA. ─ O parentesco espiritual é contraído não em virtude da instrução devida, mas
da geração espiritual, para a qual coopera.

RESPOSTA À TERCEIRA. ─ Um não batizado não pode receber ninguém, da fonte sagrada, por não ser
membro da Igreja e não poder por isso representá-la ao exercício dessa função. Pode contudo batizar,
por ser uma criatura de Deus, e poder portanto representá-lo, como o representa quem batiza. Mas
nem por isso pode contrair nenhum parentesco espiritual, porque está privado da vida espiritual, que
anima o homem logo depois do batismo.

## Art. 4 — Se o parentesco espiritual se transmite da marido para a mulher.
O quarto discute-se assim. ─ Parece que o parentesco espiritual não se transmite do marido para a
mulher.

1. Pois, a união espiritual e a corporal são diferentes e de gêneros diversos. Logo, por meio da conjunção
carnal entre marido e mulher, não se transmite o parentesco espiritual.

2. Demais. ─ O padrinho e a madrinha muito mais contribuem para a geração espiritual, que é a causa
do parentesco espiritual, que o marido ao fazer o papel de padrinho, e a sua mulher. Ora, o padrinho e a
madrinha não contraem entre si nenhum parentesco espiritual. Logo, nem pelo fato de ser o marido
padrinho de uma pessoa contrai com esta a madrinha qualquer parentesco espiritual.

3. Demais. ─ Pode se dar, que o marido seja batizado e não a mulher; assim quando aquele, de infiel que
era, se converteu sem a mulher ter-se convertido, Ora, um não-batizado não é susceptível de
parentesco espiritual. Logo, não se transmite este de marido para mulher.

4. Demais. ─ O marido e a esposa podem simultaneamente receber uma pessoa, ao sair da fonte
batismal. Se, portanto, o parentesco espiritual se transmitisse de marido à mulher, resultaria que, os
cônjuges seriam duas vezes pai espiritual ou mãe espiritual da mesma pessoa. O que não pode ser.
Mas, em contrário. ─ Os laços espirituais se comunicam mais facilmente que os corporais. Ora, a
consangüinidade do marido se transmite à mulher pela afinidade. Logo, e com maior razão, o
parentesco espiritual.

SOLUÇÃO. ─ De dois modos pode uma pessoa tornar-se compadre da outra. ─ Primeiro, pelo ato desta,
a qual lhe batizou o filho ou o levou ao batismo. E neste caso o parentesco espiritual não se transmite
de marido para mulher, salvo se a criança for filho desta; porque então, do mesmo modo que o marido,
a mulher contrai diretamente o parentesco espiritual. ─ De outro modo, por ato próprio, como quando
recebe da fonte sagrada o filho de outrem. E nesse caso o parentesco espiritual passa para a mulher, se
o marido já teve com ela conjunção carnal; não porém, se o matrimônio ainda não se consumou, porque
então ainda não se tornaram uma só carne. Mas, quando o parentesco se comunica é por uma espécie
de afinidade; e portanto, pela mesma razão, passa para a mulher, com quem o homem teve conjunção
carnal, embora não seja esposa. Donde o ditado: a mulher, que levou meu filho à fonte batismal ou
aquela cujo filho foi levado por minha mulher, essa é minha comadre e não pode tornar-se minha
esposa; mas a mulher que levou à fonte o filho da minha mulher, não porém meu, essa poderia vir a ser
minha esposa depois de viúvo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ De serem de gêneros diversos, a união corporal e a
espiritual, podemos concluir que uma não é a outra; não porém que não possa uma ser a causa da
outra. Pois, coisas de gêneros diversos, pode uma ser às vezes causada outra, essencial ou
acidentalmente.

RESPOSTA À SEGUNDA. ─ O pai espiritual e a mãe espiritual de uma mesma pessoa, não ficam unidas
pela geração espiritual, senão só acidentalmente; pois, para tal, só um dos dois bastaria. Não contraem,
portanto, nenhum parentesco espiritual que os impedisse de casar um com o outro. Donde, o ditado:
Dos dois compadres um era sempre pai espiritual; o outro, carnal; e tal regra não falha. Ora, pelo
matrimônio marido e mulher se tornam uma só carne, essencialmente falando. Logo, não há símile.

RESPOSTA À TERCEIRA. ─ A esposa, não sendo batizada, não contrairá nenhum parentesco espiritual,
por não ser capaz de tal; e não porque não possa, pelo matrimônio, transmitir-se o parentesco
espiritual, do marido para a mulher.

RESPOSTA À QUARTA. ─ O fato de o pai e a mãe espirituais não contraírem nenhum parentesco
espiritual entre si não impede o marido e a mulher de receberem juntos um batizado da fonte sagrada.
Nem há inconveniente em a esposa, por causas diversas, tornar-se mãe espiritual de uma mesma
pessoa; assim como também pode vir a ser afim e consanguínea de uma mesma pessoa por parentesco
carnal.

## Art. 5 — Se o parentesco espiritual se transmite aos filhos carnais do pai espiritual.
O quinto discute-se assim. ─ Parece que o parentesco espiritual não se transmite aos filhos carnais do
pai espiritual.

1. Pois, o parentesco espiritual não é susceptível de graus. Ora, graus haveria se transmitisse de pai a
filho, porque a pessoa gerada muda de grau, como se disse. Logo, não se transmite aos filhos carnais do
pai espiritual.

2. Demais. ─ Pai e filho, irmão e irmão, no mesmo grau estão de parentesco. Se, pois, o parentesco
espiritual passa de pai a filho, pela mesma razão passará de um irmão para outro. O que é falso.
Mas, em contrário, o Mestre o prova pela autoridade citada.

SOLUÇÃO. ─ O filho é algo do pai, mas não ao inverso, como diz Aristóteles. Por isso, o parentesco
espiritual passa do pai para o filho carnal, mas não ao inverso.
Por onde é claro serem três as espécies de parentesco espiritual. Uma chamada paternidade espiritual,
entre o pai espiritual e o filho espiritual. Outra chamada compaternidade, entre o pai espiritual e o
carnal de uma mesma pessoa. A terceira chamada fraternidade espiritual, entre o filho espiritual e os
filhos carnais do mesmo pai. E qualquer deles impede o matrimônio de ser contraído e o anula se já o
foi.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A pessoa nascida de outra, por geração carnal, dista de
um grau a mais da que é parente no mesmo gênero de parentesco; mas está no mesmo grau com a que
lhe é parente de gênero diverso. Assim, um filho é parente no mesmo grau que de seu pai, da esposa
deste, mas o parentesco é de outro gênero. Ora, o parentesco espiritual é de gênero diverso do carnal.
Por isso, um filho espiritual não é parente do filho natural de seu pai espiritual, no mesmo grau em que
o filho natural é do pai, por meio do qual o primeiro participa do parentesco espiritual. E isso prova, que
o parentesco espiritual não tem necessariamente graus.

RESPOSTA À SEGUNDA. ─ Um irmão não é parte de seu irmão, como o filho o é do pai; ao passo que a
esposa é algo do marido, com quem forma um só corpo. Por isso, o parentesco espiritual não passa de
irmão para irmão, quer tenha êle nascido antes ou depois da fraternidade espiritual.