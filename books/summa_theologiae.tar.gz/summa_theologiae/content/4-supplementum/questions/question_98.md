# Questão 98: Da vontade e do intelecto dos condenados.
Em seguida devemos tratar do concernente ao afeto e ao intelecto dos condenados.
E nesta questão discutem-se nove artigos:

## Art. 1 — Se toda vontade dos condenados é má.
O primeiro discute-se assim. ─ Parece que nem toda vontade dos condenados é má.

1. ─ Pois, como diz Dionísio, os demônios desejam o que há de melhor ─ existir, viver e inteligir. Logo,
como os condenados não estão em condição pior que os demônios, parece que também eles podem ter
boa vontade.

2. Demais. ─ O mal, como diz Dionísio, é absolutamente involuntário. Logo, tudo quanto os condenados
querem como bem real ou aparente o querem. Ora, a vontade em si mesma dirigida para o bem é boa.
Logo, os condenados podem ter boa vontade.

3. Demais. ─ Certos condenados haverá que, quando viviam no mundo, conservaram certos hábitos
virtuosos. Assim, os gentios, que tinham virtudes políticas. Ora, é dos hábitos virtuosos que procedem
os atos meritórios da vontade. Logo, a vontade de certos condenados pode ser meritória.
Mas, em contrário. ─ A vontade obstinada só pode querer o mal. Ora, os condenados, como os
demônios, serão obstinados. Logo, a vontade deles nunca poderá ser boa.
2 . Demais. ─ Assim está a vontade dos condenados para o mal, como a dos santos para o bem. Ora, a
vontade dos santos nunca poderá ser má. Logo, nunca também os condenados poderão ter uma
vontade boa.

SOLUÇÃO. ─ Podemos distinguir nos condenados uma dupla vontade: a deliberativa e a natural. ─ A
natural não a têm eles de si mesmos, mas do autor da natureza, que nesta infundiu a inclinação
chamada vontade natural. Ora, como nos condenados subsiste a natureza, poderão eles ter a boa
vontade natural. ─ A vontade deliberativa porém eles a têm de si próprios, pela qual poderão inclinar o
afeto para um ou outro objeto. E essa vontade deles não pode ser senão má. E isto pela completa
aversão que têm do ─ fim último da vontade reta; nem pode vontade nenhuma ser boa senão em
ordem a esse fim último. Por onde, embora queiram algum bem, não o querem contudo bem, de modo
que a vontade se lhes pudesse chamar boa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ As palavras de Dionísio se entendem da vontade natural,
que é a inclinação da natureza para um bem. Essa inclinação natural porém lhes está corrompida pela
malícia; pois, o bem que naturalmente desejam sob certas más circunstâncias o desejam.

RESPOSTA À SEGUNDA. ─ O mal como tal não move a vontade, senão enquanto considerado bem. Ora,
da própria malícia deles procede julgarem bom o mal. Razão pela qual lhes é má a vontade.

RESPOSTA À TERCEIRA. ─ O hábito das virtudes civis não subsiste na alma separada; porque estas
virtudes só dão perfeição à vida civil, que não mais haverá depois de esta vida. Mas se perdurassem
depois dela, os maus nunca os poriam em prática, por lh'o impedir a obstinação da mente.

## Art. 2 — Se os condenados podem arrepender-se do mal que fizeram.
O segundo discute-se assim. ─ Parece que os condenados nunca poderão arrepender-se do mal que
fizeram.

1. ─ Pois, como diz Bernardo, o condenado sempre quer a iniquidade que cometeu. Logo, nunca se
arrependerá do pecado cometido.

2. Demais. ─ Querer não ter pecado é ter uma vontade boa. Ora, os condenados não terão nunca boa
vontade. Logo, não quererão nunca ter pecado. Donde a mesma conclusão que antes.

3. Demais. ─ Segundo Damasceno, o que foi para os homens a morte foi para os anjos a queda. Ora, a
vontade do anjo depois da queda ficou de tal modo inconvertível, que nunca mais poderá voltar da
eleição com que pecou. Logo, nem os condenados poderão arrepender-se dos pecados cometidos.

4. Demais. ─ Maior será a maldade dos condenados no inferno que a dos pecadores neste mundo. Ora,
certos pecadores neste mundo não se arrependem dos pecados cometidos ─ ou por cegueira da mente,
como os heréticos; ou por obstinação, como os que se alegram depois de terem feito o mal e triunfam
de prazer nas piores causas, no dizer da Escritura. Logo, também os condenados no inferno não se
arrependerão dos pecados cometidos.
Mas, em contrário, a Escritura diz dos condenados: Dentro de si tocados de arrependimento.

2. Demais. ─ Conforme o Filósofo, os maus é que têm o coração cheio de arrependimento; pois, com o
que se deleitam logo depois se contristam. Logo, os condenados, maus em sumo grau, serão os mais
arrependidos.

SOLUÇÃO. ─ Podemos nos arrepender do pecado, considerado este em si mesmo; ou por acidente. Do
pecado em si mesmo nos arrependemos quando como tal o abominamos. Acidentalmente porém
quando o detestamos em razão de alguma circunstância que o acompanha, como a pena ou cousa
semelhante. Ora, os maus não se arrependerão dos pecados em si mesmo considerado, porque têm a
vontade fixada na malícia deles. Mas, se arrependerão acidentalmente, por sofrerem a pena que pelos
pecados cometidos expiam.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Os condenados querem a iniquidade, mas tem-lhe
aversão à pena, E assim, se arrependem, por acidente, da iniquidade cometida.

RESPOSTA À SEGUNDA. ─ Querer alguém não ter pecado, por causa da turpitude do pecado, é ter uma
vontade boa. Mas essa não na terão os condenados.

RESPOSTA À TERCEIRA. ─ Sem nenhuma aversão da vontade, podem os condenados se arrepender dos
seus pecados; pois, o que lhes causa essa aversão não é o que neles antes desejaram, mas cousa
diferente ─ a pena.

RESPOSTA À QUARTA. ─ Os homens neste mundo, por mais obstinados que sejam, acidentalmente se
arrependem dos seus pecados, quando por eles punidos. Pois, como diz Agostinho, vemos até mesmos
os ferocíssimos dos animais se absterem, pelo temor das penas, dos mais intensos prazeres.

## Art. 3 — Se os condenados podem, com razão reta e deliberativa, querer não existir.
O terceiro discute-se assim. ─ Parece que os condenados não podem, com razão reta e deliberativa,
querer não existir.

1. ─ Pois, Agostinho diz: Considera quão grande bem é a existência, que a querem tanto os santos, como
os condenados. Ora, ter uma existência miserável é melhor que não a ter de nenhum modo.

2. Demais. ─ No mesmo lugar Agostinho argumenta da maneira seguinte. A pre-eleição supõe a eleição.
Ora, a inexistência, não sendo nada e não tendo nem a aparência do bem, não pode ser objeto de
eleição. Logo, os condenados não podem querer de preferência a inexistência à existência.

3. Demais. ─ O maior mal deve ser o mais evitado. Ora, inexistir é o mal máximo, pois, priva totalmente
do bem, de modo que elimina todo ser. Logo, é preferível uma existência miserável à não-existência.
Donde a mesma conclusão que antes.
Mas, em contrário, o Apóstolo: Naqueles dias os homens buscarão a morte e a morte fugirá a eles.

2. Demais. ─ A miséria dos condenados sobrepuja todas as misérias deste mundo. Ora, há quem deseje a
morte para fugir às misérias desta vida. Donde o dizer a Escritura: Ó morte, que boa é a tua sentença
para um homem necessitado e que se acha falto de forças, para o de idade já decrépita e para o que
esta cheio de cuidados, e para o desconfiado, que se vê de todo falto de sabedoria. Logo e com muito
maior razão, os condenados podem desejar o não ser, com um desejo fundado na razão deliberativa.

SOLUÇÃO. ─ O não ser podemos considerá-lo à dupla luz ─ Em si mesmo e, então, não tendo nenhuma
razão de bem, do qual é a privação pura, de nenhum modo é desejável. ─ Ou enquanto liberta de uma
vida penosa ou miserável. E então assume o aspecto de bem, pois; é um bem-estar isento do mal, como
diz o Filósofo. E neste sentido é melhor aos condenados não existir, que levar uma existência miserável.
Donde aquilo do Evangelho: Melhor fosse ao tal homem não haver nascido. E aquele outro lugar da
Escritura ─ Maldito seja o dia em que eu nasci, pondera a Glosa de Jerônimo: É melhor não existir que
ter uma existência miserável. E, a esta luz, os condenados podem, pela razão deliberativa, preeleger a
não existência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ As palavras de Agostinho significam que a inexistência
não pode, em si mesma, ser objeto de eleição; senão só por acidente, quando põe termo à uma vida
miserável. Quanto ao dito ─ todos os seres naturalmente desejam existir e viver ─ não devemos
entendê-lo, ensina o Filósofo, de uma vida má, miserável e cheia de sofrimentos.

RESPOSTA À SEGUNDA. ─ O não-ser não pode constituir em si mesmo o objeto de uma eleição, senão só
por acidente, como dissemos.

RESPOSTA À TERCEIRA. ─ Embora a inexistência seja o máximo dos males por ser a privação do ser, é
contudo um grande bem quando nos livra da miséria, o máximo dos males. E nesse sentido o não-ser
pode constituir objeto de eleição.

## Art. 4 — Se os condenados no inferno quereriam que houvesse outros condenados, além deles.
O quarto discute-se assim. ─ Parece que os condenados no inferno não querem que haja outros
condenados além deles.

1. ─ Pois, o Evangelho diz que o mau rico orava pelos seus irmãos, não viessem a cair no lugar dos
tormentos. Logo e pela mesma razão; os outros condenados não quereriam que ao menos os seus
amigos carnais fossem condenados ao inferno.

2. Demais. ─ Os condenados não ficam purificados dos seus afetos desordenados. Ora, certos
condenados amaram com afeto desordenado a outros que não foram condenados. Logo, não haveriam
de lhes querer o mal da condenação.

3. Demais. ─ Os condenados não desejam o aumento das suas penas. Ora, se houvesse maior número
deles, maior pena sofreriam, como também, ao contrário, a multiplicação dos bem-aventurados
aumenta-lhes a alegria. Logo, os condenados não quereriam que os salvos se condenassem.
Mas, em contrário, aquilo de Isaías ─ Ergueram-se de seus sólios, diz a Glosa: É consolação dos maus ter
muitos companheiros de sofrimentos.

2. Demais. ─ Os condenados têm enorme inveja uns dos outros. Logo, sofrem com a felicidade dos bem-
aventurados e lhes desejam a condenação.

SOLUÇÃO. ─ Assim como os bem-aventurados na pátria terão uma caridade perfeitíssima, assim,
perfeitíssimo será o ódio dos condenados. Por onde, assim como os santos se comprazem com todo
bem, assim todo bem será para os ímpios uma causa de dor. Daí o fazê-las soberanamente sofrer a
consideração da felicidade dos santos. Por isso diz a Escritura: vejam e sejam confundidos os que têm
inveja do teu povo e devore o fogo a teus inimigos. Por isso quereriam que todos os bons fossem
condenados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Tão grande será a inveja dos condenados que, por ser
suma a sua miséria, invejarão até a glória dos seus parentes; o que mesmo nesta vida se dá, quando a
inveja é muita. Menos invejarão porém aos parentes que aos outros, e maior lhes seria a pena se todos
os parentes se condenassem e todos os mais se salvassem, que se algum dos parentes se salvasse. E foi
por isso que o mau rico orava para seus irmãos se livrarem da condenação. Pois, sabia que muitos
outros se salvariam, e preferiria que os irmãos fossem condenados, mas com todos os outros.

RESPOSTA À SEGUNDA. ─ O amor não fundado no honesto facilmente desaparece, sobretudo entre
maus, como diz o Filósofo. Por onde, os condenados não conservarão amizade para com os que amaram
desordenadamente. Mas nisto a vontade lhes permanecerá perversa, que ainda amarão a causa desse
amor desordenado.

RESPOSTA À TERCEIRA. ─ Embora a multidão dos condenados aumente a pena de cada um, contudo
lhes crescerá o ódio e a inveja a ponto de preferirem ser mais atormentados com muitos, do que menos
sós.

## Art. 5 — Se os condenados terão ódio a Deus.
O quinto discute-se assim. ─ Parece que os condenados não terão ódio a Deus.
1 . ─ Pois, como diz Dionísio, a todos é amável o belo e o bom que é a causa de todo bem e de toda
beleza. Ora, tal é Deus. Logo, Deus não pode ser odiado de ninguém.

2. Demais. ─ Ninguém pode odiar a bondade em si mesma, como não pode querer o que é a malícia
mesma; pois, o mal é absolutamente involuntário, como diz Dionísio. Ora, Deus é a própria bondade.
Logo, ninguém pode odiá-la.
Mas, em contrário, a Escritura: A soberba de aqueles que te aborrecem sobe continuamente.

SOLUÇÃO. ─ O nosso afeto se move pelo bem ou pelo mal apreendido. Ora, Deus pode ser apreendido
de dois modos ─ em si mesmo, como o apreendem os bem-aventurados, que o vêem em essência; e
pelos seus efeitos, como o apreendemos nós e os condenados. ─ Ora, Deus, sendo em si mesmo a
bondade por essência, não pode desagradar a nenhuma vontade. Portanto, quem o vê em essência não
no pode odiar. ─ Mas dos seus efeitos uns podem repugnar à vontade pela contrariarem. Então Deus
pode ser odiado, não em si mesmo, mas em razão desses efeitos contrários à vontade. ─ Ora, os
condenados, que sentem o efeito da justiça de Deus, que é a pena, odeiam-no como odeiam as penas
que sofrem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ As palavras de Dionísio devem entender-se do apetite
natural, que os condenados têm pervertido pelo que lhe acrescenta a vontade deliberada deles, como
se disse.

RESPOSTA À SEGUNDA. ─ A objeção colheria, se os condenados contemplassem a Deus em mesmo,
como o bem por essência.

## Art. 6 — Se os condenados podem desmerecer.
O sexto discute-se assim. ─ Parece que os condenados podem desmerecer.

1. ─ Pois, os condenados têm a vontade má, como diz o Mestre. Ora, a má vontade que tiveram nesta
vida foi-lhes uma causa de demérito. Logo, se no inferno não podem desmerecer, tiram vantagem da
sua condenação.

2. Demais. ─ Os condenados estão nas mesmas condições que os demônios. Ora, os demônios, depois
da sua queda, ainda podem desmerecer. Por isso à serpente, que induziu o homem a pecar, foi-lhe
infligida uma pena por Deus, como narra a Escritura. Logo, também os condenados podem desmerecer.

3. Demais. ─ Um ato desordenadamente procedente do livre arbítrio é sempre demeritório, mesmo
quando praticado sob o império de uma necessidade, cuja causa é o próprio agente. Assim, merece
duplo castigo o ébrio, que, no estado de embriaguez cometeu outro pecado, como diz Aristóteles. Ora,
os condenados foram a causa da sua própria obstinação, que os coloca como em necessidade de pecar.
Logo, como os seus atos procedem desordenadamente do livre arbítrio, acarretam sempre o demérito.
Mas, em contrário. ─ A pena entra numa mesma divisão com a culpa. Ora, a vontade perversa dos
condenados procede da obstinação, que lhes constitui a pena. Logo, a vontade perversa dos
condenados não é culpa que lhes acarrete demérito.

2. Demais. ─ Chegado ao termo derradeiro da vida, não lhe é possível mais ao homem nenhum
movimento nem progresso, tanto em relação ao bem como ao mal. Ora, os condenados, sobretudo
depois do dia de juízo, chegarão ao termo último da sua condenação, porque então as duas cidades
terão o seu fim, como diz Agostinho. Logo, os condenados, depois do dia de juízo, não mais
desmerecerão pela sua vontade perversa; do contrário, se lhes agravaria a condenação.

SOLUÇÃO. ─ Os condenados devemos considerá-los antes e depois do dia de juízo. Ora, todos estão de
acordo em que depois do dia de juízo não haverá mais lugar para mérito nem demérito. E isto porque o
mérito e o demérito se ordenam à ulterior consecução de um bem ou um mal.
Após o dia do juízo haverá a consumação final dos bons e dos maus, de modo que nada será
ulteriormente acrescentado de bem ou de mal. Por isso, a boa vontade, nos santos, não lhes será
mérito, mas prêmio; e a má vontade, nos condenados, não lhes será demérito, mas pena somente. As
operações da virtude são precípuas na felicidade, e as contrários delas são precípuas na miséria, diz o
Filósofo.
Mas depois do dia de juízo, certos são de opinião que os bem-aventurados merecerão e os condenados
desmerecerão. ─ Isto porém não é admissível, em relação ao prêmio essencial ou à pena principal,
porque, tanto em relação a um como à outra, tanto bem-aventurados como condenados chegaram ao
termo final. Pode ser porém em relação ao prêmio acidental ou à pena secundária, susceptíveis de
aumento até ao dia do juízo. E isto sobretudo no concernente aos demônios e os bons anjos; pois, pelo
zelo destes muitas almas se salvaram, donde um aumento de alegria para eles; e pela malícia daqueles,
muitas se perderam, o que lhes redunda um aumento das penas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A miséria suma é ter caído na suma desgraça; razão por
que os condenados não podem mais desmerecer. Por onde é claro, que nenhuma vantagem tiram do
seu pecado.

RESPOSTA À SEGUNDA. ─ Não é ofício das almas condenadas arrastar os mais à condenação; mas o é
dos demônios, razão por que podem desmerecer, em relação à pena secundária.

RESPOSTA À TERCEIRA. ─ Os condenados não ficam isentos do demérito pela razão alegada, de serem
coagidos a pecar, pela necessidade; mas por terem caído no estado de suma desgraça. ─ Contudo, a
necessidade de pecar, de que nós mesmos somos a causa, excusa da culpa como necessidade que é;
pois, todo pecado há de ser voluntário. Mas não excusa enquanto oriunda de uma vontade precedente.
Por onde, todo o inquérito da culpa subsequente já está incluído na culpa antecedente.

## Art. 7 — Se os condenados podem se servir dos conhecimentos obtidos neste mundo.
O sétimo discute-se assim. ─ Parece que os condenados não podem se servir dos conhecimentos
obtidos neste mundo.

1. ─ Pois, o exercício da ciência é deleitável soberanamente. Ora, os condenados não são susceptíveis de
nenhuma deleitação. Logo, não podem de nenhum modo servir-se da ciência antes adquirida, de
nenhum modo.

2. Demais. ─ As penas dos condenados são maiores que qualquer pena deste mundo. Ora, neste mundo,
quando sofremos grandes tormentos, não podemos considerar nenhumas conclusões científicas,
absorvidos que ficamos pelo suplício dessas penas. Logo, com maior razão, os condenados no inferno.

3. Demais. ─ Os condenados estão sujeios ao tempo. Ora, a dilatação do tempo é uma causa de
esquecimento, como diz Aristóteles. Logo, os condenados hão de esquecer-se do que cá souberam.
Mas, em contrário, no Evangelho se diz ao rico condenado: Lembra-te que recebeste os teus bens em
tua vida, etc. Logo, hão de lembrar-se do que neste mundo souberam.

2. Demais. ─ As espécies inteligíveis subsistem na alma separada, como se disse. ─ Ora, se os
condenados não puderem usar delas, inúteis lhes serão.

SOLUÇÃO. ─ Pela perfeição da sua beatitude, nada terão os santos que não lhes seja matéria de alegria.
É igualmente, nada nos condenados haverá que não lhes seja causa de sofrimento, nem lhes faltará
nenhuma causa de sofrimentos, para lhes ser consumada a miséria. Ora, pensarmos em certos
conhecimentos adquiridos pode, de algum modo, ser causa de alegria ─ ou por parte dos objetos
conhecidos, que amamos; ou por parte do próprio conhecimento, pelo que tem de perfeição e de
verdadeiro. Mas pode também ser causa de sofrimento ─ por parte das cousas conhecidas, quando são
de natureza a nos fazerem sofrer; ou parte do conhecimento mesmo, quando lhe refletimos na
imperfeição, pensando no conhecimento deficiente que temos de uma cousa, que desejaríamos
conhecer perfeitamente. E assim os condenados terão, no pensamento dos conhecimentos que
adquiriram antes, matéria de sofrimento e de nenhum modo, de prazer. Assim, considerarão no mal que
fizeram e pelo qual se condenaram; e nos bens agradáveis, que perderam. E tudo isso lhes aumentará as
torturas. Também serão supliciados pensando quão imperfeito foi o conhecimento que tiveram das
verdades especulativas, e como perderam, podendo tê-la alcançado, a suma perfeição dele.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora a consideração científica possa em si mesma ser
causa de prazer, pode contudo por acidente ser causa de sofrimento. E isto se dará com os condenados.

RESPOSTA À SEGUNDA. ─ Neste mundo, a alma está unida a um corpo corruptível. Por isso, o
sofrimento do corpo impede a alma de pensar. Mas na vida futura, a alma não será assim obstruída pelo
corpo; pois, por mais atormentado que seja o corpo, contudo a alma sempre com a maior lucidez
poderá considerar no que lhe puder ser causa de sofrimento.

RESPOSTA À TERCEIRA. ─ O tempo é uma causa acidental de sofrimento, enquanto o movimento, que
ele mede, é causa de mudança. Ora, depois do dia de juízo, cessará o movimento do céu; por isso
nenhum esquecimento mais poderá haver, por mais longa que seja a duração. Mas, mesmo antes do dia
de juízo, o movimento do céu não causa nenhuma alteração na disposição da alma separada.

## Art. 8 — Se os condenados às vezes pensarão em Deus.
O oitavo discute-se assim. ─ Parece que os condenados às vezes pensarão em Deus.

1. ─ Pois, não podemos ter um ódio atual, senão do em que pensamos. Ora, os condenados terão ódio
de Deus, como diz o Mestre. Logo, às vezes pensarão em Deus.

2. Demais. ─ Os condenados terão o remorso da consciência. Ora, a consciência sofre remorso dos atos
cometidos contra Deus. Logo, os condenados às vezes pensarão em Deus.
Mas, em contrário. ─ O mais perfeito dos nossos pensamentos é o que tem Deus por objeto. Ora, os
condenados estão num estado imperfeitíssimo. Logo, não pensarão em Deus.

SOLUÇÃO. ─ De dois modos pode ser Deus objeto dos nossos pensamentos. ─ Primeiro, em si mesmo e
pelo que propriamente é; i. é, como princípio de toda bondade. E então de nenhum modo podemos
pensar em Deus sem experimentarmos prazer. Ora, assim, os condenados não pensarão absolutamente
em Deus. ─ Segundo, pelos seus efeitos, como punir ou outro semelhante, que lhe são como acidentes.
E então o pensar em Deus pode ser causa de sofrimento. E assim os condenados pensarão em Deus .

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Os condenados não pensam em Deus senão por causa
das proibições que faz ou das penas que inflige, e que lhes contraria à vontade má. Por isso não no
consideram senão como quem lhes impõe castigos e proibições. Donde se deduz a resposta à segunda
objeção. ─ Porque a consciência do pecado não remorde, senão enquanto contrária ao preceito divino.

## Art. 9 — Se os condenados vêem a glória dos bem-aventurados.
O nono discute-se assim. ─ Parece que os condenados não vêem a glória dos bem-aventurados.

1. ─ Pois, mais dista deles a glória dos bem-aventurados que as cousas que se passam neste mundo. Por
isso, aquilo de Job ─ Ou os seus filhos estejam exaltados, etc., diz Gregório: Assim como os que vivem
ainda neste mundo ignoram o lugar onde estão as almas dos mortos, assim os mortos, que viveram
neste mundo, não sabem o que passa com os que nele deixaram. Logo e com muito maior razão, não
podem ver a glória dos bem-aventurados.

2. Demais. ─ O que é concedido, como um grande dom aos santos nesta vida, nunca será concedido aos
condenados. Mas a Paulo foi concedido como um grande dom ver a vida que os santos vivem
eternamente com Deus, como diz a Glosa a um lugar das suas epístolas. Logo, os condenados não verão
a glória dos santos.
Mas, em contrário, o Evangelho: Quando o rico estava nos tormentos viu a Abraão e Lázaro no seu seio.

SOLUÇÃO. ─ Os condenados, antes do dia de juízo, verão a glória dos bem-aventurados. Não que a
conheçam tal qual é; mas por apenas saberem que gozam de uma glória incomparável. E com isso se
perturbarão, quer pela inveja, que os faz sofrer com a felicidade dos santos; quer também por terem,
eles, perdido essa glória. Donde o dizer a Escritura, dos ímpios: Vendo-os assim perturbar-se-ão com
temor horrível. Mas depois do dia de juízo ficarão totalmente privados da visão dos bem-aventurados .
Mas isso, longe de lhes diminuir, há de aumentar-lhes a pena. Porque terão na memória a glória dos
bem-aventurados, que viram no juízo, ou antes dele, o que lhes redundará em tormentos. E ainda mais
supliciados ficarão vendo-se julgados indignos mesmo de ver a glória que os santos merecem possuir.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ As cousas que se passam neste mundo se as vissem os
condenados não os afligiriam tanto como a visão da glória dos santos. Por isso não lhes são essas cousas
reveladas, como o é a glória dos santos. Embora lhes seja dado conhecimento, das cousas desta vida,
aquelas que lhes podem, aumentar os suplícios.

RESPOSTA À SEGUNDA. ─ Paulo teve conhecimento da vida que os santos vivem com Deus,
experimentando-a e esperando mais perfeitamente na vida futura. O que não se dá com os condenados.
Logo, o símil não colhe.