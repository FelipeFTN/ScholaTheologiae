# Questão 67: Do libelo de repúdio.
Em seguida devemos tratar do libelo de repúdio.
E nesta questão discutem-se sete artigos:

## Art. 1 — Se a indissolubilidade do matrimônio é de lei natural.
O primeiro discute-se assim. ─ Parece que a indissolubilidade do matrimônio não é de lei natural.

1. Pois, a lei da natureza é comum para todos. Ora, nenhuma lei, senão a de Cristo, proíbe repudiar a
esposa. Logo, a sua união inseparável com o marido não é de lei natural.

2. Demais. ─ Os sacramentos não foram instituídos pela lei natural. Ora, a indissolubilidade do
matrimônio pertence ao bem do sacramento. Logo, não é de lei natural.

3. Demais. ─ A conjunção entre marido e mulher se ordena principalmente à geração dos filhos, à
criação e à instrução deles. Ora, tudo isso se realiza num tempo determinado. Logo, depois desse
tempo, é lícito ao marido separar-se da esposa, sem colidir em nada com a lei natural.

4. Demais. ─ O fim principal do matrimônio é o bem da prole. Ora, a dissolubilidade do casamento
contraria esse bem; porque, como dizem os filósofos, não pode ter filhos de uma mulher um homem
que também poderia tê-los de outra, e a qual por seu lado também poderia conceber de outro homem.
Logo, a indissolubilidade do matrimônio é antes contrária à lei da natureza, que estabelecida por ela.
Mas, em contrário. ─ Aquilo sobretudo é de lei natural, que a natureza teve, desde o seu princípio, como
bem instituído. Ora, tal é a indissolubilidade do matrimônio, como lemos no Evangelho. Logo, é de lei
natural.

2. Demais. ─ É de lei natural que o homem não desobedeça a Deus. Ora, de certo modo podia
desobedecer-lhe se separasse os que Deus uniu. Logo, como daí resulta a indissolubilidade do
matrimônio, parece que esta é de lei natural.

SOLUÇÃO. ─ O matrimônio na intenção da natureza, se ordena à criação dos filhos, não só
temporariamente, mas por toda a vida deles. Por isso é de lei natural que os pais entesourem para os
filhos e estes sejam herdeiros daqueles. Logo, sendo os filhos o bem comum do marido e da mulher,
deve a sociedade conjugal ficar perpetuamente indissolúvel, segundo o ditame da lei natural. Assim que
a indissolubilidade do casamento é de lei natural.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Só a lei de Cristo conduziu o gênero humano à perfeição
restituindo-lhe a prístino estado da sua natureza. Por isso à lei de Moisés nem às leis humanas foi
possível fazer desaparecer tudo o contrário à lei natural; o que só à lei do espírito e da vida estava
reservado.

RESPOSTA À SEGUNDA. ─ A indissolubilidade é natural ao matrimônio, como símbolo da perpétua
conjunção entre Cristo e a Igreja, e como exigido pela sua função natural, ordenada ao bem da prole,
como se disse. E como a dissolução do matrimônio mais diretamente repugna à significação do
sacramento, que ao bem da prole, a que só por consequência repugna, como dissemos, por isso a
indissolubilidade do matrimônio se entende antes, como para o bem do sacramento que para o da
prole. Embora possa estar compreendido tanto num como noutro bem. Ora, enquanto pertencente ao
bem da prole, será a indissolubilidade de lei natural; mas não enquanto pertinente ao bem do
sacramento.

RESPOSTA À TERCEIRA. ─ Resulta do que foi dito.

RESPOSTA À QUARTA. ─ O matrimônio principalmente se ordena ao bem comum, em razão do fim
principal, que é o bem da prole; embora em razão do fim secundário também se ordene ao bem da
pessoa que o contraiu, pois o casamento é, em si mesmo considerado, remédio à concupiscência. Por
isso, nas leis reguladoras do matrimônio mais se consulta ao interesse geral que a casos particulares.
Assim, pois, embora a indissolubilidade do matrimônio impida o bem da prole num caso particular,
contudo convém a esse bem absolutamente considerado. Por isso a objeção não colhe.

## Art. 2 — Se pode ser lícito em virtude de uma dispensa, repudiar a esposa.
O segundo discute-se assim. ─ Parece que não pode ser lícito, em virtude de nenhuma dispensa,
repudiar a esposa.

1. Pois, o que no matrimônio é contrário ao bem da prole vai contra os preceitos primeiros da lei da
natureza, que não são susceptíveis de dispensa. Ora, tal é o que se dá no fato de o marido repudiar a
esposa. Logo, etc.

2. Demais. ─ Uma concubina difere da esposa sobretudo por não viver uma vida conjugal indissolúvel.
Ora, ter uma concubina não era possível em virtude de nenhuma dispensa. Logo, nem repudiar a
esposa.

3. Demais. ─ As mesmas dispensas podem conceder-se hoje, que se podiam outrora, Ora, hoje ninguém
pode obter dispensa para repudiar a esposa. Logo, nem outrora.
Mas, em contrário. ─ Agar conviveu com Abraão com afeto uxório, como se disse. Ora, por preceito
divino ele a deitou fora e não pecou. Logo, uma dispensa podia tornar lícito ao marido repudiar a
mulher.

SOLUÇÃO. ─ Dispensar em preceitos, sobretudo quando de algum modo pertencem à lei da natureza, é
como alterar o censo natural das coisas. O qual de dois modos pode ser mudado. ─ Ou por lima causa
natural que impede o censo natural de outra, como se dá nos casos pouco frequente de fenômenos
naturais casuais. Mas deste modo o curso natural das coisas não varia, quando elas se sucedem sempre,
senão só quando se sucedem com frequência. ─ Ou por uma causa totalmente sobrenatural, como no
caso dos milagres. E deste modo pode mudar-se o curso natural dos fenômenos naturais, não somente
o ordenado a se realizar frequentemente, mas também o ordenado a se realizar sempre. Como no caso
do sol, que parou, no tempo de Josué, e retrogradou, no de Ezequias; e do eclipse miraculoso, no tempo
da paixão de Cristo.
Ora, a razão de haver dispensa nos preceitos da lei natural às vezes a descobrimos nas causas inferiores.
E assim os preceitos secundários da lei natural são susceptíveis de dispensa, não porém os primários,
por serem como de existência necessária, conforme dissemos a propósito da pluralidade de mulheres e
de casos semelhantes. Outras vezes porém a razão da dispensa está só nas causas superiores. E então
Deus pode dispensar, mesmo contrariando os preceitos primários da lei da natureza, em razão de algum
mistério divino a ser significado ou revelado. Tal a dispensa feita a Abraão no preceito que lhe proibia
imolar o filho inocente. E tais dispensas não se concedem comum ente a todos, mas só a certas pessoas
em particular, como se dá no caso do milagre. Se, pois, a indissolubilidade do matrimônio está contida
nos preceitos primários da lei da natureza, só podia ser susceptível de dispensa, do segundo modo. Se
porém entre os preceitos secundários dessa lei, então era susceptível de dispensa, mesmo do primeiro
modo. Ora, está contido, antes, entre os preceitos secundários da lei natural. Pois, a indissolubilidade do
matrimônio não se ordena ao bem da prole, fim principal dele, senão enquanto os pais devem ser a
providência dos filhos, durante toda a vida deles, fornecendo-lhes tudo o necessário à vida. Ora, esse
fornecimento não está na intenção primeira da natureza, pela qual todas as coisas são comuns a todos.
Por onde, não está na intenção primeira da natureza o poder o marido repudiar a mulher; por
consequência esse procedimento não colide com os preceitos primários, mas contra os secundários, da
lei natural. Por onde, pode ser susceptível de dispensa também ao primeiro modo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ No bem da prole se compreende, enquanto pertencente
à intenção primeira da natureza, tanto a procriação como a criação e a instrução, até que os filhos
atinjam à idade perfeita. Mas o fato de os filhos poderem entrar mais tarde na posse da herança e de
outros bens que lhes venham ser deferidos, pertencem a intenção secundária de lei natural.

RESPOSTA À SEGUNDA. ─ Ter uma concubina vai contra o bem da prole, quanto ao fim visado pela
intenção primeira da natureza, que é a educação e a criação que exige uma diuturna colaboração dos
pais, de que não é capaz uma concubina, tomada temporariamente. Por onde o símile não colhe.
Contudo, quanto ao segundo modo de dispensar, também pode haver dispensa para um homem ter
uma concubina, como está claro na Escritura.

RESPOSTA À TERCEIRA. ─ A indissolubilidade, embora corresponda ao fim secundário do matrimônio,
como função da natureza, pertence-lhe porém ao fim primário dele, como sacramento da Igreja. Por
isso, desde que foi instituído como sacramento da Igreja e enquanto permanecer assim instituído, não
pode ser objeto de dispensa, senão talvez ao segundo modo de dispensar.

## Art. 3 — Se a lei de Moisés permitia repudiar a mulher.
O terceiro discute-se assim. ─ Parece que a lei de Moisés permitia repudiar a mulher.

1. Pois, um modo de consentirmos é não impedir o que poderíamos impedir. Logo, não tendo Moisés
proibido o repúdio da esposa, sem pecar, assim procedendo, porque a lei é santa, na expressão do
Apóstolo ─ parece que permitiu o repúdio.

2. Demais, ─ Os profetas falavam por inspiração do Espírito Santo, como diz a Escritura. Ora, esta
também diz: Quando tu lhe vieres a cobrar aversão, despede-a. Logo, como o Espírito Santo não inspira
nada de ilícito, parece que o repúdio da mulher nem sempre foi ilícito.

3. Demais. ─ Crisóstomo diz, que assim como os Apóstolos permitiram as segundas núpcias, assim
Moisés permitiu o libelo de repúdio. Ora, as segundas núpcias não são pecado. Logo, nem o repúdio da
mulher, sob a lei de Moisés.
Mas, em contrário, diz o Senhor, que o libelo de repúdio foi dado aos judeus por Moisés, por causa da
dureza do coração deles. Ora, essa dureza de coração não os escusava de pecado. Logo, nem a lei sobre
o libelo de repúdio.

2. Demais. - Crisóstomo diz: Moisés, concedendo o libelo de repúdio, não quis revelar as exigências da
justiça divina, mas tirar do pecado a culpa que ele implica, a fim de procedendo os judeus de acordo
com a lei, por assim dizer, o pecado deles não fosse considerado tal.

SOLUÇÃO. ─ Nesta matéria duas são as opiniões. Uns dizem que aqueles que repudiavam; de acordo
com a lei de Moisés, a esposa, depois de lhe ser mandado o libelo de repúdio, não ficavam isentos de
pecado, embora ficassem escusados da pena a lhes ser infligida, segundo essa lei. Por isso se diz que
Moisés permitiu o libelo de repúdio. E assim, distinguem quatro modos de permissão. O primeiro
consiste em não ordenar; pois, quando não se ordena um bem maior entende-se permitido o menor;
assim o Apóstolo, não prescrevendo a virgindade, permitiu o casamento. O segundo consiste na
ausência de proibição; assim consideram-se permitidos os pecados veniais, quando não foram
proibidos. O terceiro, na ausência de coibição; assim, todos os pecados se consideram permitidos por
Deus se os não proibiu podendo fazê-lo. O quarto, na ausência de punição; e assim o libelo de repúdio
foi permitido pela lei de Moisés; não a fim de ser conseguido um maior bem, como no caso da dispensa
para casar com várias mulheres, mas a fim de coibir o maior mal do uxoricídio, a que os judeus eram
inclinados pela depravação da potência concupiscível. Assim também lhes foi permitido exercer a usura
para com os estrangeiros, pela corrupção da sua potência concupiscível, a fim de não na praticarem
para com os próprios irmãos. E ainda, por causa da desordem que a suspeita introduz na parte racional,
foi-lhes permitido o sacrifício do espírito de zelos, a fim de que uma simples suspeita não lhes alterasse
o juízo.
Mas a Lei Velha, embora não conferisse a graça, contudo foi dada com o fim de fazer conhecer o
pecado, como os Santos Padres geralmente o ensinavam. Por isso outros pensam que se, repudiando a
esposa pecassem, ao menos deveriam disso ser advertidos pela lei e pelos profetas, segundo aquilo da
Escritura: Anuncia ao meu povo as suas maldades. Do contrário, pareceriam demasiado negligentes, se
nunca lhes anunciassem o necessário à salvação, deles ignorando o que não se pode admitir, porque
pela justiça da lei, observada no tempo para que foi dada, mereciam a vida eterna. Por isso ensinam
que, embora repudiar a esposa seja em si mesmo um mal, lícito contudo se tornava por divina
permissão. E isso o confirma a autoridade de Crisóstomo, quando diz que o legislador, permitindo o
repúdio, quis tirar ao pecado a culpa que ele implica. Mas, embora esta opinião seja provável, contudo a
primeira é mais comumente defendida. Por onde, passamos a responder às objeções.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Quem pode proibir não peca, abstendo-se de fazê-lo por
não esperar correção; ao contrário, julgando resultar um maior mal, procedente dessa proibição. Talo
que se deu com Moisés. Por isso, apoiado na autoridade divina, não proibiu o libelo de repúdio.

RESPOSTA À SEGUNDA. ─ Os profetas, inspirados pelo Espírito Santo, não disseram que a esposa podia
ser repudiada por uma como ordem do Espírito Santo, mas como tendo-o este apenas permitido, a fim
de evitar maiores males.

RESPOSTA À TERCEIRA. ─ Crisóstomo não assimila sob todas suas formas essas duas permissões, mas só
quanto à causa delas; pois ambas foram feita para impedir uma vergonhosa desordem.

RESPOSTA À QUARTA. ─ Embora a dureza de coração pão os escusasse do pecado, contudo os escusava
a permissão fundada nessa dureza. Assim certas coisas se proíbem aos sãos, que se permitem aos
doentes, sem que contudo estes pequem usando de tal permissão.

RESPOSTA À QUlNTA. ─ Um bem pode ser preterido de dois modos. ─ Primeiro, para se conseguir um
maior bem, então a preterição do primeiro bem houve a sua honestidade no bem maior colimado, assim
foi honestamente dispensado Jacó da lei que obrigara a uma só esposa, por causa do bem, que são os
filhos. ─ De outro modo, um bem pode ser preferido para evitar um mal maior. E então, se quem assim
proceder tinha autoridade para fazê-la, a preterição desse bem não implica nenhum modo, embora
ainda não se torne por isso honesta. Assim a indissolubilidade do casamento foi preterida pela lei de
Moisés para evitar o mal do uxoricídio. Por isso diz Crisóstomo, que Moisés quis tirar do pecado a culpa
que ele implica. Pois embora o repúdio continuasse a ser uma desordem, pelo que, se chama pecado,
não tinha contudo o reato da pena temporal nem eterna, por ser permitido por dispensa divina. E assim
ficava isento de culpa. Por isso Crisóstomo acrescenta, no mesmo lugar, que foi permitido o repúdio, um
mal por certo, contudo licito, Mas os defensores da primeira opinião não querem entender essas
palavras então como significando, que não havia no repúdio o reato da pena temporal.

## Art. 4 — Se era lícito à mulher repudiada casar com outro marido.
O quarto discute-se assim. ─ Parece que era licito à mulher repudiada casar com outro marido.

1. Pois, no repúdio maior era a iniquidade do marido repudiador, que da mulher repudiada. Ora, o
homem podia sem pecado casar com outra mulher. Logo, também sem pecado podia a mulher casar
com outro.

2. Demais. ─ Agostinho diz, do fato de ter um homem mais de uma mulher, que não era pecado, quando
o costume o justificava. Ora, na vigência da lei Velha, era costume uma mulher repudiada casar com
outro, como se lê: Se ela, depois de ter saído, casar com outro, etc. Logo, não pecava unindo-se a outro
homem.

3. - Demais. ─ O senhor mostra ser a justiça do novo testamento superabundante em relação à do Velho.
Ora, diz que em virtude da superabundante justiça do novo testamento, a mulher repudiada não pode
casar de novo. Logo, a Lei antiga o permitia. Mas, em contrário, o Evangelho: Todo aquele que repudiar
sua mulher comete adultério. Ora, o adultério nunca o permitiu a Lei Antiga. Logo, à mulher repudiada
não era lícito casar de novo.

2. Demais. ─ A Lei Antiga diz que a mulher repudiada que tomar outro marido, ficou poluta e se faz
abominável diante do Senhor. Logo, pecava casando de novo.

SOLUÇÃO. ─ Segundo a primeira opinião pecava a mulher repudiada casando com outro, por não estar
ainda dissolvido o primeiro matrimônio. Porque a mulher, que está sujeita ao marido, enquanto houver
o marido, alada está à lei, como, diz o Apóstolo. Pois não podia ter dois maridos ao mesmo tempo. ─
Mas, de acordo com a segunda opinião, assim como era lícito, por dispensa divina ao marido repudiar a
mulher, assim a esta casar de novo. Porque a indissolubilidade do matrimônio ficava colhida em virtude
de uma permissão divina, e só se compreendem as palavras do Apóstolo na vigência do matrimônio
indissolúvel.
Respondamos, pois às objeções de lado a lado.

RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Ao marido era lícito ter mais de uma mulher, por dispensa divina.
Por onde, repudiada uma, podia casar com outra, mesmo sem o casamento estar dissolvido. Mas nunca
foi lícito, a uma mulher ter mais de um marido. Logo, o símile não colhe.

RESPOSTA À SEGUNDA. ─ Nessas palavras de Agostinho a palavra: mos não quer dizer costume, mas um
ato honesto; no sentido em que se diz ser alguém morigerado, palavra derivada de mos, quando é de
costumes honestos; ou quando designamos a filosofia moral com um vocábulo derivado de mos.

RESPOSTA À TERCEIRA. ─ O senhor mostra que a Lei Nova superabunda, em relação à Velha, no
atinente aos Conselhos; não só relativamente ao que a Lei Velha permitia, mas também quanto ao que
proibia, e que muitos julgavam lícito pela má compreensão do que a lei prescrevia. Tal o caso do ódio ao
inimigo. E o mesmo se dava com o repúdio.

RESPOSTA À QUARTA. ─ As palavras do Senhor se entendem, dos tempos da Lei Nova, que eliminou
essa permissão. E desse modo também se entendem certas palavras de Crisóstomo, quando diz, que
quem repudia a mulher, segundo a lei, comete quatro iniquidades. Assim, perante Deus, é homicida, por
ter o propósito de matar a esposa, se não na repudiar; e porque a repudia sem ela ter adulterado, caso
único em que o Evangelho permite o repúdio; e ainda pela fazer adúltera, assim ramo o outro com que
se uniu.

RESPOSTA À QUINTA. ─ Uma glosa interlinear diz: Ficou poluta e se fez abominável, isto é, no juízo de
aquele que a repudiou antes, como adúltera. E assim não é poluta, absolutamente falando. ─ Ou se
chama poluta no mesmo sentido em que era chamado imundo quem tocava num morto ou num
leproso, não por imundícia de culpa, mas de certa irregularidade legal. Porém também não era
permitido a um sacerdote casar com uma viúva ou repudiada.

## Art. 5 — Se era lícito ao marido retomar a esposa repudiada.
O quinto discute-se assim. ─ Parece que era lícito ao marido retomar a esposa repudiada.

1. Pois, é lícito corrigir o mal feito. Ora, era mal feito o marido repudiar a esposa, era lícito corrigi-lo,
chamando-a de novo.

2. Demais. ─ Sempre foi lícito ser indulgente para com um pecador, preceito moral que todas as
legislações admitem. Ora, retomando a esposa repudiada, o marido era indulgente para com uma
pecadora. Logo, tal lhe era licito.

3. Demais. ─ A lei mosaica dá como causa de não poder a repudiada ser recebida de novo como esposa o
jato de ser poluta. Ora, a repudiada não fica poluta, senão casando de novo. Logo, ao menos, antes de
casar com outro, era licito ao marido tomá-la de novo como esposa.
Mas, em contrário, a Escritura: Não poderá o primeiro marido tornar a tomá-la como mulher, etc.

SOLUÇÃO. ─ A lei sobre o libelo de repúdio permitia duas coisas ─ repudiar a esposa e poder a esposa
repudiada casar com outro. E preceituava outras duas: o escrito do libelo de repúdio, e que o marido
repudiador não na podia receber de novo como esposa. O que tudo foi feito, segundo os que professam
a primeira opinião como pena e afligida a mulher, que casou com outro e ficou poluta por esse pecado.
Mas, segundo outros, a fim de o marido não repudiar facilmente a mulher, que depois, de nenhum
modo poderia recuperar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Como remédio ao mal cometido pelo marido, que
repudiava a mulher, a lei ordenava que não podia tornar a recebê-la como esposa, segundo do
sobredito se colhe. Por isso assim foi disposto por lei divina.

RESPOSTA À SEGUNDA. ─ Sempre foi lícito, abundante o rancor do coração, ter indulgência para com
um pecador; mas não fará deixar de aplicar uma pena imposta por Deus.

RESPOSTA À TERCEIRA. ─ Nesta matéria há duas opiniões ─ Uns dizem que era lícito à repudiada
reconciliar-se com o marido, desde que não estivesse unida com outro em matrimônio. E esta proibição
foi feita como pena do adultério voluntariamente conhecido pela mulher, de modo que não podia voltar
a viver com o primeiro marido. ─ Mas como a proibição feita pela lei era geral, por isso dizem outros que
mesmo antes de ela casar com outro não podia o marido tornar a chamá-la para junto de si, uma vez
repudiada, porque o ser ela poluta não se entende como o sendo por culpa, mas conforme se disse.

## Art. 6 — Se a causa do repúdio era o ódio pela mulher.
O sexto, discute-se assim. ─ Parece que causa de repúdio era o ódio pela mulher.
1 Pois, diz a Escritura: Quando tu lhe vieres a cobrar aversão. Logo, etc.

2. Demais. ─ A Escritura, diz: Se não for agradável a seus olhos por causa de alguma fealdade etc. Logo, a
mesma conclusão anterior.
Mas, em contrário. ─ A esterilidade e a fornicação contrariam mais o casamento, que o ódio. Logo,
deveriam, mais que o ódio, ser as causas do repúdio.

2. Demais. ─ O ódio pode ser causado pela virtude da pessoa odiada. Se pois, o ódio fosse causa
suficiente de repúdio, então uma mulher poderia ser repudiada por causa da sua virtude. O que é
absurdo.

3. Demais. ─ A Escritura diz: Se um homem casar com uma mulher e depois lhe criar aversão, e acusá-la
de relações ilícitas antes do casamento e não no conseguir provar, será açoitado e condenado a pagar
cem ciclos de prata e não na poderá repudiar enquanto viver. Logo, o ódio não é causa suficiente de
repúdio.

SOLUÇÃO. ─ A causa da permissão de repudiar a esposa foi evitar o uxoricídio como os Santos Padres
em geral explicam. Ora a causa principal do homicídio é o ódio. Logo, é o ódio a causa próxima do
repúdio. Ora, tanto o ódio como o amor procedem de alguma causa. Por onde, devemos admitir outras
causas, remotas essas que eram a causa do ódio.
Ora, Agostinho diz: Havia na lei muitas causas de a esposa ser repudiada, Cristo só permitia como causa
de repúdio a fornicação; e ordenou que se suportassem os outros sofrimentos oriundos do casamento,
em defesa da fidelidade e da castidade conjugal. Essas causas se entendem como sendo os males do
corpo, por exemplo, a doença, ou outros defeitos graves; a fornicação e pecados semelhantes, causas de
costumes desonestos, e que maculam a alma. Outros porém reduzem o número dessas causas, dizendo
com bastante probabilidade, que não era lícito o repúdio senão por uma causa sobreveniente ao
casamento. Nem por uma qualquer dessas causas, mas só pelas capazes de contrariar o bem dos filhos ─
quer corporal, como a esterilidade, a lepra e males semelhantes; quer da alma, como os maus costumes,
que levariam os filhos a imitar o exemplo materno.
Mas uma glosa, àquilo da Escritura ─ Se não for agradável, etc. ─ ainda restringe mais, considerando
como causa de repúdio só o pecado, dizendo que nesse texto, por fealdade se entende o pecado. Mas
essa glosa considera como pecado o que contraria não só o bem moral da alma, mas ainda, à natureza
do corpo.
Assim, pois, concedemos as duas primeiras objeções.

RESPOSTA À TERCEIRA. ─ A esterilidade e defeitos semelhantes são causa de ódio e assim, são causas
remotas.

RESPOSTA À QUARTA. ─ A virtude, em si mesma considerada, não torna ninguém odioso, porque a
bondade é causa do amor. Logo, a objeção não colhe.

RESPOSTA À QUINTA. ─ Era dado como pena ao marido não poder, nesse caso, repudiar a esposa para
sempre; assim também como no outro caso, quando a tinha deflorado, de virgem que era.

## Art. 7 — Se as causas de repúdio deviam ser escritas no libelo.
O sétimo discute-se assim ─ Parece que as causas de repúdio deviam ser escritas no libelo.

1. Pois, pelo libelo escrito de repúdio, o marido ficava livre da pena imposta pela lei. Ora, isso parece
absolutamente injusto, salvo se o repúdio tivesse causas suficientes. Logo, deviam ela ser escritas no
libelo.

2. Demais. ─ O escrito de repúdio para nenhuma outra coisa servia senão para exarar as causas do
repúdio. Logo, se estas não fossem escritas, inútil o marido mandar tal escrito à esposa.

3. Demais. ─ Assim o diz o mestre das Sentenças.
Mas, em contrário. ─ As causas do repúdio eram ou não suficientes. Se o eram, as segundas núpcias, que
a lei permitia à mulher, ficavam-lhe proibidas. Se não eram, o repúdio revelava-se como injusto e então
não podia ter lugar. Logo, de nenhum modo as causas ele repúdio eram minuciosamente escritas no
libelo.

SOLUÇÃO. ─ As causas do repúdio não eram escritas minuciosamente no libelo, mas só em geral, para
mostrar que o repúdio era justo. Ora, segundo Josefo, as coisas assim se passavam a fim de a mulher
munida do libelo escrito de repúdio poder casar de novo; pois do contrário ninguém nela acreditaria.
Por isso na sua opinião, a escritura rezava: Prometo nunca mais viver maritalmente consigo. Mas,
segundo Agostinho, assim era escrito o libelo a fim de enquanto ele demorava a ser feito e pela
intervenção do conselho dissuasório dos escribas, o marido abandonasse o propósito de repudiar.
Donde se deduzem as respostas às objeções.