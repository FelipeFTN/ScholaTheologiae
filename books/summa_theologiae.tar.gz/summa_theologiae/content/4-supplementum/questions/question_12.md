# Questão 12: Da satisfação, quanto a sua quididade.
Em seguida devemos tratar da satisfação, sobre a qual há quatro questões a considerar. Primeiro, da sua
quididade. Segundo, da sua possibilidade. Terceiro, da sua qualidade. Quarto, do pelo que o homem
satisfaz a Deus.
Na primeira questão discutem-se três artigos:

## Art. 1 — Se a satisfação é uma virtude ou um ato de virtude.
O primeiro discute-se assim. — Parece que a satisfação não é uma virtude nem um ato de virtude.

1. ─ Pois, todo ato virtuoso é meritório. Ora, segundo parece, a satisfação não é meritória; porque,
sendo o mérito gratuito, a satisfação supre um débito. Logo, a satisfação não é um ato de virtude.

2. Demais. ─ Todo ato de virtude é voluntário. Ora, às vezes se nos dá satisfação contra a nossa vontade;
como quando é punido pelo juiz quem nos ofendeu. Logo, a satisfação não é ato virtuoso.

3. Demais. ─ Segundo o Filósofo, na virtude moral a eleição é o principal. Ora, a satisfação, respeitando
principalmente os atos externos, não se faz por eleição. Logo, não é um ato de virtude. Mas, em
contrário. ─ A satisfação faz parte da penitência. Ora, a penitência é uma virtude. Logo, também ato de
virtude é a satisfação.

2. Demais. ─ Nenhum ato, salvo o virtuoso, contribui para o perdão do pecado; pois, um contrário
destrói o outro. Ora, pela satisfação o pecado fica totalmente delido. Logo, a satisfação não é um ato de
virtude.

SOLUÇÃO. ─ De dois modos pode um ato ser chamado virtuoso. ─ Primeiro, materialmente. E assim,
qualquer ato sem malícia implícita, ou falta da circunstância própria, pode ser chamado virtuoso; pois,
qualquer ato tal como andar, falar e outros, pode a virtude empregar para o seu fim. ─ De outro modo,
dizemos ser um ato formalmente virtuoso quando a sua denominação implica implícita a forma e a
essência da virtude; assim, sofrer com valentia se considera ato de fortaleza. Ora, a idéia de mediedade
é o que toda virtude moral tem de formal. Portanto, todo ato que implica a idéia de mediedade é
chamado formalmente um ato de virtude. E sendo a igualdade um meio termo, implicado pelo nome
mesmo de satisfação — pois, não dizemos satisfeito senão o que implica proporção de igualdade com
outra causa — resulta que a satisfação também formalmente é um ato de virtude.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora a satisfação em si mesma seja um débito,
contudo enquanto praticamos essa obra voluntariamente, por nossa parte o ato se apresenta como
gratuito. Assim, fazemos da necessidade virtude. Pois, se o débito diminui o mérito é por implicar a
necessidade, que contraria a vontade. Portanto, a vontade consentindo no necessário não exclui a idéia
de mérito.

RESPOSTA À SEGUNDA. ─ O ato de virtude não implica o voluntário no paciente, mas no agente, por ser
ato deste. Por onde, como aquele contra o qual o juiz exerce a vindita se comporta como paciente,
quanto à satisfação, e não como agente, não é necessário seja a sua satisfação voluntária, senão só ao
juiz agente.

RESPOSTA À TERCEIRA. — O principal na virtude pode ser considerado a dupla luz. ─ Primeiro, como o
principal nela, enquanto virtude. E assim, o elemento racional, ou o que mais se lhe aproxima, é o
principal na virtude. De modo que a eleição e os atos inferiores, na virtude como tal, são o que há nela
de principal. ─ De outra maneira, podemos considerar o principal relativamente a uma determinada
virtude. E então, o mais principal nela é o donde tira a sua determinação. Ora, em certas virtudes, os
atos internos se determinam pelos externos; porque a eleição, comum a todas as virtudes, por isso
mesmo que é a eleição de um tal ato, torna-se própria dessa virtude. E assim, os atos exteriores em
certas virtudes são os mais principais. Tal é o caso também da satisfação.

## Art. 2 — Se a satisfação é um ato de justiça.
O segundo discute-se assim. ─ Parece que a satisfação não é um ato de justiça.

1. ─ Pois, o fim da satisfação é nos reconciliar com quem ofendemos. Ora, a reconciliação, implicando o
amor, supõe a caridade. Logo, a satisfação é ato de caridade e não de justiça.

2. Demais. ─ As causas dos pecados em nós são as paixões da alma, pelas quais somos incitados ao mal.
Ora, a justiça, segundo o Filósofo, não tem por objeto as paixões, mas os atos. Logo, sendo próprio da
satisfação eliminar as causas dos pecados, como diz a letra do Mestre, conclui-se que não é um ato de
justiça.

3. Demais. ─ Acautelar para o futuro não é ato de justiça, mas antes, de prudência, de que a cautela faz
parte. Ora, isto implica a satisfação, pois a ela pertence não permitir a entrada às sugestões dos
pecados. Logo, a satisfação não é um ato de justiça.
Mas, em contrário. ─ Nenhuma virtude leva em conta a noção de débito, senão a justiça. Ora, a
satisfação dá a honra devida a Deus, como diz Anselmo. Logo, a satisfação é um ato de justiça.

2. Demais. ─ Nenhuma virtude, a não ser a justiça, realiza a igualdade entre as coisas exteriores. Ora,
isso o faz a satisfação, que estabelece a igualdade entre a reparação e a ofensa. Logo, a satisfação é um
ato de justiça.

SOLUÇÃO. — Segundo o Filósofo, a mediedade da justiça se funda na igualdade entre duas coisas,
segundo uma certa proporcionalidade. Por onde, como essa igualdade implica a denominação mesma
de satisfação, pois o advérbio latino satis designa uma igualdade de proporção, conclui-se ser a
satisfação formalmente um ato de justiça. Ora, o ato de justiça, segundo o Filósofo, ou é de nos para
com outrem, como quando lhe pagamos o devido; ou de outrem para com outrem, como quando o juiz
estabelece a justiça entre duas partes. ─ Ora, quando é um ato de justiça de nós para com outrem, a
igualdade se constitui em nós mesmos: quando de outrem para com outrem, a igualdade se constitui
pelo ato de justiça recebido. E como a satisfação exprime a igualdade no agente, significa o ato de
justiça nosso para com outrem, propriamente falando. ─ No outro lado, um ato nosso para com outrem
pode realizar a justiça, no atinente às ações e às paixões, ou às coisas externas; assim como co mete
uma injustiça para com outrem quem lhe subtrai o que lhe pertence ou o lesa por qualquer ato. E sendo
o dar o uso dos bens externos, por isso o ato de justiça, enquanto restabelece a igualdade nas causas
externas, significa propriamente restituir, ao passo que satisfazer exprime manifestamente a igualdade
nas ações, embora às vezes isto se tome por aquilo. ─ Mas, igualdade não pode haver senão entre
causas desiguais. Por isso a satisfação pressupõe a desigualdade entre as ações, desigualdade que
constitui a ofensa; por onde, diz respeito a uma ofensa precedente senão a justiça vindicativa. E esta
restabelece a igualdade no que recebe o ato justo; e é indiferente seja o paciente o mesmo que o
agente ─ como quando nos impomos uma pena a nós mesmos; ou que o seja ─ como quando o juiz pune
alguém; pois, em ambos os casos se exerce a justiça vindicativa. Semelhantemente, a penitência, que
restabelece a igualdade só no agente, pois, é o penitente mesmo que se dá a si a pena; e assim a
penitência faz de certo modo parte da justiça vindicativa. Donde se conclui, que a satisfação, que
restabelece no agente a igualdade relativamente à ofensa precedente, é um ato de justiça, no atinente à
parte chamada penitência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A satisfação, cama do sobredito se colhe, é uma certa
compensação pela injustiça feita. Por onde, assim como a injustiça praticada causava imediatamente a
desigualdade da justiça e, por consequência, a desigualdade oposta à amizade, assim também a
satisfação conduz diretamente à igualdade da justiça e, por consequência, à igualdade da amizade. E
como um ato procede, como elícito, do hábito a cujo fim imediatamente se ordena; e como imperado,
daquele a cujo fim ultimamente tende, por isso a satisfação é um
ato elícito da justiça, mas imperado pela caridade.

RESPOSTA À SEGUNDA. ─ Embora a justiça respeite principalmente os atos, contudo, por consequência,
respeita as paixões, enquanto causas dos atos. Mas, assim como a justiça coíbe à ira, impedindo-nos de
causar injúria a outrem; e a conscupiscência, impedindo-nos de violar o leito alheio; assim também a
satisfação pode eliminar as causas dos pecados.

RESPOSTA À TERCEIRA. ─ Qualquer virtude moral participa do ato da prudência, porque ela realiza
formalmente em cada uma a idéia da virtude; pois, é a que estabelece a mediedade em cada uma das
virtudes morais, como o demonstra a definição de virtude dada por Aristóteles.

## Art. 3 — Se é boa a definição da satisfação dada por Agostinho, e reproduzida pelo Mestre das Sentenças, e que reza: a satisfação consiste em eliminar as causas dos pecados e não Ihes permitir a entrada às sugestões.
O terceiro discute-se assim. ─ Parece que não é boa a definição da satisfação dada por Agostínho, e
reproduzi da pelo Mestre das Sentenças, e que reza: a satisfação consiste em eliminar as causas dos
pecados e não lhes permitir a entrada às sugestões.

1. ─ Pois, a causa atual do pecado é a concupiscência. Ora, nesta vida não podemos eliminar a
concupiscência. Logo, a satisfação não consiste em eliminar as causas dos pecados.

2. Demais. ─ A causa do pecado é mais forte que ele. Ora, por nossas próprias forças não podemos
eliminar o pecado. Logo e com maior razão, as causas do pecado. Donde, a mesma conclusão anterior.

3. Demais. ─ A satisfação, sendo parte da penitência, diz respeito ao passado e não ao futuro. Ora, não
permitir a entrada às sugestões dos pecados diz respeito ao futuro. Logo, não deve entrar na definição
da satisfação.

4. Demais. ─ A satisfação diz respeito à ofensa passada. Ora, da ofensa passada nenhuma menção se faz.
Logo, está mal formulada a definição da satisfação.

5. Demais. ─ Anselmo dá outra definição: A satisfação consiste em dar a honra devida a Deus. Onde não
faz nenhuma menção do que Agostinho põe na sua. Logo, uma delas há de ser errada.

6. Demais. ─ A honra devida a Deus também um inocente pode dá-la. Ora, satisfazer não cabe ao
inocente. Logo, a definição de Anselmo é mal formulada.

SOLUÇÃO. ─ A justiça não visa somente fazer desaparecer a desigualdade precedente, punindo a culpa
passada; mas também há de guardar a igualdade no futuro; porque, segundo o Filósofo, as penas são
remédios. Por onde, também a satisfação, ato de justiça causador da pena, é um remédio curativo dos
pecados passados e preservativo dos futuros. Por onde, quando satisfazemos a outrem, compensamos o
passado e acautelamos o futuro. Sendo assim, podemos definir de dois modos a satisfação. ─ Primeiro,
em relação à culpa passada, que ela elimina por uma compensação. Por isso se diz que a satisfação é um
restabelecimento da igualdade da justiça violada pela injúria feita. E nisso vem dar também a definição
de Anselmo, dizendo que satisfazer é dar a honra devida a Deus, considerando-se o débito em razão da
culpa cometida. ─ De outro modo podemos defini-la como preservativa da culpa futura: e assim a define
Agostinho. Ora, a preservação de uma doença do corpo se faz pela eliminação das suas causas
produtoras. O mesmo porém não se dá com a doença espiritual, pois, o livre arbítrio não pode sofrer
coação; por isso, pode evitar as causas precedentes do mal, embora dificilmente; e pode incorrer neste,
mesmo removidas essas causas. Por isso, introduz na definição da satisfação duas coisas: a eliminação
das causas, quanto às causas precedentes; e a relutância do livre arbítrio contra o pecado, quanto ao
incorrer no pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Devemos entender aqui, por causa do pecado atual, as
suas duas causas próximas: a concupiscência, resultante do hábito ou do ato do pecado, e outras
consequências do pecado passado; e as ocasiões externas de pecar, como o lugar, a má companhia e
semelhantes. Essas causas ficam eliminadas nesta vida pela satisfação, embora a concupiscência, causa
remota do pecado atual, não fique totalmente eliminada nesta vida pela satisfação, embora fique
debilitada.

RESPOSTA À SEGUNDA. ─ A causa do mal ou da privação, no sentido em que a tem, não é senão a falha
do bem, e o bem mais facilmente se perde que se constitui. Por isso é mais fácil cortar as causas da
privação e do mal do que remover a este, o qual não se remove senão sendo substituído pelo bem,
como se dá com a cegueira e as suas causas. ─ E contudo as referidas causas do pecado não são causas
suficientes, pois delas não resulta necessàriamente o pecado; são apenas umas ocasiões. ─ Além disso, a
satisfação não é possível sem o auxílio de Deus, e este não vem sem a caridade, conforme o dizemos.

RESPOSTA À TERCEIRA. ─ Embora a penitência, pelo que propriamente é, diga respeito ao passado,
contudo, mesmo por consequência, diz respeito ao futuro, enquanto remédio preservativo. E assim
também a satisfação.

RESPOSTA À QUARTA. ─ Agostinho define a satisfação enquanto dada a Deus, a quem verdadeiramente
falando, nada pode ser tirado, embora o pecador faça o que em si está para o privar de alguma coisa.
Por isso a referida satisfação mais principalmente exige a emenda no futuro, que a compensação pelos
atos passados. Donde vem definir Agostinho a satisfação neste ponto de vista. ─ Mas nem por isso
podemos menos conhecer, pelo acautelamento do futuro, a compensação do passado, pois, tanto esta
como aquele recaem sobre as mesmas coisas, de modo inverso. Pois, no passado, considerando as
causas dos pecados as detestamos por causa dos pecados, começando o movimento da detestação
pelos pecados; mas na cautela começamos pelas causas de modo que, eliminadas estas, mais facilmente
evitemos os pecados.

RESPOSTA À QUINTA. ─ Nenhum inconveniente há em darmos diversas definições do mesmo objeto,
segundo os aspectos diversos que nele distinguirmos. E tal se dá no caso vertente, como do sobre dito
se colhe.

RESPOSTA À SEXTA. ─ Por débito se entende o que devemos a Deus em razão da culpa cometida; pois, a
penitência diz respeito ao débito, como dissemos.