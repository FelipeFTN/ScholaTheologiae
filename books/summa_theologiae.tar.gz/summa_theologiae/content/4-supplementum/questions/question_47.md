# Questão 47: Do consentimento coacto e condicionado.
Em seguida devemos tratar do consentimento coacto e condicionado. E nesta questão discutem-se seis
artigos:

## Art. 1 — Se o consentimento pode ser coado.
O primeiro discute-se assim. ─ Parece que nenhum consentimento pode ser coacto.

1. Pois, o livre arbítrio não é susceptível de coação em nenhum dos seus aspectos, como se disse. Ora, o
consentimento é ato do livre arbítrio. Logo, não pode ser coacto.

2. Demais. ─ O violento, é o mesmo que coacto. Mas o coacto é, segundo o Filósofo, o ato cujo principio
é exterior ao paciente, mas que em nada contribui para ele. Ora, o princípio de todo consentimento é
íntimo. Logo, nenhum consentimento pode ser coacto.

3. Demais. ─ Todo pecado se consuma pelo consentimento. Ora, o que é causa do pecado não pode ser
efeito da coação; pois, segundo Agostinho, ninguém peca praticando o que não pode evitar. Logo,
definição que os juristas dão da violência ─ uma força imperiosa que não pode ser contrastada ─ conclui-
se que o consentimento não pode ser coacto nem violento.

4. Demais. ─ A escravidão opõe-se à liberdade. Ora, coagir é próprio do senhor, como o diz uma
definição de Túlio, de acordo com a qual a violência é uma força impetuosa, que sujeita um ser a laços
estranhos. Logo, o livre arbítrio não é susceptível de violência. E portanto nem o consentimento que é o
seu ato.
Mas, em contrário, o que não pode existir não pode impedir nada. Ora, a coação impede o
consentimento no matrimônio, como diz o Mestre. Logo, o consentimento não pode ser coacto.

2. Demais. ─ O matrimônio reveste a forma de um contrato. Ora, nos contratos a vontade pode ser
coacta; por isso o legislador concede a restituição por inteiro, não tendo como ratificado o feito por
violência ou medo. Logo, no matrimônio o consentimento pode ser coacto.

SOLUÇÃO. ─ A coação ou violência pode ser de duas espécies. Uma produz a absoluta necessidade. E
esse violento é o considerado absoluto pelo Filósofo; assim, quando forçamos alguém andar. ─ Outra
gera a necessidade condicionada. E a esse violento o Filósofo chama misto; assim, quando se arrojam
mercadorias ao mar a fim de não naufragar. E nesta espécie de violência, embora o ato não seja
voluntário, contudo, consideradas as circunstâncias é voluntário hic et nunc. Ora, como todo ato é
particular, por isso é voluntário absolutamente falando, mas involuntário de certo modo. Por onde, esta
espécie de violência ou de coação pode atingir o consentimento, que é um ato de vontade; mas não a
primeira espécie. E como ela se opera temor de um perigo iminente, por isso, esta violência é o mesmo
que o medo, que de certo modo coage a vontade. Ao passo que a primeira espécie pode atingir também
os atos corpóreos.
E como o legislador considera não só os atos íntimos, mas sobretudo os externos, por isso entende por
violência e coação em sentido absoluto; e assim a violência se distingue do medo. Ora, agora tratamos
do consentimento interior, não susceptível de coação ou de violência, enquanto distinta do medo. Por
onde, no caso vertente, o mesmo é a coação que o medo. Mas o medo, segundo os jurisperitos é a
perturbação do espírito causada por um perigo atual ou futuro.
Donde se deduzem as respostas às objeções. Pois, as primeiras se fundam na violência pura, e as outras,
na mista.

## Art. 2 — Se o varão constante é susceptível do temor causado pela coação.
O segundo discute-se assim ─ Parece que o varão constante não é susceptível do temor causado pela
coação.

1. Pois, é próprio do varão constante não temer diante do perigo. Ora, sendo o medo o temor da alma
perante um perigo iminente, parece que não pode o constante sofrer a coação do medo.

2. Demais. ─ De todas as coisas a terribilíssima é a morte, segundo o Filósofo; é como o mais perfeito
objeto de terror. Ora, o varão constante não teme a morte, pois, afronta-lhe o perigo. Logo, o homem
forte não é susceptível de temor.
3 . Demais. ─ De todos os perigos o mais temido pelos bons é o da infâmia. Ora, o temor da infâmia não
se considera como capaz de influenciar um varão constante, pois, como diz a lei, o temor da infâmia não
está mencionado no edito intitulado ─ Dos atos causados pelo temor. Logo, nenhum outro temor pode a
tingir o varão constante.

4. Demais. ─ O temor, leva a pecar quem lhe sofre a coação, pois. fá-lo prometer o que não tem a
intenção de cumprir e, assim, fá-lo mentir. Ora, não é próprio de um varão constante ter um pecado,
por mínimo que seja, levado do temor. Logo não é susceptível de nenhum temor.
Mas em contrário. ─ Abraão e Isaac foram varões constantes. Ora, deixaram-se levar do medo, pois, por
causa dele, fizeram passar por esposas as irmãs. Logo, o varão constante pode também ser vítima do
temor.

2. Demais. ─ Onde há um violento misto há algum temor coativo. Ora, a ação de uma violência pode
sofrer um homem, por forte que seja; assim, se estiver no mar, lançará fora as mercadorias para escapar
ao naufrágio. Logo, o temor pode também sofrê-lo o varão constante.

SOLUÇÃO. ─ Sofrer alguém o temor é sofrer a coação que ele causa. Ora, sofre a coação causada pelo
temor quem faz o que sem ele não faria, com o fim de o evitar. Ora, por aí o varão constante se
distingue do inconstante de dois modos. - Primeiro, quanto à qualidade do perigo que teme. Pois, o
varão constante obedece à razão reta, que o ensina, num caso dado, o que deve omitir e o que deve
fazer. Porque devemos sempre escolher o menor mal ou o maior bem. Por isso, temor do mal maior
obriga o varão constante a suportar o menor; não o coage porém ao mal maior para evitar o menor. Ao
passo que o temor força o homem fraco a um mal maior para evitar o menor; assim, ao pecado, por
medo da pena corpórea. O pertinaz, ao contrário, não pode ser coagido mesmo a suportar o mal menor
ou a fazê-lo, para evitar o maior. Por onde, o varão constante é um meio termo entre o inconstante e o
pertinaz. Em segundo lugar o varão constante difere do inconstante pelo modo com que avalia o perigo
iminente. Assim, o constante não se deixa influenciar senão por um perigo que considera grave e
provável; ao passo que o inconstante se deixa dominar por um perigo leve, segundo aquilo da escritura:
O ímpio foge sem que ninguém o persiga.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O varão constante, como o diz o Filósofo também do
forte, é intrépido, não que seja de todo inaccessível ao temor, mas por não temer senão o que deve
temer e quando o deve.

RESPOSTA À SEGUNDA. ─ O pecado é o máximo dos males. Por isso nada há que possa obrigar o varão
constante a praticá-lo, ao contrário, deve antes morrer que cometê-lo como também o Filósofo o
ensina. Mas dos danos corporais, uns são menores que outros. Dentre eles são os principais os que
atingem a pessoa, como a morte, os açoites, a desonra infamante e a escravidão. Por isso levam o varão
constante a suportar outros danos corporais; estão eles contidos no versículo:
Desonra ou situação, açoite e morte.
Nem importa que atinjam a pessoa própria, ou a da esposa, ou a dos filhos ou de pessoas tais.

RESPOSTA À TERCEIRA. ─ Embora a desonra seja o maior dano que possamos sofrer, é contudo fácil
evitá-la. Por isso, os janistas não consideram o temor da desonra como capaz de influir num varão
constante.

RESPOSTA À QUARTA. ─ O varão constante não é forçado a mentir, por temor, pois no momento
mesmo quer cumprir a promessa. Mas decide a pedir depois a restituição, ou pelo menos, a denunciar
ao juiz, se prometeu não haver de a pedir. Não pode porém prometer que não fará a denúncia, pois
encontraria o bem da justiça, e nada pode coagi-lo a agir contra ela.

## Art. 3 — Se o consentimento coacto anula o matrimônio.
O terceiro discute-se assim. ─ Parece que o consentimento coacto não anula o matrimônio.

1. Pois, assim como no matrimônio deve haver o consentimento, assim no batismo a intenção de
recebê-lo. Ora, quem, coagido pelo temor, recebeu o batismo batizado está. Logo, quem, coagido pelo
temor, deu o seu consentimento, contraiu o matrimônio.

2. Demais. ─ O violento misto tem, segundo o Filósofo, mais de voluntário que de involuntário. Ora, o
consentimento não pode ser coacto senão pelo violento misto. Logo, não exclui totalmente o voluntário.
E portanto deixa existente o matrimônio.

3. Demais. ─ A quem consentiu num matrimônio coacto deve-se aconselhar que nele permaneça;
porque fazer uma promessa e não a cumprir é uma aparência de mal, da qual o Apóstolo diz que nos
devemos guardar. Ora, tal não se daria se o consentimento coacto tornasse o matrimônio
absolutamente nulo. Logo ,etc.
Mas, em contrário, determina uma decretal: Como o temor e a violência não deixam lugar ao
consentimento, quando intervêm, devemos evitar, nos contratos que o exigem de ambas as partes, tudo
o que pode produzi-los. Ora, o matrimônio exige o consentimento de ambas as partes. Logo etc.

2. Demais. ─ O matrimônio significa a união de Cristo com a Igreja, fundada na liberdade do amor. Logo,
não pode fazer-se pelo consentimento coacto.

SOLUÇÃO. ─ O vínculo do matrimônio é perpétuo. Por onde, tudo o que repugna à perpetuidade anula o
matrimônio. Ora, o temor, capaz de influenciar um varão constante, destrói a perpetuidade do contrato,
porque dá lugar ao pedido da restituição por inteiro. Por onde, o temor capaz de coagir o varão
constante é o que anula o matrimônio, e não outro. Ora, o varão constante é julgado virtuoso, que é a
medida de todas as obras humanas, como diz o Filósofo. Certos porém opinam, que havendo o
consentimento, ainda coacto, o matrimônio é válido no foro da consciência perante Deus; mas não
perante a Igreja, que presume ter o temor eliminado o consentimento interno ─ mas esta opinião é
insustentável. Porque a Igreja não deve presumir em ninguém o pecado, antes de provado. Ora, quem
disse que consentia e não consentiu pecou. Por isso, a Igreja lhe presume o consentimento, mas o
considera como extorquido e portanto insuficiente para produzir o matrimônio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A intenção não é a causa eficiente do sacramento no
batismo, mas só a causa eficiente da ação do agente. Ao contrário, o consentimento é a causa eficiente
do matrimônio. Logo, o símile não colhe.

RESPOSTA À SEGUNDA. ─ Não é qualquer voluntário, mas só o voluntário completo, que causa o
matrimônio, porque este deve ser perpétuo. Logo, fica impedido pelo violento misto.

RESPOSTA À TERCEIRA. ─ Nas circunstâncias supostas, nem sempre se deve dar ao casado o conselho de
assim permanecer, mas só quando se teme que a ruptura possa causar um perigo. Aliás, romper um tal
casamento não seria pecado, porque nenhuma aparência de mal é deixarmos de cumprir uma promessa
involuntariamente feita.

## Art. 4 — Se o consentimento coacto, ao menos para a parte que coagiu, causa o matrimônio.
O quarto discute-se assim. ─ Parece que o consentimento coacto, ao menos para a parte que coagiu,
causa o matrimônio.

1. Pois o matrimônio é sinal da união espiritual. Ora, a união espiritual, fundada na caridade, pode tê-la
mesmo quem não tem a caridade. Logo, também o matrimônio pode ser contraído mesmo com quem
não o quer.

2. Demais. ─ A coagida, mas que depois consentiu, contraiu verdadeiro matrimônio. Ora, esse
consentimento não liga quem a obrigou a consentir. Logo, estava já ela casada em virtude do
consentimento anterior.
Mas, em contrário. ─ O matrimônio é uma relação de igualdade, Ora, tal relação deve existir do mesmo
modo em ambos. Portanto, se houver impedimento da parte de um, não haverá casamento da parte do
outro.

SOLUÇÃO. ─ O matrimônio é uma relação de igualdade. Ora, não pode a relação abranger um dos
extremos sem abranger também ao outro. Logo, o que impede o casamento de um impede também o
de outro, pois não é possível um marido sem esposa, ou uma esposa sem marido, como o é uma mãe
sem filho. Por isso se costuma dizer, que o matrimônio não claudica.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora possamos amar quem não nos ama, contudo
união não pode haver sem amor mútuo. Por isso diz o Filósofo, que a amizade, implicando a união, exige
a retribuição.

RESPOSTA À SEGUNDA. ─ O casamento de uma pessoa, forçada, a princípio, a consentir e que depois
livremente consentiu, não é válido senão se a outra parte continua a consentir livremente. Mas se esta
não o fizesse não existirá o casamento.

## Art. 5 — Se o casamento condicionado gera o matrimônio.
O quinto discute-se assim. ─ Parece que o consentimento condicionado não gera o matrimônio.

1. Pois, o que afirmamos sob condição não o afirmamos de maneira absoluta. Ora, o consentimento no
matrimônio deve ser expresso por palavras de sentido absoluto. Logo, um consentimento condicional
não gera o matrimônio.

2. Demais. ─ O matrimônio deve ser certo. Ora, uma afirmação condicional é duvidosa. Logo, tal
consentimento não gera o matrimônio.
Mas, em contrário. ─ Os outros contratos podem fazer-se sob condição e subsistem enquanto a
condição está de pé. Logo, sendo o matrimônio um contrato, parece que o consentimento nele pode ser
condicional.

SOLUÇÃO. ─ A condição acrescentada ou se refere ao presente ou ao futuro. ─ Se ao presente e não
sendo contrária ao matrimônio, quer honesta quer desonesta, o casamento é válido se a condição
subsiste, e não é válido no caso contrário. Mas se a condição for contrária aos fins do matrimônio não
poderá tê-lo como efeito. ─ Quanto à condição para o futuro, ou é necessário, como p.ex. ─ se o sol
nascer amanhã; e então será válido o matrimônio porque esses futuros já são presentes nas suas causas.
Ou o futuro será contingente, como se der dinheiro, se os pais consentirem; e então devemos julgar
esse consentimento, como o pelo qual se consente num casamento futuro, e que portanto não gera o
matrimônio.
Donde se deduzem claras as respostas às objeções.

## Art. 6 — Se uma ordem paterna pode obrigar os filhos ao contrato matrimonial.
O sexto discute-se assim. ─ Parece que uma ordem paterna pode obrigar ao contrato matrimonial.

1. Pois, diz o Apóstolo: Filhos, obedecei em tudo a vossos pais. Logo, também estão obrigados a
obedecer neste ponto.

2. Demais. ─ Como lemos na Escritura, Isaac ordenou a Jacó que não tomasse mulher entre as filhas de
Canaan. Ora, não o teria feito, se por direito não tivesse podido mandá-la. Logo, nesta matéria os filhos
estão obrigados a obedecer aos pais.

3. Demais. ─ Ninguém pode prometer, sobretudo sob juramento, em nome de quem não pode compelir
a cumprir o que foi jurado. Ora, os pais se comprometem, em nome dos filhos, a um casamento futuro,
e mesmo o confirmam com juramento. Logo, podem obrigá-las a cumprir o que ordenaram.

4. Demais. ─ O Papa, Pai espiritual, pode compelir por preceito, ao matrimônio espiritual, isto é, a
aceitação do episcopado. Logo, também um pai carnal pode compelir ao matrimônio carnal.
Mas, em contrário. ─ Mesmo que o pai ordene o matrimônio, o filho poderá, sem pecado, entrar em
religião. Logo, nesse ponto não está obrigado a lhe obedecer.

2. Demais. - Se estivesse obrigado a obedecer, os esponsais contraídos pelos pais sem o consentimento
dos filhos seriam válidos. Ora, isso é contra o direito. Logo, etc.

SOLUÇÃO. ─ Sendo o matrimônio uma como servidão perpétua, o pai não pode, sob preceito, coagir o
filho livre a contrai-lo. Mas pode induzi-lo com causa racionável. E então, assim, está o filho para essa
causa, como para o preceito paterno. Isto é, se essa causa não for cogente por motivo de necessidade
ou honestidade, também desse mesmo modo é que o preceito paterno obrigará; do contrário não.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ As palavras do Apóstolo não se aplicam nos casos em que
o filho é tão livre com o pai. Ora, tal é o matrimônio pelo qual também o filho se torna pai.

RESPOSTA À SEGUNDA. ─ Jacó devia por outras razões fazer o que lhe Isaac mandou ─ quer por causa
da malícia dessas mulheres; quer por causa da disparição próxima da raça de Canaan, da terra
prometida à descendência dos Patriarcas. Por isso Isaac podia mandar.

RESPOSTA À TERCEIRA. ─ Os pais não juram senão subentendida a condição ─ se lhes agradar. Devem
então tratar, com boa fé, de induzi-los ao casamento.

RESPOSTA À QUARTA. ─ Certos pretendem que o Papa não pode mandar ninguém aceitar o episcopado,
porque o consentimento deve ser livre. ─ Mas se assim fosse, desapareceria a ordem eclesiástica. Pois,
se ninguém pudesse ser obrigado a tomar o governo da Igreja, esta não poderia subsistir, porque os
mais idôneos para tal se recusariam fazê-lo, sem ser forçados. Por isso devemos responder, que não há
símile nos dois casos. Porque o matrimônio espiritual não implica nenhuma servidão corporal. Pois, o
casamento espiritual é uma como função necessária à república, conforme aquilo do Apóstolo: Os
homens devem nos considerar, etc.