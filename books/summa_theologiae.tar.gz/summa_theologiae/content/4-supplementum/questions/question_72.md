# Questão 72: Da oração dos santos na pátria.
Em seguida devemos tratar da oração dos santos na pátria.
E nesta questão discutem-se três artigos:

## Art. 1 — Se os santos tem conhecimento das nossas orações.
O primeiro discute-se assim ─ Parece que os santos não tem conhecimento das nossas orações.

1. ─ Pois, diz a Escritura: Tu é que és nosso pai e Abraão não nos conheceu e Israel não soube de nós. Ao
que diz a Glosa de Agostinho: Os santos, na outra vida, não sabem o que fazem os vivos, mesmo os
filhos. E depois de ter citados as palavras aduzidas do profeta, continua Agostinho: Se esses tão grandes
Patriarcas, Abraão e Jacó, não conheciam o estado do povo descendente deles, como os mortos
poderão conhecer os atos e favorecer os interesses dos vivos? Logo, os santos não poderão conhecer as
nossas orações.

2. Demais. ─ Na Escritura, o Senhor faz dizer ao rei Josias: Por isso, i. é, por teres chorado perante mim,
eu te farei descansar com teus pais, para que os teus olhos não vejam todos os males que eu hei de
fazer cair sobre este lugar. Ora, a morte não teria livrado Josias de um tal espetáculo, se pudesse
conhecer no outro mundo as desgraças que cairiam sobre o seu povo. Logo, os santos mortos não
conhecem os nossos atos e, portanto, não ouvem as nossas orações.

3. Demais. ─ Quanto mais perfeita for a nossa caridade, mais somos levados a socorrer os próximos nos
seus perigos. Ora, os santos, enquanto viviam neste mundo, davam boas inspirações e manifestamente
socorriam aos próximos, sobretudo parentes, nos perigos. Ora, como depois da morte tem caridade
muito maior, se tivessem conhecimento dos nossos atos, muito mais inspirariam e auxiliariam nos
perigos aos que lhes foram caros e chegados. Ora, não no fazem. Logo, parece não terem conhecimento
dos nossos atos nem das nossas orações.

4. Demais. ─ Assim como os santos depois da morte vêem o Verbo, assim também os anjos, de quem diz
o Evangelho: Os seus anjos incessantemente estão vendo a face de meu Pai. Ora, nem por
contemplarem o Verbo os anjos conhecem tudo; pois, os anjos inferiores são livrados da ignorância
pelos superiores, como diz Dionísio. Logo, nem os santos, embora contemplem o Verbo, nele conhecem
as nossas orações e o mais que fazemos.

5. Demais. ─ Só Deus lê nos corações. Ora, a oração consiste sobretudo numa elevação do coração.
Logo, os santos não tem conhecimento das nossas orações.
Mas, em contrário. ─ Aquilo da Escritura: Ou os seus filhos estejam exaltados ou estejam abatidos, ele o
não conhecerá, diz Gregório: Isto não devemos aplicar às almas santas. Pois, as almas absorvidas na
contemplação da glória de Deus onipotente, de nenhum modo devemos crer haja fora nada que
ignorem. Logo, tem conhecimento das nossas orações.

2. Demais. ─ Gregório diz: A alma que vê o Criador vê também o universo como encerrado num pequeno
espaço. Pois, por pouco que contemple a luz do Criador, vê como próximas todas as causas criadas. Ora,
o maior obstáculo para as almas dos santos conhecerem as nossas orações e os nossos atos é a distância
que delas nos separa. Mas, como essa distância não é mais um empecilho, do modo explicado pela
autoridade citada, parece que as almas separadas conhecem as nossas orações e todos os nossos atos.

3. Demais. ─ Se os santos não soubessem o que nós fazemos, também não orariam por nós, por
ignorarem as nossas necessidades. Ora, esse é o erro de Vigilância, como refere Jerônimo. Logo, tem
conhecimento do que fazemos.

SOLUÇÃO. ─ A divina essência é um meio suficiente para fazer conhecer tudo; o que resulta do fato de
Deus, contemplando a sua essência, ver nela todas as cousas. Mas daí não resulta, que quem visse a
essência de Deus tudo conhecesse; pois, isto só o poderia quem compreendesse tal essência. Assim
como o conhecimento de um princípio não nos dá por consequência o conhecimento de tudo quanto
dele deriva, se não compreendermos a virtude total dele. Ora, como as almas dos santos não
compreendem a essência divina, por consequência não podem conhecer tudo quanto por essa essência
pode ser conhecido. Por isso, também os anjos inferiores tem de certas cousas conhecimento por
iluminação dos superiores, embora todos contemplem a essência divina. Mas cada um dos bem
aventurados conhece, da essência divina, só o necessário à perfeição da sua beatitude. Ora, a perfeição
da beatitude exige que o homem tenha tudo quanto quer, sem nada querer desordenadamente. Ora,
queremos com razão reta conhecer o que nos concerne. Por onde, os santos, retos por excelência, hão
de querer conhecer o que lhe diz respeito. E isso é necessariamente no Verbo que conhecerão. Ora,
contribui-lhes para a glória prestar auxílio aos que deste precisam, para salvar-se. E assim, tornam-se
cooperadores de Deus, a mais divina das cooperações, na expressão de Dionísio. Por onde, é claro que
os santos tem conhecimento do necessário à esse ministério. E assim é manifesto, que no Verbo
conhecem os desejos, as devoções e as orações dos homens, que lhes pedem auxílio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ As palavras de Agostinho devem entender-se do
conhecimento natural das almas separadas. Conhecimento esse que nos varões santos não está
obscurecido, como o está nos pecadores. Mas não se referem ao conhecimento no Verbo, de que não
gozava Abraão no tempo em que Isaías pronunciou essas palavras; pois, antes da paixão de Cristo
ninguém fruía da visão de Deus.

RESPOSTA À SEGUNDA. ─ Os santos, embora depois de esta vida tenham conhecimento do que nela se
passa, não devemos contudo crer que sofram nenhuma dor, por saberem das adversidades dos que
neste mundo amaram. Pois, gozam a tal ponto da plenitude da felicidade, que não são susceptíveis de
nenhuma dor. Por onde embora conheçam, depois da morte, os infortúnios dos seus, nem por isso Deus
deixa de lhes obviar a dor, se os retirou do mundo antes de sucederem esses infortúnios. ─ Talvez
porém as almas não glorificadas sentissem dor se conhecessem os sofrimentos dos que lhes são caros. E
como a alma de Josias não foi glorificada logo ao separar-se do corpo, Agostinho, fundado nisso, procura
concluir, que as almas dos mortos não tem conhecimento do que se passa com os vivos.

RESPOSTA À TERCEIRA. ─ As almas dos santos tem a vontade plenamente conforme com a vontade
divina, mesmo quanto ao objeto do querer. Por onde, embora o sentimento da caridade as prenda ao
próximo, não lhe prestam auxílio porém senão na medida em que a justiça divina o vê disposto.
Contudo devemos crer, que muito socorrem os próximos intercedendo por eles perante Deus.

RESPOSTA À QUARTA. ─ Embora nem por contemplarem o Verbo, necessariamente hão de os santos
ver tudo no Verbo, contudo vêem o concernente à perfeição da sua beatitude, como se disse.

RESPOSTA À QUINTA. ─ As cogitações dos corações só Deus mesmo é quem as conhece; mas também
podem-nas conhecer aqueles a quem Deus as revela, ou pela visão do Verbo, ou de qualquer outro
modo.

## Art. 2 — Se devemos invocar os santos para orarem por nós.
O segundo discute-se assim. ─ Parece que não devemos invocar os santos para orarem por nós.

1. ─ Pois, não invocamos os amigos de outrem a pedirem por nós, senão por pensarmos que eles tem
junto dessa pessoa o poder de alcançar mais facilmente a graça almejada. Ora, Deus é infinitamente
mais misericordioso que qualquer santo; e assim a sua vontade com maior facilidade se inclina a nos
ouvir, que a vontade de qualquer santo. Logo, parece supérfluo constituirmos os santos em mediadores
entre nós e Deus, para intercederem por nós.

2. Demais. ─ Se devemos invocá-las para orarem por nós, tal não serão senão por sabermos que a sua
oração é aceita de Deus. Ora, o mais santo dos santos terá a sua oração mais aceita de Deus, que todos
os outros. Logo, deveríamos sempre constituir os santos superiores, e nunca os menores, nossos
intercessores perante Deus.

3. Demais. ─ Cristo, mesmo como homem, é chamado o Santo dos Santos; e a ele devemos orar como
homem. Ora, nunca invocamos a Cristo para orar por nós. Logo, também não devemos invocar os outros
santos.

4. Demais. ─ Quem intercede por outrem, apresenta as orações do seu protegido aquele junto de quem
intercede. Ora, é inútil fazer representação a quem tudo é presente. Logo, é inútil constituirmos os
santos nossos intercessores perante Deus.

5. Demais. ─ Aquilo é supérfluo que, feito em vista de um fim, este independentemente disso se
realizaria ou não. Ora, quer lhes oremos quer não, os santos rezarão ou não por nós. Pois, sendo dignos
de orarem por nós, por nós rezarão mesmo sem lh'o pedirmos; sendo, ao contrário, indignos, não
rezarão, ainda que lh'o peçamos. Logo, é absolutamente supérfluo invocá-las para orarem por nós.
Mas, em contrário, a Escritura: Chama, se há alguém que te responda, e volta-te para algum dos santos.
Ora, chamar, é para nós, como diz Gregório, jazer humildes preces a Deus. Logo, querendo orar a Deus,
devemos invocar os santos, para que peçam a Deus por nós.

2. Demais. ─ Os santos na pátria são mais queridas de Deus, que quando viviam neste mundo. Ora,
devemos constituir nossos intercessores, perante Deus, os santos que estão na pátria, a exemplo do
Apóstolo, que dizia: Rogo-vos, ó irmãos, por Nosso Senhor Jesus Cristo e pelo amor do Espírito Santo,
que me ajudeis com as vossas orações por mim a Deus. Logo, e com maior razão, também nós devemos
pedir aos santos que estão na pátria, que nos ajudem com as suas orações a Deus.

3. Demais. ─ É costume comum da Igreja pedir, nas suas ladainhas, a oração dos santos.

SOLUÇÃO. ─ Deus estabeleceu uma ordem tal no universo, que os seres inferiores dele dependam
mediante outros que são médios entre esses e ele; segundo diz Dionísio. Ora, como os santos na pátria
estão mui próximos de Deus, e segundo a ordem da lei divina requer, nós que, enquanto estamos no
corpo, vivemos ausentes do Senhor, a ele havemos de chegar mediante os santos. E isso se dá quando
Deus nos distribui os seus dons pelo ministério deles. Ora, a nossa volta para Deus deve corresponder
aos benefícios da sua bondade para conosco. Por onde, assim como por meio das orações dos santos é
que recebemos esses benefícios, assim devemos corresponder-lhes, recebendo-os sempre pela
intercessão deles. Por isso os constituímos nossos intercessores perante Deus, e como uns mediadores,
pedindo-lhes orarem por nós.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Não é por falta de poder que Deus age mediante as ações
das causas segundas. Mas para, completando a ordem do universo, nele difundir mais amplamente a
sua bondade, fazendo com que todos os seres não recebam só dele os seus bens próprios, mas ainda de
outras cousas. Ora, assim também, não é por falta de misericórdia, que Deus quer exercer a sua
clemência para conosco mediante as orações dos santos, mas para observar a referida ordem universal.

RESPOSTA À SEGUNDA. ─ Embora os santos superiores tenham mais influência perante Deus, que os
inferiores, poderá contudo ser útil fazermos orações a estes, por cinco razões. ─ Primeiro, porque pode
um ter maior devoção para com um santo inferior do que para com um superior. Ora, da devoção
depende sobretudo o efeito da oração. ─ Segundo, para evitar o tédio, gerado pela repetição dos
mesmos atos. Ora, rezando a santos diversos, a nossa devoção se afervora pela novidade de cada
invocação. ─ Terceiro, porque certos santos nos patrocinam particularmente contra determinados
males; assim, Santo Antonio, contra o fogo do inferno. ─ Quarto, para prestarmos a honra devida a
todos os santos. ─ Quinto, para obtermos, pelas orações de vários santos, o que não obteríamos pelas
de um só.

RESPOSTA À TERCEIRA. ─ A oração é um ato. Ora, os atos concernem às pessoas. Por onde, se
rezássemos ─ Cristo, ora por nós ─ sem mais nada, parece que dirigiríamos essas palavras à pessoa de
Cristo. E assim cairíamos no erro de Nestório, que distinguia em Cristo a pessoa do Filho do homem, da
do Filho de Deus. Ou no erro de Ario, que ensinava ser a pessoa do Filho menor que a do Pai. E, para
evitar esses erros, a Igreja não diz ─ Cristo ora por nós; mas ─ Cristo, ouve-nos; ou ─ Tem compaixão de
nós.

RESPOSTA À QUARTA. ─ Como a seguir diremos, os santos não apresentam a Deus os nossos pedidos,
como se lhe fossem desconhecidos. Mas lhe pedem que os ouça, ou o consultam sobre a verdade dessas
preces, para saber como determina a sua providência, sobre o procedimento que hão de ter.

RESPOSTA À QUINTA. ─ Por isso mesmo nos tornamos dignos de um santo orar por nós, que lhe a ele
recorremos com pura devoção nas nossas necessidades. E assim não é supérfluo rezarmos aos santos.

## Art. 3 — Se as orações, que os santos fazem por nós a Deus, são sempre ouvidas.
O terceiro discute-se assim. ─ Parece que as orações, que os santos fazem a Deus, por nós nem
sempre são ouvidas.

1. ─ Pois, se fossem sempre ouvidas, sê-lo-iam sobretudo quando as fazem em seu próprio favor. Ora,
tal não se dá, e por isso refere a Escritura que aos mártires, pedindo vingança, dos habitantes da terra,
foi-lhes dito que repousassem ainda um pouco de tempo até que se completasse o número dos seus
conservas. Logo e com maior razão, as orações dos santos nem sempre são ouvidas quando pedem
pelos outros.

2. Demais. ─ A Escritura diz: Ainda que Moisés e Samuel se pusessem diante de mim, não está a minha
alma com este povo. Logo, os santos nem sempre são ouvidos quando pedem por nós a Deus.

3. Demais. ─ Os santos, na pátria, serão como os anjos de Deus, na frase do Evangelho. Ora, os anjos
nem sempre são ouvidos nas suas orações a Deus. O que se conclui do seguinte lugar da Escritura: Eu
vim por teus rogos; e o príncipe do reino dos Persas me resistiu por vinte e um dias. Ora, o anjo que
falava não viria em auxílio de Daniel, senão depois de ter pedido a Deus a sua libertação. Contudo, a sua
oração não foi ouvida. Logo, nem os outros santos são sempre ouvidos quando pedem a Deus por nós.

4. Demais. ─ Quem na sua oração pede alguma cousa de certo modo a merece. Ora, os santos na pátria
não estão em estado de merecer. Logo, não podem por suas orações pedir nada a Deus por nós.

5. Demais. ─ Os santos conformam em tudo a sua vontade com a de Deus. Logo, não querem senão o
que sabem que Deus quer. Ora, ninguém pede senão o que quer. Portanto, não pedem os santos senão
o que sabem que Deus quer. Ora, a vontade de Deus se cumpre mesmo que eles não lh'o pedissem.
Logo, as orações dos santos não são eficazes para obter nada.

6. Demais. ─ As orações de toda a corte celeste, se pudessem obter algo de Deus, seriam mais eficazes
que todas as orações da Igreja terrestre. Ora, seria totalmente liberada das penas do purgatório a alma
pela qual a Igreja fizesse reiteradas orações. Logo, como os santos, na pátria, oram pelas almas do
purgatório, pela mesma razão por que oram por nós, se tiverem ouvidas as orações que fazem por nós,
se tiverem pelas orações deles as almas do purgatório ficariam totalmente liberadas das suas penas. O
que é falso, porque então os sufrágios da Igreja pelos defuntos seriam supérfluos.
Mas, em contrário, a Escritura: este é Jeremias, profeta de Deus, que ora muito pelo povo e por toda a
santa cidade. E que a sua oração foi ouvida, conclui-se da sequência do texto: Ao mesmo tempo
estendera Jeremias a mão e dera a Judas uma espada de ouro, dizendo ─ Toma esta santa espada como
um presente que Deus te faz, etc.

2. Demais. ─ Jerônimo escreve: Dizes no teu libelo, que enquanto vivemos, podemos orar um pelo
outro; mas depois de morto, ninguém é ouvido nas suas orações por terceiros. O que a seguir assim
refuta: Se os Apóstolos e os mártires, enquanto ainda vivem neste mundo, preocupados com a sua
sorte, podem orar pelos outros, quanto mais depois de coroados, pelas suas vitórias e triunfos?

3. Demais. ─ É costume da Igreja pedir frequentemente que os santos nos ajudem com as suas orações.

SOLUÇÃO. ─ De dois modos podemos dizer que os santos oram por nós. Expressamente, implorando a
clemência divina em nosso favor com os seus votos. Ou interpretativamente, pelos seus méritos, que
sempre presentes diante de Deus, não somente lhes redundam em glória, mas também fervem de
sufrágios e orações em nosso favor. No mesmo sentido dizemos, que o sangue de Cristo, derramado por
nós, pede perdão por nós. Ora, de ambos os modos, as orações dos santos são por si mesmas eficazes
para alcançar o que pedem. Mas, da nossa parte, podem falhar e podemos não colher o fruto dessas
orações, que fazem por nós pelo fato de poderem os seus méritos nos aproveitar. Mas, quando oram
por nós, pedindo a Deus em nosso favor, com os seus votos, as suas orações sempre são ouvidas.
Porque não querem senão o que Deus quer nem pedem senão o que quer Deus que se cumpra. Ora, o
que Deus quer sempre se cumpre. Salvo se nos referimos à sua vontade antecedente, pela qual quer
que todos os homens se salvem ─ o que nem sempre se realiza. Por onde, não é para admirar se
também o que os santos querem com esse modo de querer, nem sempre se realize.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Essa oração dos mártires outra cousa não é senão o
desejo de receber as vestimentas do seu corpo e de serem incorporados na sociedade dos que se
salvarão; e o consentimento com que aderem à divina justiça primitiva dos maus. Por isso, àquilo da
Escritura ─ Até quando, Senhor, etc. ─ diz a Glosa: Desejam maior glória e a companhia dos santos, pois
que consentem na justiça de Deus.

RESPOSTA À SEGUNDA. ─ O Senhor aí se refere a Moisés e a Samuel, conforme ao estado em que
viveram nesta vida. Pois, como refere a Escritura, aplacaram a cólera divina com as suas orações pelo
povo. Mas se tivessem vivido no tempo de Jeremias não poderiam com suas orações aplacar a ira de
Deus contra o povo, por causa da malícia deste. Tal o sentido do lugar citado.

RESPOSTA À TERCEIRA. ─ Essa luta dos anjos bons não se entende no sentido em que fizessem a Deus
orações contrárias, mas como significando que expunham ao exame divino os méritos contrários das
diversas partes e esperavam a sentença divina. Assim o explica Gregório expondo as referidas palavras
de Daniel: Os espíritos superiores, diz, constituídos príncipes das nações, de nenhum modo combatem
pelos que procedem injustamente, mas lhes discernem os atos julgando com justiça. E quando a culpa
ou a justiça de um determinado povo é levada ao conselho da corte suprema, do anjo preposto a esse
povo dizemos que ganhou ou perdeu na luta. Contudo, todos ganham a mesma vitória pela submissão à
vontade suprema do Criador. Como tem os olhos sempre voltados para ela o que de nenhum modo
podem obter de nenhum modo querem. Por isso nem o pedem. Donde também se conclui que as suas
orações são sempre ouvidas.

RESPOSTA À QUARTA. ─ Embora os santos não possam mais merecer para si, depois de estarem na
pátria, podem contudo merecer para os outros; ou antes, pelos seus méritos anteriores podem-nos
socorrer. Pois, enquanto ainda viviam, mereceram de Deus, que lhes ouvisse as orações, depois da
morte. ─ Ou podemos responder que a oração merece, por uma causa, e é eficaz por outra. Pois, o
mérito consiste numa certa adequação entre um ato com o fim que visa, e que lhe constitui como a
recompensa. Ora, o pedido da oração se funda na liberalidade de aquele a quem é feita; assim às vezes
obtemos da liberalidade, de aquele a quem pedimos, o que contudo não merecíamos. E assim, embora
os santos estejam num estado em que não podem mais merecer, daí contudo não se segue que não
possam obter o que pedem.

RESPOSTA À QUINTA. ─ Como resulta do lugar citado de Gregório, os santos e os anjos não querem
senão o que vêem como querido pela vontade divina; e assim nada mais que isso pedem. Nem por isso
lhes é porém infrutífera a oração; porque, como diz Agostinho, as orações dos santos aproveitam aos
predestinados, por ter sido talvez preordenado que estes se salvassem pelas orações desses
intercessores. E assim, também Deus quer que as orações dos santos alcancem aquilo que vêem que
Deus quer.

RESPOSTA À SEXTA. - Os sufrágios da Igreja pelos defuntos são umas como satisfações dadas pelos
vivos, em lugar dos mortos. Por isso estes ficam liberados das penas que ainda não cumpriram. Ora, os
santos na pátria não mais podem satisfazer. Não há, pois, símil entre as orações deles e os sufrágios da
Igreja.