# Questão 9: Da qualidade da confissão.
Em seguida devemos tratar da qualidade da confissão.
Sobre a qual discutem-se quatro artigos:

## Art. 1 — Se a confissão pode ser informe.
O primeiro discute-se assim. ─ Parece que a confissão não pode ser informe.

1. ─ Pois, diz a Escritura: A confissão, depois de o homem estar morto, fenece, tornando-se como num
puro nada. Ora, quem não tem caridade está morto, porque ela é a alma da vida. Logo, sem caridade
não pode haver confissão.

2. Demais. ─ A confissão divide-se, por contrariedade, da contrição e da satisfação. Ora, a contrição e a
satisfação nunca podem existir sem a caridade. Logo, nem a confissão.

3. Demais. ─ Na confissão há de a boca concordar com o coração, pois, o próprio nome de confissão
assim o exige. Ora, quem ainda tem afeto ao pecado, que confessa, não tem o coração de acordo com a
boca, pois, tem o coração preso ao pecado, que de boca condena.
Mas, em contrário. ─ Todos estão obrigados a confessar os pecados mortais. Ora, quem confessou,
estando ainda em estado de pecado mortal, não está mais obrigado a confessar os mesmos pecados;
pois, como ninguém sabe se tem caridade, ninguém poderá saber que se confessou. Logo, não é
necessário ser a confissão informada pela caridade.

SOLUÇÃO. ─ A confissão é um ato de virtude e parte do sacramento. ─ Ora, enquanto ato de virtude é
um ato propriamente meritório. E então a confissão não vale sem a caridade, princípio do mérito. ─ Mas
enquanto parte do sacramento, torna o confitente dependente do sacerdote, que tem o poder das
chaves da Igreja, e pela confissão conhece a consciência do confitente. E assim, pode confessar mesmo
quem não tem contrição, pois, pode expor ao sacerdote os seus pecados e sujeitar-se ao poder das
chaves da Igreja. E embora não receba então o fruto da absolvição, contudo poderá colhê-lo desde que
desapareça a sua dissimulação. O mesmo se dá também com os outros sacramentos. Por isso não está
obrigado a renovar a confissão quem se a ela achega dissimuladamente; mas está obrigado a confessar
depois a sua dissimulação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Essa autoridade deve entender-se quanto à percepção do
fruto da confissão, que não recebe ninguém sem ter a caridade.

RESPOSTA À SEGUNDA. ─ A contrição e a satisfação se fazem a Deus; mas a confissão, ao homem. Por
isso é da natureza da contrição e da satisfação que o homem esteja unido a Deus pela caridade; mas
não, da natureza da confissão.

RESPOSTA À TERCEIRA. ─ Quem conta os pecados que tem fala verdade. E assim o coração concorda
com a palavra ou com as palavras quanto à substância da confissão, embora discorde do fim da
confissão.

## Art. 2 — Se é necessário a confissão ser íntegra.
O segundo discute-se assim. ─ Parece que não é necessário a confissão ser íntegra, de modo que se
confessassem todos os pecados a um só sacerdote.

1. ─ Pois, a vergonha contribui para a diminuição da pena. Ora, quanto maior o número dos sacerdotes a
que nos confessemos tanto maior será a vergonha sofrida. Logo, será mais frutuosa a confissão quando
feita a vários sacerdotes.

2. Demais. ─ A confissão é necessária na penitência a fim de a pena ser aplicada ao pecador segundo o
arbítrio do sacerdote. ─ Ora, diversos sacerdotes podem impor uma pena suficiente a pecados diversos.
Logo, não é necessário confessar todos os pecados a um só sacerdote.

3. Demais. ─ Pode acontecer que, depois da confissão feita e da satisfação completa, recordemo-nos de
algum pecado mortal que a memória não teve presente, enquanto confessávamos; e que então não
tenhamos o ensejo de tornar a encontrar o sacerdote próprio, a quem confessamos antes. Logo, só
poderemos confessar esse pecado a outro. E então seriam pecados diversos confessados a sacerdotes
diversos.

4. Demais. ─ Ao sacerdote não devemos fazer confissão dos pecados senão em vista da absolvição. Ora,
às vezes o sacerdote, que ouve a confissão, pode absolver certos pecados, mas não todos. Logo, pelo
menos em tal caso não é preciso a confissão ser íntegra.
Mas, em contrário. ─ A hipocrisia é impedimento à penitência. Ora, fazer por partes a confissão constitui
hipocrisia, como diz Agostinho. Logo, a confissão deve ser íntegra.

2. Demais. ─ A confissão faz parte da penitência. Ora, a penitência deve ser íntegra. Logo, também a
confissão.

SOLUÇÃO. ─ Na medicina corporal é necessário que o médico conheça não somente e a doença para a
qual deve dar remédio, mas ainda a disposição total do enfermo. Porque uma doença se agrava com a
sobrevivência de outra e o remédio, que curaria daquela, poderá ser contraproducente em relação a
esta. E o mesmo se dá com os pecados: um se agrava com a sobrevivência de outro e o que para um
seria o remédio conveniente poderia ser incentivo para o outro, pois, às vezes pode alguém estar
contaminado de pecados contrários, como o ensina Gregório. Por onde, a confissão exige
necessàriamente confessemos todos os pecados que temos na memória; não o fazendo, não haverá
confissão, mas simulação dela.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora se multiplique o pejo quando se confessem
pecados diversos a sacerdotes diversos, contudo esse pejo multiplicado não é de tanta intensidade de
como o pejo único com que confessamos simultaneamente todos os nossos pecados. Por que cada
pecado considerado de per si não mostra má disposição do pecador, igual a que revela quando
considerado juntamente com os outros. Pois, num pecado só às vezes caímos por ignorância ou
fraqueza; ao passo que a multidão dos pecados revela a malícia do pecador, ou a sua grande corrupção.

RESPOSTA À SEGUNDA. ─ A pena imposta por diversos sacerdotes não seria suficiente; porque cada um
consideraria o pecado confessado só em si mesmo, sem a gravidade que ele recebe pela adjunção de
outro; e às vezes a pena aplicada a um viria a promover outro. ─ E além disso, o sacerdote ao ouvir a
confissão faz às vezes de Deus. E por isso a confissão lhe deve ser feita do mesmo modo por que o é a
Deus pela contrição. Por onde, assim como a contrição não existiria senão extensiva a todos os pecados,
também confissão não haveria sem se confessarem todos os pecados ocorrentes à memória.

RESPOSTA À TERCEIRA. ─ Certos dizem que quando nos recordamos do que tínhamos esquecido,
devemos de novo confessar, mesmo o que já tínhamos confessado; e sobretudo se não pudermos nos
confessar de novo ao mesmo sacerdote de antes que nos conhecia todos os pecados, de modo que o
mesmo sacerdote seria então o que nos conhecesse totalmente a gravidade da culpa. ─ Mas isto não é
necessário. Porque o pecado tira de si mesmo a sua gravidade e da sua adjunção com outro. Ora, aos
pecados que confessamos manifestamos a gravidade, que em si mesmos tinham. Mas para o sacerdote
conhecer a gravidade, sob o duplo aspecto referido, do pecado cuja confissão nos esquecemos, basta
revelá-lo explicitamente ao nos confessar de novo, falando dos outros em geral, dizendo que, tendo
confessado muitos outros, desse nos esquecemos.

RESPOSTA À QUARTA. ─ Embora o sacerdote não possa absolver de todos os pecados, contudo o
penitente está obrigado a lhe confessar todos, a fim de ele conhecer a gravidade total da culpa; e
aqueles que não pode absolver remeta ao superior.

## Art. 3 — Se podemos confessar por meio de outrem ou por escrito.
O terceiro discute-se assim. ─ Parece que podemos confessar por meio de outrem ou por escrito.

1. ─ Pois, a confissão é necessária para se abrirmos a consciência do penitente ao sacerdote. Ora,
podemos manifestar a nossa consciência ao sacerdote por meio de outrem ou por escrito. Logo, basta
confessar por escrito ou por meio de outrem.

2. Demais ─ Certos não são entendidos pelo sacerdote próprio por causa da diversidade de línguas; e
esses não podem confessar senão mediante terceiros. Logo, o sacramento não exige necessariamente
que nos confessemos por nós mesmo. E assim, parece que basta à salvação nos confessemos por
outrem, de qualquer modo.

3. Demais. ─ O sacramento exige necessàriamente que nos confessemos ao sacerdote próprio, como do
sobredito resulta. Ora, às vezes o sacerdote próprio está ausente e não lhe pode falar diretamente o
penitente, que porém lhe poderia manifestar a consciência por escrito. Logo, parece que por escrito lh'a
deve manifestar.
Mas, em contrário. ─ Estamos obrigados à confissão dos pecados como o estamos à da fé. Ora, a
confissão da fé deve ser feita oralmente, como diz o Apóstolo. Logo, também a dos pecados.

2. Demais. ─ Quem por si mesmo pecou deve por si mesmo fazer penitência. Ora, a confissão é parte da
penitência. Logo, o penitente deve confessar-se diretamente.

SOLUÇÃO. ─ A confissão não só é ato de virtude, mas também parte do sacramento. Embora, pois, baste
que de qualquer modo a façamos, enquanto ato de virtude, não obstante a dificuldade de um modo ser
talvez menos que a de outro, contudo, enquanto parte do sacramento, implica um ato determinado,
assim como também os outros sacramentos têm matéria determinada. É assim como no batismo, para
significar a ablução interior, toma-se aquele elemento de que sobretudo nos servimos para lavar, assim,
no ato sacramental, para nos manifestarmos como devemos, praticamos aquele ato pelo qual
sobretudo costumam nos manifestar, isto é, as nossas palavras próprias. Quanto aos outros modos,
foram aplicados como suplemento desse.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Assim como no batismo não basta uma ablução qualquer,
mas é preciso fazê-lo com o elemento determinado, assim também não basta na penitência manifestar
os pecados de qualquer modo, mas é necessário os manifestemos por um ato determinado.

RESPOSTA À SEGUNDA. ─ Os que não podem usar da linguagem, como o mudo, ou que não falam uma
língua estrangeira, basta confessarem por escrito, por sinais ou por um intérprete, porque não é
possível exigir de um homem mais de que ele pode; embora ninguém possa ou deva receber o batismo
senão com a água. Por ser a água um elemento absolutamente exterior e nos ser dada por outrem. Ora,
o ato da confissão nós mesmos é que o praticamos; e portanto quando não podemos praticá-lo de um
modo, devemos confessar como podemos.

RESPOSTA À TERCEIRA. ─ Na ausência do nosso sacerdote próprio podemos fazer a confissão mesmo a
um leigo. E por isso não é necessário fazê-la por escrito; porque é mais necessário o ato da confissão
que aquele a quem a fazemos.

## Art. 4 — Se as dezesseis condições enumeradas pelos Mestres são necessárias à confissão.
O quarto discute-se assim. - Parece não serem necessárias à confissão as dezesseis condições
enumeradas pelos mestres nos versos seguintes:
Seja simples, humilde a confissão, pura, fiel,
E freqüente, clara, discreta, voluntária, verecunda,
íntegra, secreta, lacrimosa, pronta
Forte e acusadora e disposta a obedecer.

1. ─ Pois, a fé, a simplicidade e a fortaleza são em si mesmas virtudes. Logo, não devem ser postas como
condições da confissão.

2. Demais. ─ Puro é o que não tem nenhuma virtude. Semelhantemente, simples é o que repugna à
composição e à mistura. Logo, é supérfluo o uso dessas duas palavras.

3. Demais. ─ O pecado uma vez cometido ninguém está obrigado a confessá-lo senão uma vez. Logo, se
não recairmos no pecado, não é preciso fazer confissão frequente.

4. Demais. ─ A confissão se ordena à satisfação. Ora, a satisfação às vezes é pública. Logo, a confissão
nem sempre deve ser secreta.

5. Demais. ─ O que não depende de nós não pode ser de nós exigido. Ora, verter lágrimas não depende
de nós. Logo, não pode ser exigido do confitente.

SOLUÇÃO. ─ Das referidas condições umas são necessárias à confissão, outras são para a perfeição dela.
As necessárias à confissão, ou lh'o são enquanto ato de virtude, ou enquanto parte do sacramento.
Quanto às necessárias, elas o são ou em razão da virtude, genericamente considerada, ou em razão da
virtude especial de que são atos, ou em razão mesma do ato.
A virtude genericamente considerada pertencem quatro condições, como diz Aristóteles. ─ A primeira, é
que tenhamos ciência. E, quanto a essa, a confissão se diz discreta, enquanto que a prudência é
necessária a todos os atos virtuosos. E essa discrição consiste em confessarmos os pecados maiores
mais ponderadamente. ─ A segunda condição é ser de livre eleição, porque os atos virtuosos devem ser
voluntários. Por isso se diz ─ voluntária. ─ A terceira condição é que pratiquemos o ato para alguma
coisa, isto é, para o fim devido. E por isso, diz que deve ser pura, isto é, que a intenção seja reta. - A
quarta, que pratiquemos o ato com firmeza. E por isso diz que deve ser forte, de modo que não
ocultemos a verdade por vergonha.
Demais, a confissão é ato da virtude de penitência. ─ E essa tem o seu início no horror pela torpeza do
pecado. E por isso a confissão deve ser verecunda, de modo que não nos jactemos dos pecados por
alguma vaidade do século que se infiltre nela. ─ Depois, a confissão nos leva à dor do pecado cometido.
E por isso deve ser lacrimosa. ─ E em terceiro lugar, termina na humilhação de nós mesmos. E por isso
deve ser humilde, de modo que nos confessemos miseráveis e enfermos. Mas, pela sua natureza
mesma, o ato da confissão deve ser manifestativo. Cuja manifestação pode ser impedida por quatro
obstáculos. ─ Primeiro, pela falsidade. E por isso diz fiel, isto é, verdadeira. ─ Segundo, pela obscuridade
das palavras. E contra isso diz ─ clara, de modo a não empregar palavras obscuras. ─ Terceiro, pela
multiplicação das palavras. E contra ela diz - simples, de modo a não declararmos na confissão senão os
pecados realmente cometidos. ─ Quarto, que não ocultemos nada do que devemos revelar. E contra isso
diz ─ íntegra.
Enquanto parte do sacramento, a confissão concerne ao juízo do sacerdote, ministro do sacramento. E
por isso é necessário seja ela acusadora, por parte do confitente; disposta a obedecer, às ordens do
sacerdote; secreta, quanto à condição do foro, em que se tratam coisas ocultas da consciência. Mas
para a confissão ser frutuosa há de ser frequente, e prontal; isto é, devemos confessar sem demora.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Nenhum inconveniente há em a condição de uma virtude
ser implicada no ato de outra, imperado pela primeira. Ou que a mediedade, própria principalmente de
uma virtude, também pertença a outras por participação.

RESPOSTA À SEGUNDA. ─ A condição pura exclui à intenção má, de que nos purificamos; e a de ser
simples exclui a mistura de elemento estranho.

RESPOSTA À TERCEIRA. ─ O que a objeção refere não é de necessidade para a confissão, mas para ser
perfeita.

RESPOSTA À QUARTA. ─ Para evitar escândalo dos outros, que poderiam inclinar-se ao pecado por
causa dos pecados ouvidos, não deve a confissão ser feita em público, mas ocultamente. Quanto à pena
satisfatória ninguém com ela se escandaliza, pois às vezes por um pecado pequeno ou nulo fazem-se
tais obras satisfatórias.

RESPOSTA À QUINTA. ─ Devemos entendê-lo das lágrimas da alma.