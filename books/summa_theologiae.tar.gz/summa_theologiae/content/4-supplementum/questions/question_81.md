# Questão 81: Da qualidade dos ressurgentes.
Em seguida devemos tratar da qualidade dos ressurgentes.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se todos ressurgem em idade viril.
O primeiro discute-se assim. ─ Parece que nem todos ressurgirão na idade viril.

1. ─ Pois, Deus não privará os ressurrectos, sobretudo os bem-aventurados, de nenhuma perfeição
humana. Ora, a idade é uma perfeição humana; assim, a velhice é uma idade venerável. Logo, os velhos
não ressurgirão em idade viril.

2. Demais. ─ A idade se calcula pelo tempo passado. Ora, é impossível o tempo passado deixar de sê-lo.
Logo, é impossível os mortos em idade avançada ressurgir em idade viril.

3. Demais. ─ O que sobretudo ressurgirá em cada um é o que por excelência verdadeiramente lhe
constituiu a natureza. Ora, mais uma cousa se aproxima da origem do homem, mais profundamente
parece pertencer à verdade da natureza humana. Porque na velhice a virtude da espécie fica debilitada
e por isso o Filósofo compara o corpo humano envelhecido ao vinho misturado com água. Logo, se
todos devem ressurgir na mesma idade, mais conviria ressurgirem na idade adolescente que na viril.
Mas, em contrário, o Apóstolo: Até que todos cheguemos a estado de varão perfeito, segundo a medida
da idade completa de Cristo. Ora, Cristo ressurgiu na idade viril, que começa cerca dos trinta anos, como
diz Agostinho. Logo, também os outros ressurgirão na idade viril.

2. Demais. ─ O homem ressurgirá na perfeição máxima da natureza. Ora, o estado perfeitissimo da
natureza humana é a idade viril. Logo, todos ressurgirão com essa idade.

SOLUÇÃO. ─ O homem ressuscitará isento de todos os defeitos da natureza humana; porque assim
como Deus a instituiu sem defeito, assim sem defeito a restaurará. Ora, a natureza humana sofre uma
dupla deficiência: a de não ter ainda alcançado a sua perfeição última e a de tê-la perdido. A primeira
defeituosidade é a das crianças; a segunda, a dos velhos. Por isso em ambos a natureza humana será
reduzida, pela ressurreição, ao estado da perfeição última, que é a da idade viril, quando termina o
movimento de crescer e começa o da decadência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A idade da velhice merece reverência, não pela condição
do corpo, que é defeituosa, mas pela sabedoria da alma, que nela se presume adquirida pela grande
longevidade. Por isso os eleitos terão a reverência devida à velhice, porque gozam da plenitude da
sabedoria divina que neles habitará, mas não sofrerão a decadência da velhice.

RESPOSTA À SEGUNDA. ─ Não nos referimos aqui à idade, quanto ao número dos anos, mas pelo estado
em que a ação dos anos constitui o corpo humano. Por isso se diz que Adão foi formado em idade viril,
porque o seu corpo teve a formação dessa idade desde o primeiro dia da sua existência. Por onde, a
objeção não colhe.

RESPOSTA À TERCEIRA. ─ Dizemos que a virtude especifica é mais perfeita no adolescente que na idade
viril, por ter, de certo modo, maior eficácia para transformar os alimentos; assim como também é mais
perfeita no esperma que no homem completo. Nos jovens porém é mais perfeita quanto ao termo do
crescimento. Por onde, o que mais profunda e verdadeiramente constitui a natureza humana terá
aquela perfeição que tem na idade viril; não na da primeira idade, quando os humores ainda não
chegaram à sua última consistência.

## Art. 2 — Se todos ressurgirão com a mesma estatura.
O segundo discute-se assim. ─ Parece que todos ressurgirão com a mesma estatura.

1. ─ Pois, assim como o homem é medido pela quantidade dimensiva, assim também pela de duração.
Ora, a quantidade de duração será reduzida em todos à mesma medida, porque todos ressurgirão com a
mesma idade. Logo, também a quantidade dimensiva será reduzida em todos à mesma medida, porque
todos ressurgirão com a mesma estatura.

2. Demais. ─ O Filósofo diz, que a natureza estabeleceu para todos os seres o termo e a lei da grandeza e
do crescimento. Ora, esse termo é fixado pela forma, a que deve corresponder a quantidade, como
todos os outros acidentes. Logo, como todos os homens tem a mesma forma especifica, todos devem
chegar à mesma quantidade dimensiva do corpo, salvo erro da natureza, ora, o erro da natureza se
corrigirá na ressurreição. Portanto, nem todos ressurgirão com a mesma estatura.

3. Demais. ─ A estatura do ressurrecto não poderá ser proporcionada à primeira virtude natural
formadora do corpo, do contrário, os que não puderam atingir uma estatura maior pela virtude natural,
nunca poderiam ressurgir com essa maior estatura ─ o que é falso. Logo, essa estatura há de
proporcionar-se à virtude reconstituidora do corpo humano na ressurreição, e à matéria de que será
reconstituído. Ora, a virtude que há de reconstituir todos os corpos será a mesma ─ a virtude divina; e
todas as cinzas, de que os corpos humanos se reconstituirão, são igualmente aptas a receber a ação
dessa virtude. Logo, todos os homens hão de ter como termo a mesma quantidade corpórea. Donde, a
mesma conclusão anterior.
Mas, em contrário. ─ A mesma quantidade natural resulta da natureza de cada indivíduo. Ora, na
ressurreição não variará a natureza do indivíduo. Logo, nem a sua quantidade natural. Mas nem todos
tem a mesma quantidade natural. Logo, nem todos ressurgirão com a mesma estatura.

2. Demais. ─ A natureza humana será reconstituída pela ressurreição para entrar no gozo da glória ou no
sofrimento da pena. Ora, nem todos os ressurrectos gozarão na mesma intensidade a glória nem na
mesma intensidade sofrerão a pena. Logo, também não ressurgirão com a mesma estatura.

SOLUÇÃO. ─ Na ressurreição a natureza humana não será reconstituída na mesma espécie só, mas
também no mesmo indivíduo. Por onde devemos atender não somente ao que convém, então, à
natureza específica, mas também à natureza individual. Ora, a natureza específica tem uma
determinada grandeza quantitativa que não pode, sem erro, ultrapassar nem deixar de atingir. Essa
grandeza porém é susceptíva de certos graus de latitude, e não deve ser considerada como tendo uma
medida determinada. Ora, cada indivíduo da espécie humana atinge, dentro dos termos dessa latitude,
uma certa grandeza quantitativa própria à sua natureza individual. E essa ele a atinge no termo do seu
crescimento, salvo erro na obra da natureza, causador de algum acréscimo ou alguma subtração nessa
quantidade, cuja medida se funda na proporção do calor que dilata, e da umidade susceptível de
estender-se, que não tem a mesma virtude em todos. Logo, nem todos ressurgirão com a mesma
quantidade corpórea; mas cada qual ressurgirá com as dimensões que teria no termo do crescimento,
se não houver erro nem falha da natureza. O que porém for excessivo ou deficiente no corpo, o poder
divino o amputará ou suprirá.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Do sobredito já se conclui, que quando se afirma a
ressurreição de todos com a mesma idade, não se afirma tenham todos a mesma quantidade de
duração; mas que terão todos o mesmo estado de perfeição. Estado que pode coexistir com uma
estatura maior ou menor.

RESPOSTA À SEGUNDA. ─ A estatura do indivíduo corresponde não só à forma específica, mas também
à natureza individual. Logo, a objeção não colhe.

RESPOSTA À TERCEIRA. ─ A estatura do ressurrecto não é proporcional à virtude reconstitutiva do
corpo, que não pertence à natureza deste; nem às cinzas, no estado em que se encontram antes da
ressurreição; mas à natureza primitiva do indivíduo. Contudo, se a virtude formativa, por alguma
deficiência, não pudesse restabelecer a estatura própria à espécie, a virtude divina suprirá essa falha na
ressurreição. Tal o caso dos anãos. E o mesmo se dirá dos que foram de estatura descomedida e fora do
natural.

## Art. 3 — Se todos ressurgirão com o sexo masculino.
O terceiro discute-se assim. ─ Parece que todos ressurgirão com o sexo masculino.

1. ─ Pois, diz o Apóstolo: Todos chegaremos ao estado de varão perfeito. Logo, não haverá na
ressurreição senão o sexo masculino.

2. Demais. ─ No século futuro cessará todo principado, como diz a Glosa a um lugar do Apóstolo. Ora, a
mulher, por uma ordem natural, está sujeita ao homem. Logo, as mulheres não ressurgirão com o sexo
feminino, mas com o masculino.

3. Demais. ─ O que foi produzido ocasionalmente e fora da intenção da natureza não ressurgirá; porque
na ressurreição todos os erros serão reparados. Ora, o sexo feminino não estava na intenção da
natureza, produzido como foi por deficiência da virtude formativa do esperma, que não pôde dar ao ser
concebido a forma viril. Donde o dizer o Filósofo que a mulher é um homem ocasional (imperfeito).
Logo, o sexo feminino não ressurgirá.
Mas, em contrário, diz Agostinho: Mais acertadamente opinam os que não duvidam da ressurreição de
ambos os sexos.

2. Demais. ─ Deus reconstituirá na ressurreição o que deu ao homem na sua primitiva instituição. Ora,
fez a mulher da costela do homem, como o narra a Escritura. Logo, reconstituirá o sexo feminino na
ressurreição.

SOLUÇÃO. ─ Assim como, considerada a natureza do indivíduo, homens diversos tem estatura diversa,
assim também, considerada essa mesma natureza, os seres humanos devem distribuir-se em sexos
diversos. Essa diversidade também é própria à perfeição da espécie, cujos graus diversos são realizados
por essa diversidade de sexos ou de estatura. Portanto, assim como os homens ressurgirão com
estaturas diversas, assim também com sexos diversos. E embora haja na ressurreição a diferença de
sexos, não haverá contudo nenhuma vergonha resultante da visão mútua deles, porque ficará então
destruída a concupiscência, causa do pejo, pela torpeza a que ela exista.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A expressão citada ─ Todos chegaremos ao estado de
varão perfeito ─ não designa o sexo viril, mas a forca da alma, de que todos serão dotados ─ homens e
mulheres.

RESPOSTA À SEGUNDA. ─ A mulher está sujeita ao marido por causa da sua fraqueza natural, tanto
quanto ao vigor da alma quanto à robustez do corpo. Mas depois da ressurreição não haverá mais essas
diferenças, senão só a diversidade dos méritos. Logo, a objeção não colhe.

RESPOSTA À TERCEIRA. ─ Embora a geração da mulher esteja fora da intenção particular da natureza,
esta porém na sua intenção geral, que exige a dualidade dos sexos para a perfeição da espécie humana.
Nem haverá na ressurreição nenhuma deficiência resultante dos sexos, como do sobre dito se colige.

## Art. 4 — Se os ressurrectos terão a vida animal de modo a exercerem a função nutritiva e a genésica.
O quarto discute-se assim. ─ Parece que os ressurrectos terão a vida animal de modo a exercerem a
função nutritiva e a genésica.

1. ─ Pois, a nossa ressurreição será conforme à de Cristo. Ora, segundo os Evangelhos, Cristo se nutriu
depois da ressurreição. Logo, todos os homens também hão de nutrir-se depois da ressurreição. E pela
mesma razão hão de gerar.

2. Demais. ─ A distinção dos sexos se ordena à geração; e semelhantemente, os órgãos destinados à
função nutritiva se ordenam à manducação. Ora, o homem ressurgirá com todos esses órgãos. Logo,
exercerá a função genésica e a nutritiva.

3. Demais. ─ O homem será beatificado no seu ser completo ─ alma e corpo. Ora, a beatitude ou
felicidade, segundo o Filósofo, consiste numa operação perfeita. Logo, todas as potências da alma e
todos os órgãos do corpo dos bem-aventurados exercerão os seus atos, depois da ressurreição. Donde a
mesma conclusão que antes.

4. Demais. ─ Os bem-aventurados gozarão depois da ressurreição de uma perfeita e beata felicidade.
Ora, essa felicidade inclui todos os prazeres, pois, a beatitude é, segundo Boécio, um estado perfeito
pela agregação de todos os bens; e perfeito é ao que nada falta, como ensina Aristóteles. Ora, como o
exercício da função genésica e o da nutritiva causam grande prazer, parece que os bem-aventurados
praticarão esses atos da vida animal. E com muito maior razão os outros, que tiverem corpos menos
espiritualizados.
Mas, em contrário, o Evangelho: Na ressurreição nem as mulheres terão maridos, nem os maridos
mulheres.

2. Demais. ─ A geração se ordena a reparar as falhas causadas pela morte e à multiplicação do gênero
humano; e a nutrição a reparar as energias perdidas e a produzir o crescimento do corpo. Ora, na
ressurreição, já o gênero humano estará constituído em toda a multidão dos indivíduos predeterminada
por Deus; porque haverá geração até essa época. Semelhantemente, cada homem ressurgirá com a sua
estatura adequada. Nem mais haverá morte nem os órgãos do corpo sofrerão qualquer perda de
energia. Logo, inúteis serão as funções genésica e nutritiva.

SOLUÇÃO. ─ A ressurreição não será necessária para o homem atingir a sua perfeição primitiva,
consistente na integridade de tudo o pertinente à natureza. Porque a isso podemos chegar no estado da
vida presente, pela ação das causas naturais. Mas a ressurreição lhe é necessária para atingir a perfeição
última, consistente na consecução do último fim. Por onde, na ressurreição aquelas funções naturais
não hão de mais exercer-se que se ordenam a causar ou a conservar a perfeição primitiva da natureza
humana. E tais são os atos da vida animal no homem, os atos da natureza nos elementos, e o
movimento do céu. Tudo isto portanto cessará na ressurreição. Ora, comer, beber, dormir e gerar são
atos da vida animal, ordenados à perfeição primitiva da natureza humana. Logo, tais atos não mais hão
de existir na ressurreição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A nutrição de Cristo não foi premida pela necessidade,
como se a sua natureza humana precisasse de alimentar-se depois da ressurreição. Mas foi para
manifestar o seu poder, mostrando assim ter verdadeiramente reassumido a natureza humana, que
tinha no seu estado anterior, quando com os discípulos comia e bebia. Ora, essa manifestação, por
conhecida de todos, não será necessária na ressurreição universal. Por isso se diz, dispensativamente,
que Cristo comeu, conforme o modo de falar dos juristas que definem a dispensa como uma suspensão
do direito comum; porque Cristo suspendeu, pela razão aduzida, condição comum aos ressurrectos, de
não usarem de alimentos. Por onde, a objeção não colhe.

RESPOSTA À SEGUNDA. ─ A diferença dos sexos e a variedade dos órgãos será para reintegrar a
natureza humana na sua perfeição específica e individual. Donde pois não se segue que sejam inúteis,
embora não se exerçam as funções animais.

RESPOSTA À TERCEIRA. ─ As referidas funções não são do homem como tal, segundo o Filósofo. Por isso
nelas não consiste a felicidade do corpo; mas o corpo humano será glorificado pela redundância da
razão, que torna o homem tal a ela se submetendo.

RESPOSTA À QUARTA. ─ Os prazeres corpóreos são, como diz o Filósofo, medicinais, concedidos ao
homem para lhe tolher o tédio da vida; ou doenças, quando procuradas desordenadamente como se
fossem verdadeiros prazeres, assim como quem tem um gosto depravado se deleita com cousas com
que não se comprazeria uma pessoa de gosto são. Por onde não é necessário sejam esses prazeres da
perfeição da beatitude, como pensam os judeus e os sarracenos, e o ensinaram certos heréticos
chamados Quiliastas. Os quais, mesmo segundo a doutrina do Filósofo, não tem senso reto; pois, só os
prazeres espirituais, segundo ele, são deleitações, no seu sentido próprio, e são os únicos que devemos
buscar por si mesmos. Por onde, só esses são necessários à felicidade.