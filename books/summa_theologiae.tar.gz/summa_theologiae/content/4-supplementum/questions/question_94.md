# Questão 94: Das relações entre os santos e os condenados.
Em seguida devemos tratar das relações entre os santos e os condenados.
E nesta questão discutem-se três artigos:

## Art. 1 — Se os bem-aventurados na pátria verão as penas dos condenados.
O primeiro discute-se assim. ─ Parece que os bem-aventurados na pátria não verão as penas dos
condenados.

1. ─ Pois, maior distância há entre os condenados e os bem-aventurados que entre eles e os que
vivemos neste mundo. Ora, os bem-aventurados não sabem o que se passa conosco nesta vida; donde o
dizer a Escritura ─ Abraão não nos conheceu, o que a Glosa assim comenta: Não sabem os mortos,
mesmo santos, o que fazem os vivos, mesmo sendo filhos. Logo, muito menos verão as penas dos
condenados.

2. Demais. ─ A perfeição da visão depende da perfeição do visível. Por isso diz o Filósofo: A operação
mais perfeita da vista se realiza quando esse sentido está na sua melhor disposição para perceber os
objetos mais belos que estiverem ao seu alcance. Logo e ao contrário, um objeto visível mas vil redunda
em imperfeição da visão. Ora, nenhuma imperfeição existirá nos bem-aventurados. Logo, não verão as
misérias dos condenados, de suma vileza.
Mas, em contrário, a Escritura: Eles sairão e verão os cadáveres dos homens que prevaricaram contra
mim. Ao que diz a Glosa: Os eleitos sairão, pelo pensamento ou por uma visão manifesta, a fim de mais
ardentes se tornarem em dar louvor a Deus.

SOLUÇÃO. - Os bem-aventurados não devem ficar privados de nada que lhes contribua para a perfeição
da felicidade. Ora, conhecemos melhor uma cousa quando a comparamos com a sua contrária; porque
os contrários postos em presença uns dos outros mais sobressaem. Por onde, para a beatitude dos
santos lhes causar maior alegria e darem por ela maiores graças a Deus, é-lhes concedido conhecerem
perfeitamente a pena dos ímpios.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A Glosa citada se refere aos santos mortos, no que lhes é
possível à natureza; pois, não hão mister de conhecer, por um conhecimento natural, tudo o que se
passa com os vivos. Mas os santos que estão na pátria conhecem claramente tudo o que se passa
conosco neste mundo e com os condenados. Por isso diz Gregório: Não devemos aplicar às almas santas
aquele lugar de Job ─ Ou os seus filhos estejam exaltados ou abatidos, ele os não conhecerá, etc.; pois,
os que no céu gozam da claridade de Deus de nenhum modo devemos crer que haja fora da mansão
celeste algo que ignorem.

RESPOSTA À SEGUNDA. ─ Embora a beleza do objeto visível contribua para a perfeição da visão, a vileza
porém desse objeto pode não contribuir em nada para a imperfeição dela. Pois, na alma, as espécies das
cousas, pelas quais conhece os contrários, não são contrárias. Por isso também Deus, que tem o
perfeitíssimo dos conhecimentos, vê tudo ─ tanto as cousas belas como as vis.

## Art. 2 — Se os bem-aventurados se compadecem das misérias dos condenados.
O segundo discute-se assim. ─ Parece que os bem-aventurados se compadecem das misérias dos
condenados.

1. ─ Pois, a compaixão procede da caridade. Ora, os bem-aventurados terão uma caridade perfeita.
Logo, mais que ninguém, se compadecerão das misérias dos condenados.

2. Demais. ─ Os bem-aventurados nunca, estarão mais afastados da compaixão, que Deus. Ora, Deus de
certo modo se compadece das nossas misérias, e por isso é chamado misericordioso; assim também os
anjos. Logo, os bem-aventurados se compadecem.
Mas, em contrário. ─ Quem se compadece de outrem de certo modo lhe participa da miséria. Ora, os
bem-aventurados não podem compadecer-se da miséria de ninguém. Logo, não se compadecem das
misérias dos condenados.

SOLUÇÃO. ─ A misericórdia ou a compaixão pode alguém tê-las de dois modos: a modo de paixão e a
modo de eleição. Ora, nos bem-aventurados não haverá certamente nenhuma compaixão na parte
inferior da alma, senão consequente à eleição da razão. Portanto, não terão eles compaixão nem
misericórdia senão segundo a eleição da razão. E assim, da eleição da razão nasce a misericórdia ou a
compaixão, quando queremos livrar a outrem do mal que padece; por onde, males que não queremos,
de conformidade com a razão, repelir, não provocam em nós nenhuma compaixão. Ora, os pecadores,
enquanto neste mundo, em tal estado vivem que, sem prejuízo da divina justiça, podem, do estado de
miséria e de pecado, passar para o de beatitude. Por isso podem ser objeto de compaixão, tanto pela
eleição da vontade, e assim dizemos que Deus, os anjos e os santos deles se compadecem por lhes
querer a salvação; como pela paixão, e assim deles se compadecem os bons que ainda vivem neste
mundo. Mas, na vida futura, não mais poderão sair do seu estado de miséria. Por onde, não pode haver
compaixão para com eles fundada numa eleição reta. Portanto, os santos na glória nenhuma compaixão
terão dos condenados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A caridade é então princípio de compaixão quando,
fundados nela, podemos querer que alguém fique livre da sua miséria. Ora, os santos, pela caridade,
não o podem querer, em relação aos condenados, pois, isso repugna à divina justiça. Portanto, a
objeção não colhe.

RESPOSTA À SEGUNDA. ─ Dizemos que Deus é misericordioso por vir em auxílio daqueles que, na ordem
da sua sabedoria e da sua justiça, convém livrar da miséria em que jazem. Não que se compadeça dos
condenados, senão talvez pelos punir menos do que mereceriam.

## Art. 3 — Se os bem-aventurados se alegram com as penas dos ímpios.
O terceiro discute-se assim. ─ Parece que os bem aventurados não se alegram com as penas dos ímpios.

1. ─ Pois, alegrar-se com o mal de outrem só pode ser por ódio. Ora, os bem-aventurados não terão
nenhum ódio. Logo, não se alegrarão com as misérias dos condenados.

2. Demais. ─ Os santos na pátria serão sumamente conformes a Deus. Ora, Deus não se deleita com os
nossos males, diz a Escritura. Logo, nem os santos se deleitarão com as penas dos condenados.

3. Demais. ─ O que é repreensível nos que ainda vivemos neste mundo de nenhum modo pode se
conceber nos que gozam da visão divina.
Ora, neste mundo é culposo por excelência alegrar-mo-nos com as penas alheias; e o que há de mais
louvável é condoermo-nos delas. Logo, os bem-aventurados de nenhum modo se alegram com as penas
dos condenados.
Mas, em contrário, a Escritura: Alegrar-se-á o justo quando vir a vingança.

2. Demais. ─ A Escritura diz: Servirão de espetáculo a toda a carne, até ela se fartar de ver semelhante
objeto. Ora, o fartar-se designa a saciar do coração. Logo, os bem-aventurados se alegrarão com as
penas dos ímpios.

SOLUÇÃO. ─ De dois modos pode uma coisa nos ser motivo de alegria. ─ Em si mesma, quando nos
comprazemos com uma causa, como tal. E, neste sentido, os santos não se alegrarão com a pena dos
ímpios. ─ Ou por acidente, i. é, em razão de um bem que os acompanha. ─ E neste sentido, os santos
hão de alegrar-se com as penas dos condenados, considerando neles a ordem da divina justiça gozando
o prazer de se verem livres delas. Assim, pois, a divina justiça e o contentamento de se se sentirem livres
de tais penas serão para os santos causa de alegria; mas essas penas em si mesmas só por acidente lhes
produzirão alegria.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Alegrarmo-nos com o mal de outrem, como tal, constitui
ódio; mas não alegrarmo-nos com ele em razão de um elemento a ele anexo não o constitui. Deste
último modo podemos nos alegrar com o mal próprio nosso; assim quando nos comprazemos nos
nossos sofrimentos próprios, enquanto lhes redunda em mérito para a vida eterna, conforme aquilo da
Escritura: Tende por um motivo ela maior alegria para vós as diversas tribulações que vos sucedem.

RESPOSTA À SEGUNDA. ─ Embora Deus não se deleite com os nossos males, como tais, contudo com
eles se deleita enquanto ordenados pela sua justiça.

RESPOSTA À TERCEIRA. ─ Não seria louvável, aos que vivemos nesta vida deleitarmo-nos com os males
alheios, em si mesmos considerados; é louvável porém alegrarmo-nos com eles pelo bem que os
acompanha. ─ Contudo não se dá conosco, neste mundo, o que se dá com os que vêem a Deus. Pois, as
nossas paixões frequentemente se revoltam contra o discernimento racional. Toda via essas paixões são
às vezes dignas de louvor, enquanto revelam boas disposições da alma; tal o caso do pudor, da
misericórdia e da penitência pelo mal cometido. Ao passo que nos santos não podem existir paixões
senão submetidas ao juízo da razão.