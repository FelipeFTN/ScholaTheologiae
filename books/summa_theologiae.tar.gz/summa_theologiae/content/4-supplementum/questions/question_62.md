# Questão 62: Do impedimento da fornicação, sobreveniente ao
matrimônio consumado.
Em seguida devemos tratar do impedimento da fornicação sobreveniente ao matrimônio consumado, a
qual impede o matrimônio precedente quanto ao ato, deixando subsistir o vínculo matrimonial.
E nesta questão discutem-se seis artigos:

## Art. 1 — Se por causa, de fornicação é licito ao marido repudiar a esposa.
O primeiro discute-se assim. ─ Parece que por causa de fornicação não é lícito ao marido repudiar a
esposa.

1. Pois, não devemos pagar o mal com o mal. Ora, o marido, repudiando a esposa por causa de
fornicação, paga o mal com o mal. Logo, não lho é lícito.

2. Demais. ─ Mais grave era o pecado de fornicação de ambos, que de um só. Ora, a fornicação de
ambos não pode dar lugar à separação. Logo, nem a de um só.

3. Demais. ─ A fornicação espiritual e certos outros pecados são mais graves que a fornicação carnal.
Ora, aquela não pode ser causa de rotura do laço conjugal. Logo, nem a fornicação carnal.

4. Demais. ─ O vício contra a natureza é mais contrário aos bens do matrimônio que a fornicação, que se
pratica de acordo com a natureza. Logo, devia ser, mais que a fornicação, causa de separação.
Mas, em contrário, o Evangelho.

2. Demais. ─ Para com quem quebra a fidelidade prometida ninguém está obrigado a ser fiel. Ora, a
mulher que fornica quebra a fé devida ao outro cônjuge. Logo, este pode repudiá-la por causa de
fornicação.

SOLUÇÃO. ─ O Senhor permitiu repudiar a mulher por causa de fornicação, como pena à mulher da fé
quebrada e como favor ao marido que se conservou fiel; de modo que o cônjuge fiel não mais está
obrigado a cumprir para com o infiel o dever conjugal. Por isso se excetuam sete casos nos quais não é
lícito ao marido repudiar a esposa infiel, nos quais ou a mulher fica isenta de culpa eu ambos são
atualmente culpados. ─ O primeiro é quando também o marido fornicou. ─ O segundo, se prostituiu a
esposa. ─ O terceiro, quando a mulher, crendo com probabilidade que o marido morreu, fundada na sua
longa ausência, casou com outro. ─ O quarto, se teve relações com um homem que, sob a figura de ser
marido, e sem que ela o soubesse, lhe participou do leito. ─ O quinto, se assim procedeu oprimida pela
violência. ─ Sexto, se o marido, depois de ter ela adulterado, se reconciliou tendo relações carnais com
ela. ─ O sétimo se, tendo sido o matrimônio contraído entre dois cônjuges infiéis, o marido mano dou
libelo de repúdio à mulher e esta se casou com outro; pois então, se ambos se converterem, está
obrigado o marido a recebê-la.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O marido que repudiar a mulher, que fornicou, levado
pela vingança, peca. Se porém a repudiou para não parecer participante do seu crime, ou para corrigir o
pecado da mulher, ou para evitar a incerteza da prole, não peca.

RESPOSTA À SEGUNDA. ─ A separação por causa de fornicação se processa acusando um cônjuge ao
outro. E como ninguém pode acusar, que cometeu o mesmo crime, quando ambos fornicaram a
separação não pode ter lugar; embora seja maior pecado contra o matrimônio a fornicação de ambos
que a de um só.

RESPOSTA À TERCEIRA. ─ A fornicação vai diretamente contra o bem do matrimônio, porque elimina a
certeza da prole, quebra a fé conjugal e o simbolismo, porque então um dos cônjuges repartiu com
várias outras pessoas a sua carne. Por isso os outros crimes, embora talvez mais graves que a fornicação,
não causam contudo a separação. Mas como a infidelidade, chamada fornicação espiritual, também vai
contra o bem do matrimônio, que é educar os filhos para o culto de Deus, também ela causa a
separação. Diferentemente porém da fornicação corporal. Porque um só ato de fornicação carnal basta
para justificar a separação, mas não um só ato de infidelidade; pois esta deve ser habitual e assim
reveladora da pertinência, que dá à infidelidade toda a sua plenitude.

RESPOSTA À QUARTA. ─ Também o vício contra a natureza pode ser causa de separação. Mas dele não
se faz menção entre as causas de separação, tanto por ser uma paixão nefanda, como por ser rara a sua
prática quer porque não causa nenhuma incerteza em relação à prole.

## Art. 2 — Se o marido está obrigado por lei a repudiar a esposa que fornicou.
O segundo discute-se assim. ─ Parece que a mando esta obrigado por lei a repudiar a esposa que
fornicou.
1 . Pois o marido, sendo chefe da mulher, esta obrigado a corrigi-la. Ora, a rotura do laço conjugal foi
permitida para a correção da esposa, prevalecedora. Logo, está o marido obrigado a separar-se dela.

2. Demais. ─ Quem consente em que outro peque mortalmente também mortalmente peca. Ora, o
marido, que consente em coabitar com a esposa infiel, consente no pecado dela, como diz o Mestre.
Logo, peca se não na arreda de si.

3. Demais. ─ O Apóstolo diz: O que se ajunta com a prostituta jaz um mesmo corpo com ela. Ora,
ninguém pode ser ao mesmo tempo membro de uma prostituta e de Cristo, como no mesmo lugar se
diz. Logo, o marido, consentindo em coabitar com a esposa infiel, deixa de ser membro de Cristo, por
pecar mortalmente.

4. Demais. ─ Assim como o parentesco impede o vínculo matrimonial, assim a infidelidade separa do
toro. Ora, o marido, se depois de saber o parentesco que tem com sua mulher, consentir em ter
conjunção carnal com ela, peca mortalmente. Logo, mortalmente também peca, se o consentir depois
de saber que ela fornicou.
Mas, em contrário, diz a glosa, que o Senhor permitiu ao marido repudiar a esposa, por causa de
fornicação. Logo, não o estabeleceu como preceito.

2. Demais. ─ Todos podemos perdoar a quem contra nós pecou. Ora, a mulher prevaricando, pecou
contra o marido. Logo, este pode perdoá-la deixando de a repudiar.

SOLUÇÃO. ─ O repúdio da mulher que prevaricou foi permitido para, como pena, corrigi-la do pecado.
Ora, uma pena corretiva não pode aplicar-se onde não há possibilidade de emenda. Logo, se a mulher
fizer penitência do pecado, não está o marido obrigado a repudiá-la. Esta porém obrigado, se ela não se
penitenciar dele, a fim de não parecer consentir nele, por não lhe aplicar a correção devida.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O pecado de fornicação cometido pela mulher pode ser
castigado, não somente pela pena referida, mas também por palavras e açoites. Por onde, se está
disposta a aceitar outras correções, não está o marido obrigado a castigá-la com a referida pena.

RESPOSTA À SEGUNDA. ─ Então é o marido considerado como consenciente no pecado da mulher,
quando continua a coabitar com ela sem que ela deixe o pecado passado. Mas, desde que se emendou,
não mais pode ser considerado como dando o seu consentimento.

RESPOSTA À TERCEIRA. ─ Desde que sua mulher se penitenciou da prevaricação, em que caiu, não pode
ser considerada meretriz. Portanto o marido, unindo-se com ela, não se torna membro de uma meretriz.
─ Ou podemos responder que não se une com ela como meretriz, mas como esposa.

RESPOSTA À QUARTA. ─ Não há símile. Porque o parentesco faz com que não possa haver entre as
partes o vínculo conjugal; portanto, torna-se ilícita a cópula carnal. Ao contrário, a fornicação não
elimina o referido vínculo. Logo, o ato em si mesmo considerado, permanece lícito; e só acidentalmente
será ilícito, enquanto o marido consente na torpeza da esposa.

RESPOSTA À QUINTA. ─ Essa permissão se deve entender como significando a privação da proibição. E
assim não está em oposição com nenhum preceito, pois também o objeto de um preceito não constitui
uma proibição.

RESPOSTA À SEXTA. ─ A mulher não peca tanto contra o marido, como contra si mesma e contra Deus.
Logo, o marido não pode perdoar totalmente a pena, sem que se ela emende.

## Art. 3 — Se o marido pode, por juízo próprio, repudiar a esposa que fornicou.
O terceiro discute-se assim. ─ Parece que o marido pode, por juízo próprio, repudiar a esposa que
fornicou.

1. Pois, a sentença proferida por um juízo podemos executá-la sem necessidade de nenhum outro juízo.
Ora, Deus, juiz justo, proferiu a sentença em virtude da qual o marido pode, por causa de fornicação,
repudiar a esposa. Logo, não é necessário, para tal nenhum outro juízo.

2. Demais, ─ O Evangelho diz, que José, como era justo, resolveu deixar secretamente a Maria. Logo,
parece que o marido pode resolver a separação ocultamente, sem o juízo da Igreja.

3. Demais. ─ Se o marido, depois de saber da fornicação da mulher, cumprir para com ela o dever
conjugal, perde a ação que contra ela tinha. Logo, a denegação de cumprir o dever conjugal, causa de
separação, deve preceder ao juízo da Igreja.

4. Demais. ─ O que não pode ser provado não pode ser trazido ao juízo da Igreja. Ora, o olho do adúltero
observa a escuridade, ao dizer da Escritura. Logo, não deve a referida separação ser trazida perante o
juízo da Igreja.

5. Demais. ─ Uma acusação deve ser precedida da inscrição pela qual se obriga à pena de crime da
fornicação não pode ser provado, porque talião quem não conseguir, provar a acusação. Ora, tal não é
possível nesta matéria; pois, qualquer que fosse o resultado do processo, o marido conseguiria o seu
intento, quer devesse repudiar a esposa, quer a esposa repudiar a ele. Logo, não deve tal acusação ser
trazida perante o tribunal da Igreja.

6. Demais. ─ Mais obrigado está o marido para com a mulher que para com um estranho. Ora, não
devemos deferir ao juízo da Igreja o crime alheio, mesmo de um estranho, senão depois de termos feito
advertência em segredo, como esta claro no Evangelho. Logo, muito menos deve o marido deferir à
Igreja o crime da esposa, sem primeiro tê-la advertido particularmente.
Mas, em contrário. ─ Ninguém deve ser juiz em causa própria. Ora o marido, que por arbítrio próprio
demitisse a esposa prevaricadora, seria juiz em causa própria. Logo, isso não lhe deve ser permitido.

2. Demais. ─ Ninguém pode ser autor e juiz numa mesma causa. Ora, o marido é o autor queixoso de
uma ofensa que sua mulher lhe fez. Logo, não pode ser também juiz. E assim, não deve repudiá-la por
arbítrio próprio.

SOLUÇÃO. ─ O marido pode repudiar a mulher de dois modos. ─ Primeiro, só quanto ao tóro. E então
pode fazê-lo, por juízo próprio, desde que lhe souber da infidelidade. Nem fica obrigado a cumprir para
com ela o dever conjugal, quando dele o exigir, salvo se a Igreja lh'o impuser. E neste último caso, o
cumprimento desse dever não lhe causa nenhum dano. ─ De outro modo, quando ao tóro e à
coabitação. E então não na pode repudiar senão por juízo da Igreja. E se proceder diferentemente, deve
ser compelido à coabitação, salvo se lhe puder provar imediatamente o fato da infidelidade. E esse
repúdio se chama divórcio. Donde devemos concluir que este não pode ser decretado senão por juízo
da Igreja.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Uma sentença é a aplicação do direito comum a um fato
particular. Por isso, o Senhor promulgou o direito, de acordo com o qual deve ser formulada a sentença
no juízo.

RESPOSTA À SEGUNDA. ─ José quis deixar a Maria, não pela suspeita de infidelidade, mas por lhe
respeitar a santidade, temendo coabitar com ela. ─ Mas o símile não colhe. Porque nesse tempo o
adultério não só dava lugar ao divórcio, mas além disso, à lapidação. Não porém agora, no processo
perante o tribunal da Igreja.

RESPOSTA À TERCEIRA. ─ Deduz-se do que foi dito.

RESPOSTA À QUARTA. ─ Pode o marido, suspeitando a esposa de adultério, vigiá-la a fim de com
testemunhas, apanhá-la em flagrante delito de adultério e poder depois proceder à acusação. ─ Além
disso, se o fato não puder ser provado, pode haver dele suspeitas veementes, provadas as quais,
provado também ficará o adultério; assim, se foi encontrada a sós com um homem, em horas e lugar
suspeitos, e estando ambos despidos.

RESPOSTA À QUINTA. ─ De dois modos pode o marido acusar a esposa de adultério. ─ Primeiro, perante
o juízo espiritual, com o fim de obter a separação do toro. E então não é preciso que se obrigue de ante-
mão e por escrito à peça de talião; porque seria isso conseguir exatamente o seu intento, como a
objeção o prova. Outro fim seria a punição do crime em juízo secular. De outro modo, há de proceder a
inscrição, pela qual se obriga à pena de talião, se não puder provar a acusação.

RESPOSTA À SEXTA. ─ Como determina uma decretal, pode proceder-se de três modos, no juízo
criminal. Primeiro, por inquisição, que deve ser precedida do rumor público insinuativo da existência, o
que tem lugar de acusação. Segundo, por acusação, que deve ser precedida pela inscrição. Terceiro, pela
denúncia, a que deve preceder a correção fraterna. Ora, as palavras do Senhor se entendem, aplicáveis
quando se procede por via de denúncia, e não por via de acusação; por que então o fim não é só a
correção do delinquente, mas também a punição, com o fito de conservar o bem comum, que pereceria
com a falta de justiça.

## Art. 4 — Se marido e mulher, em causa de divórcio, devem julgar-se em igualdade de condições.
O quarto discute-se assim. ─ Parece que marido e mulher não devem, em causa de divórcio, julgar-se
em igualdade de condições.

1. Pois, o divórcio está, na Lei Nova, em lugar do repúdio da Lei Velha, como se lê no Evangelho. Ora, no
repúdio, marido e mulher não eram julgados em igualdade de situações; assim aquele podia repudiar a
esta, mas não ao contrário. Logo, nem no divórcio devem julgar-se no mesmo pé de igualdade.

2. Demais. ─ É mais contra no à lei natural uma mulher ter vários maridos, que um homem várias
mulheres; por isso era às vezes permitida esta última situação, mas nunca a primeira. Logo, no adultério
a mulher peca mais gravemente que o homem. E por tanto não devem ser julgados no mesmo pé de
igualdade.

3. Demais. ─ Tanto maior é o dano causado ao próximo, tanto mais grave é o pecado. Ora, maior dano
causa a mulher adúltera ao marido, que à esposa o marido adúltero; porque o adultério da mulher
causa a incerteza da prole, mas não o do marido. Logo, o pecado da mulher é mais grave. E portanto,
marido e mulher não devem julgar-se no mesmo pé de igualdade.

4. Demais. ─ O divórcio foi introduzido para corrigir o crime de adultério. Ora, pertence sobretudo ao
marido, cabeça da mulher, na expressão do Apóstolo, corrigir a mulher, e não o inverso. Logo, não
devem marido e mulher, em causa de divórcio, ser julgados no mesmo pé de igualdade, mas deve ser
superior a condição do marido.
Mas, em contrário. ─ Parece que, em causa de divórcio, superior deve ser a condição da mulher. Porque
quanto maior for a fragilidade do pecador, tanto mais digno de vênia será o pecado. Ora, na mulher há
maior fragilidade que no homem, em razão do que, diz Crisóstomo ser a luxúria a paixão própria da
mulher. E o Filósofo ensina que as mulheres, propriamente falando, não podem chamar-se continentes,
por causa de resvalarem facilmente na concupiscência. Assim também os brutos não podem ser
continentes, por não poderem impor nenhum freio à concupiscência. Logo, deve haver maior
contemplação com as mulheres ao aplicar a pena do divórcio.

2. Demais. ─ O homem foi constituído cabeça da mulher a fim de governá-la. Logo, peca mais
gravemente que ela. E portando deve sofrer pena maior.

SOLUÇÃO. ─ Em causa de divórcio, marido e mulher são julgados como tendo direito a coisas iguais, de
modo a ser lícito e ilícito a um o que também o for ao outro. Mas não são julgados como no mesmo pé
de igualdade em relação à essas coisas; porque a causa de divórcio é maior em um que em outro,
embora ambos dêem causa suficiente a êle. Pois, o divórcio é a pena do adultério, enquanto este vai
contra os bens do matrimônio. Quanto porém ao bem da fidelidade, a que os cônjuges estão
mutuamente obrigados, tanto peca contra o matrimônio o adultério de um como o de outro, sendo em
ambos causa suficiente de divórcio. Mas quanto ao bem da prole, mais grave é o adultério da mulher
que o do marido; portanto, maior causa de divórcio é o adultério dela que o dele. Por onde, marido e
mulher estão adstritos a obrigações iguais, mas não por causa igual. Nem há nisso injustiça, porque em
ambos os casos há causa suficiente para a pena do divórcio, como se dá com dois réus condenados à
mesma pena de morte, embora tenha um pecado mais gravemente que outro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O repúdio não era permitido senão para evitar o
homicídio. E como esse perigo mais corria o homem que a mulher, por isso ao marido, pela lei do
repúdio, se lhe permitia deixar a mulher, e não ao inverso.

RESPOSTA À SEGUNDA E À TERCEIRA. ─ Essas objeções procedem enquanto, relativamente ao bem da
prole, maior causa de divórcio é o adultério da esposa que o do marido. Mas daí não se segue que não
sejam julgados com direito a coisas iguais, como do sobredito se colhe.

RESPOSTA À QUARTA. - Embora o homem seja a cabeça da mulher, como governando-a, não fica por
isso constituído em juiz dela; e nem inversamente. Portanto, no processo judicial não tem maior poder o
marido sobre a mulher, que esta sobre aquele.

RESPOSTA À QUINTA. ─ O pecado de adultério implica a mesma gravidade que a fornicação simples
agravada pelo fato de lesar o matrimônio. Considerado pois o que há de comum entre o adultério e a
fornicação, o pecado do homem está para o da mulher como o excedente para o excedido; porque a
mulher, sendo mais rica em humores, é mais propensa à concupiscência; ao passo que no varão há
maior ardência, excitante da concupiscência. Contudo, absolutamente falando e todas as circunstâncias
iguais, o homem, na fornicação simples, peca mais gravemente que a mulher, porque tem mais
desenvolvido o bem da razão, que prevalece sobre os movimentos das paixões do corpo. Quanto à
ofensa porém ao matrimônio, que o adultério acrescenta à fornicação simples e que causa o divórcio,
mais gravemente peca a mulher que o homem, como do sobre dito se colhe. E como isto é mais grave
que a simples fornicação, por isso, simplesmente falando, e em igualdade de condições, mais grave é o
pecado da adúltera que o do adúltero.

RESPOSTA À SEXTA. ─ Embora o governo que o marido tem sobre a mulher, seja uma circunstância
agravante, contudo, a circunstância da lesão do matrimônio, que muda a espécie do pecado, torna-o
por isso mais grave; pois essa lesão fá-lo transformar-se numa espécie de injustiça, porque introduz uma
prole espúria, furtivamente.

## Art. 5 — Se depois do divórcio o marido pode casar com outra.
O quinto procede-se assim. ─ Parece que depois do divórcio o marido pode casar com outra.

1. Pois, ninguém, está obrigado à continência perpétua. Ora, o marido está obrigado, em certo caso a
separar perpetuamente de si a esposa adúltera, como do sobre dito se colhe. Logo, parece que ao
menos em tal caso pode casar com outra.

2. Demais. ─ Ao pecador não se lhe deve dar mais ocasião de pecar. Ora, o cônjuge separado por culpa
de fornicação, se não lhe for lícito buscar outra união, dá-se-lhe maior ocasião de pecado; pois não é
provável que quem não foi continente no matrimônio, possa vir a sê-lo depois. Logo, parece que se lhe
deve permitir novo casamento.

3. Demais. ─ A mulher não está obrigada senão a cumprir o dever conjugal para com o marido e a
coabitar com ele. Ora, de ambas essas obrigações fica desonerada pelo divórcio. Logo, solta fica da lei
do marido. Portanto, pode casar com outro. E o mesmo se diga do marido.

4. Demais. ─ O Evangelho diz: Todo aquele que repudiar sua mulher, se não é por causa de fornicação, e
casar com outra, comete adultério. Logo, se por causa de fornicação, repudiar a mulher e casar com
outra, não adultera. Portanto, terá contraído verdadeiro matrimônio.
Mas, em contrário. ─ O Apóstolo diz: mando não eu, senão o Senhor, que a mulher se não separe do
marido; e se ela se separar, que fique sem casar.

2. Demais. ─ Ninguém pode tirar qualquer vantagem do pecado. Ora tira-la-ia a adúltera a que fosse
lícito convolar a núpcias mais desejadas; e daria isso ocasião de adultério aos desejosos de contrair novo
matrimônio. Logo, não é lícito fazer contração de novo casamento, nem ao homem nem à mulher.

SOLUÇÃO. ─ Nada de sobreveniente ao matrimônio pode ser causa de sua dissolução. Logo, o adultério
não pode anular um casamento verdadeiramente existente. Pois, como diz Agostinho, o vinculo conjugal
subsiste entre ambos por toda a vida, nem pode ser roto pela separação ou pela união com outra
pessoa. Portanto, enquanto vive um não pode o outro passar a segundas núpcias.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora ninguém esteja, absolutamente falando,
obrigado à continência, pode um porém o estar por acidente. Assim o estará o marido cuja mulher sofra
de doença incurável tal, que impida a cópula carnal. E o mesmo se dará se praticar incorrigivelmente a
fornicação, que é uma doença espiritual.

RESPOSTA À SEGUNDA. ─ Essa confusão mesma resultante do divórcio, deve coibí-la do pecado. E se
não na puder coibir, menos mal será pecar ela só, que lhe tornar cúmplice do pecado o marido.

RESPOSTA À TERCEIRA. ─ Embora a mulher, depois do divórcio, não esteja obrigada a cumprir o dever
conjugal para com o marido adúltero e a coabitar com ele contudo ainda subsiste o vínculo matrimonial
que a obrigava. Portanto não pode contrair outro casamento, durante a vida do marido. Pode porém,
contra a vontade dele, fazer voto de continência; salvo se a Igreja verificar que foi enganada por falsas
testemunhas, quando sentenciou o divórcio. Porque em tal caso, mesmo depois de ter emitido o voto
de profissão, seria restituída ao marido e estaria obrigada ao dever conjugal, mas o marido não no
poderia exigir.

RESPOSTA À QUARTA. ─ Essa exceção, fundada nas palavras do Senhor, se refere ao repúdio da esposa.
Por onde, a objeção procede de um mau entendimento do texto.

## Art. 6 — Se depois do divórcio marido e mulher podem reconciliar-se.
O sexto discute-se assim. ─ Parece que depois do divórcio marido e mulher não podem reconciliar –se.

1. Pois, é um princípio de direito: O que foi uma vez bem estabelecido não deve sofrer nenhuma
alteração. Ora, por determinação da Igreja foi estabelecido que devem separar-se. Logo, não podem
mais reconciliar-se.

2. Demais. ─ Se pudesse haver reconciliação, parece que depois de a mulher ter feito penitência o
marido estaria obrigado a recebê-la. Ora, não o está, porque também a mulher não pode entrar em
juízo com a exceção da sua penitência, contra o marido que a acusa de fornicação. Logo de nenhum
modo pode fazer-se a reconciliação.

3. Demais. ─ Se pudesse haver reconciliação, parece que a esposa adúltera estaria obrigada a voltar a
viver com o marido que lhe propõe a reconciliação. Ora, não o esta, porque já foram separados por juízo
da Igreja. Logo, etc.

4. Demais. ─ Se fosse lícita a reconciliação com a esposa adúltera, sobretudo devia fazer-se no caso em
que, depois do divórcio, o marido veio a cometer adultério. Ora, em tal caso a mulher não pode obrigá-
lo à reconciliação, por ter sido com justiça sentenciado o divórcio. Logo, de nenhum modo podem
reconciliar-se.

5. Demais. ─ Se o marido adúltero repudiar ocultamente a mulher acusada de adultério pelo juízo da
Igreja, parece que não houve justiça no julgamento do divórcio. Contudo, o marido não está obrigado a
se reconciliar com a esposa, porque esta não pode provar em juízo o adultério do marido. Logo e com
maior razão, quando houve justiça na decretação do divórcio, pode fazer se a reconciliação.
Mas, em contrário, O Apóstolo: Se ela se separar, que fique sem casar ou que faça paz com seu marido.

2. Demais. ─ O marido pode não a demitir, depois da fornicação. Logo e pela mesma razão, pode
reconciliar-se com ela depois do divórcio.

SOLUÇÃO. ─ Se a mulher, depois do divórcio, tendo feito penitência vier a emendar-se, pode o marido
reconciliar-se com ela. Se porém perseverar incorrigivelmente no pecado, não deve retomá-la, pela
mesma razão por que não lhe era lícito retê-la se não queria desistir do pecado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A sentença da Igreja que impôs o divórcio não obrigou à
separação, mas apenas a permitiu. Por onde, sem retratação da sentença precedente pode fazer-se ou
seguir-se a reconciliação.

RESPOSTA À SEGUNDA. ─ A penitência da mulher deve induzir o marido a não acusá-la nem demiti-la de
si, por causa de fornicação; não pode contudo ser obrigado a tal, nem pode a esposa, pela penitência
feita, repelir-lhe a acusação. Porque cessada a culpa, tanto quanto ao ato como quanto à mácula, ainda
algo permanece do reato; e cessado o reato em relação a Deus, ainda permanece relativamente à pena
a ser aplicada pelo juízo humano, porque o homem não vê, como Deus, o coração.

RESPOSTA À TERCEIRA. ─ O que é feito para favorecer alguém não lhe pode redundar em prejuízo. Por
onde, se o divórcio foi aplicado a favor do marido, não lhe tira o direito de pedir à mulher o
cumprimento do dever conjugal e de propor-lhe a reconciliação. Portanto, está ela obrigada a cumprir
para com ele esse dever e com ele reconciliar-se, se lhe for a reconciliação proposta; salvo se, com sua
licença, fez ela voto de continência.

RESPOSTA À QUARTA. ─ Por causa do adultério, que o marido inocente, antes do divórcio, veio a
cometer depois dele, não fica obrigado, em vigor de direito, a retomar a esposa já adúltera antes do
divórcio. Contudo, a equidade do direito pede que o juiz, por dever seu, advirta-o a fim de que não
ponha a sua alma em risco e evite escandalizar os outros. Todavia não tem a esposa o direito de pedir a
reconciliação.

RESPOSTA À QUINTA. ─ O adultério oculto do marido não tira à esposa adúltera o direito de repelir por
uma exceção a acusação do marido, embora não no possa provar. Portanto peca o marido requerendo
divórcio; e se depois da sentença que o concedeu, a mulher lhe pedir o cumprimento do dever conjugal
ou lhe propuser a reconciliação, esta obrigado a ambas as coisas.