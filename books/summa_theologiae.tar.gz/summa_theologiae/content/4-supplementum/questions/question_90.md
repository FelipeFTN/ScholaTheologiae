# Questão 90: Da forma sob a qual vira o juiz julgar.
Em seguida devemos tratar da forma sob a qual virá o juiz julgar.
E nesta questão discutem-se três artigos:

## Art. 1 — Se Cristo virá julgar sob sua forma humana.
O primeiro discute-se assim. ─ Parece que Cristo não virá julgar sob sua forma humana.

1. Pois, o juízo requer a autoridade em quem julga. Ora, Cristo tem autoridade sobre vivos e mortos
enquanto Deus, pois, nessa qualidade é que é o Senhor e Criador de tudo. Logo, virá julgar sob forma
divina.

2. Demais. ─ O juiz há de ter um poder irresistível, donde o dizer a Escritura: Não pretendas ser juiz se
não tem valor para romperes com esforço por entre as iniquidades. Ora, poder invencível é o de Cristo
enquanto Deus. Logo, julgará como Deus.

3. Demais. ─ O Evangelho diz: O Pai a ninguém julga, mas todo o juízo deu ao Filho, a fim de que todos
honrem ao Filho bem como honram ao Pai. Ora, ao Filho não é devida, na sua natureza humana, a
mesma honra que ao Pai. Logo, não virá julgar sob forma humana.

4. Demais. ─ A Escritura diz: Eu estava atento ao que via, até que foram postos uns tronos e o antigo dos
dias se assentou. Ora, os tronos designam o poder judiciário; e a antiguidade se atribui a Deus em razão
da sua eternidade, como diz Dionísio. Logo, julgar convém ao Filho, como eterno. Portanto, não como
homem.

5. Demais. ─ Agostinho, citado pelo Mestre diz: Pelo Verbo de Deus se opera a ressurreição das almas;
pelo Verbo feito na carne Filho do homem se opera a ressurreição dos corpos. Ora, o juízo final
concernirá mais a alma que o corpo. Logo, é antes como Deus que como homem, que Cristo virá julgar.
Mas, em contrário. ─ Diz o Evangelho: Deu-lhe o poder de julgar, por ser Filho do homem.

2. Demais. ─ Diz a Escritura: A tua causa tem sido julgada como a de um ímpio; por Pilatos, diz a Glosa.
Por isso, ganharás a causa e a sentença; para julgares com justiça, diz a Glosa. Ora, Cristo foi, como
homem, julgado por Pilatos. Logo, como homem virá julgar.

3. Demais. ─ Julgar pertence a quem pertence legislar. Ora, Cristo nos deu a lei do Evangelho,
revestindo-se da natureza humana. Logo, como tal é que virá julgar.

SOLUÇÃO. ─ Todo juízo supõe o domínio do juiz sobre aquele que julga, donde o dizer o Apóstolo: Quem
és tu que julgas o servo alheio? Por onde a Cristo compete julgar, pelo domínio que tem sobre os
homens, que serão o objeto principal do juízo final. Ora, Cristo é nosso Senhor, não só em razão da
criação, pois o Senhor é Deus, ele nos fez e não nós outros a nós, como diz a Escritura; mas também em
razão da redenção, que operou pela sua natureza humana, e por isso diz o Apóstolo ─ por isso é que
morreu Cristo e ressuscitou para ser Senhor tanto de mortos como de vivos. Ora, para alcançarmos o
prêmio da vida eterna não nos bastariam os bens da criação, sem o acréscimo do benefício da redenção,
por causa dos obstáculos provenientes à natureza criada pelo pecado dos nossos primeiros pais. Por
onde, como pelo juízo final uns serão admitidos no reino celeste e outros excluídos dele, conveniente
será que o próprio, Cristo, na sua natureza humana, por benefício de cuja redenção o homem é
admitido no reino dos céus, presida a esse juízo. E, tal o diz a Escritura: Ele é o que por Deus foi
constituído juiz de vivos e mortos. Ora, pela redenção do gênero humano não só restaurou a natureza
humana mas também em universal todas as criaturas, na medida em que todas se aperfeiçoam, com a
restauração do homem, segundo aquilo do Apóstolo: Pacificando, pelo sangue da sua cruz tanto o que
está na terra como o que está no céu. Por onde, Cristo, pela sua, paixão, mereceu exercer o domínio e o
poder judiciário, não só sobre o homem, como sobre todas as criaturas, conforme aquilo do Evangelho:
Tem-se-me dado todo o poder no céu e na terra.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Cristo, na sua natureza divina, tem a autoridade de
senhor sobre todas as criaturas, por direito de criação. Mas, pela sua natureza humana tem a
autoridade do domínio merecida pela sua paixão, autoridade essa como secundária e adquirida. Ao
passo que a primeira é natural e eterna.

RESPOSTA À SEGUNDA. ─ Embora Cristo enquanto homem não tenha, por si mesmo, um poder
irresistível, por virtude natural da espécie humana, contudo por dom da divindade tem, mesmo na sua
natureza humana, um poder irresistível, pelo qual todas as cousas sujeitou debaixo dos pés dele. Por
isso julgará, certo, na sua natureza humana, mas por virtude da divindade.

RESPOSTA À TERCEIRA. ─ Cristo não seria capaz de obrar a redenção do gênero humano, se fosse um
puro homem. Por onde, o fato mesmo de ter podido redimir, na sua natureza humana, o gênero
humano, e adquirido desse modo o poder judiciário, mostra manifestamente que é também Deus e
assim merece ser honrado por igual com o Pai, não como homem, mas como Deus.

RESPOSTA À QUARTA. ─ Nessa visão de Daniel está manifestamente expressa toda a ordem do poder
judiciário. O qual, como na sua origem primária, reside no próprio Deus, e especialmente no Padre,
fonte de toda a divindade. Por isso no texto de Daniel diz, primeiro que o Antigo dos dias se assentou.
Mas, do Padre, o poder judiciário foi transmitido ao Filho, não só abeterno segundo a natureza divina,
mas também no tempo segundo a natureza humana, pela qual mereceu esse poder. Por isso, na visão
referida o profeta acrescenta: E eis que vi um como o Filho do homem, que vinha com as nuvens do céu,
e que chegou até o Antigo dos dias e ele lhe deu o poder, e a honra e o reino.

RESPOSTA À QUINTA. ─ Agostinho se exprime num sentido analógico, reduzindo os efeitos que Cristo
obrou em a natureza humana à causas de certo modo semelhantes. E como pela nossa alma somos à
imagem e semelhança de Deus, mas pela carne somos da mesma espécie que Cristo humanado, por isso
o que Deus operou em nossas almas Agostinho o atribui à divindade; e o que obrou ou há de fazê-lo na
carne, lhe atribui à carne. Embora a carne de Cristo, enquanto órgão da divindade, como diz
Damasceno, também tenha ação sobre as nossas almas, segundo aquilo do Apóstolo: O sangue de Cristo
limpará a nossa consciência das obras da morte. E assim também o verbo feito carne é causa da
ressurreição das almas. Por isso, também pela sua natureza humana a Cristo cabe ser juiz não só dos
bens do corpo mas também dos da alma.

## Art. 2 — Se Cristo no juízo aparecerá sob a forma da humanidade gloriosa.
O segundo discute-se assim. ─ Parece que Cristo no juízo não aparecerá sob a forma da humanidade
gloriosa.

1. ─ Pois, àquilo do Evangelho ─ Eles verão aquele a quem traspassaram, diz a Glosa: Porque virá com a
mesma carne com que foi crucificado. Ora, foi crucificado numa forma abatida. Logo, com essa mesma
forma aparecerá e não com forma gloriosa.

2. Demais. ─ O Evangelho diz, que aparecerá o sinal do Filho do homem no céu, i. é, o sinal da cruz. E
Crisóstomo diz: Cristo virá ao juízo com sinais ostensivos não só das feridas cicatrizadas mas também da
sua morte ignominiosíssima. Logo, parece que não aparecerá em forma gloriosa.

3. Demais. ─ Cristo aparecerá no juízo em forma que possa ser visto por todos. Ora, sob a forma da sua
humanidade gloriosa Cristo não poderá ser visto por todos, bons e maus; porque os olhos não
glorificados não são proporcionados à vista da claridade de um corpo glorioso. Logo, não aparecerá sob
forma gloriosa.

4. Demais. ─ O prometido como prêmio aos justos não será concedido aos iníquos. Ora, contemplar a
glória da humanidade e o prêmio prometido aos justos pelo Evangelho, quando diz: Ele entrará e sairá e
achará pastagens, i. é, alimento na divindade e na humanidade, como o expõe Agostinho. E outro lugar
da Escritura diz: Verão o rei no seu esplendor. Logo, no juízo não aparecerá a todos sob forma gloriosa.
5: Demais. ─ Cristo julgará naquela forma com que foi julgado. Por isso, aquilo do Evangelho ─ Dá o Filho
vida àqueles que quer, diz a a Glosa: Na forma em que foi injustamente julgado, nessa mesma julgará,
de modo a poder ser visto dos ímpios. Ora, foi julgado numa forma de humilhado. Logo, nessa mesma
comparecerá ao juízo.
Mas, em contrário, o Evangelho: Então verão o Filho do homem, que virá sobre uma nuvem com grande
poder e majestade. Ora, a majestade e o poder são atributos da glória. Logo, aparecerá em forma
gloriosa.

2. Demais. ─ Quem julga deve estar numa posição superior a quem é julgado. Ora, os eleitos, que serão
julgados por Cristo, terão corpos gloriosos. Logo e com maior razão, o juiz aparecerá em forma gloriosa.

3. Demais. ─ Assim como ser julgado implica uma situação de humilhação, assim julgar supõe a
autoridade e a glória. Ora, no seu primeiro advento, quando Cristo para ser julgado, apareceu em figura
de humilhado. Logo, no segundo advento, quando vier julgar, aparecerá em forma gloriosa.

SOLUÇÃO. ─ Cristo é chamado pelo Apóstolo o mediador entre Deus e os homens, por ter satisfeito por
eles e por eles interceder perante o Pai; e comunica aos homens o que é próprio do Pai, segundo ele
próprio o disse: Eu lhes dei a glória que tu me havias dado. E esse título de mediador lhe cabe pelos dois
modos com que comunica com ambos os extremos. Pois, enquanto comunica com os homens,
desempenha-lhes o papel perante o Pai; e enquanto comunica com o Pai distribui-lhe os dons aos
homens. Ora, como no primeiro advento teve por fim satisfazer por nós perante o Pai, por isso revestiu-
se da forma da nossa miséria. E como no segundo advento terá por alvo executar sobre os homens a
justiça do Pai, deverá manifestar a sua glória que lhe cabe em comum com o Pai. Portanto, aparecerá
em forma gloriosa.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Aparecerá Cristo com a mesma carne, mas não no
mesmo estado.

RESPOSTA À SEGUNDA. ─ O sinal da cruz aparecerá no juízo, para mostra da humilhação passada, que
nele não mais se verá. Para assim aparecer em toda a sua justiça a condenação dos que desprezaram
tão grande misericórdia e a dos que sobretudo perseguiram a Cristo injustamente. Quanto às cicatrizes
que lhe deixará ver o corpo não implicarão nenhum estado de miséria, mas serão os sinais do soberano
poder com que Cristo, pela paixão e pelo abatimento, triunfou de seus inimigos. Manifestará também
uma ignominiosíssima morte, não fazendo-a aparecer sensivelmente aos olhares, como se então a
estivesse padecendo, mas despertando nos homens a lembrança da sua morte passada pelos sinais que
fará aparecerem da sua pretérita paixão.

RESPOSTA À TERCEIRA. ─ O corpo glorioso tem o poder de deixar-se ver ou não a olhos não glorificados,
como se colhe do que foi dito. Por onde, sob forma gloriosa Cristo poderá ser visto de todos.

RESPOSTA À QUARTA. ─ Assim como a glória de um amigo nos causa prazer, assim a glória e o poder de
quem odiamos nos faz imensamente sofrer. Por onde, assim como a contemplação da gloriosa
humanidade de Cristo será um prêmio para os justos, assim há de ser um suplício para os inimigos de
Cristo. Por isso a Escritura diz: Vejam e sejam contundidos os que tem inveja do teu povo; e devore o
fogo, i. é, da inveja, aos teus inimigos.

RESPOSTA À QUINTA. ─ Forma, no lugar citado, é tomada no sentido de natureza humana, sob cuja
forma foi julgado e também virá julgar; não porém pela qualidade da natureza, que não será a mesma ─
a de humilhada ─ com que foi julgado.

## Art. 3 — Se a divindade poderá ser contemplada, sem alegria, pelos maus.
O terceiro discute-se assim. ─ Parece que a divindade poderá ser contemplada, sem alegria, pelos
maus.

1. ─ Pois, sabemos que os ímpios hão de mui manifestamente conhecer que Cristo é Deus. Logo, ver-lhe-
ão a divindade. E contudo não hão de comprazer-se com a visão de Cristo. Logo, Cristo poderá ser visto,
sem alegria, pelos maus.

2. Demais. ─ A vontade perversa dos ímpios não se opõe mais à humanidade que à divindade de Cristo.
Ora, o verem a glória da humanidade de Cristo lhes redunda em pena, como se disse. Logo e com maior
razão, a vista da sua divindade lhes causará, antes, tristeza que alegria.

3. Demais. ─ Um fato afetivo não é necessariamente a consequência de um fato intelectual; donde o
dizer Agostinho: Ao ato do intelecto, precedente, pode-se-lhe seguir um ajecto tardio ou não se lhe
seguir nenhum. Ora, a visão é própria ao intelecto, ao passo que a alegria, ao afeto. Logo, é possível ver-
se a divindade sem sentir com isso nenhuma alegria.

4. Demais. ─ Tudo o que é recebido o é ao modo do recipiente, e não ao do recebido. Ora, tudo o que é
visto de certo modo é recebido pelo vidente. Logo, embora a divindade seja, em si mesma, a fonte de
toda a alegria, contudo, vista pelos que estão absorvidos pela tristeza, não deleitará, mas ao contrário,
aumentará a tristeza.

5. Demais. ─ Assim está o sentido para o sensível como o intelecto para o inteligível. Ora, com todos os
sentidos se dá o que se passa com o do gosto que, quando não que agrada o pão, que lhe constitui uma
pena quando esse sentido está mal disposto, como diz Agostinho. Logo, como os condenados tem o
intelecto mal disposto, parece que a visão da luz incriada é-lhes antes causa de pena que de alegria.
Mas, em contrário, o Evangelho: A vida eterna consiste em que conheçam por um só verdadeiro Deus a
ti; por onde é claro que a essência da felicidade consiste na visão de Deus. Ora, da essência da beatitude
é a alegria. Logo, a divindade não pode ser vista sem advir dela a alegria.

2. Demais. ─ A essência mesma da divindade é a essência da verdade. Ora, a cada um é agradável
conhecer a verdade, pois, todos os homens por natureza desejam saber, como diz Aristóteles. Logo, a
divindade não pode ser vista sem causar alegria.

3. Demais. ─ A visão que não for sempre uma causa de alegria há de às vezes ser causa de tristeza. Ora, a
visão de Deus não pode nunca ser causa de tristeza, porque o prazer de inteligir não é mesclado de
nenhuma tristeza, como diz o Filósofo. Logo, como a divindade não pode ser contemplada senão pelo
intelecto, parece que ver a Deus não é possível, sem alegria.

SOLUÇÃO. ─ Em todo objeto apetível ou deleitável duas cousas devemos considerar: o objeto apetecido,
ou que causa prazer; e a razão da apetibilidade ou do prazer. Ora, assim como, segundo Boécio, o que é
pode ter alguma cousa mais do que aquilo que é, mas o seu ser mesmo não é susceptível de nenhuma
mescla, assim, um objeto apetível ou deleitável é susceptível de mescla com o que pode fazê-lo perder
essas duas qualidades, mas a razão mesma que o torna deleitável não comporta nem pode comportar
nenhuma mescla pela qual deixe de ser deleitável ou apetível. As cousas porém deleitáveis por uma
bondade participada, razão pela qual são deleitáveis e apetíveis, podem, quando apreendidas, não
deleitar; mas o que por essência é bom, é impossível que não cause prazer quando essa essência é
percebida. Ora, Deus sendo em si mesmo a bondade essencial, a sua divindade não pode ser vista sem
causar alegria.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Os ímpios conhecerão manifestamente que Cristo é Deus,
não por lhe verem a divindade, mas pelos sinais claríssimos dela.

RESPOSTA À SEGUNDA. ─ A divindade, essencialmente considerada, ninguém pode odiá-la, como
ninguém pode odiar a bondade por essência. Mas dizemos que alguns odeiam certos atos da divindade,
quando fazem ou ordenam o que contraria à vontade. Por onde, a ninguém pode deixar de ser
deleitável a visão da divindade.

RESPOSTA À TERCEIRA. ─ As palavras de Agostinho devem ser aplicadas quando o objeto de uma
apreensão precedente do intelecto é o bem por participação e não por essência, como o são todas as
criaturas; podendo por isso conter esse objeto algo que não mova o afeto. Semelhantemente, neste
mundo conhecemos a Deus pelos seus efeitos, e o nosso intelecto não lhe atinge a essência mesma da
bondade.
Por onde, não é forçoso que o afeto resulte da apreensão antecedente do intelecto, como o seria se
apreendesse a essência divina em si mesma, que é a própria bondade.

RESPOSTA À QUARTA. ─ A palavra tristeza não designa uma disposição, mas antes, uma paixão. Ora,
toda paixão fica aniquilada por uma causa superveniente mais forte, longe de aniquilar a esta. Assim, a
tristeza dos condenados desapareceria se vissem a Deus em essência.

RESPOSTA À QUINTA. ─ A indisposição de um órgão faz desaparecer a proporção natural entre ele e o
objeto que naturalmente lhe causaria prazer, que, por isso, fica impedido. Mas a indisposição dos
condenados não os priva da proporção com que se ordenavam à contemplação da divina bondade, pois,
não deixarão nunca de ser a imagem do Criador. Não há portanto símil.