# Questão 14: Da qualidade da satisfação.
Em seguida devemos tratar da qualidade da satisfação.
E nesta questão discutem-se cinco artigos:

## Art. 1 — Se podemos satisfazer por um pecado, sem satisfazermos por outro.
O primeiro discute-se assim. ─ Parece que podemos satisfazer por um pecado, sem satisfazermos por
outro.

1. ─ Pois, de coisas sem conexão mútua podemos eliminar uma sem eliminarmos a outra. Ora, os
pecados não têm conexão mútua; do contrário quem tivesse um teria todos. Logo, podemos expiar um
sem dar satisfação por outro.

2. Demais. ─ Deus é mais misericordioso que o homem. Ora, nós recebemos a solução de uma dívida
com exclusão de outra. Logo, também Deus receberá satisfação de um pecado sem a receber por outro.

3. Demais. ─ A satisfação, como diz a letra do Mestre, consiste em eliminar as causas dos pecados, sem
lhes permitir a entrada às suges tões. Ora, isso pode se dar em relação a um pecado e não a outro; como
se alguém referisse a luxúria e desse largas à avareza. Logo, podemos satisfazer por um pecado sem
satisfazermos por outro.
Mas, em contrário. ─ Lemos na Escritura, que o jejum de aqueles que jejuarem para prosseguir
demandas e contendas, não era aceito de Deus, embora o jejum seja obra satisfatória. Ora, não
podemos dar satisfação senão por uma obra aceita de Deus. Logo, não pode quem tem algum pecado
satisfazer a Deus.

2. Demais. ─ A satisfação é um remédio curativo dos pecados passados e preservativo dos futuros, como
se disse. Ora, os pecados não podem curar-se sem a graça. Logo, como qualquer pecado nos priva da
graça, não podemos satisfazer por um pecado sem ao mesmo tempo satisfazermos pelos outros.

SOLUÇÃO. ─ Certos, como o Mestre das Sentenças literalmente o diz, afirmaram que podemos satisfazer
por um pecado sem satisfazermos pelos outros. ─ Mas isto não pode ser. Pois, como a satisfação deve
eliminar a ofensa precedente, há de o modo da satisfação ser tal que possa delir a ofensa. Ora, apagar a
ofensa é reatar a amizade. Por onde, havendo algum obstáculo, impediente do reatamento da amizade,
também não poderá haver satisfação, mesmo entre os homens. Ora, como qualquer pecado impede a
amizade da caridade, que é a existente entre o homem e Deus, é impossível satisfazermos por um
pecado sem o fazermos pelos outros; assim como não satisfaria ao seu semelhante quem se lhes
prostrasse diante, por um tapa que lhe deu, aplicando-lhe simultaneamente outro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Como os pecados não têm entre si conexão por um laço
comum, podemos cometer um sem cometer outro. Mas é por uma única razão que todos são
perdoados. Por onde é conexa a remissão de pecados diversos. Portanto, não podemos satisfazer por
um sem satisfazermos também pelos outros.

RESPOSTA À SEGUNDA. ─ Na obrigação do débito só há desigualdade oposta à justiça, por ter um a
coisa de outrem. Por isso a restituição não exige senão que se restaure em igualdade. E isso pode se dar
em relação a um débito sem se dar em relação a outro. ─ Mas onde há ofensa aí há também
desigualdade, não somente oposta à justiça, mas ainda à amizade. Por onde, para ser a ofensa apagada
pela satisfação, não somente é necessária a restituição da igualdade da justiça, pela compensação de
uma pena igual, mas também que seja restituída a igualdade de amizade. E isso não pode fazer-se se
algum obstáculo impede a amizade.

RESPOSTA À TERCEIRA. ─ Um pecado com o seu peso arrasta outro, como diz Gregório. Logo, quem
retém um pecado não elimina totalmente as causas de outro.

## Art. 2 — Se quem primeiro teve contrição de todos os pecados, e depois veio a pecar, pode, estando assim sem caridade, satisfazer pelos outros pecados, que lhe foram perdoados.
O segundo discute-se assim. ─ Parece que quem primeiro teve contrição de todos os pecados, e depois
veio a pecar, pode, estando assim sem caridade, satisfazer pelos outros pecados que lhe foram
perdoados.

1. ─ Pois, disse Daniel a Nabucodonosor: Rime os teus pecados com esmola. Ora, ainda era ele pecador,
como o demonstra a pena subseqüente. Logo, pode satisfazer quem está em pecado.

2. Demais. ─ Diz a Escritura: Não sabe o homem se é digno de amor ou de ódio. Se, pois, não pode
satisfazer senão quem tem a caridade, ninguém teria a certeza de haver satisfeito. O que não é
admissível.

3. Demais. ─ A nossa intenção inicial informa totalmente o ato que praticamos. Ora, o penitente, ao
começar a penitência, estava em caridade. Logo, toda a satisfação subseqüente tirou a sua eficácia
dessa caridade informadora da intenção.

4. Demais. ─ A satisfação consiste numa certa igualdade entre a pena e a culpa. Ora, essa igualdade
pode existir mesmo em quem não possui a caridade. Logo, etc.
Mas, em contrário. Diz a Escritura: A caridade cobre todos os delitos. Ora, a virtude da satisfação é
apagar os delitos. Logo, não tem a sua virtude sem a caridade.

2. Demais. ─ A obra principal na satisfação é a esmola. Ora, a esmola feita sem caridade não vale,
conforme ao dito do Apóstolo: Se eu distribuir todos os meus bens em o sustento dos pobres, etc. Logo,
também não há nenhuma satisfação.

SOLUÇÃO. ─ Certos disseram, que quem teve todos os seus pecados perdoados pela contrição
precedente e veio depois a cair em pecado, antes de cumprir a satisfação, e está a cumprir em estado de
pecado, a esse lhe vale a satisfação, de modo que morrendo no seu pecado, não será ele punido no
inferno. ─ Mas isto não pode ser. Porque a satisfação exige, além do reatamento da amizade, a
restauração da igualdade da justiça, cujo contrário destrói a amizade, como diz o Filósofo. Ora,
relativamente a Deus a igualdade da satisfação não se funda na equivalência mas antes, na aceitação
dele. Por isso é necessário, mesmo se a ofensa já foi perdoada pela contrição precedente, que as obras
satisfatórias sejam aceitas de Deus. E isso lhes faculta a caridade. Portanto, feitas sem caridade as obras
não são satisfatórias.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O conselho de Daniel supõe que o rei cessasse de pecar e
fizesse penitência, e assim satisfizesse pelas suas esmolas.

RESPOSTA À SEGUNDA. ─ Assim como não sabemos com certeza se tivermos a caridade ao satisfazer e a
temos, assim também com certeza não sabemos se plenamente satisfizemos. Donde o dizer a Escritura:
Não estejas sem temor da ofensa que te foi remitida. Não é porém necessário, que por causa desse
temor, reiteremos a satisfação já dada, se não temos consciência do pecado mortal. Embora, pois, não
expiemos a pena com essa satisfação, contudo não incorremos no reato de omissão de uma satisfação,
que deixasse de ser devida; assim como quem se achega à Eucaristia sem consciência de pecado mortal
a que estivesse preso, não incorre no reato de a receber indignamente.

RESPOSTA À TERCEIRA. ─ Essa intenção foi interrompida pelo pecado subseqüente. Por isso não influi
em nada nas obras feitas depois do pecado.

RESPOSTA À QUARTA. ─ Não pode haver igualdade suficiente nem quanto à aceitação divina, nem por
equivalência. Por isso a objeção não colhe.

## Art. 3 — Se depois de termos a caridade começa a valer a satisfação precedente.
O terceiro discute-se assim. ─ Parece que depois de termos a caridade começa a valer a satisfação
precedente.

1. ─ Pois, aquilo da Escritura ─ Se teu irmão, achando-se pobre, etc. ─ diz a Glosa: Os frutos da boa
conversação devem ser contados desde o tempo que se pecou. Ora, não seriam contados se não
recebessem alguma eficácia da caridade subseqüente. Logo, começam a valer depois da caridade
recuperada.

2. Demais. ─ Assim como a eficácia da satisfação fica impedida pelo pecado, assim a do batismo, pela
dissimulação. Ora, o batismo começa a valer quando desaparece a dissimulação. Logo, a satisfação,
quando desaparece o pecado.

3. Demais. ─ A quem tivessem sido impostos muitos jejuns pelos pecados cometidos e de os terem
cumprido depois de caído em pecado, a esse, quando de novo confessar, não se lhe reiteram esses
jejuns. Ora, eles se lhe reiterariam si por eles não fosse cumprida a satisfação. Logo, da penitência
subseqüente as obras precedentes recebem a sua eficácia satisfatória.
Mas, em contrário. ─ As obras feitas sem caridade não foram satisfatórias, por serem mortas. Ora, a
penitência não as vivifica. Logo, nem começam por ela a ser satisfatórias.

2. Demais. ─ A caridade não informa senão um ato que dela de certo modo procedeu. Ora, as obras não
podem ser aceitas de Deus, e portanto não podem ser satisfatórias, sem serem informadas pela
caridade. Logo, como as obras feitas sem caridade não procedem dela de nenhum modo, nem jamais
poderão proceder, de maneira nenhuma podem considerar-se como satisfatórias.

SOLUÇÃO. ─ Alguns disseram que as obras feitas com caridade, e chamadas vivas, são meritórias para a
vida eterna e satisfatórias para o perdão da pena. E que a caridade subseqüente vivifica as obras feitas
sem ela, para o efeito de serem satisfatórias, não porém para o de serem meritórias da vida eterna. ─
Mas isto não pode ser. Pois, ambos esses efeitos as obras feitas com caridade o produzem pelo mesmo
fundamento, a saber, o de serem gratas a Deus. Por onde, assim como a caridade adveniente não pode
tornar gratas as obras feitas sem caridade, para um efeito, assim também não o podem para o outro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Não se deve entender que os frutos sejam contados
desde o tempo em que se começou a estar em pecado, mas do em que se cessou de pecar isto é, desde
o tempo em que se esteve por último em pecado. ─ Ou significa o tempo em que, logo depois do
pecado, tivemos contrição e fizemos muitas obras boas, antes da confissão. ─ Ou significa que quanto
maior a contrição tanto mais diminui a pena; e quanto mais fizermos boas obras, estando em pecado,
mais nos dispomos à graça da contrição; sendo então provável que seremos devedores de uma pena
menor. Por isso o sacerdote deveria discretamente atentar em nos impor uma pena menor desde que
nos encontre bem dispostos.

RESPOSTA À SEGUNDA. ─ O batismo imprime caráter na alma; não porém a satisfação. Por isso a
caridade adveniente, que elimina a dissimulação e o pecado, faz o batismo produzir o seu efeito; mas
não o faz o mesmo com a satisfação. ─ Além disso, o batismo justifica pelo dom mesmo que lhe foi feito
(ex opere operato) que não procede do homem, mas de Deus. Por isso não se torna uma obra mortal,
do mesmo modo que a satisfação, obra do homem.

RESPOSTA À TERCEIRA. Há certas satisfações que influem determinados efeitos nos satisfacientes,
mesmo depois de acabado o ato da satisfação; assim, do jejum resta a debilitação do corpo; das esmolas
distribuídas, a diminuição do patrimônio; e assim por diante. E tais satisfações pelos pecados não é
preciso sejam reiteradas; porque, pelo delas remanescente, são recebidas de Deus como penitência.
Mas as satisfações, que não deixam após si nenhum efeito no satisfaciente, depois de o ato acabado,
essas hão de ser renovadas, como a oração e outras semelhantes. Ora, o ato interior, por desaparecer
totalmente, de nenhum modo pode ser vivificado, mas é necessário ser reiterado.

## Art. 4 — Se as obras feitas sem caridade merecem algum bem, ao menos temporal.
O quarto discute-se assim. ─ Parece que as obras feitas sem caridade merecem algum bem, ao menos
temporal.

1. ─ Pois, assim está a pena para o ato mau como o prêmio para o bom. Ora, nenhuma obra má fica
impune perante Deus, juiz justo. Portanto, por esse bem algo se merece.

2. Demais. ─ Recompensa não se dá senão ao mérito. Ora, as obras feitas sem caridade recebem
recompensa; assim, diz o Evangelho que os que fazem obras boas, por glória humana, recebem a sua
recompensa. Logo, essas obras foram meritórias de algum bem.

3. Demais. ─ Duas pessoas em estado de pecado, uma tendo feito muitas obras genéricas e
circunstancialmente boas, e outra nenhumas, não estão em situação igualmente próxima para
receberem bens de Deus; do contrário, não teriam nenhuma razão de fazer qualquer boa obra. Ora,
quem mais se aproxima de Deus mais lhe recebe os bens. Logo, quem fez quaisquer obras boas merece
algum bem de Deus.
Mas, em contrário, Agostinho diz: o pecador não é digno do pão que come. Logo, nada pode merecer de
Deus.

2. Demais. ─ Quem é nada pode merecer. Ora, o pecador, sem caridade como é, é nada enquanto ser
espiritual, na expressão do Apóstolo. Logo, nada pode merecer.

SOLUÇÃO. ─ Chama-se propriamente mérito a ação que torna justa uma retribuição a quem a praticou.
Ora, a justiça é susceptível de duplo sentido. Um próprio, aplicado ao direito estrito que tem alguém a
uma cousa. Outro, analógico quando significa apenas uma conveniência da parte de quem dá, pois,
podemos dar o que contudo não é recebido por outrem como lhe sendo devido. Por isso se chama a
justiça uma conveniência da divina bondade; e Anselmo diz que Deus é justo quando tem misericórdia
dos pecadores, porque isso lhe convém. Sendo assim, o mérito é susceptível de duplo sentido. Num,
significa o ato pelo qual o agente recebe alguma cousa como lhe sendo devida. E esse se chama o mérito
de condigno. Noutro é o ato pelo qual a dádiva é feita por conveniência do doador. E esse se chama
mérito de côngruo.
Ora, sendo o amor a razão de todas as dádivas gratuitas é impossível que quem carece da amizade se
torne objeto de tais dádivas. E portanto, como todos os bens temporais e eternos nos são dados pela
divina liberalidade, ninguém pode receber como lhe sendo devido nenhum dos referidos dons senão
pela caridade para com Deus. Por onde, as obras feitas sem caridade não são meritórias perante Deus
de nenhum bem eterno nem temporal, ex condigno. ─ Mas como é próprio da divina bondade
acrescentar uma perfeição a todo ser a esta disposto, por isso dizemos que alguém merece, por mérito
de côngruo, um bem por boas obras que fez sem caridade. E neste sentido, essas obras são susceptíveis
de um tríplice valor: para a consecução de bens temporais; para a disposição para a graça: e para gerar o
costume da prática de boas obras.
Esse mérito porém não merece propriamente o nome de mérito; donde devemos concluir que tais obras
não são meritórias de nenhum bem, do que dizer que o sejam.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Como diz o Filósofo, um filho, por mais que faça, não
pode dar em retorno do pai tanto quanto dele recebeu; por isso não pode nunca o pai tornar-se
devedor do filho. E muito menos podemos fazer de Deus o nosso devedor, por equivalência de obras.
Donde, nenhuma obra nossa pode merecer nada, seja qual for a sua bondade; mas o pode por força da
caridade, que torna comuns os bens dos amigos. Portanto, por boa que seja a obra feita sem caridade,
não faz, propriamente falando, com que Deus esteja obrigado a dar por ela nenhuma remuneração. A
obra má porém merece uma pena equivalente à gravidade da sua malícia; porque, da parte de Deus,
nenhumas obras más nos foram feitas como o foram as boas. Por onde, embora uma obra má mereça
uma pena ex condigno, contudo nenhuma obra boa feita sem caridade merece ex condigno prêmio.

RESPOSTA À SEGUNDA E TERCEIRA. ─ Essas objeções procedem relativamente ao mérito ex condigno.
Quanto às outras objeções, elas procedem relativamente ao mérito ex condigno.

## Art. 5 — Se as obras referidas valem para a mitigação das penas do inferno.
O quinto discute-se assim. ─ Parece que as obras referidas valem para a mitigação das penas do
inferno.

1. ─ Pois, segundo a quantidade da culpa tal será a quantidade da pena no inferno. Ora, as obras feitas
sem caridade não diminuem a quantidade do pecado. Logo, nem a pena do inferno.

2. Demais. ─ A pena infernal, embora de duração infinita, é contudo de intensidade finita. Ora, toda
quantidade finita desaparece, se lhe fazem subtrações de suas partes finitas. Se, pois, as obras feitas
sem caridade causassem alguma diminuição da pena devida aos pecados, resultaria que essas obras
podiam multiplicar-se a ponto de eliminar totalmente a pena do inferno. O que é falso.

3. Demais. ─ Os sufrágios da Igreja são mais eficazes que as obras feitas sem caridade. Ora, como diz
Agostinho, aos condenados ao inferno não aproveitam os sufrágios da Igreja. Logo, com muito maior
razão, as penas não se mitigam pelas obras feitas sem caridade.
Mas, em contrário diz o mesmo Agostinho, que as obras feitas sem caridade valem para a remissão
plena ou para se tornar mais tolerável a danação.

2. Demais. ─ Mais é fazer o bem que perdoar o mal. Ora, perdoar o mal sempre evita a pena, mesmo em
quem carece da caridade. Logo e com maior razão, fazer o bem.

SOLUÇÃO. ─ De dois modos podemos entender a diminuição da pena infernal. Por ser o condenado
liberado da pena já merecida. E então como ninguém é liberado da pena que não seja absolvido da
culpa ─ pois, os efeitos não diminuem nem desaparecem senão diminuindo ou eliminando a causa ─
pelas obras feitas sem caridade, por não poderem eliminar nem diminuir a culpa, a pena do inferno não
pode ser mitigada. ─ Ou, de outro modo, por impedir o mérito da pena. E então as referidas obras
diminuem a pena do inferno. Primeiro, porque evita o reato da omissão quem tais obras pratica.
Segundo, porque tais obras de certo modo dispõem ao bem fazendo com que, se pecamos, com menor
desprezo de Deus o façamos; ou ainda que nos livremos, por tais obras, de muitos pecados. ─ Quanto à
diminuição ou à dilação da pena temporal, essas obras a merecem, como diz Acab, do mesmo modo por
que merecem alcançar os bens temporais.
Certos porém dizem, que diminuem a pena do inferno, não por lhe tirar nada à substância, mas por
fortificar o autor delas para melhor as suportar. ─ Mas isto não pode ser. Pois, a fortificação não resulta
senão de extirpação da possibilidade. Ora, a possibilidade é proporcional à gravidade da culpa. Por
onde, não diminuindo a culpa, também o sujeito não pode fortificar-se.
Certos outros dizem ainda, que diminui a pena do verme roedor da consciência, embora não a do fogo.
─ Mas também nada disto é exato. Pois, assim como a pena do fogo é proporcional à culpa, assim
também a do remordimento da consciência. Por isso o mesmo se dá com ambas.
Donde se deduzem as RESPOSTAS ÀS OBJEÇÕES.