# Questão 26: Dos que podem conceder indulgências.
Em seguida devemos tratar dos que podem conceder indulgências.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se qualquer sacerdote pároco pode conceder indulgências.
O primeiro discute-se assim. ─ Parece que qualquer sacerdote pároco pode conceder indulgências.

1. ─ Pois, a indulgência tira a sua eficácia da abundância dos méritos da Igreja. Ora, não há nenhuma
congregação de fiéis, que não tenha alguma abundância de méritos. Logo, qualquer sacerdote pode
conceder indulgências, e semelhantemente qualquer prelado, desde que tenham jurisdição sobre uma
congregação de fiéis.

2. Demais. ─ Qualquer prelado representa a pessoa de toda a multidão dos fiéis; assim como um homem
representa a sua pessoa. Ora, qualquer pode comunicar a outrem os seus bens, satisfazendo por ele.
Logo, também o prelado pode comunicar os bens de todos os fiéis que lhe estão confiados. E portanto,
parece que pode conceder indulgências.
Mas, em contrário. ─ É menos excomungar, que conceder indulgências. Ora, excomungar não o pode um
sacerdote pároco. Logo, nem conceder indulgências.

SOLUÇÃO. ─ O efeito da indulgência consiste em as obras satisfatórias de um serem aplicadas a outro,
não só por força da caridade, mas também pela intenção do autor delas, de certo modo aplicada a quem
ganha a indulgência. Ora, a intenção de um pode aplicar-se a outro de três modos: especial, geral ou
singularmente. ─ Singularmente, quando um satisfaz por outro determinadamente. E então qualquer
pode comunicar a outrem os seus bens. ─ Especialmente, quando alguém ora pela sua comunidade,
pelos fámulos e benfeitores, ordenando também para tal fim as suas obras satisfatórias. E então o
superior de uma comunidade de fiéis pode comunicar a outrem as boas obras, aplicando a uma
determinada pessoa a intenção dos que lhe pertencem à comunidade. ─ Geralmente, porém, quando
alguém ordena as suas obras ao bem da Igreja em geral. E assim, o chefe geral da Igreja pode comunicar
as referidas obras, aplicando a sua intenção a este ou aquele. E como um homem faz parte de uma
comunidade e esta, da Igreja, por isso na intenção de um bem particular se inclui intenção do bem da
congregação e do bem de toda a Igreja. Por onde, o chefe da Igreja pode comunicar tanto os bens da
comunidade como os de cada um em particular; e o chefe de uma comunidade pode comunicar os de
um membro dela mas não inversamente.
Ora, nem a primeira espécie de comunicação nem a segunda constituem mas indulgência, mas só a
terceira e por duas razões ─ Primeiro porque por aquelas duas primeiras comunicações, embora o
pecador fique livre do reato da pena, perante Deus, não fica contudo isento do dever de cumprir a
satisfação imposta, a que está obrigado por preceito da Igreja. Mas, a terceira comunicação absolve
também desse débito. ─ Segundo, porque uma pessoa ou uma comunidade podem ter falta de méritos
para poderem valer a si e a todos os demais. Por onde, um particular não fica totalmente absolvido da
pena devida, se não se lhe fizer por ele determinadamente tanto quanto devia. Ao contrário, na Igreja
universal não há deficiência de méritos, sobretudo por causa do mérito de Cristo. ─ Portanto, só quem
está à testa da Igreja é que pode conceder indulgência.
Mas, sendo a Igreja a comunidade dos fiéis e havendo duas espécies de comunidade humana - a
econômica, constituída pelos membros de uma família; e a política, constituída dos que formam um
povo ─ a Igreja é comparável à comunidade política, pois é o povo mesmo que é chamado Igreja. Ao
passo que as diversas comunidades ou paróquias de uma diocese são comparáveis às agremiações das
diversas famílias ou dos diversos ofícios. Por onde, só ao bispo se chama propriamente prelado da
Igreja; e por isso só ele, como sendo o esposo, recebe da Igreja o anel. Portanto, só ele tem o pleno
poder de dispensar os sacramentos e a plena jurisdição no foro das causas, quase pessoa pública; os
outros o tem na medida em que o recebem dele. Os sacerdotes porém que dirigem uma comunidade de
fiéis, não são prelados, pura e simplesmente, mas uns como coadjutores; por isso, na consagração dos
sacerdotes o bispo diz ─ Quanto mais fracos somos, tanto mais necessitamos destes auxílios. Por isso
também é que não podem dispensar todos os sacramentos. Por onde, os sacerdotes párocos, os abades
ou outros prelados não podem conceder indulgências.

## Art. 2 — Se um diácono ou um não sacerdote pode conceder indulgências.
O segundo discute─se — Parece que um diácono ou um não sacerdote não pode conceder
indulgências.

1. — Pois, o perdão dos pecados é um efeito do poder das chaves. Ora, poder das chaves não o tem
senão o sacerdote. Logo, só ele pode conceder indulgências.

2. — Demais. — Perdão mais pleno da pena há, nas indulgências que no foro da penitência. Ora,
perdoar no foro da penitência só o pode o sacerdote. Logo, também conceder indulgências.
Mas, em contrário. — Pode dispensar os tesouros da Igreja só quem tem dela o governo. Ora, este
governo às vezes é cometido a um não sacerdote. Logo, também este pode conceder indulgências, que
tiram a sua eficácia da dispensa dos tesouros da Igreja.

SOLUÇÃO. — O poder de conceder indulgências resulta da jurisdição, como dissemos. E como os
diáconos e outros não-sacerdotes podem ter jurisdição — ou cometida, como os legados, ou ordinária,
como os prelados eleitos — por isso também os não-sacerdotes podem conferir indulgências, embora
não possam absolver no foro da penitência, que supõe a ordem.
Donde se deduzem as RESPOSTAS ÀS OBJEÇÕES. — Pois, conceder indulgências pertence à chave da
jurisdição e não à chave da ordem.

## Art. 3 — Se pode o bispo conceder indulgência.
O terceiro discute-se assim. — Parece que não pode o bispo conceder indulgências.

1. — Pois, o tesouro da Igreja é comum a toda a Igreja. Ora, o comum a toda a Igreja não pode ser
dispensado senão pelo chefe universal da mesma. Logo, só o Papa é quem pode conceder indulgências.

2. Demais. — Ninguém pode perdoar as penas estabelecidas pelo direito, salvo quem tem o poder de
fazer o direito. Ora, as penas satisfatórias não são por pecados determinados em direito. Logo, perdoar
essas penas só o Papa, que pode constituir o direito.
Mas, em contrário, o costume da Igreja, pelo qual os bispos concedem indulgências.

SOLUÇÃO. — O Papa tem a plenitude do poder pontifical, como um rei no seu reino. Ao passo que os
bispos são estabelecidos como juízes de cada cidade para aliviar o Papa de parte da sua universal
solicitude. Por isso, nas suas cartas só os bispos o Papa chama irmãos; aos demais, filhos. Por onde, o
poder de conceder indulgências o Papa o tem na sua plenitude; pois, pode concedê-las como quiser,
desde que haja causa legítima. Ao passo que os bispos tem esse poder determinadamente, por ordem
do Papa. Por onde, podem concedê-las conforme lhe foi determinado, mas não mais.
Donde se deduzem claras às RESPOSTAS ÀS OBJEÇÕES.

## Art. 4 — Se quem está em pecado mortal pode conceder indulgências.
O quarto discute-se assim. Parece que quem está em pecado mortal não pode conceder indulgências.

1. — Pois, nenhum rio pode existir senão emanado de uma fonte. Ora, a um prelado em estado de
pecado mortal não lhe mana a fonte da graça, a saber, o Espírito Santo. Logo, não pode fazê-las manar a
outrem, concedendo indulgências.

2. Demais. — Mais é conceder indulgência que recebê-la. Ora, quem está em pecado mortal não na
pode ganhar, como se dirá. Logo, nem pode concedê-la.
Mas, em contrário. — As indulgências se concedem pelo poder dado aos prelados da Igreja. Ora, o
pecado mortal não tira o poder, mas a bondade. Logo, quem está em pecado mortal pode conceder
indulgências.

SOLUÇÃO. — Conceder indulgências pertence à jurisdição. Ora, o pecado não faz perder a jurisdição.
Por onde, as indulgências tem todo o seu valor, concedidas por quem esta em pecado mortal, como se o
foram por quem é santíssimo. Pois, não perdoam a pena em virtude dos méritos de quem as concede,
mas em virtude dos méritos ocultos nos tesouros da Igreja.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O prelado que conceder indulgências, em estado de
pecado mortal, nada coloca de seu nelas. Por isso, não é necessário receba a emanação da fonte, para
as suas indulgências valerem.

RESPOSTA À SEGUNDA. — Mais é conceder indulgências que recebê-las, quanto ao poder; mas é
menos, quanto à utilidade própria.