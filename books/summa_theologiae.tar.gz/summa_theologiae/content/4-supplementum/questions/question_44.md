# Questão 44: Da definição do matrimônio.
Em seguida devemos tratar da definição do matrimônio. E nesta questão discutem-se três artigos:

## Art. 1 — Se o matrimônio é uma união.
O primeiro discute-se assim. ─ Parece que o matrimônio não é uma união.

1. Pois, o vínculo que une duas coisas se distinguem da união delas, como a causa, do efeito. Ora, o
matrimônio é um vínculo que liga os unidos pelo matrimônio. Logo, não é uma espécie de união.

2. Demais. ─ Todo sacramento é um sinal sensível. Ora, nenhuma relação é um acidente sensível. Logo, o
matrimônio, sendo um sacramento, não pertence ao gênero da relação e, portanto, nem ao da união.

3. Demais. ─ A união, como a igualdade, é uma relação de equivalência. Ora, a relação da igualdade não
é numericamente a mesma em cada um dos extremos, como diz Avicena. Logo, nem uma só será a
união. Logo, se o matrimônio pertence ao gênero da união, não há um matrimônio só entre os dois
cônjuges.
Mas, em contrário. ─ A relação faz dois seres se referirem um ao outro. Ora, o matrimônio leva dois
seres se referirem um ao outro; assim, o varão se chama o marido da mulher e esta, esposa do marido.
Logo, o matrimônio pertence ao gênero da relação, nem é mais que uma união.

2. Demais. ─ A redução de dois seres num só não se opera senão pela união. Ora, tal é o efeito do
matrimônio, segundo aquilo da Escritura: Serão dois em uma só carne. Logo, o matrimônio pertence ao
gênero da união.

SOLUÇÃO. - A união implica uma certa aunação. Logo, onde há aunação de dois seres há também aí e
sempre, uma união. Ora, coisas que se ordenam para outra se dizem aunadas em relação a ela; assim
muitos homens se aunam para formarem uma milícia ou realizarem um negocio, e por isso se chamam
companheiros de coisas ou sócios do negócio. Por onde, como no matrimônio os cônjuges se aunam
para o mesmo fim da geração e da educação da prole, e além disso para a comunidade da vida
doméstica, resulta que o matrimônio é uma união, razão pela qual um dos cônjuges se chama marido e
o outro a mulher. E tal união ordenada a um determinado fim é o matrimônio. Quanto à união dos
corpos e das almas, ela resulta do matrimônio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O matrimônio é um vínculo de ligação formal e não
efetiva. Por isso não deve ser senão a união dos cônjuges.

RESPOSTA À SEGUNDA. ─ Embora a relação mesma não seja um acidente sensível, contudo sensíveis
podem lhe ser as causas. Nem o sacramento exige sejam sensíveis a realidade e o sacramento; e é,
assim que se comporta a referida união no sacramento do matrimônio. As palavras porém, que
exprimem o consentimento, que constituem só o sacramento e a causa da referida união, são sensíveis.

RESPOSTA À TERCEIRA. ─ A relação tem um fundamento que lhe é a causa, assim a semelhança se funda
na qualidade; e tem outro fundamento, que lhe é o sujeito, e são as realidades sensíveis. Ora, de ambos
os lados pode resultar a unidade ou a diversidade da relação. Mas a semelhança supõe em cada um dos
termos semelhantes uma qualidade especificamente, a mesma. Além disso os sujeitos da semelhança
são em número de dois. E o mesmo se dá com a igualdade. Por isso, tanto a igualdade como a
semelhança são, sob todos os aspectos semelhantes e iguais. A relação porém do matrimônio tem de
um lado unidade em cada um dos extremos, isto é, quanto à causa, pois se ordena a uma geração
numericamente a mesma; mas, pelo sujeito, implica diversidade numérica. Donde o ser essa relação una
pela causa e múltipla pelo sujeito. E por ser múltipla pelo sujeito é expressa pelos nomes ─ marido e
mulher. E enquanto uma, é designada pelo nome de matrimônio.

## Art. 2 — Se o matrimônio está bem denominado.
O primeiro discute-se assim. ─ Parece que o matrimônio não é uma união.

1. Pois, o vínculo que une duas coisas se distinguem da união delas, como a causa, do efeito. Ora, o
matrimônio é um vínculo que liga os unidos pelo matrimônio. Logo, não é uma espécie de união.

2. Demais. ─ Todo sacramento é um sinal sensível. Ora, nenhuma relação é um acidente sensível. Logo, o
matrimônio, sendo um sacramento, não pertence ao gênero da relação e, portanto, nem ao da união.

3. Demais. ─ A união, como a igualdade, é uma relação de equivalência. Ora, a relação da igualdade não
é numericamente a mesma em cada um dos extremos, como diz Avicena. Logo, nem uma só será a
união. Logo, se o matrimônio pertence ao gênero da união, não há um matrimônio só entre os dois
cônjuges.
Mas, em contrário. ─ A relação faz dois seres se referirem um ao outro. Ora, o matrimônio leva dois
seres se referirem um ao outro; assim, o varão se chama o marido da mulher e esta, esposa do marido.
Logo, o matrimônio pertence ao gênero da relação, nem é mais que uma união.

2. Demais. ─ A redução de dois seres num só não se opera senão pela união. Ora, tal é o efeito do
matrimônio, segundo aquilo da Escritura: Serão dois em uma só carne. Logo, o matrimônio pertence ao
gênero da união.

SOLUÇÃO. - A união implica uma certa aunação. Logo, onde há aunação de dois seres há também aí e
sempre, uma união. Ora, coisas que se ordenam para outra se dizem aunadas em relação a ela; assim
muitos homens se aunam para formarem uma milícia ou realizarem um negocio, e por isso se chamam
companheiros de coisas ou sócios do negócio. Por onde, como no matrimônio os cônjuges se aunam
para o mesmo fim da geração e da educação da prole, e além disso para a comunidade da vida
doméstica, resulta que o matrimônio é uma união, razão pela qual um dos cônjuges se chama marido e
o outro a mulher. E tal união ordenada a um determinado fim é o matrimônio. Quanto à união dos
corpos e das almas, ela resulta do matrimônio.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O matrimônio é um vínculo de ligação formal e não
efetiva. Por isso não deve ser senão a união dos cônjuges.

RESPOSTA À SEGUNDA. ─ Embora a relação mesma não seja um acidente sensível, contudo sensíveis
podem lhe ser as causas. Nem o sacramento exige sejam sensíveis a realidade e o sacramento; e é,
assim que se comporta a referida união no sacramento do matrimônio. As palavras porém, que
exprimem o consentimento, que constituem só o sacramento e a causa da referida união, são sensíveis.

RESPOSTA À TERCEIRA. ─ A relação tem um fundamento que lhe é a causa, assim a semelhança se funda
na qualidade; e tem outro fundamento, que lhe é o sujeito, e são as realidades sensíveis. Ora, de ambos
os lados pode resultar a unidade ou a diversidade da relação. Mas a semelhança supõe em cada um dos
termos semelhantes uma qualidade especificamente, a mesma. Além disso os sujeitos da semelhança
são em número de dois. E o mesmo se dá com a igualdade. Por isso, tanto a igualdade como a
semelhança são, sob todos os aspectos semelhantes e iguais. A relação porém do matrimônio tem de
um lado unidade em cada um dos extremos, isto é, quanto à causa, pois se ordena a uma geração
numericamente a mesma; mas, pelo sujeito, implica diversidade numérica. Donde o ser essa relação una
pela causa e múltipla pelo sujeito. E por ser múltipla pelo sujeito é expressa pelos nomes ─ marido e
mulher. E enquanto uma, é designada pelo nome de matrimônio.

## Art. 3 — Se o Mestre das Sentenças definiu bem o matrimônio.
O terceiro discute-se assim. ─ Parece que o Mestre das Sentenças definiu mal o matrimônio.

1. Pois, na definição de marido é necessário incluir-se o matrimônio; porque marido é quem está ligado
à mulher pelo matrimônio. Ora, ele emprega a expressão ─ união marital ─ ao definir o matrimônio.
Logo, há círculo nessas definições.

2. Demais. ─ O matrimônio tanto faz do varão marido da mulher, como da mulher esposa do varão.
Logo, não há razão para se dizer, antes, união marital, que uxória.

3. Demais. ─ O regime de vida é genericamente o costume. Ora, frequentemente os unidos pelo
matrimônio são mui diversos de costumes. Logo, não se deve dizer do definir o matrimônio: que
mantém entre os cônjuges um mesmo regime de vida.

4. Demais. ─ Outras definições se deram do matrimônio. Assim, Hugo Victorino: o matrimônio é a união
de duas pessoas idôneas fundada num consentimento legítimo. ─ Outros definem: o matrimônio é o
consórcio de uma vida em comum, que comunica o direito divino e o humano. Pergunta-se em que
diferem essas definições.

SOLUÇÃO. ─ Como dissemos, três elementos se consideram no matrimônio ─ a sua causa, a sua essência
e os seus efeitos. Levando em conta esses três elementos, podemos classificar as três definições que se
deram do matrimônio. ─ Assim, a de Hugo considera a causa, isto é, o consentimento; e essa definição é
clara. ─ A definição dada pelo Mestre considera a essência do matrimônio, isto é, a união. E acrescenta
um objeto determinado quando diz: entre pessoas idôneas. Também indica a diferença específica dessa
união quando diz ─ marital. Pois, sendo o matrimônio uma união em vista de um fim determinado, a sua
espécie se determina pelo fim a que se ordena, e este depende do marido. Enuncia também a força
dessa união, que é indissolúvel, quando diz: Que mantém entre os cônjuges um mesmo regime de vida.
─ A outra definição enfim considera o efeito, a que o matrimônio se ordena, a saber, a vida doméstica
em comum, E como toda sociedade se funda em alguma lei, por isso a definição enuncia a lei reguladora
dessa sociedade, a saber, o direito divina e o humano. Quanto às outras sociedades ─ a dos negociantes
e a dos soldados ─ são instituições de puro direito humano.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Dá-se algumas vezes, que os caracteres predominantes
não são mencionados, que deviam entrar numa definição. Por isso se enunciam, nela, elementos que;
absolutamente considerados, vêm em segundo lugar, mas que nos são melhor conhecidos. Assim, na
definição da qualidade, o Filósofo emprega o adjetivo qual, quando diz: A qualidade permite dizer quais
nós somos. Do mesmo modo, na definição do matrimônio se diz ─ marital, para significar que o
matrimônio é uma união com o fim de realizar o dever do marido. O que tudo não podia ser designado
com uma só palavra.

RESPOSTA À SEGUNDA. ─ A diferença assinalada enuncia o fim da união, como se disse. E como, na
expressão do Apóstolo, não foi criado o varão por causa da mulher, mas a mulher por causa do varão,
por isso, essa diferença deve fundar-se, antes, no varão que na mulher.

RESPOSTA À TERCEIRA. ─ Assim como a vida civil não implica a atividade particular de tal indivíduo ou a
de tal outro, senão só o concernente à vida social, assim também a vida conjugal não é senão a
convivência que essa sociedade implica. Por onde, essa vida em comum implica sempre uma
convivência individual, embora os atos de cada cônjuge se pratiquem em separado.

RESPOSTA À QUARTA. ─ A resposta resulta do que foi dito.