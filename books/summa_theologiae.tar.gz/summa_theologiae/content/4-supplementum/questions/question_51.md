# Questão 51: Do impedimento do erro.
Em seguida devemos tratar dos impedimentos especiais do matrimônio. E primeiro, do impedimento do
erro.
E nesta questão discutem-se dois artigos:

## Art. 1 — Se o erro deve ser considerado como um impedimento essencial ao matrimônio.
O primeiro discute-se assim. ─ Parece que o erro não deve ser considerado como um impedimento
especial do matrimônio.

1. Pois, o consentimento, que é a causa do matrimônio tem os mesmos impedimentos que o voluntário.
Ora, o voluntário, segundo o Filósofo, pode ser eliminado pela ignorância. A qual não é idêntica ao erro;
pois, ao passo que a ignorância implica a ausência de conhecimento, o erro supõe o conhecimento;
consistindo em tomar o falso como verdadeiro, segundo Agostinho. Logo, não o erro, mas antes, a
ignorância é que deverá ser considerada impedimento ao matrimônio.

2. Demais. ─ Impedimento essencial ao matrimônio pode ser o que lhe contraria os bens. Ora, tal não é
o erro. Logo, não é impedimento essencial ao matrimônio.

3. Demais. - Assim como o consentimento é necessário para haver matrimônio, assim a intenção para
haver batismo. Ora, quem batizar João, crendo batizar Pedro, nem por isso deixa de batizar
verdadeiramente. Logo, o erro não exclui o matrimônio.

4. Demais. ─ Entre Lia e Jacó houve verdadeiro matrimônio. Ora, houve erro. Logo, o erro não exclui o
matrimônio.
Mas, em contrário, lê-se no Digesto: Que há de mais contrário ao consentimento que o erro? Ora, o
consentimento é necessário para o matrimônio. Logo, o erro o impede.

2. Demais. ─ Consentimento implica de certo modo o voluntário; pois, o voluntário, segundo o Filósofo,
Gregório Nisseno e Damasceno, tem o seu princípio no ajuste conhecente das contingências particulares
da ação que pratica. Ora, isso não se dá com quem erra. Logo, o erro impede o matrimônio, o que é de
natureza a impedir uma causa impede-lhe também o efeito. Ora, o consentimento é a causa do
matrimônio, como se disse. Logo, o que anula o consentimento também anula o matrimônio. Ora, o
consentimento é um ato da vontade, que pressupõe o ato do intelecto. Por onde, a falta daquele
acarreta necessariamente a deste. Portanto, quando o erro impede o conhecimento, também há de
impedir o consentimento; e logo, o matrimônio.
E assim, por direito natural, o erro anula o casamento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A ignorância, absolutamente falando, difere do erro; pois,
ao passo que por natureza exclui todo ato de conhecimento, o erro nos leva a julgar mal de um
determinado objeto. Contudo, quanto ao efeito de impedir o voluntário, não há diferença entre
ignorância e erro. Pois, só pode impedi-lo a ignorância acompanhada do erro; porque o ato da vontade
pressupõe uma apreciação ou um juízo sobre o projeto de uma ação intencionada; e portanto, havendo
ignorância, haverá necessariamente erro. Por isso o erro é considerado como a causa próxima da falta
de consentimento.

RESPOSTA À SEGUNDA. ─ Embora o erro, em si mesmo, não contrarie o matrimônio, contraria-o porém
na sua causa.

RESPOSTA À TERCEIRA. ─ O caráter do batismo não é diretamente infundido pela intenção de quem
batiza; mas pelo rito material realizado exteriormente. A intenção não tem outro resultado senão
adaptar o elemento material do seu efeito próprio. Ao contrário, o vínculo conjugal é causado
diretamente. Logo, não há símile.

RESPOSTA À QUARTA. ─ Como ensina o Mestre das Sentenças, o matrimônio entre Lia e Jacó, não se
consumou pelas relações carnais havidas por engano, mas pelo consentimento posterior. Contudo
ficaram escusados de pecado, como diz o Mestre, na mesma distinção.

## Art. 2 — Se todo erro impede o matrimônio.
O segundo discute-se assim. ─ Parece que todo erro impede o matrimônio, e não só o sobre a
condição ou a pessoa, como diz o Mestre.

1. Pois, o que convém a uma realidade, em razão da sua natureza, em todos os casos lhe convém. Ora, o
erro por natureza impede o matrimônio, como se disse. Logo, todo erro o impede.

2. Demais. ─ Se o erro como tal impede o matrimônio, um erro maior deve ser maior impedimento. Ora,
maior é o erro sobre a fé, cometido pelos heréticos que não sem neste sacramento, que o erro sobre a
pessoa. Logo, deve ser o erro sobre a fé maior impedimento que este último.
3 . Demais. ─ O erro não anula o matrimônio senão na medida em que exclui o voluntário. Ora, o ignorar
de qualquer circunstância exclui o voluntário como o diz Aristóteles. Logo, não é só o erro sobre a
condição e sobre a pessoa, que impede o matrimônio.

4. Demais. ─ Assim como a condição de escravo é um acidente, que afeta a pessoa, assim também o é
uma qualidade do corpo ou da alma. Ora, o erro sobre a condição impede o matrimônio. Logo e pela
mesma razão, o erro sobre a qualidade ou a fortuna.

5. Demais. ─ Assim como a escravidão e a liberdade são condições da pessoa, assim a nobreza ou a
ignobilidade, a dignidade de que se desfruta ou a privação desta. Ora, o erro sobre a condição de livre
ou escravo impede o matrimônio. Logo, também o que recai sobre as demais condições referidas.

6. Demais. ─ Assim como a condição de escravo impede o matrimônio, assim também a disparidade de
culto e a impotência física, como a seguir se dirá. Logo, assim como o erro sobre a condição é um
impedimento, assim também deviam impedir o matrimônio o erro sobre a disparidade do culto e a
impotência.
Mas, em contrário. ─ Parece que o erro sobre a pessoa não impede o matrimônio. Pois, assim como a
compra é um contrato, assim também o matrimônio. Ora, a compra e venda não será anulada porque se
deu uma moeda de ouro em lugar de outra do mesmo valor. Logo, nem o matrimônio fica impedido de
quem esposar uma mulher em lugar de outra.

2. Demais. ─ Pode-se dar que os cônjuges elaborem nesse erro durante muitos anos e gerem filhos e
filhas. Ora, grave seria dizer que se deveriam separar, depois de tantos anos. Logo, o primeiro erro não
dirimiu o matrimônio.

3. Demais. ─ Pode uma mulher, por erro, consentir em casar com o irmão do homem com quem queria
realmente contrair matrimônio, e este venha a com ela ter conjunção carnal. Donde então o resultado
de não lhe ser possível voltar a casar com aquele a quem iria dar o seu consentimento, devendo
permanecer com o irmão. E assim, o erro sobre a pessoa não impede o matrimônio.

SOLUÇÃO. ─ Assim como o erro, por causar o involuntário, escusa do pecado, assim pela mesma razão
impede o matrimônio. Ora, só escusa do pecado o erro sobre uma circunstância, cuja presença ou
ausência torna o ato lícito ou ilícito. Assim, quem ferir o próprio pai com um bastão de ferro, crendo ser
de madeira, não fica completamente escusado, embora o fique parcialmente. Mas quem crê açoitar um
filho, por causa de disciplina, e açoite o próprio pai, fica totalmente escusado, contanto que o fizesse de
todo por engano. Por onde e necessariamente, o erro impeditivo do matrimônio há de ser daqueles que
atingem a essência mesma dele. Mas, o matrimônio implica duas condições essenciais: as duas pessoas
vinculadas e o poder que mutuamente se dão, uma sobre a outra. Ora, a primeira fica excluída pelo erro
sobre a pessoa; a segunda, pelo erro sobre a condição, pois um escravo não tem a faculdade de conferir
a outrem poder sobre o seu corpo, sem
o consentimento do senhor. Razão pela qual esses dois erros impedem o matrimônio, e não os outros.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Não é pela sua natureza genérica, mas pela diferença
adjunta, que o erro impede o matrimônio, Isto é, porque recai sobre um dos elementos essenciais do
casamento.

RESPOSTA À SEGUNDA. ─ O erro de um infiel em relação ao matrimônio recai sobre as consequências
dele, a saber, se é sacramento, ou se é lícito. Por isso tal erro não o impede, assim como um erro
relativo ao batismo não impede a impressão do caráter, contanto que o batizando tenha a intenção de
fazer ou de receber o que a Igreja confere, embora nisso não creia.

RESPOSTA À TERCEIRA. ─ Não é a ignorância de qualquer circunstância que causa o involuntário que
escusa de pecado, como se disse. Por isso a objeção não colhe.

RESPOSTA À QUARTA. ─ A diversidade de fortuna como a de qualidade nada altera do essencial ao
matrimônio, como o altera a condição da escravidão. Por onde, a objeção não colhe.

RESPOSTA À QUINTA. ─ O erro sobre a nobreza, como tal, não anula o matrimônio, pela mesma razão
por que não o anula o erro sobre uma qualidade. Mas, se o erro sobre a nobreza ou a dignidade
redundar em erro sobre a pessoa, então impedi-lo-á. Assim, se o consentimento da mulher recai
diretamente sobre certa pessoa, o erro sobre a nobreza dela não ê impedimento ao matrimônio. Se
porém entendia consentir diretamente em casar como filho de um rei, seja êle qual for, então, casando
com outro que não o filho do rei, cometerá um erro sobre a pessoa e o matrimônio será nulo.

RESPOSTA À SEXTA. ─ O erro também sobre os outros impedimentos ao matrimônio, que tornam certas
pessoas incapazes dele, impede-o. Mas o Mestre não menciona esses erros, porque, mesmo quando
inexistentes, os impedimentos produzem sempre os seus efeitos. Tal o caso da mulher que casar com
um subdiácono; quer o saiba, quer não, o matrimônio será nulo. Mas a condição de escravo, quando
conhecida, não o impede. Logo, o símile não colhe.

RESPOSTA À SÉTIMA. ─ Nos contratos, o dinheiro exerce a função de medida universal, como o
demonstra Aristóteles, e não da matéria deles. Por isso nada obsta ao contrato o fato de se dar uma
moeda em lugar de outra, equivalente. Mas
se o erro recaísse sobre a matéria, objeto do contrato, este seria nulo; tal o caso de quem vendesse um
asno por um cavalo. Ora, o mesmo se dá no caso proposto.

RESPOSTA À OITAVA. ─ Nas circunstâncias imaginadas, só haverá matrimônio se a mulher renovar o
consentimento, seja qual for o tempo durante o qual coabitaram.

RESPOSTA À NONA. ─ Se a mulher não consentiu em casar com o primeiro irmão, pode ficar com o que
aceitou por erro ; nem pode voltar a viver com o outro, sobretudo se já teve relação carnal com o a que
deu o seu consentimento. Se porém consentiu em casar como o primeiro, por palavras de presente, não
pode convolar as núpcias com o segundo, enquanto viver o outro; mas poderá separar-se do segundo
ou voltar a conviver com o primeiro. Seja como for, a ignorância do fato escusa de pecado; como o
escusaria se depois de consumado o matrimônio, tivesse relações com o irmão de seu marido, enganada
por esse irmão; pois, não pode ficar prejudicada pela fraude alheia.