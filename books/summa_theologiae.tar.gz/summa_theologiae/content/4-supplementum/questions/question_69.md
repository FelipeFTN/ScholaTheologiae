# Questão 69: Do concernente a ressurreição e, primeiro, do lugar das
almas depois da morte.
Em seguida, devemos tratar da questão da ressurreição. Pois, após termos tratado dos sacramentos,
pelos quais ficamos liberados da morte da culpa, devemos consequentemente tratar da ressurreição,
pela qual ficamos liberados da morte da pena.
No tratado da ressurreição, três pontos devemos considerar: as coisas precedentes à ressurreição; as
concomitantes; as subsequentes. E assim devemos, primeiro, tratar das coisas precedentes à
ressurreição, senão todas, ao menos em parte. Segundo, da ressurreição mesma e das circunstâncias
que a acompanham. Terceiro, do que se lhe segue.
Ora, a primeira coisa a investigar, das precedentes à ressurreição, são os lugares assinalados a receber
as almas depois da morte. A segunda, a qualidade e a pena das almas separadas, e a pena do fogo que
lhes é infligida. A terceira, os sufrágios pelos quais os vivos socorrem as almas dos defuntos. A quarta, as
orações dos santos, que estão na pátria. A quinta, os sinais precursores do juízo universal. A sexta, o
fogo da última conflagração do mundo precedente à vinda do supremo juiz.
Na primeira questão discutem-se sete artigos:

## Art. 1 — Se às almas depois da morte lhes são atribuídos determinados receptáculos.
O primeiro discute-se assim. ─ Parece que às almas, depois da morte, não lhes são atribuídos nenhuns
receptáculos.

1. ─ Pois, como diz Boécio, é opinião comum dos sábios, que os seres espirituais não podem ocupar
lugar. Com o que concorda Agostinho quando diz: Podemos responder imediatamente, que as almas
não podem ser conduzidas para lugares espaciais, senão quando unidas ao corpo. Ora, a alma separada
não tem corpo como o diz ainda Agostinho. Logo, é absurdo dizer que às almas separadas lhes são
atribuídos receptáculos.

2. Demais. ─ Tudo o que tem um lugar determinado, mais se relaciona com esse lugar do que com
qualquer outro. Ora, as almas separadas, como todas substâncias espirituais, são indiferentes a
quaisquer lugares. Pois, não podemos dizer que tenham inclinação para certos corpos e se afastem de
outros, porque não estão de modo nenhum sujeitas a quaisquer condições materiais. Logo, não
podemos dizer que lhes sejam atribuídos nenhuns receptáculos.

3. Demais. ─ Tudo o atribuído às almas separadas, depois da morte, lhes há de redundar em pena ou em
prêmio. Ora, um lugar material não lhes pode redundar nem em pena nem em prêmio, pois não são
susceptíveis de nada de material. Logo, não lhes podem ser atribuídos nenhuns receptáculos.
Mas, em contrário. ─ O céu empíreo é um lugar material. E contudo, como diz Beda, logo depois de
criado foi cheio dos santos anjos. Logo, sendo os anjos, como as almas separadas, incorpóreos, parece
que também a elas se lhes devem ser atribuídos receptáculos determinados.
Demais. ─ Que as almas separadas são conduzidas para lugares determinados, resulta do que Gregório
conta a respeito de Pascácio, que Germano, bispo de Cápua, encontrou num balneário; e de dizer que a,
alma do rei Teodorico foi conduzida para a geena. Logo, às almas, depois da morte, lhes são atribuídos
determinados receptáculos.

SOLUÇÃO. ─ Embora as substâncias espirituais não existam dependentes de corpos, contudo, os corpos
são governados por Deus mediante os espíritos, como dizem Agostinho e Gregório. Por onde, há uma
certa conveniência entre as substâncias espirituais e as corpóreas, fundada numa determinada
congruência, de modo que às substâncias mais nobres se adaptem corpos de natureza mais nobre. Por
isso também os Filósofos distinguiram as ordens dos móveis relativamente às substâncias separadas.
Ora, apesar de às almas, depois da morte, não lhes serem atribuídos nenhuns corpos, de que sejam as
formas ou motores determinados, são-lhes contudo, por uma certa congruência, atribuídos lugares
determinados, conforme ao grau de dignidade delas. E nesses lugares estão elas como que colocadas,
do modo por que seres incorpóreos podem ocupar um lugar, conforme mais ou menos próximos estão
da substância primeira, Deus, a qual, por congruência, é atribuído o lugar superior, e a cuja sede a
Escritura chama céu. Por onde, as almas perfeitamente participantes da divindade, no céu as colocamos;
e as privadas dessa participação dizemos que lhes são destinados os lugares opostos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Os seres incorpóreos não ocupam lugar do modo que nos
é conhecido e habitual, como quando dizemos, em sentido próprio, que um corpo está num lugar.
Ocupam lugar porém ao modo das substâncias espirituais, o que nós não podemos claramente
compreender como é.

RESPOSTA À SEGUNDA. ─ Há duas espécies de conveniência ou semelhança. ─ Uma, por participação de
determinada qualidade; assim os corpos quentes convêm entre si. Ora, nesse sentido não pode haver
conveniência entre seres incorpóreos e lugares corpóreos. ─ Outra, por uma certa proporção; e nesse
sentido a Escritura atribui ao espírito o que pertence ao corpo, como quando diz que Deus é sol, por ser
o princípio da vida espiritual como Deus o é da vida do corpo. E, então, certa conveniência existe entre
determinados modos de ser da alma e determinados lugares. Assim, há uma natural conveniência entre
as almas espiritualmente iluminadas e os corpos luminosos; e entre as almas entenebrecidas pela culpa
e os lugares tenebrosos.

RESPOSTA À TERCEIRA. ─ Uma alma separada nada recebe diretamente de um lugar material, ao modo
por que os corpos recebem, que acham no seu lugar o princípio da sua conservação. Mas as almas, pelo
fato mesmo de se saberem destinadas a determinados lugares, enchem-se de alegria ou de tristeza; daí
o lhes redundar em pena ou em prêmio o lugar que lhes é atribuído.

## Art. 2 — Se imediatamente depois da morte as almas são conduzidas ao céu ou ao inferno.
O segundo discute-se assim. ─ Parece que nenhuma alma é imediatamente conduzida, depois da
morte, nem ao céu nem ao inferno.

1. ─ Pois, àquilo da Escritura ─ Ainda um pouco e não existirá o pecador ─ diz a Glosa: Os santos são
libertados no fim do mundo; mas ainda não estarás, depois desta vida, onde estarão os santos, aos quais
será dito ─ vinde, benditos de meu Pai. ─ Ora, esses santos estarão no céu. Portanto, os santos, depois
desta vida, não subirão logo ao céu.

2. Demais. ─ Agostinho diz: No tempo decorrido entre a morte e a ressurreição final, as almas habitarão
lugares secretos, no descanso ou no sofrimento, conforme ao mérito de cada uma. Ora, esses lugares
secretos não podem entender-se como sendo o céu e o inferno, porque neles estarão as almas com os
seus corpos, mesmo depois da ressurreição final; e assim em nada se distinguirão os tempos anteriores
e os posteriores à ressurreição. Logo, não estarão nem no inferno nem no paraíso até o dia do juízo.

3. Demais. ─ Maior é a glória da alma que a dos corpos. Ora, a glória dos corpos será concedida a todos
simultaneamente, de modo a ser maior a alegria de cada uma pela participação da alegria comum.
Assim o dito do Apóstolo ─ Tendo disposto Deus alguma causa melhor a nosso favor ─ o comenta a
Glosa: Para resultar maior, da comum alegria de todos, a alegria de cada um. Logo e com maior razão,
convém diferir a glória das almas até o fim, para a gozarem todas simultaneamente.

4. Demais. ─ A pena e o prêmio, conferidos pela sentença do juiz, não devem preceder o juízo. Ora, o
fogo do inferno e a alegria do paraíso serão dados a todos pela sentença de Cristo juiz, i. é, no juízo final,
como o diz o Evangelho. Logo, antes do dia do juízo, ninguém subirá ao céu nem descerá ao inferno.
Mas, em contrário, o Apóstolo: Se a nossa casa terrestre desta morada for desfeita, temos de Deus um
edifício, casa não feita por mãos humanas, que durará sempre nos céus. Logo separada do corpo, terá a
alma uma morada, que durará sempre nos céus.

2. Demais. ─ O Apóstolo diz: Tenho desejo de ser desatado da carne e estar com Cristo. Baseado no que,
assim argumenta Gregório: Logo, quem não duvida que Cristo esteja no céu, também não negará que
nele esteja a alma de Paulo. Ora, não podemos negar que Cristo esta no céu, por ser artigo de fé. Logo,
nem devemos duvidar sejam as almas dos santos levadas ao céu. E também sabemos que certas almas
caem no inferno logo depois da morte, por aquilo do Evangelho: Morreu também o rico e foi sepultado
no inferno.

SOLUÇÃO. ─ Assim como os corpos são dotados de peso ou de leveza, que os fazem entrar nos seus
lugares, que é o fim do movimento deles, assim também tem as almas o seu mérito e o seu demérito,
pelos quais alcançam o prêmio ou a pena, fins das ações delas. Por onde, assim como, a menos de um
obstáculo, a gravidade ou a leveza faz os corpos imediatamente ocuparem o seu lugar, assim
imediatamente as almas, dissoluto o vínculo da carne, que as prendia até a esta vida, recebem o prêmio
ou a pena, se nada o impedir. p. ex., a consecução do prêmio a impediria o pecado venial, que deveria
ser expiado antes, donde resultaria o retardamento do prêmio. Ora, conforme o prêmio ou a pena, que
merece, à alma, logo depois de separada do corpo, lhe é atribuído o seu lugar. Ou é precipitada no
inferno, ou sobe aos céus, salvo se o impedir algum reato, que diferirá a sua entrada no céu, até ser
purificada. ─ E essa verdade tanto a confirmam manifestamente as autoridades da Escritura canônica,
como os documentos dos santos Padres. O contrário deve ser tido como herético.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A Glosa se elucida a si mesma. Pois, quando diz ─ Ainda
não estarás onde estarão os santos ─ logo, como se explicando, acrescenta ─ i. é, não terás as vestes
duplas que terão os santos na ressurreição.

RESPOSTA À SEGUNDA. ─ Entre os outros receptáculos ocultos, de que fala Agostinho, também
devemos contar o inferno e o paraíso, onde certas almas demoram, antes da ressurreição. Mas
distingue entre o tempo anterior e o posterior à ressurreição. Porque, antes dela, aí estão sem corpo;
depois, com corpo. E porque em certos receptáculos agora estão as almas, onde não estarão depois da
ressurreição.

RESPOSTA À TERCEIRA. ─ Os homens, pelos seus corpos, tem uma certa continuidade que os une uns
aos outros; e por isso é verdade o dito da Escritura: De um só fez Deus todo o gênero humano. Ao passo
que as almas as criou cada uma de per si. Por onde, não há tanta conveniência em os homens todos
serem simultaneamente glorificados na alma, como em o serem simultaneamente no corpo. ─ Além
disso, a glória do corpo não é essencial, como a da alma. Por isso, maior detrimento sofreriam os santos,
tendo diferida a glória da alma, que a do corpo. Nem poderia esse detrimento da glória ser
recompensado pela ampliação da alegria de cada um, participando da alegria comum.

RESPOSTA À QUARTA. ─ Gregório propõe a mesma objeção e a resolve. Se, diz, estão agora no céu as
almas dos justos, que receberão no dia de juízo como retribuição pela sua justiça? E responde: A sua
glória lhes exercerá porque agora não gozam senão da felicidade da alma; depois da ressurreição,
porém, fruirão a do corpo, de modo que também gozarão na carne pelas dores e tormentos sofridos
pelo Senhor. E o mesmo se diga dos condenados.

## Art. 3 — Se as almas, que estão no céu ou no inferno, podem sair de lá.
O terceiro discute-se assim. ─ Parece que as almas, que estão no céu ou no inferno, de lá, não podem
sair.

1. ─ Pois, Agostinho diz: Se as almas dos mortos cuidassem das cousas desta vida, minha piedosa mãe,
para só dar este exemplo, nenhuma noite me abandonaria, ela que transpunha terras e mares para
estar a meu lado. Donde conclui que as almas dos defuntos não se intrometem na vida humana. Ora,
podiam fazê-la se pudessem sair das suas moradas. Logo, não podem delas sair.

2. Demais. ─ A Escritura diz: Que habite eu na casa do Senhor todos os dias da minha vida. E noutro
lugar: Aquele que descer aos infernos não subirá. Logo, tanto os bons como os maus não sairão das suas
moradas.

3. Demais. ─ Os lugares atribuídos às almas, depois da morte, o foram como prêmio ou castigo. Ora,
depois da morte, não diminuirão nem o prêmio dos santos nem a pena dos condenados. Logo, não
podem sair dos lugares que lhes foram atribuídos.
Mas, em contrário. ─ Diz Jerônimo a Vigilância: Pois, dizes que as almas dos Apóstolos e dos mártires,
que tiveram como destino o seio de Abraão, o lugar de refrigério ou os que estão sob o olhar de Deus,
não podem, mesmo querendo, vir ter aos seus túmulos, na terra. E assim impões leis a Deus, atas com
vínculos os Apóstolos, que os prenderão até ao dia do juízo, sem poderem entrar no gozo do seu
Senhor, a eles dos quais foi escrito ─ Seguem ao Cordeiro seja para onde for que vão. ─ Mas, se o
Cordeiro está em toda parte, podemos crer que também os santos estarão com ele, achem-se onde se
acharem. É portanto falso dizer que as almas dos mortos não podem sair das suas moradas.

2. Demais. ─ Jerônimo, no mesmo lugar, assim argumenta: Se o diabo e os demônios vagam por toda a
terra, presentes em toda parte com incrível rapidez, os mártires não poderão, eles que derramaram o
seu sangue, sair da arca do altar celeste? Donde se pode concluir que não só os bons, mas também os
maus, lhes é possível sair dos lugares onde estão; pois, não sofrem maior condenação que os demônios
que vagam por toda parte.

3. Demais. ─ O mesmo podemos provar com Gregório, quando narra de muitos mortos, que apareceram
aos vivos.

SOLUÇÃO. ─ De dois modos podemos entender que uma alma saiu do inferno ou do paraíso. ─ Primeiro,
absolutamente falando, de modo que saíam de um ou outro desses lugares, que deixará portanto de
lhes ser a morada. Ora, assim, ninguém que tenha sido definitivamente destinado ao inferno ou ao céu,
poderá dele sair, como mais adiante diremos. ─ Noutro sentido podemos entender a saída como
temporária. E então devemos distinguir entre o que convém aos espíritos pela lei da sua natureza, e o
que lhes convém pela ordem da divina providência. Pois, como diz Agostinho, uns são os limites das
causas humanas, e outros os sinais do poder divino; uns são os fenômenos naturais e outros, os
miraculosos.
Ora, segundo o curso natural das cousas, as almas separadas, uma vez nos lugares que lhes foram
destinados, ficam completamente segregadas da convivência humana. Pois, pelo curso da natureza, os
que ainda vivemos unidos ao corpo mortal não temos nenhum comércio imediato com as substâncias
separadas, porque todos os nossos conhecimentos tem a sua origem nos sentidos. Ora, as almas dos
mortos não poderiam sair das suas moradas senão para intervir nas cousas humanas.
Mas por disposição da divina providência, por vezes as almas separadas, saindo das suas moradas,
apareceram à vista dos homens. Assim Agostinho conta, no livro referido, que o mártir Felix apareceu
visivelmente aos cidadãos de Nola, quando esta cidade foi atacada pelos bárbaros. E também podemos
crer tenha sido às vezes permitido aos condenados, para advertirem e aterrarem os homens,
aparecerem aos vivos. Ou também para pedirem sufrágios, se se trata de almas do purgatório; ou por
muitas outras razões aduzídas. Mas há entre os santos e os condenados a diferença, que os santos
podem aparecer aos vivos quando quiserem, mas não os condenados. Pois, aqueles, enquanto ainda
vivem neste mundo, recebem, pelos dons da graça gratuita, o poder de obrar curas e prodígios,
maravilhas de que só o poder divino é capaz, e que não podem ser feitos por quem não recebeu os dons
referidos. Assim também nenhum inconveniente há em, por virtude da glória, ser dada uma faculdade
às almas dos santos, de modo a poderem, quando quiserem, aparecer aos vivos milagrosamente. O que
os condenados não podem senão quando lhos for permitido.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Agostinho, como se vê pela continuação do texto, fala
segundo o curso comum da natureza. ─ Mas nem daí se segue, mesmo admitindo que os mortos possam
aparecer aos vivos quando quiserem, que o façam tantas vezes quantas apareciam enquanto ainda
viviam unidos ao corpo. Porque, uma vez separados do corpo, ou se conformam absolutamente com a
vontade divina, de modo que aparecer aos vivos não lhes será possível senão enquanto pareça
conveniente por disposição divina; ou ficarão de tal modo oprimidos pela pena, que, muito mais
abismados estarão na sua miséria, que pressurosos de aparecer aos vivos.

RESPOSTA À SEGUNDA. ─ As autoridades citadas querem dizer que ninguém pode, absolutamente
falando, sair do paraíso nem do inferno; não porém que não o possam temporariamente.

RESPOSTA À TERCEIRA. ─ Como do sobredito se colhe, o lugar atribuído a uma alma lhe redunda em
pena ou em prêmio, por ficar ela cheia de alegria ou de tristeza, pelo fato de estar em tal lugar. E essa
alegria ou essa dor, pelo fato de lhe serem atribuídos esses lugares, acompanham a alma, mesmo
quando saia deles. Assim, o pontífice a quem foi dada a honra de sentar-se na cátedra da sua Igreja, não
se lhe diminui a glória, quando da cátedra se levanta, pois, embora deixe então de estar sentado nela,
nem por isso deixará esse lugar de lhe ser destinado.
Mas devemos também responder às OBJEÇÕES contrárias.

RESPOSTA À PRIMEIRA DELAS. ─ Jerônimo se refere aos Apóstolos e aos mártires, pensando no
acréscimo de poder que lhes dá a glória, e não no que lhes convém como resultante da sua natureza
mesma. E quando diz que estão em toda parte, não quer significar que estejam simultaneamente em
vários lugares ou em toda parte, mas que podem estar onde quiserem.

RESPOSTA À SEGUNDA. ─ Não há símil entre os demônios e os anjos, e as almas dos santos e dos
condenados. Os anjos bons ou maus tem como função presidir ao destino dos homens, guardando-os ou
tentando-os. O que não se pode dizer das almas humanas. Contudo, pelo poder que lhes resulta da
glória, podem as almas dos santos estar onde quiserem. Tal o que quer dizer Jerônimo.

RESPOSTA À TERCEIRA. ─ Embora possam as almas dos santos ou dos condenados estar presentes onde
aparecem, não devemos contudo crer que isso sempre se dê. Pois, às vezes essas aparições se realizam;
quer durante o sono ou durante a vigília, por obra dos bons ou maus espíritos, para instrução ou ilusão
dos vivos. Assim como também às vezes os vivos aparecem a nos dizerem muitas cousas em sonho,
embora se saiba que não estão presentes, do que Agostinho apresenta muitos exemplos.

## Art. 4 — Se o limbo do inferno é o mesmo que o seio de Abraão.
O quarto discute-se assim. ─ Parece que o limbo do inferno não é o mesmo que o seio de Abraão.

1. ─ Pois, diz Agostinho: Ainda não encontrei tomada em bom sentido a palavra interno, na Escritura.
Ora, a expressão ─ seio de Abraão ─ é tomada em bom sentido. Por isso Agostinho acrescenta: Ninguém
poderia aceitar a opinião, que não se deve tomar em bom sentido o seio de Abraão, e aquele descanso
para onde foi levado pelos anjos o pobre Lázaro. Logo, o seio de Abraão não é o mesmo que o limbo do
inferno.

2. Demais. ─ Os que estão no inferno não vêem a Deus. Ora, no seio de Abraão Se vê a Deus. Assim
Agostinho, falando de Nebridio, diz: Entenda-se o que se quiser pelo seio de Abraão, lá vive o meu
Nebridio. E mais adiante: Já não dá ouvidos às minhas palavras, mas aproxima os lábios do seu espírito à
fonte da tua verdade; e sorve a longos tragos a tua sabedoria ─ eternamente feliz. Logo, o seio de
Abraão não é o mesmo que o limbo do inferno.

3. Demais. ─ A Igreja não reza para ninguém ser levado ao inferno. Ora, reza para que os anjos levem
para o seio de Abraão as almas dos defuntos. Logo, parece que o seio de Abraão não é o mesmo que o
limbo.
Mas, em contrário. ─ Seio de Abraão se chama ao lugar para onde foi conduzido o mendigo Lázaro. Ora,
ele foi levado ao inferno; pois, àquilo da Escritura ─ Onde há casa estabelecida para todo vivente ─ diz a
Glosa: O inferno era a casa de todos os vivos, antes da vinda de Cristo. Logo, o seio de Abraão é o
mesmo que o limbo.

2. Demais. ─ Jacó dizia a seus filhos: Levareis com essa dor a minha velhice ao inferno. Logo, Jacó sabia
que, morrendo, iria ao inferno. E assim, pela mesma razão, Abraão foi transferido, pela morte, ao
inferno.

SOLUÇÃO. - As almas humanas, depois da morte, não podem alcançar o descanso senão pelo mérito da
fé: porquanto é necessário que o que se chega a Deus creia que há Deus. Ora, o primeiro exemplo da
crença foi dado aos homens por Abraão, o primeiro que se separou da sociedade dos infiéis e recebeu
um especial sinal da fé. Por isso, aquele repouso dado aos homens depois da morte se chama seio de
Abraão, como está claro em Agostinho. Ora, as almas dos santos não tiveram em todos os tempos,
depois da morte, o mesmo repouso. Pois, depois do advento de Cristo, gozam do pleno descanso,
fruindo da visão divina. Antes do advento de Cristo, porém, tinham certo repouso, pela imunidade da
pena, mas não tinham a quietude dos desejos, que dá a consecução do fim. Por isso, o estado dos
santos, antes do advento de Cristo, pode ser considerado pelo que tinham de descanso, e assim se
chama seio de Abraão; ou quanto ao que de descanso lhe faltava, e então se chama limbo do interno.
Por onde, o limbo do inferno e o seio de Abraão eram, antes do advento de Cristo, a mesma cousa,
acidental e não essencialmente falando. Por isso, nada impede, depois do advento de Cristo, existir um
seio de Abraão absolutamente diverso do limbo; porque cousas unidas por acidente podem separar-se.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Pelo que tinha de bom, o estado dos santos Patriarcas era
chamado seio de Abraão. Mas, pela sua deficiência, era denominado inferno. Assim, nem o seio de
Abraão é tomado em mau sentido, nem em bom o inferno, embora de certo modo sejam a mesma
cousa.

RESPOSTA À SEGUNDA. ─ Assim como o lugar do repouso dos santos Patriarcas, antes do advento de
Cristo, se chamava seio de Abraão, assim depois desse advento, mas em sentido diverso. Pois, como
antes do advento de Cristo, o descanso dos santos era incompleto, a mesma cousa significavam o
inferno e o seio de Abraão, porque aí não se via a Deus. Mas como depois do advento de Cristo o
descanso dos santos é completo, pois vêem a Deus, esse lugar de descanso se chama seio de Abraão, e
não mais inferno. E a esse seio de Abraão a Igreja reza para os fiéis serem conduzidos.

DONDE SE DEDUZ A RESPOSTA À TERCEIRA OBJEÇÃO. ─ E assim também deve entender-se a Glosa
àquilo do Evangelho ─ Sucedeu morrer este mendigo, etc. ─ que diz: O seio de Abraão é o lugar do
repouso dos bem-aventurados, dos quais é o reino dos céus.

## Art. 5 — Se o limbo é o mesmo que o inferno dos condenados.
O quinto discute-se assim. ─ Parece que o limbo não é o mesmo que o inferno dos condenados.

1. - Pois, conforme a Escritura, Cristo foi a mordedura do inferno, mas não no destruiu, porque de lá
retirou um certo número de almas, mas não todas. Ora, não teria sido chamado a mordedura do
inferno, se os que livrou não fossem apenas uma parte da multidão das almas lá encarceradas. Mas,
como os que livrou estavam encerrados no limbo, estavam também no inferno. Logo, o limbo é o
mesmo que o inferno, ou parte deste.

2. Demais. ─ No Símbolo se diz, que Cristo desceu ao inferno. Ora, só desceu ao limbo dos Patriarcas.
Logo, o limbo dos Patriarcas é o mesmo que o inferno.

3. Demais. ─ A Escritura diz: Tudo o que me pertence descerá ao mais profundo do inferno. Ora, Job
sendo justo e santo, desceu ao limbo. Logo, o limbo é o mesmo que o mais profundo do inferno.
Mas, em contrário. ─ Nenhuma redenção há no inferno. Ora, os santos Patriarcas foram redimidos do
inferno. Logo, o limbo não é o mesmo que o inferno.

2. Demais. ─ Agostinho diz: Não vejo como possamos crer que o descanso, em que entrou Lázaro fosse
no inferno. Ora, a alma de Lázaro desceu ao limbo. Logo, o limbo não é o mesmo que o inferno.

SOLUÇÃO. ─ A dupla luz podemos considerar as moradas das almas depois da morte: na sua situação ou
na qualidade dos lugares, i. é, se há lugares onde as almas recebam penas ou prêmios. ─ Considerado,
pois, o limbo dos Patriarcas e o inferno, quanto à qualidade de esses lugares, não há dúvida sobre a
diversidade deles. Quer porque no inferno existe a pena sensível, que não existia no limbo dos
Patriarcas; quer também por ser eterna a pena do inferno, ao passo que no limbo dos santos Patriarcas
estavam encerrados apenas temporariamente. ─ Consideradas porém as situações desses lugares, é
provável que são um mesmo lugar, ou quase contíguos, o inferno e o limbo; havendo uma parte
superior do inferno chamada limbo dos Patriarcas. Pois, os que estão no inferno sofrem penas diversas
conforme a diversidade das suas culpas. Assim, conforme a gravidade dos pecados que cometeram,
assim o lugar do inferno mais ou menos obscuro e profundo onde são encarcerados os condenados. Por
onde, os santos Patriarcas, cuja culpabilidade era mínima, ocupavam lugar mais elevado e menos
tenebroso do que o de todos os condenados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ No sentido da identidade de lugares, do inferno e do
limbo, é que a Escritura diz, que Cristo foi a mordedura do inferno e a ele desceu, para retirar do limbo
os Patriarcas.

DONDE SE DEDUZ A RESPOSTA À SEGUNDA OBJEÇÃO.

RESPOSTA À TERCEIRA. ─ Job não desceu ao inferno dos condenados, mas ao limbo dos Patriarcas. E
esse é chamado um lugar profundíssimo, não relativamente aos lugares onde se cumprem penas, mas
em comparação com os outros, no sentido em que uma mesma denominação inclui todos os lugares
onde se cumprem penas. ─ Ou podemos responder com Agostinho, quando diz, a respeito de Jacó:
Quando Jacó dizia a seus filhos ─ Entristecereis a minha velhice com uma dor que me levará aos infernos
─ temia não viesse uma dor excessiva a lhe perturbar a alma, a ponto de, perdendo o descanso dos
santos, cair no inferno dos pecadores. No mesmo sentido podemos entender as palavras de Job, que
seriam, antes, palavras de quem teme do que de quem afirma.

## Art. 6 — Se o limbo dos meninos é o mesmo limbo dos Patriarcas.
O sexto discute-se assim. ─ Parece que o limbo dos meninos é o mesmo limbo dos Patriarcas.

1. ─ Pois, a pena deve responder à culpa. Ora, pela mesma culpa estavam encerrados no limbo os
Patriarcas e os meninos, i. é, pela culpa original. Logo, devem ambos sofrer a pena no mesmo lugar.

2. Demais. ─ Agostinho diz: Mui branda é a pena dos meninos, mortos com o só pecado original. Ora,
nenhuma pena era mais branda que a sofrida pelos santos Patriarcas. Logo, ambos sofrem suas penas
no mesmo lugar.
Mas, em contrário. ─ Assim como ao pecado atual é devida uma pena temporal no purgatório, e eterna
no inferno, assim também ao pecado original é devida uma pena temporal no limbo dos Patriarcas, e
eterna no limbo dos meninos. Se, pois, inferno e purgatório não são idênticos, parece que idênticos
também não são o limbo dos meninos e o dos Patriarcas.

SOLUÇÃO. ─ O limbo dos Patriarcas e o dos meninos sem nenhuma dúvida diferem, quanto à qualidade
do prêmio ou da pena. Pois, os meninos não tem nenhuma esperança da vida eterna, que tinham os
Patriarcas no limbo, nos quais também refulgia o lume da fé e o da graça. Mas, quanto à situação,
podemos crer com probabilidade que esses lugares eram idênticos; salvo que o limbo dos Patriarcas
estava em lugar mais elevado que o dos meninos, como dissemos a respeito do limbo e do inferno.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Quanto à culpa original, os Patriarcas e os meninos não
se achavam nas mesmas condições. Pois, os Patriarcas expiavam a culpa do pecado original como culpa
pessoal; mas como culpa da natureza, constituía o pecado original um obstáculo aos Patriarcas para
entrarem no céu, por não estar ainda completamente expiada. Ao passo que constituía um obstáculo à
glória eterna, para os meninos, por lhes ser uma culpa tanto pessoal como da natureza. Daí o serem
atribuídos a uns e a outros lugares diversos.

RESPOSTA À SEGUNDA. ─ Agostinho se refere às penas incorridas por uma culpa pessoal; e essa a
sofrem brandíssima todos os culpados apenas do pecado original. Ainda mais branda, porém, é a pena
de aqueles impedidos de gozar a glória, não por culpa pessoal, mas por uma falha da natureza; e nesse
sentido, a dilação mesma da glória é considerada pena.

## Art. 7 — Se se devem distinguir os tantos receptáculos quantos os referidos.
O sétimo discute-se assim. ─ Parece que não se devem distinguir tantos receptáculos quantos os
referidos.

1. ─ Pois, os receptáculos atribuídos às almas, devem ser tantos, por causa do pecado, quantos por
causa do mérito. Ora, em razão do mérito, só um receptáculo lhes é atribuído o paraíso. Logo, também
um só lhes deve ser atribuído, em razão dos pecados.

2. Demais. ─ Os receptáculos atribuídos à alma depois da morte o são em virtude do mérito ou do
demérito. Ora, um só é o lugar onde merecem ou desmerecem. Logo, só um receptáculo lhes deve ser
assinalado depois da morte.

3. Demais. ─ Os lugares onde se expiam as penas devem corresponder às culpas cometidas. Ora, só há
três espécies de culpa ─ a original, a venial e a mortal. Logo, não deve haver mais de três receptáculos
onde se sofram as penas.
Mas, em contrário. ─ Parece que os receptáculos devem ser muito mais que os assinalados. Pois, este ar
caliginoso é o cárcere dos demônios, como lemos na Escritura. E contudo não é computado entre os
cinco receptáculos, assinalados por certos. Logo, os receptáculos são mais de cinco.

2. Demais. ─ Um é o paraíso terrestre e outro, o celeste. Ora, certos, depois desta vida foram
transferidos do paraíso terrestre, como narra a Escritura, de Enoch e de Elias. Logo, não estando o
paraíso terrestre enumerado entre os cinco receptáculos, parece que eles são mais de cinco.

3. Demais. ─ A cada estado de pecadores deve corresponder um lugar onde expiem as penas. Ora, a
quem morrer maculado só pelo pecado original e pelo venial, não lhe foi assinalado nenhum
receptáculo próprio. Pois, no paraíso não poderia entrar, por estar privado da graça. Pela mesma razão,
nem no limbo dos meninos, onde não sofrem nenhuma pena sensível, devida contudo a quem morre
em pecado venial. Semelhantemente, nem no purgatório, onde não há senão pena temporal; ora, no
caso vertente, é devida uma pena perpétua. Enfim, também não no inferno dos condenados, porque
não morreu em estado de pecado mortal atual. Logo, um sexto receptáculo lhe deve ser atribuído.

4. Demais. ─ O grau dos prêmios e das penas varia conforme as diferenças das culpas e dos méritos. Ora,
infinitos são os graus dos méritos e das culpas. Logo, devem-se distinguir infinitos receptáculos, onde as
almas serão punidas ou premiadas depois da morte.

5. Demais. ─ As vezes as almas são punidas nos lugares onde pecaram, como o diz Gregório. Ora,
pecaram no lugar onde habitamos. Logo, este lugar também deve ser computado entre os receptáculos,
e tanto mais quanto certos são punidos neste mundo pelos seus pecados, como disse o Mestre.

6. Demais. ─ Certos, apesar de mortos em estado de graça, devem ainda sofrer uma pena, por terem
alguns pecados veniais. Ao contrário, outros, apesar de mortos Em pecado mortal, merecem contudo
um prêmio por boas ações que praticaram. Ora, aos mortos em graça, mas em estado de pecado venial,
lhes é atribuído o purgatório, receptáculo onde são punidos, antes de alcançarem o prêmio. Logo e pela
mesma razão, mas inversamente, o mesmo se deve dar com os mortos em pecado mortal, mas que
praticaram certas boas obras.

7. Demais. - Assim como os Patriarcas tiveram diferida a plenitude da glória da alma até ao advento de
Cristo, assim o mesmo se dá hoje com os que vão para o céu, quanto à glória do corpo. Logo, assim
como se distingue o receptáculo dos santos Patriarcas, antes da vinda de Cristo, daquele onde
atualmente habitam, assim deve este último ser distinto daquele onde devem ser recebidos depois da
ressurreição.

SOLUÇÃO. ─ O receptáculo das almas varia conforme o estado delas. Assim, a alma unida ao corpo
mortal vive em estado de merecer; mas quando ela se separa do corpo, entra em estado de receber a
recompensa ou o castigo, conforme o mereceu. Logo, depois da morte, ou está em estado de receber o
prêmio final ou de ser privada dele. Se no de receber a retribuição final, de dois modos pode sê-la. Ou
pelo bem, e então entra no paraíso; ou pelo mal e então cai no inferno, se a culpa é atual, ou no limbo
dos meninos, se é original. Se porém o seu estado é tal que impede alcançar a retribuição final, ou será
por culpa pessoal, e então irá para o purgatório, onde as almas ficam detidas sem poder alcançar logo o
prêmio, por causa de pecados que cometeram; ou por defeito da natureza, e então irá para o limbo dos
Patriarcas, onde estes estavam impedidos de alcançar a glória, por causa do reato da natureza humana,
que ainda não podiam expiar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O bem só de um modo existe, ao passo que o mal é
multifário, como diz Dionísio e o Filósofo. Por isso, não há inconveniente em ser um o lugar onde se frui
a felicidade, e outro onde se cumprem as penas.

RESPOSTA À SEGUNDA. ─ O estado de merecer e desmerecer são um só, pois, no mesmo estado
podemos merecer e desmerecer. Por isso a todos os que se acham nesse estado devem ter o mesmo
lugar. Mas as almas, que recebem o prêmio pelo que mereceram, estão em estados diversos. Logo, o
símil não colhe.

RESPOSTA À TERCEIRA. ─ Pela culpa original pode um ser punido duplamente, como do sobredito se
colhe: em razão da pessoa, ou em razão só da natureza. Por isso a tal culpa corresponde um duplo
limbo.

RESPOSTA À QUARTA. ─ O ar caliginoso que nos rodeia, não é atribuído aos demônios como lugar onde
recebam a paga do que merecem, mas para o exercício da função a que são destinados, que é nos
exercer na luta pelo bem. Por isso, esse lugar não é enumerado entre os receptáculos de que ora
tratamos; pois, o lugar que propriamente lhes compete é o fogo do inferno, como o ensina o Evangelho.

RESPOSTA À QUINTA. ─ O paraíso terrestre pertence, antes, ao estado do homem viandante que ao
estado terminal onde recebe a paga do merecido. Por isso não é contado entre os receptáculos de que
agora tratamos.

RESPOSTA À SEXTA. ─ A hipótese do argumento é impossível. Mas se fosse possível, esses tais seriam
punidos no inferno eternamente. Pois, se o pecado venial é punido temporalmente no purgatório, é por
causa da graça que o acompanha. Mas se se acrescentasse à culpabilidade do pecado mortal, que não é
acompanhado de nenhuma graça, seria punido no inferno com a pena eterna. Ora, aquele que
supusermos culpado do pecado original e do pecado venial não teria a graça; seria portanto
eternamente punido no inferno.

RESPOSTA À SÉTIMA. ─ A diversidade de graus nas penas ou nos prêmios não diversifica os estados, e é
pela diversidade deles que se distinguem os receptáculos.

RESPOSTA À OITAVA. ─ Embora as almas separadas sejam às vezes punidas neste mundo que
habitamos, não se pode daí concluir seja este o lugar próprio para aqui cumprirem as suas penas; o que
só para nossa instrução se dá; a fim de, vendo-Ih'as, abstenhamo-nos das culpas. ─ Quanto às almas
ainda unidas ao corpo, neste mundo punidas pelos seus pecados, não vêem ao caso; pois essa pena não
as põe fora do estado de merecer ou desmerecer. Ora, agora tratamos dos receptáculos atribuídos à
alma depois que já não estão mais no estado de merecer ou desmerecer.

RESPOSTA À NONA. ─ Não há mal que não vá de mistura com algum bem, mas o sumo bem exclui toda
mistura de mal. Por onde, só podem entrar no gozo da felicidade, que é o sumo bem, os que foram
purificados de todo mal. Por isso é necessário haver um lugar onde se purifiquem, se ainda não estavam
perfeitamente puros ao sair da vida. Mas os que foram precipitados no inferno não são destituídos de
todo bem. Portanto, não colhe o símil; porque os que estão no inferno podem receber o prêmio das
suas boas obras, enquanto o bem que praticaram contribui para lhes mitigar as penas.

RESPOSTA À DÉCIMA. ─ Na glória da alma consiste o prêmio essencial; a glória do corpo porém, que lhe
redunda da alma, consiste toda e quase originalmente, na da alma. Portanto, a privação da glória desta
diversifica os estados, mas não a privação da glória do corpo. Por isso também o mesmo lugar ─ o céu
empíreo ─ é atribuído às almas dos santos separadas do corpo e às unidas a corpos gloriosos. Mas as
almas dos Patriarcas, antes de receberem a glória da alma, não deviam ter a mesma morada que
tiveram depois.