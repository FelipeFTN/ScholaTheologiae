# Questão 78: Do termo original da ressurreição.
Em seguida devemos tratar do termo original da ressurreição.
E nesta questão discutem-se três artigos:

## Art. 1 — Se para todos a morte será o termo original da ressurreição.
O primeiro discute-se assim. ─ Parece que a morte não será para todos o termo original da
ressurreição.

1. ─ Pois, certos não morrerão mas serão revestidos de imortalidade; assim, o Símbolo diz que o Senhor
virá julgar os vivos e os mortos. Ora, isto não pode entender-se do tempo do juízo, porque então todos
estarão vivos. Logo, essa distinção entre vivos e mortos há de necessariamente referir-se ao tempo
precedente. Portanto, nem todos morrerão antes do juízo.

2. Demais. ─ Um desejo natural e comum não pode ser a tal ponto estéril e vão, que nunca se realize.
Ora, segundo o Apóstolo, é desejo comum, que não queremos ser despojados, mas sim revestidos por
cima. Logo, certos haverá que nunca serão despojados do corpo pela morte, mas se revestirão da glória
da ressurreição.

3. Demais. ─ Agostinho diz, que as quatro últimas petições da oração dominical concernem à vida
presente. Uma delas é ─ perdoai-nos as nossas dívidas. Logo, a Igreja pede lhe sejam perdoadas nesta
vida as suas dívidas. Ora, a oração da Igreja não pode ser a tal ponto vã, que não seja ouvida, segundo
aquilo do Evangelho: Se vós pedirdes a meu Pai alguma causa em meu nome, ele vo-la há de dar.
Portanto, a Igreja, nalgum tempo desta vida, alcançará a remissão de todas as dívidas. Ora, uma dessas
dívidas que contraímos pelo pecado dos nossos primeiros pais, é nascermos com o pecado original.
Logo, um dia o Senhor concederá à Igreja, que os homens nasçam sem pecado original. Ora, a morte é a
pena do pecado original. Portanto, certos homens, no fim do mundo, não morrerão. Donde a mesma
conclusão que antes.

4. Demais. ─ O sábio deve sempre escolher o caminho mais curto. Ora, transferir imediatamente à
impassibilidade da ressurreição os que então estiverem vivos é caminho mais curto do que ressurgi-los
da morte para a imortalidade, depois de terem morrido. Logo, Deus, suma sabedoria, tomará esse
caminho em relação aos que então estiverem vivos. Donde a mesma conclusão que antes.
Mas, em contrário. ─ Diz o Apóstolo: O que tu semeias não se vivifica se primeiro não morre. E fala, com
a semelhança de semente da ressurreição dos corpos. Logo, os corpos ressurgirão da morte.

2. Demais. ─ O Apóstolo diz: Porque como a morte veio por Adão, assim também todos serão vivificados
em Cristo. Ora, em Cristo todos serão vivificados. Logo, em Adão todos morrerão. Portanto, da morte é
que todos ressurgirão.

SOLUÇÃO. ─ Os Santos Padres resolvem diversamente esta questão, como diz o Mestre. A opinião
porém mais segura e comum é que todos morrerão e depois ressurgirão. ─ E isto por três razões.
Primeiro, por estar mais de acordo com a justiça divina, que condenou a natureza humana por causa do
pecado cometido pelos nossos primeiros pais; de modo que todos os que, pela origem natural deles
recebera, contraíram a infecção do pecado original, ficassem consequentemente sujeitos à morte. ─
Segundo, por estar mais de acordo com a divina Escritura, que
prediz a futura ressurreição de todos. Ora, a ressurreição não é própria senão de quem perdeu a vida
pela dissolução do corpo, como diz Damasceno. ─ Terceiro, porque melhor concorda com a ordem da
natureza, que nos mostra que tudo o corrupto e viciado não se reduz à sua pureza primitiva senão
mediante a corrupção; assim o vinagre não volta a ser vinho senão depois de corrupto e transformado
no suco da uva. Ora, como a natureza humana degradou-se e ficou sujeita à morte, não poderá
readquirir a imortalidade senão mediante a morte. Esta
opinião melhor concorda com a ordem da natureza ainda por outra razão. Porque, segundo ensina
Aristóteles, o movimento do céu é como que a vida para todos os seres da natureza; assim como o
movimento do coração é de certo modo a vida de todo o corpo. Por onde, assim como cessado o
movimento do coração, todos os membros morrem, assim, cessado o movimento do céu, não pode
nenhum ser vivo continuar a ter aquela vida que se conservava por influência desse movimento. Ora,
essa é a vida que agora vivemos. Por onde, é necessário que a percam os que estiverem vivos quando
cessar o movimento do céu.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Essa distinção entre mortos e vivos não deve aplicar-se
ao tempo mesmo do juízo, nem à totalidade do tempo passado, porque todos os que deverão ser
julgados Em certo tempo foram vivos e, em certo outro, mortos; mas sim, àquele tempo determinado
imediatamente precedente ao juízo, quando começarem a se manifestar os sinais dele.

RESPOSTA À SEGUNDA. ─ O desejo perfeito dos santos não pode ser vão; mas nada impede que lh'o
seja o desejo condicionado. Ora, quando desejam ser revestidos da imortalidade sem serem despojados
do corpo mortal, se o for possível, nutrem um desejo condicionado. E esse é chamado por certos
veleidade.

RESPOSTA À TERCEIRA. ─ É errôneo afirmar que alguém mais, além de Cristo, foi concebido sem pecado
original. Do contrário, os que assim fossem concebidos não precisariam da redenção, operada por
Cristo. E este seria então o redentor de todos os homens. ─ Nem colhe dizer que dessa redenção não
precisaram por lhes ter sido concedido que fossem concebidos sem pecado; porque ou a graça lhe foi
feita aos pais de ficarem isentos do vicio da natureza, sem o que não poderiam engendrar filhos isentos
do pecado original; ou foi feita à natureza mesma, que foi sanada. Ora, devemos admitir que cada um
precisa pessoalmente da redenção de Cristo, e não só em razão da natureza. Pois, ser livrado do mal ou
perdoado de uma dívida não o pode senão quem a contraiu ou foi contaminado do mal. Por onde, não
poderiam todos colher em si mesmos o fruto da oração dominical, se não tivessem todos nascido
devedores e sujeitos ao mal. Portanto, as expressões ─ perdão das dívidas, ou, liberação do mal ─ não
podem aplicar-se a quem nasceu sem dívida ou isento do mal, senão só a quem, nascido devedor, foi
depois liberado pela graça de Cristo. ─ Mas mesmo concedendo que se possa afirmar sem erro, que
certos morrerão, daí não se pode deduzir que nasceram sem culpa original, embora a morte seja a pena
do pecado original. Porque Deus pode, na sua misericórdia, perdoar a pena a que um esteja obrigado
pela culpa pretérita; assim, quando despediu a adúltera sem lhe impor nenhuma pena. Do mesmo
modo, poderá liberar da morte os que lhe contraíram o reato, nascendo com o pecado original. Por
onde, não há sequência no raciocínio: Se não hão de morrer é que nasceram sem pecado original.

RESPOSTA À QUARTA. ─ Devemos escolher sempre o caminho mais curto, mas nem sempre, senão só
quando mais ou igualmente acomodado à consecução do fim. O que não se dá no caso vertente, como
do sobre dito se colhe.

## Art. 2 — Se todos ressuscitarão das suas cinzas.
O segundo discute-se assim. ─ Parece que nem todos ressurgirão das cinzas.

1. ─ Pois, a ressurreição de Cristo é o modelo da nossa. Ora, Cristo não ressurgiu das cinzas, porque a
sua carne não viu a corrupção, no dizer da Escritura. Logo, nem todos ressurgirão das cinzas.

2. Demais. ─ O corpo do homem nem sempre é queimado. Ora, nada pode ser reduzido a cinzas senão
pela combustão. Logo, nem todos os homens ressurgirão das cinzas.

3. Demais. ─ O corpo de um homem morto não se reduz a cinzas imediatamente depois da morte. Ora,
certos ─ os que viverem no fim do mundo ─ ressurgirão logo depois de mortos, como diz o Mestre. Logo,
nem todos ressurgirão das cinzas.

4. Demais. ─ O termo de origem corresponde ao termo final. Ora, o termo final da ressurreição não é o
mesmo para os bons e para os maus, conforme àquilo do Apóstolo: Todos certamente ressuscitaremos,
mas nem todos seremos mudados. Logo, o termo de origem não será o mesmo para todos. Portanto, se
os maus hão de ressurgir das suas cinzas, não o hão de os bons.
Mas, em contrário, diz Haymo: Todos os nascidos em pecado original terão que cumprir a sentença ─ és
terra e em terra te tornarás. Ora, todos os que ressurgirem, na ressurreição universal, foram réus do
pecado original, ou por terem assim nascido do ventre materno, ou pelo menos por terem sido
concebidos assim no ventre materno. Logo, todos ressurgirão das suas cinzas.

2. Demais. ─ Muitas cousas há no corpo humano que não pertencem verdadeiramente à natureza
humana. Ora, tudo isso há de ser eliminado. Logo, todos os corpos hão necessariamente de reduzir-se a
cinzas.

SOLUÇÃO. ─ Pelas mesmas razões por que provamos que todos ressurgirão da morte, provaremos
também que todos ressurgirão das cinzas, na ressurreição universal: salvo se a certos, por privilégio
especial da graça lhes for concedido o contrário, assim como também lhes pode ser concedido ressurgir
antes. Pois, a Escritura Santa prediz a ressurreição, assim também a reconstituição dos corpos. Por onde
e necessariamente, assim como todos hão de morrer para poderem com verdade ressurgir, assim os
corpos de todos hão de dissolver-se para que todos possam reconstituir-se. Porque, assim como a
justiça divina infligiu aos homens a morte como pena, assim também a dissolução do corpo, conforme o
diz a Escritura: Tu és terra e em terra te tornarás. Do mesmo modo, a ordem da natureza exige não
sàmente a separação da alma do corpo, mas ainda a mistura dos elementos; assim como o vinagre não
pode retomar a qualidade do vinho senão depois de feita a sua resolução na matéria primitiva. Ora, essa
mistura mesma dos elementos é causada e conservada pelo movimento do céu; cessado o qual, todos
os corpos mistos se resolverão nos seus elementos simples.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A ressurreição de Cristo é o modelo da nossa, quanto ao
termo final, mas não quanto ao termo original.

RESPOSTA À SEGUNDA. ─ Por cinzas se entendem todos os restos do corpo humano dissolvido, por duas
razões. ─ Primeiro, porque era costume dos antigos queimar o corpo dos mortos e conservar-lhes a
cinza. Donde o ter prevalecido o costume de se chamarem cinzas os elementos em que se resolve o
corpo humano. ─ Segundo, pela causa da resolução, o fogo da concupiscência, que infeccionou
radicalmente o corpo humano. Por isso, a fim de purificar dessa infecção, há de o corpo humano
resolver-se até os seus elementos componentes. Ora, do que se resolve pelo fogo dizermos que se
reduziu a cinzas. Donde a denominação de cinzas dada aquilo em que se o corpo humano resolve.

RESPOSTA À TERCEIRA. ─ O fogo, que há de purificar a face do mundo, poderá reduzir imediatamente a
cinzas os corpos dos que viverem então, assim como resolverá a matéria primitiva os outros corpos
mistos.

RESPOSTA À QUARTA. ─ O movimento não se especifica pelo seu termo de origem, mas pelo termo
final. Por onde, a ressurreição dos santos, que será gloriosa, há de por força diferir da dos ímpios, que
não será gloriosa, pelo termo final e não pelo termo original. Pois, como acontece frequentemente,
pede um corpo partir do mesmo ponto de origem e chegar a pontos finais diversos; poderá, de negro,
passar a ser branco ou amarelo.

## Art. 3 — Se as cinzas, de que o corpo humano se reconstituirá, tem alguma inclinação natural para a alma que lhe estava unida.
O terceiro discute-se assim. ─ Parece que as cinzas, de que o corpo humano se reconstituirá, tem uma
inclinação natural para a alma que lhe estava unida.

1. ─ Pois, se nenhuma inclinação tivesse para a alma, estaria para ela como as cinzas dos outros corpos.
Logo, nenhuma diferença haveria em o corpo, que devesse estar unido a essa alma, ser reconstituído
das cinzas próprias dele ou das de outro. O que é falso.

2. Demais. ─ Maior é a dependência do corpo, da alma, que da alma, do corpo. Ora, a alma separada do
corpo ainda tem uma certa dependência dele; por isso fica retardada a sua tendência para Deus, pelo
desejo que tem a se unir ao corpo, como diz Agostinho. Logo e com maior razão, separado da alma, a
que estava unido, tem o corpo para ela uma inclinação natural.

3. Demais. ─ Job diz: Os seus ossos se encherão dos vícios da sua mocidade e com ele dormirão no pó.
Ora, vícios só os pode ter a alma. Logo, as cinzas do corpo ainda conservarão uma inclinação natural
para a alma a que estava unida.
Mas, em contrário. ─ O corpo humano pode resolver-se nos seus elementos próprios ou converter-se na
carne dos outros animais. Ora, os elementos são homogêneos; e semelhantemente, a carne do leão ou
de outro animal qualquer. Logo, como as partes dos elementos ou dos animais não tem nenhuma
inclinação natural para alma a que estiverem unidas, também as partes em que se converteu o corpo
humano terá qualquer inclinação para a alma a que esteve unido. O que se conclui do seguinte lugar de
Agostinho: O corpo humano, seja qual for a substância dos outros corpos ou os elementos a que se
reduza; quaisquer que sejam os animais ou os homens a que sirva de alimento ou em cujas carnes se
transforme, voltará a unir-se num momento àquela alma humana, que primeiro a animou para que se
tornasse um homem, vivesse e crescesse.

2. Demais. ─ A toda inclinação natural corresponde um agente natural; aliás falharia em matéria
necessária. Ora, nenhum agente natural pode fazer com que um corpo humano, reconstituído das suas
cinzas, se una de novo à alma a que pertencia. Logo, essas cinzas nenhuma inclinação natural tem à
referida união.

SOLUÇÃO. ─ Nesta matéria há três opiniões.
Uns dizem que os corpos humanos nunca se resolverão nos seus elementos primitivos. E assim as suas
cinzas sempre conservarão uma virtude acrescentada aos elementos, que produz uma inclinação natural
para a mesma alma. ─ Mas esta opinião encontra à autoridade citada de Agostinho, tanto literalmente,
quanto ao sentido; pois, todos os compostos de elementos contrários podem resolver-se nesses
elementos componentes. Por isso outros são de opinião que essas partes elementares, em que o corpo
humano se resolve, conservam mais luz que os outros elementos, por terem estado unidos a uma alma
humana. Por isso tem uma certa inclinação para as almas humanas. ─ Mas, não menos frívola que a
anterior é esta opinião. Porque as partes dos elementos tem a mesma natureza e participam igualmente
da luz e da obscuridade.
Devemos, portanto, admitir que essas cinzas não têm nenhuma inclinação natural para a ressurreição,
senão só por ordem da divina providência, que determinou a essas cinzas se unirem de novo à alma.
Donde resulta que as partes dos elementos se unirão às almas a que anteriormente pertenceram, e não
partes alheias.
Donde se deduz a resposta à primeira objeção.

RESPOSTA À SEGUNDA. ─ A alma separada do corpo conserva a mesma natureza que tinha, quando
estava unida ao corpo. O que não se dá com o corpo. Por onde, o símil não colhe.

RESPOSTA À TERCEIRA. ─ As palavras citadas de Job não devem entender-se como significando que as
cinzas dos mortos permanecem atualmente pecaminosas; mas que, segundo a ordem da divina justiça,
essas cinzas são destinadas à separação do corpo que, pelos pecados cometidos, será eternamente
cruciado.