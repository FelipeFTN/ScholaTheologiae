# Questão 24: Da absolvição da excomunhão.
Em seguida devemos tratar da absolvição da excomunhão.
E nesta questão discutem-se três artigos:

## Art. 1 — Se qualquer sacerdote pode absolver o seu súdito da excomunhão.
O primeiro discute-se assim. — Parece que qualquer sacerdote pode absolver o seu súdito da
excomunhão.

1. — Pois, mais forte é o vínculo do pecado que o da excomunhão. Ora, qualquer sacerdote pode
absolver o seu súdito do pecado. Logo, com muito maior razão, da excomunhão.

2. Demais. — Desaparecida a causa desaparece o efeito. Ora, a causa de excomunhão é o pecado
mortal. Logo, como qualquer sacerdote possa absolver desse pecado mortal, poderá também absolver
da excomunhão. Mas, em contrário. — Quem pode excomungar também pode absolver o
excomungado. Ora, os sacerdotes inferiores não podem excomungar os seus súditos. Logo, nem
absolver.

SOLUÇÃO. — De uma excomunhão menor pode absolver quem o pode da participação no pecado. Mas
se a excomunhão for maior — ou terá sido proferida pelo juiz, e então quem a aplicou, ou o seu
superior, também poderá absolver dera; ou terá sido aplicada por direito, e então o bispo ou mesmo um
sacerdote pode absolver, exceto seis casos que o autor do direito, isto é, o Papa, reservou a si. O
primeiro é o de lançar mãos sobre um clérigo ou um religioso; o segundo, o do que foi denunciado por
ter incendiado uma igreja;o terceiro, o denunciado de ter arrombado uma Igreja; quarto, o de quem
comunica in divinis cientemente, com quem foi nominalmente excomungado pelo Papa; o quinto, o de
quem falsifica as cartas da Sé Apostólica; o sexto, o de quem comunica com o crime do excomungado.
Pois, não deve ser absolvido senão por quem excomungou, mesmo se não for seu súdito; salvo se, por
dificuldade de ir ter com ele, o excomungado fosse absolvido pelo bispo, pelo seu sacerdote próprio,
feito contudo o juramento, que obedecerá à ordem do juiz que proferiu a sentença.
No primeiro caso porém há oito exceções. A primeira, se é artigo de morte, quando de qualquer
excomunhão pode o excomungado ser absolvido por qualquer sacerdote; a segunda, quanto se trata de
porteiro de pessoa poderosa e que agrediu o clérigo ou sacerdote, mas não por ódio nem
intencionalmente; a terceira, se quem o fez foi uma mulher; a quarta, se um escravo, cuja ausência, sem
culpa sua, prejudicou o seu dono a quinta, se um regular agride outro, se não houver excesso no ato de
violência; a sexta, se o culpado é um pobre; a sétima, se um impúbere, um velho ou um valetudinário; a
oitava, se houver inimizade capital entre o agressor e a vítima.
Há também outros sete casos, em que quem agredir um clérigo não incorre em excomunhão. Primeiro
se, por causa de disciplina, como mestre ou prelado, é que o fez; segundo, por jocosa leviandade;
terceiro pelo ter apanhado praticando uma turpitude com a esposa, a mãe, a irmã ou a filha; quarto, se
repelir imediatamente a força com a força; quinto, se ignorar que é clérigo; sexto, se o encontrar em
estado de apostasia, depois da terceira advertência; sétimo se transferir-se o clérigo a uma situação que
lhe é absolutamente contrária, como se se fizer soldado, ou cair em bigamia.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora o vínculo do pecado seja, absolutamente
falando, mais forte que o da excomunhão, contudo de certo modo o da excomunhão é mais forte,
porque não somente obriga perante a Deus mas também perante a Igreja. Por Isso, para absolver da
excomunhão é necessária a jurisdição no foro externo; não porém para a absolvição do pecado; nem se
exige a garantia do juramento, como se exige para a absolvição da excomunhão, pois, o juramento faz
desaparecer as dúvidas existentes entre os homens, segundo o Apóstolo,

RESPOSTA À SEGUNDA. — Como o excomungado não participa dos sacramentos da Igreja, o sacerdote
não no pode absolver da culpa, se não for este, primeiro, absolvido da excomunhão.

## Art. 2 — Se alguém pode ser absolvido contra a vontade.
O segundo discute-se assim. — Parece que ninguém pode ser absolvido contra a vontade.

1. — Pois, os bens espirituais não se conferem a ninguém contra a vontade. Ora, a absolvição da
excomunhão é um benefício espiritual. Logo, a ninguém pode ser dada contra a vontade.

2. Demais. — A causa da excomunhão é a contumácia. Ora, sobretudo contumaz é quem não quer ser
absolvido, por desprezo pela excomunhão. Logo, não pode ser absolvido.
Mas, em contrário. — A excomunhão pode ser imposta a alguém contra a sua vontade. Ora, o que
adquirimos sem cooperação da nossa vontade também podemos perder sem essa cooperação, como o
demonstram os bens da fortuna. Logo, pode-se impor a excomunhão a alguém contra a sua vontade.

SOLUÇÃO. - O mal da culpa e o da pena diferem em que o princípio da culpa esta em nós, por ser todo
pecado voluntário. O princípio da pena porém esta às vezes fora de nós, pois, não é necessário seja a
pena voluntária, antes, é da natureza dela ser contra a vontade. Por onde, assim como os pecados não
os cometemos senão por vontade, assim a ninguém se lhe perdoam contra a vontade. Mas a
excomunhão, assim como pode ser imposta contra a vontade do excomungado, assim também contra a
sua vontade pode ser absolvido.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A objeção é verdadeira relativamente aos bens
espirituais que dependem da nossa vontade, tais as virtudes que não podemos involuntariamente
perder. A ciência porém, embora bem espiritual, podemos perdê-la contra a nossa vontade, p. ex., por
uma doença. Logo, a razão aduzida não vem a propósito.

RESPOSTA À SEGUNDA. — Mesmo ao contumaz se lhe pode discreta e justamente levantar a
excomunhão, se se vir que isso lhe convém à salvação, pois para seu remédio é que lhe foi ela lançada.

## Art. 3 — Se pode o excomungado ser absolvido de uma excomunhão, sem o ser de todas.
O terceiro discute-se assim. — Parece que não pode o excomungado ser absolvido de uma
excomunhão, sem o ser de todas.

1. — Pois, o efeito deve ser proporcionado à causa. Ora, a causa da excomunhão é o pecado. E como
ninguém pode ser absolvido de um pecado sem o ser de todos, também não poderá ser de uma
excomunhão sem o ser de todas.

2. Demais. — A absolvição da excomunhão se faz na Igreja. Ora, quem já está sob o peso de uma
excomunhão está fora da Igreja. Logo, enquanto uma permanece, não pode ser absolvido de outra.
Mas, em contrário. — A excomunhão é uma pena. Ora, podemos ficar livres de uma pena, sem o
ficarmos de outra. Logo, pode o excomungado ser absolvido de uma excomunhão sem o ser de outra.

SOLUÇÃO. — As excomunhões não tem entre si nenhuma conexão. Por isso pode o excomungado ser
absolvido de uma sem o ser de outra.
Mas, nesta matéria, devemos saber que o excomungado às vezes o é por várias excomunhões lança das
pelo mesmo juiz. E então, absolvido de uma, entende-se absolvido de todas, salvo determinação em
contrário; ou quando o que está sob o peso de várias excomunhões e pede a absolvição de uma só das
causas dela. — Outras vezes porém é excomungado por várias excomunhões e por vários juízos. E
então, o ser absolvido de uma não implica em o ser de outra; salvo se todos os juízes, a pedido do
excomungado, confirmarem a absolvição; ou se todos derem ao excomungado uma mesma absolvição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Todos os pecados são conexos na aversão da vontade,
de Deus, com cuja aversão não pode coexistir a remissão dos pecados; por isso um pecado pode ser
absolvido sem o outro. Ora, as excomunhões não tem nenhuma conexão dessa natureza. Nem, além
disso, a absolvição da excomunhão fica impedida por contrariedade com a vontade. Logo, a objeção não
colhe.

RESPOSTA À SEGUNDA. — Assim como o excomungado estava separado da Igreja por várias causas,
assim é possível que essa separação seja removida quanto a uma causa e não quanto a outra.