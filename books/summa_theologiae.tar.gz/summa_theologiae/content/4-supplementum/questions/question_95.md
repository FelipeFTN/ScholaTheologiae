# Questão 95: Dos dotes dos bem-aventurados.
Em seguida devemos tratar dos dotes dos bem-aventurados.
E nesta questão discutem-se cinco artigos:

## Art. 1 — Se devemos atribuir dotes aos bem-aventurados.
O primeiro discute-se assim. ─ Parece que não devemos atribuir nenhuns dotes aos bem-aventurados.

1. ─ Pois, o dote, segundo o direito, é o que é dado ao esposo para obviar aos encargos do matrimônio.
Ora, os santos não desempenham o papel de esposa, mas antes de esposo, enquanto membros da,
Igreja. Logo, não se lhes dão dotes.

2. Demais. - Segundo o direito, os dotes são dados não pelo pai do esposo, mas pelo da esposa, Ora,
todos os dons da beatitude são dados aos santos pelo Pai do Esposo, i. é, Cristo, segundo aquilo da
Escritura: Toda a dádiva em extremo excelente e todo o dom perfeito vem lá de cima e desce do Pai das
luzes, etc. Logo, esses dons conferidos aos bem-aventurados não se devem chamar dotes.

3. Demais. ─ No matrimônio carnal os dotes são dados para mais facilmente se suportarem os encargos
do matrimônio. Ora, o matrimônio espiritual não comporta nenhuns encargos, sobretudo no estado da
Igreja triunfante. Logo, não se lhe devem atribuir quaisquer dotes.

4. Demais. ─ Dotes não se dão senão em vista do matrimônio. Ora, o matrimônio espiritual é contraído
com Cristo, pela fé, segundo o estado da Igreja militante. Logo e pela mesma razão, se certos dotes
convêm aos bem-aventurados, convirão também aos santos que ainda vivem neste mundo. Ora, a estes
não convêm. Logo, nem aos bem-aventurados.

5. Demais. ─ Os dotes fazem parte dos bens exteriores chamados bens de fortuna. Ora, os prêmios dos
bem-aventurados serão bens internos. Logo, não devem chamar-se dotes.
Mas, em contrário. ─ O Apóstolo diz: Este sacramento é grande, mas eu digo em Cristo e na Igreja.
Donde se conclui que o matrimônio espiritual é significado pelo carnal. Ora, no matrimônio carnal a
noiva dotada é levada à casa do noivo. Logo, como os santos, quando entram na bem-aventurança, são
levados à mansão de Cristo, parece que com certos dotes hão de ser dotados.

2. Demais. ─ Dão-se dotes, no matrimônio carnal, para lhe aliviar os encargos. Ora, o matrimônio
espiritual é mais deleitável que o corporal. Logo, a ele sobretudo se lhe devem atribuir dotes.

3. Demais. ─ Os ornatos das noivas fazem parte do dote. Ora, os santos o ornato lhes consiste em serem
introduzidos na glória, conforme aquilo da Escritura: Ele me cobriu com vestidura de salvação como a
esposa ornada dos seus colares. Logo, os santos na pátria terão dotes.

SOLUÇÃO. ─ Sem duvida aos bem-aventurados, quando introduzidos na glória. Deus, lhes dá certos dons
que lhes constituem ornatos; e esses ornatos o Mestre lhes chama dotes. Daí a seguinte definição do
dote, no sentido em que agora dele tratamos: O dote é o ornato perpétuo do corpo e da alma,
suficiente à vida e que dura perenemente na eterna beatitude. E essa noção se funda na semelhança do
dote corporal com que se orna a esposa e providencia os meios com que possa o esposo sustentar
suficientemente a ela e aos filhos. E contudo o dote pertence à esposa, que nunca poderá ser dele
privada, de modo que a ela reverterá, uma vez dissolvido o matrimônio.
Mas quanto à significação da palavra, variam as opiniões.
Assim, uns dizem que a significação do dote não se funda em nenhuma semelhança do matrimônio
corpóreo; mas no uso comum de falar pelo qual chamamos dote a toda perfeição ou ornato de qualquer
homem. Assim, dizemos que é dotado de ciência quem é realmente sábio. Nesse sentido usou Ovídio do
vocábulo, no verso:
Agrada com o dote com que puderes agradar.
Mas esta explicação não convém totalmente. Porque sempre que empregamos um nome para significar
alguma cousa, não costumamos tomá-lo em sentido translato, senão fundados em alguma semelhança.
Por onde, como na sua aplicação primária a palavra dote foi usada para significar o matrimônio carnal, é
forçoso que qualquer outra significação desse vocábulo se funde nalguma semelhança com a
significação principal.
Por isso outros dizem que a semelhança se funda em que o dote propriamente significa um dom, que no
matrimônio corporal é dado à esposa pelo esposo, quando é levada para a casa deste e que lhe constitui
a ela um ornato. O que se deduz das palavras de Sichem a Jacó e aos seus filhos: Aumentai o dote e pedi
dádivas. E noutro lugar da Escritura: Se alguém seduzir a uma donzela que ainda não está desposada e
dormir com ela, dotá-la-á e a terá por mulher. Por isso o ornato dado por Cristo aos santos, que
alcançarem o dom da glória, se chama dote.
Mas esta explicação colide manifestamente com o que dizem os juristas, a quem compete decidir nesta
matéria. Assim, dizem que o dote é propriamente uma doação feita pela mulher ao marido para
suportar os encargos do matrimônio. Quanto ao que o noivo dá à noiva, chama-se doação por causa de
núpcias. E este sentido tem a palavra dote no lugar da Escritura, onde diz que Faraó, rei do Egito, veio e
tomou Gazer e o deu em dote à sua filha, esposa de Salomão, ─ Nem colhem contra esta explicação as
autoridades citadas. Pois, embora fosse costume ser o dote constituído pelo pai da noiva, pode contudo
se dar que o noivo ou o seu pai constituam o dote em lugar do pai da noiva. O que de dois modos pode
dar-se. Ou pelo seu grande afeto para com ela, como no caso de Hemor, pai de Sichem, que quis dar o
dote que devia receber, por causa do seu filho para com a noiva deste; ou tal se da como uma pena para
com o noivo, que deve dar, de seus bens, um dote à virgem que corrompeu, dote que deveria ter sido
constituído pelo pai da moça. E tal é o sentido da autoridade citada de Moisés.
Por isso, segundo outros, devemos dizer que, no matrimônio corporal chama-se propriamente dote o
que é dado pelos parentes da mulher aos parentes do marido, para obviar aos encargos do matrimônio,
como se disse.
Mas então subsiste a dificuldade, de como adaptar essa significação ao nosso propósito; porque os
ornatos, na beatitude, são dados à esposa espiritual pelo pai do esposo. O que se tornará manifesto nas
respostas aos argumentos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora, no matrimônio carnal o dote é dado ao esposo
para que dele use, contudo o domínio e a propriedade dele pertence à esposa. O que resulta do fato de,
segundo o direito, ser o dote conservado à esposa, uma vez dissolvido o matrimônio. E assim também
no matrimônio espiritual, os ornatos mesmos dados à esposa espiritual, i. é, à Igreja e aos seus
membros, são por certo propriedades do esposo, enquanto lhe redundam em glória e honra dele; mas
da esposa, enquanto que com eles se adorna.

RESPOSTA À SEGUNDA. ─ O pai do Esposo, i. é, de Cristo, é só a pessoa do Pai; ao passo que o Pai da
esposa é toda a Trindade. Pois, a ação sobre as criaturas pertence a toda a Trindade. Por isso tais dotes,
no matrimônio espiritual, são dados, propriamente falando, antes pelo pai da esposa que pelo Pai do
esposo. ─ Mas essa calação, embora feita por todas as Pessoas da Trindade, pode contudo apropriar-se
a cada uma das Pessoas, de certo modo. A Pessoa do Pai, como ao que dá; porque nele reside a
autoridade; a ele também é própria a paternidade em relação à criatura, de modo que assim o mesmo é
o Pai do esposo e da esposa. É própria também ao Filho, enquanto feita por causa dele e por meio dele.
Ao Espírito Santo enfim enquanto feita nele e segundo ele; pois o amor é a razão de toda doação.

RESPOSTA À TERCEIRA. ─ Ao dote convém, essencialmente, o efeito que causa, a saber, suportar os
encargos do matrimônio. Mas, acidentalmente, os obstáculos que remove, a saber, o ônus do
matrimônio, que fica mais leve. Assim, como o efeito essencial da graça é tornar alguém justo; mas o
acidental será fazer do ímpio um justo. Embora, pois, no matrimônio espiritual não haja nenhuns ônus, é
acompanhado porém da suma felicidade. E para consumar plenamente essa felicidade dotes são feitos à
esposa, .de modo que, por eles se una deleitavelmente com o esposo.

RESPOSTA À QUARTA. ─ Não era costume dar dotes à esposa quando era desposada, senão quando
conduzida à casa do esposo para que realmente este tomasse posse dela. Ora, enquanto estamos nesta
vida, vivermos ausentes do Senhor. Por onde, os dons, feitos aos santos neste mundo, não se chamam
dotes; senão só aqueles que lhes são feitos quando alcançam a glória, onde gozam do Esposo face à
face.

RESPOSTA À QUINTA. ─ O matrimônio espiritual requer a beleza interior, conforme aquilo da Escritura:
Toda a glória da que é filha do Rei é de dentro. Ora, o matrimônio espiritual requer a beleza interior. Por
onde, não é necessário que tais dotes sejam dados, no matrimônio espiritual, como o são no carnal.

## Art. 2 — Se dote é o mesmo que beatitude.
O segundo discute-se assim. ─ Parece que dote é o mesmo que beatitude.

1. ─ Pois, como resulta da definição anterior do dote, o dote é um ornato do corpo e da alma, que dura
perpetuamente, na eterna beatitude. Ora, a beatitude da alma é um ornato dela. Logo, a beatitude é
um dote.

2. Demais. ─ O dote é o meio de a esposa se unir aprazívelmente ao esposo. Ora, tal é a beatitude do
matrimônio espiritual. Logo, a beatitude é um dote.

3. Demais. ─ A visão, segundo Agostinho, é a substância total da beatitude. Ora, a visão é considerada
como um dos dotes. Logo, a beatitude é um dote.

4. Demais. ─ O gozo torna feliz. Ora, o gozo é um dos dotes. Logo, dote é a beatitude.

5. Demais. ─ Segundo Boécio, a felicidade é um estado perfeito pela reunião de todos os bens. Ora, o
estado dos bem-aventurados se completa pelos dotes. Logo, os dotes são partes da beatitude.
Mas, em contrário. ─ O dote é dado sem méritos. Ora, a beatitude não é dada, mas é uma recompensa
pelos méritos. Logo, dote não é a beatitude.

2. Demais. ─ A beatitude é uma só, ao passo que os dotes são vários. Logo, a beatitude não é dote.

3. Demais. ─ A beatitude o homem a goza pelo que tem de mais elevado, como diz Aristóteles. Ora, de
dote também é susceptível o corpo. Logo, dote e beatitude não são o mesmo.

SOLUÇÃO. ─ Nesta matéria há uma dupla opinião.
Certos pretendem que beatitude e dote são realmente idênticos, mas diferem pelo conceito racional;
porque o dote concerne o matrimônio espiritual entre Cristo e a alma; não porém a beatitude. ─ Mas
isto é indefensável, como é fácil compreender; pois, ao passo que a beatitude consiste numa operação,
o dote não é nenhuma operação, mas antes, uma qualidade ou disposição.
Por isso dizem outros, que beatitude e dote diferem também realmente, chamando-se beatitude o ato
perfeito, em si mesmo, pelo qual a alma bem aventurada se une a Deus; ao passo que se denominam
dotes os hábitos, disposições ou quaisquer outras qualidades, ordenados a esse ato perfeito. De modo
que os dotes antes se ordenam à beatitude do que se incluem nela como partes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A beatitude, propriamente falando, não é um ornato da
alma, mas algo procedente do ornato da alma, pois, é um ato; ao passo que ornato se chama um certo
adorno do bem-aventurado.

RESPOSTA À SEGUNDA. ─ A beatitude não se ordena à união, mas é a união mesma da alma com Cristo,
mediante um ato. Ao passo que os dotes são dons que dispõem para essa união.

RESPOSTA À TERCEIRA. ─ Uma visão pode ser apreciada à dupla luz. ─ Primeiro, atualmente, i. é, como o
ato mesmo da visão. E assim o dote não é visão, mas é a própria beatitude. ─ Noutro sentido, pode ser
tomado habitualmente, i. é, como um hábito de que deriva o ato referido; ou pelo esplendor mesmo da
glória com que Deus ilumina a alma para que o possa contemplar. E então o dote é o princípio da
beatitude, mas não é a beatitude mesma.
E o mesmo devemos responder à quarta objeção a respeito do gozo.

RESPOSTA À QUINTA. ─ A beatitude é a reunião de todos os bens, não como partes essenciais dela, mas
como de certo modo ordenados para ela.

## Art. 3 — Se também Cristo terá dotes.
O terceiro discute-se assim. ─ Parece que também Cristo terá dotes.

1. ─ Pois, os santos se conformarão com Cristo pela glória; donde o dizer o Apóstolo ─ O qual reformará
o nosso corpo abatido para o fazer conforme ao seu corpo glorioso. Logo, também Cristo terá dotes.

2. Demais. ─ No matrimônio espiritual dão-se dotes à semelhança do matrimônio corporal. Ora, em
Cristo há de certo modo matrimônio espiritual que lhe é próprio ─ a das duas naturezas na unidade de
pessoa; por isso se diz que nele a natureza humana foi desposada pelo Verbo, conforme o diz o Glosa
aquilo da Escritura ─ No sol pôs o seu tabernáculo, etc. ─ E o Apocalipse: Eis aqui o tabernáculo de Deus
com os homens. Logo, também Cristo deve ter dotes.

3. Demais. ─ Como diz Agostinho, Cristo, segundo a regra de Ticónio, por causa da unidade do corpo
místico entre o corpo e os membros, também se denomina esposa e não só esposo, conforme aquilo da
Escritura: Como o esposo aformoseado com a sua coroa e como a esposa ornada dos seus colares. Logo,
como os dotes são devidos à esposa, como se sabe, também devemos atribuir dotes a Cristo.

4. Demais. ─ Todos os membros da Igreja devem ter dotes, porque a Igreja é a esposa. Ora, Cristo é
membro da Igreja, segundo aquilo do Apóstolo: Vós outros sois corpo de Cristo e membros uns dos
outros. E a Glosa: i. é, de Cristo. Logo, também Cristo deve ter dotes.

5. Demais. ─ Cristo goza da visão, da fruição e da deleitação perfeitos. Ora, são três dotes. Logo, etc.
Mas, em contrário. ─ Entre esposo e esposa há necessariamente distinção de pessoas. Ora, em Cristo
nada é pessoalmente distinto do Filho de Deus, que é esposo, conforme aquilo do Evangelho: O que tem
a esposa é o esposo. Logo, como os dotes são constituídos para a esposa, ou em favor dela, parece que
Cristo não deve ter dotes.

2. Demais. ─ Não pode a mesma pessoa dar e receber dotes. Ora, Cristo é quem confere os dotes
espirituais. Logo, não deve ter dotes.

SOLUÇÃO. ─ Nesta matéria duas são as opiniões.
Uns dizem que há em Cristo tríplice união: a consentânea, pela qual está unido a Deus pela união de
amor; a dignativa, pela qual a natureza humana está unida à divina; e a terceira, pela qual Cristo está
unido à Igreja. E assim, ensinam que pelas duas primeiras uniões Cristo deve ter dotes, no sentido
próprio destes: mas pela, terceira união, embora Cristo possua em grau eminente o que constitui o
dote, este não lhe cabe contudo no seu sentido próprio, porque, nessa união, Cristo é o como esposa da
Igreja, a esposa: ora, o dote é dado à esposa para que tenha a propriedade e o domínio dele, embora
seja constituído para o uso do esposo. ─ Mas esta opinião não é aceitável. Pois, essa união pela qual
Cristo mesmo como Deus está unido ao Pai pelo consentimento do amor, não se pode considerar como
matrimônio, porque não há aí nenhuma sujeição como a que deve haver entre esposa e esposo. Nem
também pela união da natureza humana com a divina, que é uma união pessoal; nem pela
conformidade da vontade, pode haver dote no seu sentido próprio, por três razões. ─ Primeiro, porque
o matrimônio, em que se constituem dotes, exige a conformidade de natureza entre esposo e esposa; e
isto não se dá na união da natureza humana com a divina. Segundo, porque é necessária a distinção de
pessoas; e a natureza humana não é pessoalmente distinta do Verbo. Terceiro, porque o dote é dado na
ocasião em que a esposa é levada para a casa do esposo; e assim vem a pertencer à esposa que, solteira
antes, está doravante unida ao marido; ora a natureza humana assumida pelo Verbo na unidade de
pessoa, nunca deixou de estar perfeitamente unida com ele.
Por isso, segundo outros, ou se deve dizer que o dote, como tal, de nenhum modo se pode atribuir a
Cristo; Ou não lhe deve atribuir no mesmo sentido em que o é aos santos. Mas os chamados dotes eles
os têm em grau excelentíssimo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A referida conformação deve entender-se considerado o
dote no seu sentido próprio, e não no sentido em que convém a Cristo. Pois aquilo por que nos
conformamos com Cristo não é forçoso exista do mesmo modo em Cristo e em nós.

RESPOSTA À SEGUNDA. ─ Não é em sentido literal que a natureza humana é chamada esposa, na união
com que está unida ao Verbo; pois não há nessa união a distinção de pessoas necessariamente existente
entre esposo e esposa. Mas quando às vezes se diz que a natureza humana foi desposada pelo Verbo
por se lhe ter este unido, isso só é porque, à semelhança do que se dá com a esposa, está com o Verbo
inseparavelmente unida. E porque nessa união a natureza humana é inferior ao Verbo, e é por ele
governada como o é a esposa pelo esposo.

RESPOSTA À TERCEIRA. ─ Quando às vezes se diz que Cristo é esposa, não significa isso que o seja no
seu sentido próprio; mas enquanto para si assume a pessoa da Igreja, sua esposa, que lhe está
espiritualmente unida. E assim, nada impede que, de conformidade com esse modo de falar, possamos
dizer que Cristo tem dotes; não pelos ter ele, mas sim a Igreja.

RESPOSTA À QUARTA. ─ A palavra Igreja, é susceptível de dupla acepção. ─ Assim, às vezes designa
somente o corpo unido a Cristo como cabeça. E então só a Igreja compete ser a esposa: e Cristo não é
membro dela, mas a cabeça influente em todos os seus membros. ─ Noutra acepção, a Igreja designa a
cabeça e os membros que lhe estão unidos. E assim dizemos que Cristo é membro da Igreja, enquanto
tem uma função distinta de todos os outros membros e que é lhes influir a vida. Embora não possa ser
chamado membro muito propriamente, porque membro implica a idéia de parte, e em Cristo bem
espiritual não é parcial, mas totalmente íntegro. Por onde, é ele o bem total da Igreja; nem os outros
membros juntos com ele são algo de maior que ele isoladamente. Ora, considerando assim a Igreja, ela
não só designa a esposa, mas o esposo e a esposa enquanto deles resulta uma unida pela conjunção
espiritual. Por onde, embora Cristo seja de certo modo considerado membro da Igreja, de maneira
nenhuma podemos porém dizê-lo membro da esposa. Não lhe convém, pois, nesse sentido ter dote, na
acepção própria deste.

RESPOSTA À QUINTA. ─ Nessa sequência há o sofisma de acidente. Pois, essa enumeração não se aplica
a Cristo senão enquanto constitui dotes, no sentido próprio deste.

## Art. 4 — Se os anjos tem dotes.
O quarto discute-se assim. ─ Parece que os anjos tem dotes.

1. ─ Pois, àquilo da Escritura ─ Uma só e a minha pomba, diz a Glosa: Uma só é a Igreja, a dos homens e
a dos anjos. Ora, a Igreja é a esposa; e assim os membros da Igreja devem ter dotes.

2. Demais. ─ Aquilo do Evangelho: E sede vós outros semelhantes aos homens que esperam ao seu
senhor ao voltar das bodas, diz a Glosa: O Senhor foi às núpcias, quando depois da ressurreição, feito
homem novo, unia-se à multidão dos anjos. Logo, a multidão dos anjos é a esposa de Cristo. E portanto,
os anjos devem ter dotes.

3. Demais. ─ O matrimônio espiritual consiste numa união espiritual. Ora, a união espiritual não é maior
entre os anjos e Deus, que entre Deus e os santos. Logo, como os dotes, de que agora tratamos, são
conferidos em razão do matrimônio espiritual, parece que os devem ter os anjos.

4. Demais. ─ O matrimônio espiritual supõe um esposo e uma esposa espirituais. Ora, a Cristo, como
espírito por excelência, mais são conformes por natureza os anjos que os homens. Logo, o matrimônio
espiritual será antes o dos anjos que o dos homens com Cristo.

5. Demais. ─ Maior conveniência deve haver entre a cabeça e os membros, que entre o esposo e a
esposa. Ora, a conformidade entre Cristo e os anjos basta para Cristo ser considerado a cabeça deles.
Logo e pela mesma razão, basta para lhes ser chamado o esposo.
Mas, em contrário. ─ Orígenes distingue quatro pessoas: o esposo e a esposa, as moças que
acompanham a esposa e os companheiros do esposo. E diz que os anjos são os companheiros do
esposo. Logo, como dotes não os deve ter senão a esposa, parece que não convém aos anjos.

2. Demais. ─ Cristo desposou a Igreja pela incarnação e pela paixão; e é assim figurado naquele lugar da
Escritura: Tu és para mim um esposo sanguinário. Ora, pela incarnação e pela paixão Cristo não se uniu
aos anjos diferentemente do que antes. Logo, os anjos não pertencem à Igreja no sentido em que é
chamada esposa, Logo, não podem ter dotes.

SOLUÇÃO. ─ O que se entende por dotes da alma não há dúvida que convém tanto aos anjos como aos
homens. Mas, no sentido literal do vocábulo não convém a uns e a outros do mesmo modo; porque não
podem os anjos ser esposas, no sentido próprio dessa palavra, como o convém à natureza humana, pois,
entre esposo e esposa há de haver conformidade de natureza, i. é, hão de ser da mesma espécie. Ora,
essa relação a tem os homens com Cristo por ter este assumido a natureza humana, por cuja assunção
veio a assemelhar-se a todos os homens, pela natureza da espécie humana. Com os anjos porém não
comunica pela unidade específica, nem pela natureza divina, nem pela humana. Por onde, ter dotes não
convém aos anjos pela mesma razão por que o convém aos homens. ─ Contudo, os vocábulos
empregados metaforicamente, não se possa predicar uma cousa de outra. E assim, pela razão referida,
não se pode afirmar, em sentido absoluto, que os anjos não devem ter dotes; mas só que não os têem,
como os homens, no sentido próprio deles, em razão da referida semelhança.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora os anjos pertençam à unidade da Igreja, não são
contudo membros dela, no sentido em que ela é esposa por conformidade de natureza. E assim não lhes
convém ter dotes, no sentido próprio destes.

RESPOSTA À SEGUNDA. ─ Esses desposórios se tomam em sentido lato, pela união onde não há
conformidade de natureza específica. E assim também nada impede, tomando os dotes nessa acepção
lata, que os atribuamos aos anjos.

RESPOSTA À TERCEIRA. ─ Embora no matrimônio espiritual não há senão uma união espiritual, contudo
os que se unem hão de convir especificamente, para haver matrimônio perfeito. Por isso não se pode,
em sentido próprio, falar em desposórios, em relação aos anjos.

RESPOSTA À QUARTA. ─ Essa conformação pela qual os anjos se conformam com Cristo, enquanto
Deus, não é tal que baste a constituir um matrimônio real; por não haver conveniência específica, mas
antes, permanecer infinita entre Cristo e os anjos uma distância infinita.

RESPOSTA À QUINTA. ─ Nem mesmo Cristo é considerado, em sentido próprio, cabeça dos anjos, no
sentido em que ser cabeça supõe conformidade de natureza entre ela e os membros. Contudo, é mister
saber, que embora a cabeça e os outros membros sejam de um indivíduo de uma mesma espécie,
contudo, considerando-se cada membro à parte, não são todos da mesma espécie; assim, as mãos
diferem especificamente da cabeça. Por onde, considerando os membros em si mesmos, não é
necessário haja entre eles outra conveniência a não ser a de proporção, pela qual uns recebam a ação
dos outros e se sirvam reciprocamente. E assim a conveniência existente entre Deus e os anjos serve
mais de fundamento, que a de esposo, à noção de cabeça.

## Art. 5 — Se se distinguem acertadamente três dotes da alma: a visão, a dileção e a fruição.
O quinto discute-se assim. ─ Parece que não se distinguem acertadamente três dotes da alma: a visão,
a dileção e a fruição.

1. ─ Pois, a alma se une com Deus pelo intelecto; porque é imagem da Trindade pela memória, pela
inteligência e pela vontade. Ora, a dilecção pertence à vontade; a visão à inteligência. Logo, há de
atribuir-se também à memória a sua atividade própria, desde que a fruição não lhe pertence a ela, mas
antes, à vontade.

2. Demais. ─ Os dotes da beatitude se consideram como correspondentes às virtudes que praticamos
nesta vida, que são a fé, a esperança e a caridade, virtudes cujo objeto é Deus mesmo. Ora, a dileção
corresponde à caridade, e a visão à fé. Logo, devia haver também um dote correspondente à esperança,
pois, a fruição pertence antes à caridade.

3. Demais. ─ De Deus não gozamos senão pelo amor e pela visão; pois, fruímos daquilo que diretamente
gozamos, como diz Agostinho. Logo, a fruição não deve ser considerada dote diferente da dileção.

4. Demais. ─ A beatitude, na sua perfeição, requer a posse do seu objeto, conforme aquilo do Apóstolo:
Cerrei de tal maneira que alcanceis. Logo, é forçoso admitir-se um quarto dote.

5. Demais. ─ Anselmo diz que a beatitude da alma inclui: a sabedoria, a amizade, a concórdia, o poder, a
honra, a segurança, e a alegria. ─ Donde se conclui que a enumeração supra, dos dotes, é incompleta.

6. Demais. ─ Conforme Agostinho, na beatitude celeste veremos a Deus sem fim, amá-lo-emos sem
enfado e incansavelmente o louvaremos. Logo, o louvor também deve entrar na referida enumeração
dos dotes.

7. Demais. ─ Boécio distingue na beatitude cinco elementos: a suficiência, resultante das riquezas; a
alegria, resultante do prazer; a celebridade, que nasce da fama; a segurança, filha do poder; a
reverência, cuja fonte é a dignidade. Donde se conclui que esses, e não os enumerados, é que se deviam
considerar dotes.

SOLUÇÃO. ─ Todos, em geral, admitem como dotes da alma os supra-enumerados, mas diversamente.
Assim, uns dizem que três são os dotes da alma: a visão, a apreensão e a fruição. Outros: a visão, a
apreensão e a fruição. Outros ainda: a visão, a deleitação e a posse. Mas essas três enumerações se
reduzem a uma só; e todos concordam quanto ao número delas.
Ora, como dissemos, o dote é algo de inerente à alma, que a ordena ao ato em que consiste a felicidade.
Mas esse ato compreende dois elementos: a substância mesma dele, que é a visão; e a sua perfeição,
que é a deleitação; pois, a felicidade há de ser uma atividade perfeita. Ora, uma visão pode ser
deleitável a dupla luz: por causa do objeto visto, que causa prazer; e por parte da visão mesma, cujo ato
é em si mesmo deleitável, como quando nos comprazemos em ver o mal, embora este não nos deleite.
E como a atividade, em que consiste a felicidade última, deve ser perfeitíssima, há de por força a visão,
de que se trata, ser, a ambas as luzes, deleitável. Mas, para uma visão ser, como tal, deleitável, é
necessário que seja conatural, por algum hábito, ao sujeito que vê. Para ser deleitável, porém, por parte
do objeto visível, há de ter este com a vista conveniência e união.
Assim, pois, para a visão, como tal, ser deleitável, é necessário um hábito donde ela proceda. Donde um
dote, a que todos chamam visão. Por outro lado, o objeto visível requer duas condições: a conveniência,
resultante do afeto, e daí o dote a que uns chamam dileção e outros fruição, dizendo esta respeito ao
afeto, pois, o que soberanamente amamos a isso do mesmo modo estimamos como convenientíssimo.
Por parte do objeto visível é também necessária a união; donde o dote da apreensão, segundo certos,
que não é senão possuir efetivamente a Deus e o ter em si; mas outros introduzem a fruição ou
deleitação, enumerando de outro modo. Pois, a fruição perfeita, como a teremos na pátria, inclui em si
tanto a deleitação como a apreensão. Por isso, certos reduzem esses dois dotes a um só, e outros os
consideram como distintos.
Outros porém atribuem esses três dotes às três potências da alma: a visão, à alma racional; a deleitação,
à alma concupiscível; e a fruição à irascível, porque supõe uma vitória para a alcançarmos. ─ Mas isto
não é acertado. Porque o irascível e o concupiscível não pertencem à parte intelectiva, mas à sensitiva;
ora, os dotes da alma têm a sua sede no intelecto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A memória e a inteligência tem uma atividade comum; ou
por ser aquela uma operação desta, ou, se aquela for considerada uma potência, a memória não
exercerá a sua atividade senão mediante a inteligência, porque é próprio da memória reter os
conhecimentos. Por isso também à memória e à inteligência não corresponde senão o hábito do
conhecimento. Por onde, a ambas corresponde só o dote da visão.

RESPOSTA À SEGUNDA. ─ A fruição corresponde à esperança enquanto inclui a apreensão, que sucede à
esperança. Pois, o esperado ainda não é possuído; daí um certo sofrimento causado pela esperança, por
causa da ausência do objeto amado. Por isso, não mais existirá na pátria, sendo substituída pela
apreensão.

RESPOSTA À TERCEIRA. ─ A fruição, enquanto inclui a apreensão, distingue-se da visão e da dileção; mas
de modo diverso do pelo qual a dileção difere da visão. Pois, dileção e visão designam hábitos diversos,
dos quais um pertence ao intelecto e outro, ao afeto. Ao passo que a apreensão, Ou a fruição como
parte dela, não implica nenhum hábito diverso dos dois supra-referidos, mas só a remoção dos
obstáculos que impediam a alma de se unir efetivamente com Deus. O que se dá pelo fato de o hábito
mesmo da glória liberar a alma de todas as suas deficiências, pois, a torna capaz de conhecer sem
fantasmas, a ter domínio sobre o corpo e outros privilégios semelhantes, exclusivos dos obstáculos, que
nos fazem vivermos ausentes do Senhor.

RESPOSTA À QUARTA. ─ Deduz-se do que foi dito.

RESPOSTA À QUINTA. ─ Em sentido próprio, dotes são os princípios imediatos da atividade em que
consiste a perfeita beatitude, pela qual a alma se une com Cristo. Ora, tal não se dá com a enumeração
de Anselmo, cujas partes ou são concomitantes ou consequentes à beatitude, não só em relação ao
esposo, a quem, na enumeração de Anselmo, só lhe cabe a sabedoria, como também em relação aos
outros. E estes, quer sejam nossos iguais, aos quais concerne a amizade, quanto à união dos afetos, e a
concórdia, quanto ao consenso no agir; quer nos sejam inferiores, aos quais concerne o poder, pelo qual
estes recebem dos superiores a sua disposição, e a honra, prestada pelos inferiores aos superiores; e
enfim, relativamente a nós mesmos, dizendo-nos respeito então a segurança, quanto à remoção do mal,
e a alegria, quanto à consecução do bem.

RESPOSTA À SEXTA. ─ O louvor, a terceira das cousas, que, segundo Agostinho, existirão na pátria, não é
uma disposição para a beatitude, mas é antes uma consequência dela. Pois, por isso mesmo que a alma
está unida a Deus, no que consiste a beatitude, resulta o prorromper em louvores. Por isso, o louvor não
é da natureza do dote.

RESPOSTA À SÉTIMA. ─ As cinco cousas enumeradas por Boécio são umas condições da felicidade, e não
disposições para o ato em que ela consiste. Porque a beatitude, em razão da sua perfeição, só e
singularmente tem por si mesma tudo o que os homens buscam nos diversos bens materiais, como está
claro no Filósofo. E assim, Boécio mostra que as cinco as abrange a verdadeira felicidade, pois, são as
cinco que os homens buscam, na felicidade temporal. As quais, ou concernem à isenção do mal, o que é
garantido pela segurança; ou à consecução do bem ─ conveniente, donde nasce a alegria, ou perfeito e
por isso mesmo dotado de suficiência; ou concerne à manifestação do bem, ─ donde ─ a celebridade,
quando o bem de um chega ao conhecimento de muitos, e a reverência, quando se dá uma prova desse
conhecimento ou desse bem, pois, a reverência consiste na atribuição da honra, que é uma prova de
virtude. Por onde, é claro que a enumeração de Boécio não inclui cinco dotes, mas sim cinco condições
da beatitude .