# Questão 42: Do matrimônio como sacramento.
Em seguida devemos tratar do matrimônio como sacramento.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se o matrimônio é sacramento.
O primeiro discute-se assim. ─ Parece que o matrimônio não é sacramento.

1. Pois, todo sacramento da Lei Nova tem uma forma que é da essência dele. Ora, a bênção dada pelo
sacerdote nas núpcias não é da essência do matrimônio. Logo, não é sacramento.

2. Demais. ─ O sacramento, segundo Hugo, é um elemento material. Ora, o matrimônio não tem por
matéria nenhum elemento material. Logo, não é sacramento.

3. Demais. ─ Os sacramentos tiram da paixão de Cristo a sua eficácia. Ora, pelo matrimônio não nos
conformamos com a paixão de Cristo, que foi uma pena; pois o matrimônio é acompanhado de prazer.
Logo, não é sacramento.

4. Demais. ─ Todo sacramento da Lei Nova realiza o que figura. Ora, o matrimônio não opera a
conjunção entre Cristo e a Igreja, que significa. Logo, o matrimônio não é sacramento.

5. Demais. ─ Nos outros sacramentos há a realidade e o sacramento. Ora, tal não pode dar-se com o
matrimônio, que não imprime caráter; do contrário não seria reiterado. Logo, não é sacramento.
Mas, em contrário, o Apóstolo: Este sacramento é grande. Logo, etc.

2. Demais. ─ Um sacramento é sinal de uma coisa sagrada. Ora, tal é o matrimônio. Logo, etc.

SOLUÇÃO. ─ O sacramento tem por fim ministrar um remédio de santificação contra o pecado, remédio
que se apresenta sob sinais sensíveis. Ora, como tal se dá com o matrimônio, é contado entre os
sacramentos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ As palavras com que se exprime o consentimento
matrimonial são as formas deste sacramento; mas não a bênção sacerdotal, que é um sacramental.

RESPOSTA À SEGUNDA. ─ O sacramento do matrimônio se consuma pelo ato de quem o recebe, assim
como a penitência. Por onde, como a penitência não tem outra matéria senão os dotes mesmos que
caem sob o domínio dos sentidos e que tem lugar de elemento material, assim também se dá com o
matrimônio.

RESPOSTA À TERCEIRA. ─ Embora pelo matrimônio não nos conformemos com a paixão de Cristo como
pena, conformamo-nos porém com ela pela caridade com que Cristo sofreu pela Igreja que se lhe ia unir
como esposa.

RESPOSTA À QUARTA. ─ A união entre Cristo e a Igreja não é a realidade contida neste sacramento, mas
a realidade significada mas não contida; e essa realidade nenhum sacramento a produz. Mas tem outra
realidade contida e significada que produz, como dissemos. ─ O Mestre porém se refere à realidade não
contida, por pensar que o matrimônio não é causa de uma realidade que possa conter.

RESPOSTA À QUINTA. ─ Também o sacramento do matrimônio encerra esses três elementos. Porque o
que constitui só o sacramento são os atos externos aparentes; a realidade e sacramento é o laço
resultante de tais atos, que prendem o homem à mulher; a realidade última contida é o efeito deste
sacramento; e a não contida é a realidade, que designa o Mestre.

## Art. 2 — Se o matrimônio devia ser instituído antes do pecado.
O segundo discute-se assim. ─ Parece que o matrimônio não devia ser instituído antes do pecado.

1. Pois, o que é de direito natural não precisa ser instituído. Ora tal é o matrimônio, como do sobredito
resulta. Logo, não precisava ser instituído.

2. Demais. ─ Os sacramentos são uns remédios contra a doença do pecado. Ora, um remédio não se
prepara senão para curar uma doença. Logo, não devia ser instituído antes do pecado.

3. Demais. ─ Para um mesmo fim basta uma só instituição. Ora, o matrimônio foi instituído também
depois do pecado, como diz a letra do Mestre. Logo, não foi instituído antes do pecado.

4. Demais. ─ A instituição de um sacramento pode ser feita por Deus. Ora, antes do pecado, as palavras
referentes ao matrimônio não foram determinadamente proferidas por Deus, mas por Adão. Quanto às
palavras pronunciadas por Deus ─ Crescei e multiplicai-vos, também se aplicam aos brutos, para os quais
não há matrimônio, Logo, o matrimônio não foi instituído antes do pecado.

5. Demais. ─ O matrimônio é um sacramento da Lei Nova. Ora, os sacramentos da Lei Nova tiveram o
seu início na instituição de Cristo. Logo, não devia o matrimônio ser instituído antes do pecado.
Mas, em contrário, o Evangelho: Não tendes lido que quem criou o homem desde o princípio fê-los
macho e fêmea?

2. Demais. ─ O matrimônio foi instituído para a procriação dos filhos. Ora, já antes do pecado era
necessário ao homem essa procriação. Logo, o matrimônio devia ser instituído antes do pecado.

SOLUÇÃO. ─ A natureza inclina para o matrimônio tendo em vista um bem, que varia segundo os
diversos estados em que vivem, os homens. Por isso, e necessariamente, esse bem foi instituído
diversamente conforme os diversos estados humanos. Por isso, o matrimônio, enquanto ordenado à
procriação de filhos, necessária mesmo antes de existir o pecado, foi instituído antes do pecado. Mas
enquanto remédio contra as lesões causadas pecado, foi instituído depois do pecado, no tempo da lei
da natureza, Quanto porém à determinação de pessoas, a instituição teve lugar na lei de Moisés. Mas,
enquanto representa o mistério da união entre Cristo e a Igreja, foi instituído, na Lei Nova, sendo assim
sacramento dessa lei. Quanto enfim às outras vantagens resultantes do matrimônio, como a amizade e
o obséquio recíproco que os cônjuges mutuamente se prestam, haure a sua instituição na lei civil. ─ Mas
como um sacramento deve por essência ser um sinal e um remédio, o matrimônio é um sacramento em
razão das instituições intermediárias de que foi objeto. Pela sua primeira instituição, porém foi
estabelecido como uma função natural; e quanto à última, desempenha o papel de um ofício social.

DONDE A RESPOSTA À PRIMEIRA ORAÇÃO. ─ O que é em geral de direito natural precisa ser instituído
nas minúcias da sua aplicação, que correspondem diversamente aos diversos estados humanos. Assim é
de direito natural que os crimes sejam punidos mas só o direito positivo determina a pena merecida por
uma determinada culpa.

RESPOSTA À SEGUNDA. ─ O matrimônio não é só um remédio contra o pecado, mas sobretudo uma
função da natureza. Por isso, como tal e não como remédio, é que foi instituído antes do pecado.

RESPOSTA À TERCEIRA. - Sendo necessário regulamentar o casamento de maneiras diversas, não há
inconveniente em que tenha tido várias instituições. E assim essas instituições diversas não coincidem
na identidade de objeto.

RESPOSTA À QUARTA. ─ O matrimônio foi instituído por Deus antes do pecado, quando formou o corpo
da mulher de uma costela de Adão, dando-lhe a este como companheira e dizendo-lhes: Crescei e
multiplicai-vos, O que, embora também o tivesse dito aos animais, não deviam eles contudo ser
realizados por eles do mesmo modo por que o foram pelos homens. Quanto a Adão, foi por inspiração
divina que pronunciou essas palavras, para que compreendesse que a instituição do matrimônio foi feita
por Deus.

RESPOSTA À QUINTA. ─ Enquanto sacramento da Lei Nova, o matrimônio não foi instituído antes de
Cristo, como do sobredito se colhe.

## Art. 3 — Se o matrimônio confere a graça.
O terceiro discute-se assim. ─ Parece que o matrimônio não confere a graça.

1. Pois, segundo Hugo, os sacramentos, pela santificação, produzem a graça invisível. Ora, o matrimônio
não implica essencialmente nenhuma santificação. Logo, não confere nenhuma graça.

2. Demais. ─ Todo sacramento que confere graça confere-a pela sua matéria e nela sua forma. Ora, os
atos que constituem a matéria deste sacramento não são a causa da graça; pois, seria a heresia de
Pelágio considerar os nossos atos como a causa da graça. Nem tão pouco são a causa da graça as
palavras que exprimem o consentimento, pois, delas não resulta nenhuma santificação. Logo, o
matrimônio de nenhum modo confere a graça.

3. Demais. ─ A graça destinada a curar a enfermidade do pecado, é necessária a todos os que dessa
enfermidade padecem. Se, pois, o matrimônio conferisse a graça contra a enfermidade da
concupiscência todos os homens deveriam contrair matrimônio. E seria então muito estulta a abstenção
dele.

4. Demais. ─ Uma enfermidade não pode ter como remédio aquilo mesmo que a intensifica. Ora, o
matrimônio torna mais intensa a concupiscência; pois, como diz o Filósofo, é insaciável o apetite da
concupiscência e aumenta quando a satisfazemos. Logo, parece que o matrimônio não é remédio contra
a concupiscência.
Mas, em contrário. a definição e o definido devem converter-se entre si. Ora, na definição do
sacramento entra a causalidade da graça. Logo, sendo o matrimônio um sacramento será causa da
graça.

2. Demais. ─ Agostinho diz, que o matrimônio é um remédio para doentes. Ora, não é remédio senão
enquanto tem uma certa evidência. Logo, tem alguma eficácia para reprimir a concupiscência. Ora, a
concupiscência não pode ser reprimida senão pela graça. Portanto, ele a confere.

SOLUÇÃO. ─ Nesta matéria há tríplice opinião.
Certos (como o Mestre das Sentenças), disseram que o matrimônio de nenhum modo é causa da graça,
mas apenas sinal dela. ─ Mas isto não é sustentável. Porque então nenhuma vantagem teria sobre os
sacramentos da Lei Velha, não havendo portanto nenhuma razão para ser computado entre os
sacramentos da Lei Nova. Pois, buscar remédio na satisfação da concupiscência, para não cairmos se
ficássemos sujeitos a uma lei demasiado rigorosa, isso já o ato conjugal por si mesmo o realizava na
vigência da Lei Velha.
Por isso outros (S. Alberto) ensinavam, que o matrimônio confere uma graça destinada a afastar do mal
pois fica assim excusado um ato, que sem o matrimônio seria pecado. ─ Mas dizer isso não é o bastante,
porque esse efeito também a lei antiga o produzia.
Por isso dizem, que o matrimônio afasta de mal, coibindo a concupiscência, para que esta não
ultrapasse o bem do matrimônio; mas essa graça nenhum auxílio dá para usar bem do casamento. ─ Tal
porém não pode ser. Pois, a mesma graça, que impede o pecado, inclina para o bem, assim como o
mesmo calor, que expulsa o frio, aquece.
Por isso outros (S. Boaventura) ensinam que o matrimônio quando contraído com fé em Cristo, confere
a graça que nos ajuda a proceder conforme a exigências do casamento. E isto é mais provável. Pois,
sempre que Deus dá uma faculdade, dá também os auxílios de que precisamos para podermos usar bem
dela. E assim o demonstraram todas ao potências da alma, a que correspondem certos órgãos do corpo,
pelos quais podem exercer os seus atos. Por onde, como o matrimônio dá ao casado, por instituição
divina, a faculdade de usar de sua mulher para a procriação dos filhos, confere também a graça de o
poder fazer convenientemente, como também dissemos quando tratamos da ordem. E assim, essa
graça dada é a última realidade contida neste sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Assim como a água do batismo tem a virtude, por causa
do contacto que teve com a carne de Cristo, de tocar o corpo e purificar o coração, assim também o
matrimônio produz o seu efeito por causa da paixão de Cristo, símbolo da união conjugal. Mas não que
isso produzisse por ter a sua causa principal em qualquer santificação do sacerdote.

RESPOSTA À SEGUNDA. ─ Assim como a água do batismo, juntamente com a forma das palavras, não
coopera imediatamente para ser conferida a graça, mas para a impressão do caráter; assim também os
atos externos e as palavras que exprimem o consentimento produzem diretamente um liame, que é o
sacramento do matrimônio. E esse liame, por força da instituição divina, produz uma disposição para
receber a graça.

RESPOSTA À TERCEIRA. ─ A objeção seria procedente se não se pudesse aplicar um remédio mais eficaz
contra a enfermidade da concupiscência. Ora, as obras espirituais e a mortificação da carne constituem
um remédio mais eficaz, aplicado pelos que não usam do matrimônio.

RESPOSTA À QUARTA. ─ De dois modos podemos combater, a concupiscência. ─ Um consiste em lhe
resistir, reprimindo-a na sua raiz mesma. E para isso serve o matrimônio, pela graça que confere. ─
Segundo, regulando o ato carnal. E isso de dois modos. Primeiro, fazendo com que o ato para o qual a
concupiscência inclina não seja exteriormente desonesto; e isso se opera pelos bens do matrimônio, que
legitimam a concupiscência da carne. Segundo, impedindo a turpitude do ato; e isso resulta da natureza
mesma deste, pois, satisfazendo-se a concupiscência no ato conjugal, não nos incita ela a seções más.
Por onde diz o Apóstolo, que melhor é casar-se do que abrasar-se. Pois embora os atos solicitados pela
concupiscência sejam de natureza a excitá-la cada vez mais, contudo a reprimem, enquanto
subordinados à razão; pois, atos semelhantes deixam disposições e hábitos semelhantes.

## Art. 4 — Se a conjunção carnal é da integridade do matrimônio.
O quarto discute-se assim. ─ Parece que a conjunção carnal é da integridade do matrimônio.

1. Pois, quando foi instituído o matrimônio, foi dito: Serão dois numa só carne. Ora, isto não é possível
senão pela conjunção carnal. Logo, é esta a integridade do matrimônio.

2. Demais. ─ O pertinente à significação do sacramento é para a validade do sacramento, como se disse.
Ora, a conjunção carnal pertence à significação do matrimônio, como diz o Mestre das Sentenças. Logo,
é da integridade do sacramento.

3. Demais. ─ Este sacramento se ordena à conservação da espécie. Ora, a conservação da espécie não é
possível sem a conjunção carnal. Logo, é da integridade do matrimônio.

4. Demais. ─ O matrimônio, enquanto sacramento, é um remédio contra a concupiscência, do qual diz o
Apóstolo: Melhor é casar-se que abrasar-se, Ora, esse remédio não tem aplicação aos que não praticam
a conjunção carnal. Logo, o mesmo que antes.
Mas, em contrário. ─ No paraíso houve matrimônio. Ora, não havia então conjunção carnal. Logo, a
conjunção carnal não é da integridade do matrimônio.

2. Demais. ─ O sacramento, como o seu próprio nome o indica, implica a santificação. Ora, sem a
conjunção carnal o matrimônio é mais santo, como diz a letra do Mestre. Logo, a conjunção carnal não é
da integridade do matrimônio.

SOLUÇÃO. ─ Há duas espécies de integridade: uma constitui a perfeição primeira, consistente na
existência mesma do ser; outra relativa à perfeição segunda que é a ação. Ora, a conjunção carnal é um
ato; e usamos do matrimônio, que a legitima. Por isso essa conjunção pertencerá a integridade da
segunda espécie e não à da primeira.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Adão falava da integridade do matrimônio quando às
duas perfeições; pois, conhecemos uma coisa pela sua ação.

RESPOSTA À SEGUNDA. ─ A significação da realidade contida é de necessidade para o sacramento. Ora,
essa realidade não a exprime a conjunção carnal, mas antes, é a realidade não contida que a significa,
como dissemos.

RESPOSTA À TERCEIRA. ─ Nenhum agente chega ao seu fim senão pelos seus próprios atos. Por onde, o
fato de o fim do matrimônio não poder ser alcançado sem a conjunção carnal, mostra que esta pertence
à segunda espécie de integridade e não à primeira.

RESPOSTA À QUARTA. ─ Antes de haver a conjunção carnal, o matrimônio já é um remédio, por causa
da graça que confere, mas ainda não o é atualmente. Se-lo-à pela segunda espécie de integridade.