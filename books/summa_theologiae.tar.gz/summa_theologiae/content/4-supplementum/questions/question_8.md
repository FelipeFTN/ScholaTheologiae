# Questão 8: do ministro da confissão.
Em seguida devemos tratar do ministro da confissão.
E nesta questão discutem-se sete artigos:

## Art. 1 — Se é necessário confessar a um sacerdote.
O primeiro discute-se assim. ─ Parece que não é necessário confessar a um sacerdote.

1. ─ Pois, a confessar não estamos obrigados senão por instituição divina. Ora, a instituição divina nos é
proposta na Escritura: Confessai os vossos pecados uns aos outros, onde não se faz menção do
sacerdote. Logo, não devemos confessar ao sacerdote.

2. Demais. ─ A penitência é um sacramento de necessidade para a salvação, como o batismo. Ora, no
batismo, por necessidade do sacramento, qualquer homem é ministro. Logo, também na penitência.
Portanto, basta confessar a qualquer.

3. Demais. ─ A confissão é necessária a fim de ser imposto ao penitente o modo da satisfação. Ora, às
vezes quem não é sacerdote poderia com mais discernimento do que muitos sacerdotes, dar ao
penitente o modo de satisfazer. Logo, não é necessário fazer a confissão ao sacerdote.

4. Demais. ─ A confissão foi estabelecida na Igreja para os chefes conhecerem de vista o seu rebanho.
Ora, às vezes o chefe prelado não é sacerdote. Logo, a confissão nem sempre deve ser feita ao
sacerdote.
Mas, em contrário. ─ A absolvição do penitente, para a qual é feita a confissão, só podem dá-la os
sacerdotes a quem foi cometido o poder das chaves. Logo, a confissão deve ser feita ao sacerdote.

2. Demais. ─ A confissão foi prefigurada na ressurreição de Lázaro morto. Ora, o Senhor só aos discípulos
mandou que desligassem a Lázaro, como o refere o Evangelho. Logo, aos sacerdotes deve ser feita a
confissão.

SOLUÇÃO. ─ A graça dada nos sacramentos desce da cabeça para os membros. E por isso só aquele é
ministro dos sacramentos ─ pelos quais é dada a graça ─ que tem o ministério sobre o verdadeiro corpo
de Cristo. O que é próprio só do sacerdote, que pode consagrar a Eucaristia. E portanto, como no
sacramento da penitência é conferida a graça, só o sacerdote é ministro deste sacramento. Por onde, só
a ele se deve fazer a confissão sacramental, que deve ser feita a um ministro da Igreja.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Tiago se exprime na pressuposição da instituição divina.
Pois, por ter precedido a instituição divina sobre a confissão a ser feita aos sacerdotes, por lhes ter sido
dado nos Apóstolos, o poder de perdoar os pecados ─ como lemos na Escritura, por isso devemos
entender que Tiago advertiu os fiéis a fazerem a confissão aos sacerdotes.

RESPOSTA À SEGUNDA. ─ O batismo é sacramento de mais necessidade para a salvação do que a
penitência, quanto à confissão e a absolvição. Porque às vezes o batismo não pode ser preterido sem
perigo para a salvação eterna, como se da com as crianças, que não têm o uso da razão. O mesmo
porém não se passa com a confissão e a absolvição, de que só os adultos são capazes, e para os quais a
contrição com o propósito de confessar e o desejo da absolvição bastam para livrar da morte eterna. E
portanto não há símile entre o batismo e a confissão.

RESPOSTA À TERCEIRA. ─ Na satisfação não devemos atender só à intensidade da pena, mas também à
virtude dela como parte do sacramento. E assim exige um dispensador dos sacramentos; embora: a
intensidade da pena também possa ser determinada por outrem que não um sacerdote.

RESPOSTA À QUARTA. ─ Conhecer as ovelhas de vista pode ser necessário de dois modos. ─ Primeiro,
para dar a cada um o seu lugar no rebanho de Cristo. E assim, conhecer de vista as ovelhas é o objeto do
cuidado e da solicitude pastoral, que às vezes incumbe aos não sacerdotes. ─ Segundo, para que se lhe
dê o remédio conveniente à salvação. E então, conhecer as ovelhas de vista é dever daquele que deve
ministrar o remédio à salvação, isto é, sacramento da Eucaristia e outros, isto é, do sacerdote. Ora, a
esse conhecimento das ovelhas é que se ordena a confissão.

## Art. 2 — Se em algum caso é lícito confessar a outros que não ao sacerdote.
O segundo discute-se assim. ─ Parece que em nenhum caso é lícito confessar a outrem, que não o
sacerdote.

1. ─ Pois, a confissão sacramental é uma acusação, como o diz a definição dada. Ora, dispensar o
sacramento só cabe ao ministro dele. Mas, sendo o sacerdote o ministro do sacramento da penitência,
parece que a ninguém mais se deve fazer a confissão.

2. Demais. ─ A confissão, em qualquer juízo, se ordena à sentença. Ora, no foro contencioso, a sentença
dada por outrem que não o próprio juiz, é nula; por isso, a confissão não deve ser feita senão ao juiz.
Ora, o juiz, no foro da consciência é o sacerdote, que tem o poder de ligar e de absolver. Logo, não deve
a confissão ser feita a outro.

3. Demais. ─ Como qualquer pode ministrar o batismo, desde que um leigo batizou, mesmo sem
necessidade, não deve o batismo ser reiterado pelo sacerdote. Ora, quem se confessar a um leigo em
caso de necessidade, está obrigado a confessar-se de novo ao sacerdote, desde que desapareça o caso
de necessidade. Logo, a confissão não deve ser feita a um leigo, em caso de necessidade. Mas, em
contrário, é o que dispõe a letra do mestre das sentenças.

SOLUÇÃO. ─ Assim como o batismo é um sacramento de necessidade para a salvação, assim também a
penitência Ora, o batismo, sendo um sacramento de necessidade para a salvação, tem duplo ministro:
um ─ o sacerdote, a quem cabe o dever de batizar; outro ─ o a quem, em razão da necessidade, é
cometida a dispensação do batismo. E assim também o ministro da penitência, que tem o dever de ouvir
a confissão que lhe é feita, é o sacerdote; mas em caso de necessidade também um leigo pode fazer as
vezes do sacerdote, de modo que lhe possa a confissão ser feita.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ No sacramento da penitência não somente há uma que é
a parte do ministro, a saber, a absolvição e a satisfação imposta, mas ainda outra que é a de quem
recebe o sacramento, o que também é da essência deste, e é a contrição e a confissão. Quanto à
satisfação provém em parte, do ministro, pela impor; e em parte do penitente, pela cumprir. E para a
plenitude do sacramento ambos devem concorrer, quanto possível. Mas, em caso de necessidade, deve
o penitente fazer o que lhe cumpre, isto é, ter contrição e confessar a quem puder. E quem lhe ouve a
confissão, embora não possa ministrar o sacramento na sua plenitude, de modo a fazer o que faria o
sacerdote, isto é, dar a absolvição, a falta contudo do sacerdote é suprida pelo Sumo Sacerdote. E nem
por isso a confissão feita a um leigo, por falta de sacerdote, deixa de ser sacramental, de certo modo,
embora não seja um sacramento perfeito, porque lhe falta a parte que incumbe ao sacerdote.

RESPOSTA À SEGUNDA. ─ Embora um leigo não seja juiz do que ouve em confissão, contudo
absolutamente falando, em razão da necessidade, profere um juízo sobre o confitente, pois este por
falta de sacerdote se lhe sujeita.

RESPOSTA À TERCEIRA. ─ Pelos sacramentos o homem há de reconciliar-se não só com Deus, mas
também com a Igreja. Ora, reconciliar-se com Deus não o pode sem que chegue até ele a santificação da
Igreja. Mas, no batismo a santificação da Igreja nos chega mediante o elemento externo mesmo que é
aplicado, santificado pela palavra de vida, por qualquer um, segundo a forma da Igreja. E por isso quem
foi uma vez batizado, por quem quer que seja, não precisa ser batizado de novo. Mas, na penitência, a
santificação da Igreja não nos chega senão pelo ministro, porque não há nenhum elemento material
externamente aplicado, que pela santificação confira a graça invisível. Por onde, embora quem se
confessou, em artigo de necessidade, a um leigo, tenha alcançado o perdão de Deus, porque cumpriu
como pôde o propósito concebido de se confessar segundo o mandamento de Deus, contudo ainda não
está por aí reconciliado com a Igreja, de modo que deva ser admitido aos seus sacramentos, sem
primeiro ser absolvido por um sacerdote; assim como aquele que foi batizado pelo batismo de desejo
não é admitido à Eucaristia. E portanto é necessário se confesse de novo a um sacerdote, quando puder
e tiver ensejo de o fazer. E sobretudo porque, como se disse, não houve sacramento, o qual pois é
necessário seja ministrado; de modo que pela recepção mesma dele se consiga um efeito mais pleno; e
se cumpra o mandamento de receber o sacramento da penitência.

## Art. 3 — Se fora do caso de necessidade pode um não sacerdote ouvir confissão de pecados veniais.
O terceiro discute-se assim. ─ Parece que, fora do caso de necessidade, ninguém, a não ser o
sacerdote, pode ouvir confissão de pecados veniais.

1. ─ Pois, um sacramento pode ser dispensado por um leigo, em razão da necessidade. Ora, a confissão
dos pecados veniais não é necessária. Logo, não pode ser cometida a um leigo.

2. Demais. ─ Contra os pecados veniais se ordena a extrema unção, como a penitência. Ora, aquela não
pode ser ministrada por um leigo, conforme o diz a Escritura. Logo, nem o pode ser a confissão dos
pecados veniais.
Mas, em contrário, Beda, conforme a letra do Mestre das Sentenças.

SOLUÇÃO. ─ Pelo pecado venial não ficamos separados nem dos sacramentos da Igreja nem de Deus.
Por isso não precisamos da colação de nova graça nem de nos reconciliarmos com a Igreja. Por onde,
não é necessário confessemos o pecado venial ao sacerdote. E como a confissão feita mesmo a um leigo
é um sacramental, embora não sacramento perfeito, e procede da caridade, por isso pode o leigo
perdoar o pecado venial, como somos deste perdoados batendo no peito e tomando água benta.
Donde se deduz a resposta à primeira objeção. ─ Pois, para sermos perdoados dos pecados veniais, não
precisamos receber o sacramento, bastando receber um sacramental, como a água benta ou outro
semelhante.

RESPOSTA À SEGUNDA. ─ A extrema unção não é dada diretamente contra os pecados veniais: nem
nenhum outro sacramento o é.

## Art. 4 — Se é necessário confessarmos ao sacerdote próprio.
O quarto discute-se assim. ─ Parece que não é necessário confessarmos ao nosso sacerdote próprio.

1. ─ Pois, Gregório diz: Pela nossa autoridade apostólica e por dever de caridade, ordenamos que aos
sacerdotes monges, representantes dos Apóstolos, seja lícito pregar, batizar, dar a comunhão, rezar
pelos pecadores, impor penitência e perdoar os pecados. Ora, os monges não tendo cura d'alma, não
são sacerdotes próprios de ninguém. Logo, como a confissão se faz em vista da absolvição, basta que a
façamos a qualquer sacerdote,

2. Demais. ─ Assim como o sacerdote é o ministro deste sacramento, assim também o é da Eucaristia.
Ora, qualquer sacerdote pode administrar a Eucaristia. Logo, qualquer sacerdote pode ministrar o
sacramento da penitência. Logo, não devemos fazê-lo ao sacerdote próprio.

3. Demais. ─ O ao que estamos obrigados não depende da nossa eleição. Ora, não depende da nossa
eleição o sacerdote a quem devemos confessar, como está claro em Agostinho. Assim, diz: Quem quer
confessar os pecados, para receber a graça, busque um sacerdote com o poder de perdoar e reter. Logo,
parece não ser necessário confessarmos ao sacerdote próprio.

4. Demais. ─ Certos há, como os prelados, que, não tendo superior, não têm sacerdote próprio. Ora,
esses estão obrigados também à confissão. Logo, nem sempre estamos obrigados a confessar ao
sacerdote próprio.

5. Demais. ─ O que foi instituído por motivo de caridade não pode colidir com a caridade, como diz
Bernardo. Ora, a confissão, instituída por motivo de caridade, colidiria com a caridade, se estivéssemos
obrigados a confessar a um só sacerdote. Por exemplo, se o pecador soubesse ser o seu sacerdote
herético; ou que o solicitaria ao mal: ou fraco e inclinado ao pecado ouvido em confissão; ou se fosse
com probabilidade considerado como revelador da confissão; ou se o pecador lhe devesse confessar o
pecado contra ele cometido. Logo, parece que nem sempre devemos confessar ao sacerdote próprio.

6. Demais. ─ Não se nos deve fazer dificuldade no que nos é necessário à salvação, a fim de não nos ficar
impedido o caminho da mesma. Ora, grande dificuldade seria se devêssemos necessariamente confessar
a um só homem; pois, poderia ser isso causa de muitos se absterem da confissão, por temor, vergonha
ou motivos semelhantes. Logo, sendo a confissão de necessidade para a salvação, não se nos deve
impor a obrigação de confessar ao sacerdote próprio.
Mas, em contrário, uma decretal de Inocêncio, instituindo que todos, de ambos os sexos, se confessem
uma vez por ano ao sacerdote próprio.

2. Demais. ─ Assim como o bispo está para a sua diocese, assim o sacerdote para a sua paróquia. Ora,
não é lícito a um bispo exercer os seus deveres episcopais na diocese de outro, segundo o determinam
os cânones. Logo, não é lícito a um sacerdote ouvir em confissão o paroquiano de outro.

SOLUÇÃO. ─ Em relação aos outros sacramentos não é necessário que quem se achega a eles pratique
nenhum ato, mas basta recebê-los ─ como se dá com o batismo e os demais; mas, para o sujeito
constituído árbitro da sua vontade, colher o fruto do sacramento, é necessário que pratique o ato de,
por assim dizer, remover o obstáculo de simulação. Na penitência, porém, o ato de quem se achega ao
sacramento é da substância deste, pois, a contrição, a confissão e a satisfação são partes da penitência,
e são atos do penitente. Ora, os nossos atos, tendo em nós o seu princípio, não nos podem ser
dispensados por outrem, senão por império. Por onde, é necessário, que o constituído dispensador
deste sacramento, seja tal que possa mandar fazer agir. Ora, só pode ter império sobre outrem quem
sobre ele tiver jurisdição. Por isso este sacramento exige necessariamente, não somente que o ministro
tenha a ordem, como no caso dos demais sacramentos, mas também a jurisdição. Por isso, como quem
não é sacerdote não pode conferir este sacramento, assim também não o pode quem não tem
jurisdição. Daí o ser necessário fazermos a confissão, não só a um sacerdote, mas ao sacerdote próprio.
E como o sacerdote não absolve senão obrigando à prática de um certo ato, só aquele pode absolver
que tem o império para obrigar a fazê-lo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Gregório se refere aos monges que têm jurisdição, como
aos que foi cometido a cura de alguma paróquia. E desses certos diziam, mas falsamente, que pelo fato
mesmo de serem monges, não podiam absolver nem impor penitência.

RESPOSTA À SEGUNDA. ─ O sacramento da Eucaristia não exige o império sobre ninguém; ora, o
contrário se dá com este sacramento, como se disse. Por isso a objeção não colhe. ─ E contudo não é
lícito receber a Eucaristia de outrem que não o sacerdote próprio, embora recebamos verdadeiramente
o sacramento, se o recebermos de outrem.

RESPOSTA À TERCEIRA. ─ A escolha de um sacerdote discreto não nos é cometida, de modo a podermos
fazê-la por nosso arbítrio; mas, havendo licença do superior, se por acaso o nosso sacerdote próprio
fosse menos idôneo para dar ao pecado um remédio salutar.

RESPOSTA À QUARTA. ─ Porque aos prelados incumbe dispensar os sacramentos, os quais só pelos
puros devem ser tratados, por isso lhes foi concedido pelo direito que possam escolher os seus
confessores próprios, que como tais lhes são superiores; assim como um médico é curado por outro,
não enquanto médico, mas enquanto doente.

RESPOSTA À QUINTA. ─ Nesses casos, quando o penitente teme com probabilidade algum perigo, para
si ou para o sacerdote, em virtude da confissão a este feita, deve recorrer ao superior ou obter dele
licença de confessar a outro. E se não conseguir obter licença, o caso se julga identicamente do de quem
não teve ensejo de encontrar sacerdote. E então deve, de preferência, escolher um leigo a quem se
confesse. Nem se transgride assim nenhum preceito da Igreja, porque os preceitos de direito positivo
não ultrapassam a intenção do legislador, que é o fim do preceito; e este é a caridade, segundo o
Apóstolo. Nem se faz por aí nenhuma injúria ao sacerdote, pois, merece perder o seu privilégio quem
abusa do poder que lhe foi concedido.

RESPOSTA À SEXTA. ─ O ser necessário confessarmos ao nosso sacerdote próprio não nos dificulta a via
para a salvação, mas ao contrário, garante-nos o caminho por ela. Pois, pecaria o sacerdote que não
fosse fácil em dar licença de nos confessar a outro. Pois, muitos são de tal modo fracos que prefeririam
antes morrer sem confissão, que confessar ao sacerdote que recusaram. E por isso, os demasiado
solícitos em conhecer, pela confissão, a consciência dos seus súditos, preparam laços de danação para
muitos, e portanto, para si próprios.

## Art. 5 — Se podemos confessar a outrem, que não ao nosso sacerdote próprio, por privilégio ou ordem do superior.
O quinto discute-se assim. ─ Parece que não podemos confessar a outrem, que não ao nosso
sacerdote próprio, por privilégio ou ordem do superior.

1. ─ Pois, um privilégio não pode ser tolerado com prejuízo de outrem. Ora, seria em prejuízo do
sacerdote próprio se outro ouvisse a confissão do seu súdito. Logo, não podemos obter tal por
privilégio, licença ou ordem do superior.

2. Demais. ─ O empecilho ao cumprimento de um mandamento divino não pode ser concedido por
ordem nem privilégio de nenhum homem. Ora, é mandamento divino imposto aos reitores das igrejas,
que conheçam de vista as suas ovelhas, o que fica impedido se outro, que não o sacerdote próprio,
ouvir-lhes a confissão. Logo, não pode isso ser mandado por privilégio nem ordem de nenhum homem.

3. Demais. ─ Quem ouve a confissão de outrem é o juiz próprio deste; do contrário não poderia ligá-la e
absolvê-lo. Ora, um mesmo homem não pode ter vários juízes ou sacerdotes próprios; pois, então,
estaria obrigado a obedecer a muitos, o que seria impossível, no caso de mandarem coisas contrárias ou
incompatíveis umas com as outras. Logo, não nos podemos confessar senão ao sacerdote próprio,
mesmo com licença do superior.

4. Demais. ─ Faz injúria ao sacerdote quem o reitera sobre a matéria idêntica; ou pelo menos age
inutilmente. Ora, quem confessou a outro sacerdote, está obrigado a confessar de novo ao sacerdote
próprio, se este o exigir; pois não ficou livre da obediência que o obriga a tal. Logo, não podemos
licitamente confessar a outrem que não ao nosso sacerdote próprio.
Mas, em contrário. ─ Em matéria de ordem, quem tem uma pode permitir que lhe faça as funções a
quem tem ordem semelhante. Ora, o superior, como o bispo, pode ouvir em confissão quem pertence à
paróquia de qualquer presbítero; pois, além disso, reserva para si certos casos, por ser o reitor principal.
Logo, também pode cometer a outro sacerdote que ouça esse mesmo penitente.

2. Demais. ─ Tudo o que pode o inferior pode o superior. Ora, o sacerdote próprio pode dar ao seu
paroquiano licença de confessar a outro. Logo e com muito maior razão, o pode o seu superior.

3. Demais. ─ O poder que o sacerdote tem sobre o povo, do bispo o recebeu. Ora, em virtude desse
poder é que pode ouvir confissão. Logo e pela mesma razão, também o pode outro a quem o bispo deu
esse poder.

SOLUÇÃO. ─ Um sacerdote pode ficar de dois modos impedido de ouvir confissão: por falta de jurisdição
e por impossibilidade de exercer a ordem, como se dá com os excomungados, os degradados e
semelhantes. Mas, quem tem jurisdição pode fazer o que esta lhe faculta. Por onde, quem está
impedido de ouvir em confissão, por falta de jurisdição, pode obter licença para si, de quem tiver
jurisdição imediata sobre o confidente, para lhe ouvir a confissão e absolver, quer obtenha licença do
sacerdote próprio, quer do bispo, quer do Papa. Mas, se por impossibilidade de executar a ordem, não
puder ouvir, pode obter licença de ouvi-la de quem pode remover o impedimento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Não se causa prejuízo a alguém senão subtraindo-lhe o
favor que lhe foi concedido. Ora, o poder de jurisdição não foi cometido a ninguém, como favor; mas,
para utilidade do povo e glória de Deus. Por onde, se os prelados superiores entenderem necessário,
para a salvação do povo e a glória de Deus, cometer a outros a jurisdição, nenhum prejuízo sofrem os
prelados inferiores, salvo àqueles que buscam as suas próprias
coisas e não as que são de Jesus Cristo; e que superintendem no rebanho, não pelo apascentar, mas
para serem apascentados por ele.

RESPOSTA À SEGUNDA. ─ O reitor da Igreja deve de dois modos de conhecer de vista as suas ovelhas. ─
Primeiro, pela consideração atenta do seu comportamento externo, com a qual deve vigiar o rebanho
que lhe foi confiado. E para esse conhecimento não é preciso creia no súdito, mas deve, quanto possível,
inquirir da certeza do fato. ─ De outro modo, pela manifestação da confissão. E desse conhecimento não
pode ter maior certeza senão crendo na confissão do súdito; pois, esta é feita para informar a
consciência do confessor. Por isso, no foro da confissão se crê no confitente, quer fale por si quer contra
si; não porém no Foro do juízo externo. Por onde, para esse conhecimento basta creia no súdito, que diz
ter-se confessado a um sacerdote com poder de absolver. E assim é claro que tal conhecimento não fica
impedido pelo privilégio conferido a outro, de assim ouvir confissão.

RESPOSTA À TERCEIRA. ─ Inconveniente seria se dois fossem constituídos igualmente chefes sobre o
mesmo povo. Mas inconveniente não há se, desses dois constituídos chefes sobre um mesmo povo, um
é mais principal que o outro. Ora, é assim que o pároco, o bispo e o Papa têm a direção imediata do
mesmo povo; e cada um deles pode confiar ao outro o que é matéria da sua jurisdição. ─ Mas o que é o
superior mais principal pode fazê-lo de dois modos. ─ Ou por constituir o outro em seu vigário; e assim o
Papa e o bispo constituem os seus penitenciários. E então esse assim constituído é mais principal que o
prelado inferior; assim, o penitenciário do Papa é mais principal que o bispo; e o penitenciário do bispo,
que o sacerdote pároco, e a esse mais principal está o confitente obrigado a obedecer. ─ De outro
modo, constituindo-o coadjutor desse sacerdote. E como o coadjutor depende daquele a quem deve
coadjuvar, por isso o coadjutor é menos principal. Portanto o penitente não está obrigado a lhe
obedecer tanto quanto ao sacerdote próprio.

RESPOSTA À QUARTA. ─ Ninguém está obrigado a confessar pecados que não tem. E portanto, quem
tiver confessado a um bispo penitenciário, ou a quem tiver recebido licença do bispo; se os pecados
foram perdoados tanto da parte da Igreja como da parte de Deus, não está obrigado a confessá-los ao
sacerdote próprio, embora este o exija. Mas, por causa da determinação da Igreja, sobre a confissão que
devemos fazer ao sacerdote próprio uma vez no ano, deve comportar-se do mesmo modo que quem só
tem pecados veniais. Pois, esse tal deve confessar só os pecados veniais, como certos dizem; ou
confessar que está livre de pecado mortal. E o sacerdote deve, no foro da sua consciência crê-lo, e a Isso
está obrigado. ─ Se porém estivesse obrigado a confessar de novo, não se confessou antes em vão; pois,
quanto maior for o número de sacerdotes a que alguém se confesse, tanto mais se lhe perdoa a pena,
quer por causa do pejo de confessar, considerado como pena satisfatória, quer em virtude do poder das
chaves. De modo que nos poderíamos confessar tantas vezes, que nos livrássemos totalmente da pena.
Nem a reiteração constitui desrespeito para com o sacramento, salve quando este confere a santificação
imprimindo caráter ou pela matéria da consagração, o que nada se dá na penitência. E por isso é bom
que quem ouve confissão pela autoridade de bispo induza o confitente a confessar ao sacerdote
próprio. E se não o quiser, nem por isso deixe de lhe dar a absolvição.

## Art. 6 — Se no fim da vida o penitente pode ser absolvido por qualquer sacerdote.
O sexto discute-se assim. ─ Parece que no fim da vida o penitente não pode ser absolvido por
qualquer sacerdote.

1. ─ Pois, para absolver é preciso ter jurisdição, como se disse. Ora, o sacerdote não adquire jurisdição
sobre quem faz penitência no fim da vida. Logo, não pode absolvê-lo.

2. Demais. ─ Quem, em artigo de morte recebe o sacramento do batismo, de outrem que não o
sacerdote próprio, não deve ser de novo batizado pelo sacerdote próprio. Se portanto, qualquer
sacerdote pode, em artigo de morte, absolver de qualquer pecado, não deverá o penitente, se sarar,
recorrer ao seu sacerdote. O que é falso, do contrário o sacerdote não deveria conhecer de vista o seu
rebanho.

3. Demais. ─ Em artigo de morte, assim como um sacerdote estranho pode batizar, assim também um
não sacerdote. Ora, quem não é sacerdote não pode nunca absolver no foro da penitência. Logo, nem o
sacerdote, aquele que, em artigo de morte, não lhe está sujeito.
Mas, em contrário. ─ A necessidade espiritual é maior que a corporal. Ora, quem está na última
necessidade pode usar das coisas de outrem, mesmo contra a vontade do dono, para obviar à sua
necessidade corporal. Logo, também em artigo de morte, para ocorrer à necessidade espiritual,
podemos ser absolvidos por um sacerdote que não o próprio.

2. Demais. ─ O mesmo dizem as autoridades citadas pelo Mestre das Sentenças.

SOLUÇÃO. ─ Qualquer sacerdote, exerce o seu poder das chaves indistintamente sobre todos e quanto a
todos os pecados; mas o não poder absolver de todos os pecados, é porque, em virtude da ordenação
da Igreja, tem uma jurisdição limitada ou absolutamente nula. Mas, como a necessidade não conhece
lei, por isso, em artigo de urgente necessidade, não fica pela ordenação da Igreja, impedido de absolver,
mesmo sacramentalmente, desde que tem o poder das chaves. E o penitente fica tão bem absolvido por
um sacerdote estranho como o ficaria pelo próprio. Nem só dos pecados pode então ser absolvido por
qualquer sacerdote, mas também da excomunhão tenha ela sido imposta por quem for. E também esta
absolvição depende da jurisdição, delimitada por lei positiva da Igreja.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Pode um exercer a jurisdição de outrem, por vontade
deste, pois, a jurisdição é susceptível de ser delegada. Ora, como a Igreja permite a qualquer sacerdote
absolver em artigo de morte, por isso mesmo pode exercer a jurisdição alguém que dela careça.

RESPOSTA À SEGUNDA. ─ Quem foi absolvido, em artigo de morte, de seus pecados, não precisa depois
recorrer ao seu sacerdote próprio para ser de novo absolvido deles; mas basta comunicar-lhe que o foi.
Nem, do mesmo modo, é necessário que, absolvido da excomunhão, vá ao juízo, que seria o
competente para o absolver, a fim de pedir a absolvição, mas só para oferecer satisfação.

RESPOSTA À TERCEIRA. ─ O batismo tem a sua eficácia, da santificação mesma da matéria; e portanto
quem o receber, seja de quem for, recebe o sacramento. Mas, a virtude sacramental da penitência
consiste na santificação do ministro. E portanto quem confessa a um leigo, embora cumpra, de sua
parte, a confissão sacramental, não recebe contudo a absolvição sacramental. Isso porém lhe contribui
para a diminuição da pena, em virtude do mérito da confissão, e da pena; mas não obtém a diminuição
da pena, diminuição que resultaria do poder das
chaves. E portanto é necessário confessar de novo a um sacerdote. E quem morrer tendo confessado
apenas do modo referido será mais punido, depois desta vida, do que se houvesse confessado a um
sacerdote.

## Art. 7 — Se a pena temporal, cujo reato permanece depois da penitência, é determinada segundo a gravidade da culpa.
O sétimo discute-se assim. ─ Parece que a pena temporal, cujo reato permanece depois da penitência,
não é determinada segundo a gravidade da culpa.

1. ─ Pois, é determinada pela intensidade do deleite que houve no pecado, segundo aquilo da Escritura:
Quanto ela se tem glorificado e tem vivido em deleites, tanto lhe dai de tormento e prantos. Ora, às
vezes, onde há maior deleite ai é menor a culpa; porque os pecados carnais, que causados de maior
deleite que os espirituais, têm menor culpa. Logo, a pena não é determinada pela gravidade da culpa.

2. Demais. ­─ Do mesmo modo estamos obrigados pelos preceitos morais, na Lei Nova como na Lei
Antiga. Ora, na Lei Velha os pecados eram punidos com a pena de sete dias, isto é, o pecador ficava
imundo por sete dias. Logo, como no Testamento Novo se impõe a pena de sete anos por um pecado
mortal, resulta que a gravidade da pena não se mede pela da culpa.

3. Demais. ─ Maior é o pecado de homicídio, no leigo, que o da fornicação, no sacerdote; porque a
circunstância tirada da espécie do pecado mais o agrava, que a tirada da condição da pessoa. Ora, ao
leigo se lhe impõem, pelo homicídio, sete anos de penitência; e ao sacerdote, pela fornicação, uma
penitência de dez anos, segundo os cânones. Logo, a pena não é imposta conforme a gravidade da
culpa.

4. Demais. ─ O pecado máximo é o cometido contra o corpo mesmo de Cristo; pois, tanto mais grave é o
pecado quanto mais elevada é a pessoa contra quem se peca. Ora, pela infusão do sangue de Cristo,
contido no sacramento do altar, se impõe a penitência só de quarenta dias, ou pouco mais; ao passo
que pela fornicação simples é imposta a de sete anos, segundo os Cânones. Logo, a quantidade da pena
não deve proporcionar-se à gravidade da culpa.
Mas, em contrário, a Escritura: Eu a julgarei contrapondo uma a outra medida, quando ela for rejeitada.
Logo, a medida do juízo, que pune o pecado, depende da gravidade da culpa.

2. Demais. ─ O homem se reduz à igualdade da justiça pela pena infligida. Ora, isto não seria se a
gravidade da culpa não respondesse à da pena. Logo, uma responde à outra.

SOLUÇÃO. ─ A pena, depois da punição da culpa, é exigida por dois motivos: para pagar o devido e como
remédio. Pode, pois, a determinação da pena ser considerada a dupla luz. ─ Primeiro, quanto ao débito.
E assim a gravidade da pena radicalmente corresponde à da culpa, antes que desta se perdoe alguma
parte; mas desde que esta foi perdoada, como o que levou a perdoá-la é a principal das causas que lhe
podem atenuar a pena, resta depois disso menos a perdoar, por outra causa; pois, quanto mais, por
motivo da contrição, foi perdoado, da pena, tanto menos resta a ser perdoado pela confissão. Segundo,
como remédio ou para aquele que pecou ou para os outros. E assim, às vezes a um pecado menor se lhe
aplica pena maior. Quer porque ao pecado de um só, se pode mais dificilmente resistir que ao pecado
do outro ─ assim ao jovem se impõe, pela fornicação, pena maior que ao velho, embora peque menos.
Quer porque em um, como no sacerdote, o pecado é mais perigoso. ─ Ou porque a multidão é mais
inclinada a esse pecado; e assim a pena de um amedronta os outros. ─ Por onde, no foro da penitência a
pena há de ser imposta levando-se em conta esse duplo elemento. E portanto nem sempre se há de
impor pena maior ao pecado maior. Mas, a pena do purgatório só visa ao pagamento do débito; pois, já
não haverá mais lugar para o pecado. Por isso essa pena é determinada só pela gravidade do pecado,
levando-se em conta, porém a intensidade da contrição, a confissão e a absolvição, pois, todas essas são
causas de se perdoar uma parte da pena. E por isso também há de o sacerdote levá-las em conta ao
impor a satisfação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Essas palavras aludem a duas partes da culpa: A
glorificação e o prazer. Das quais a primeira respeita à soberba do pecador, que resiste a Deus; o
segundo, ao prazer do pecado. Embora às vezes haja menor prazer numa culpa maior, sempre há nela
contudo maior soberba. Por isso a objeção não colhe.

RESPOSTA À SEGUNDA. ─ Essa pena de sete dias não era expiativa da pena devida ao pecado; por isso,
se o pecador morresse depois desses dias seria punido no purgatório. Mas fazia expiar algumas
irregularidades, como a faziam expiar todos os sacrifícios legais. ─ Nem por isso, contudo, deixa o
homem, em igualdade de circunstâncias, de pecar mais gravemente no regime da Lei Nova que no da
Velha; por causa da mais ampla santificação que recebeu no batismo; e por causa das benefícios
maiores conferidos por Deus ao gênero humano. O que se conclui das palavras do Apóstolo: Quantos
maiores tormentos credes vós que merece o que pisar aos pés o Filho de Deus, e tiver em conta de
profano o sangue do Testamento em que foi santificado? Nem contudo é uma verdade universal, que
seja exigido por cada pecado mortal sete anos de penitência; mas essa é uma como regra comum,
aplicável à maior parte dos casos; que porém não se deve aplicar, consideradas as diversas
circunstâncias dos pecados.

RESPOSTA À TERCEIRA. ─ O bispo e o sacerdote pecam com maior perigo para si e para os outros. Por
isso mais solicitamente procuram os Cânones afastá-los do pecado, que os outros, impondo-lhes maior
pena, como remédio; embora na realidade não lhes fosse devida tanta. Por isso no purgatório não se lhe
há de exigir tão grave pena.

RESPOSTA À QUARTA. ─ Essa pena se deve entender aplicável quando o fato aludido se der contra a
vontade do sacerdote. Pois se espontaneamente fizesse a efusão, seria digno de pena muito mais grave.