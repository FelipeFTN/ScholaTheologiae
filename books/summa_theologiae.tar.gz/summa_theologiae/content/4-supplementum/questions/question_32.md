# Questão 32: Daqueles a quem este sacramento deve ser conferido e em
que parte do corpo.
Em seguida devemos tratar daqueles a quem este sacramento deve ser conferido e em que parte do
corpo.
Sobre o que sete artigos se discutem:

## Art. 1 — Se este sacramento deve ser conferido também aos sãos.
O primeiro discute-se assim. ─ Parece que este sacramento deve ser conferido também aos sãos.

1. ─ Pois, o efeito principal deste sacramento é a cura, antes, da alma que a do corpo, como se disse.
Ora, mesmo os sãos de corpo precisam de serem curados na alma. Logo, também a eles se lhes deve
conferir este sacramento.

2. Demais. ─ Este sacramento é o dos que se vão desta vida, assim como o batismo é o dos que entram
nela. Ora, a todos os que entram na vida se lhes confere o batismo. Logo, a todos os que dela saem deve
este sacramento ser conferido. Ora, às vezes aqueles que estão a ponto de deixar a vida, como os que
vão ser decapitados, estão sãos. Logo, a esses tais deve este sacramento ser conferido.
Mas, em contrário, a Escritura: Está entre vós algum enfermo? Etc. Logo, só compete aos enfermos.

SOLUÇÃO. ─ Este sacramento e uma cura espiritual, como se disse; e essa é significada a modo de cura
do corpo. Por onde, aqueles que não precisam de curar o corpo, isto é, os sãos, não se lhes deve conferir
a eles este sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora a saúde espiritual seja o efeito principal deste
sacramento, contudo e necessário que pela cura do corpo seja significa da a cura espiritual do
sacramento, mesmo se dela não resulta a saúde do corpo. Por isso, a saúde espiritual só aqueles este
sacramento a pode conferir, que precisam da saúde do corpo, isto é, os enfermos; assim como só pode
receber o batismo quem pode receber a ablução do corpo, e portanto não o pode o feto existente no
ventre materno.

RESPOSTA À SEGUNDA. ─ Mesmo o batismo só o podem receber os que entrando na vida, são
susceptíveis da ablução. Por onde, a extrema unção só a podem receber os que se vão da vida e que
assim são susceptíveis de cura do corpo.

## Art. 2 — Se este sacramento deve ser ministrado em qualquer enfermidade.
O segundo discute-se assim. ─ Parece que este sacramento deve ser ministrado em qualquer
enfermidade.

1. ─ Pois, quando a Escritura refere a instituição deste sacramento nenhuma enfermidade determina.
Logo, em todas as enfermidades deve ele ser ministrado.

2. Demais. ─ Quanto mais digno é um remédio tanto mais geral deve ser. Ora, este sacramento é mais
digno que o remédio do corpo. Logo, sendo o remédio do corpo dado a todos os doentes, parece que
também deve sê-lo este sacramento.
Mas, em contrário: ─ Este sacramento é chamado por todos extrema unção. Ora, nem toda doença leva
a vida ao fim, pois certas são causas de uma vida mais longa, como o diz o Filósofo. Logo, nem em todas
as enfermidades deve ser conferido este sacramento.

SOLUÇÃO. ─ Este sacramento é o último remédio que a Igreja pode conferir, quase imediatamente
dispositivo para a glória. Por isso só deve ser conferido aos enfermos moribundos, quando a doença é
de natureza a causar a morte e teme-se esse perigo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Qualquer doença pode, chegada a um certo grau, causar
a morte. Por onde, pesados os gêneros das enfermidades, em qualquer doença pode-se ministrar este
sacramento; por isso o Apóstolo não se refere a nenhuma determinadamente. Levando-se em conta
porém o modo e o estado da doença, nem sempre deve aos doentes ser conferido este sacramento.

RESPOSTA À SEGUNDA. ─ O remédio corporal tem como principal efeito a saúde do corpo, da qual
todos os doentes em qualquer estado necessitam. Ora, este sacramento tem como efeito principal a
melhoria necessária ao estado da alma dos que estão a ponto de sair desta vida e se encaminham para a
glória. Logo, o símile não colhe.

## Art. 3 — Se aos loucos e aos dementes pode ser conferido este sacramento.
O terceiro assim se discute. ─ Parece que aos loucos e aos dementes pode ser conferido este
sacramento.

1. ─ Pois, tais doenças são perigosíssimas e dispõem com rapidez para a morte. Ora, a um perigo deve-se
aplicar um remédio. Logo, este sacramento, remédio às enfermidades humanas, deve ser conferido aos
de que se trata.

2. Demais. ─ O sacramento do batismo é mais digno que este. Ora, o batismo pode ser conferido aos
loucos, como se disse. Logo, também este lhes deve ser ministrado.
Mas, em contrário. ─ Este sacramento não deve ser conferido senão aos que o reconhecem. Ora, tais
não são os loucos nem os dementes. Logo, não se lhes deve conferir.

SOLUÇÃO. ─ Para colher o efeito deste sacramento muito contribui a devoção de quem o recebe, o
mérito pessoal dos que o conferem e o geral de toda a Igreja; isso resulta claro da forma deprecativa
que nele é proferida. Por onde, os que não podem ter o conhecimento desse sacramento e recebê-lo
com devoção, a esses não se lhes deve dar. E sobretudo aos loucos e aos dementes, capazes de tratar
com irreverência o sacramento, profanando-o com atos inconvenientes. Salvo se tiverem intervalos
lúcidos, em que pudessem reconhecê-lo; e então nesse estado se lhes poderia ministrar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora esses tais possam às vezes estar em perigo de
morte, contudo não se lhes pode aplicar um remédio mediante a devoção própria deles. Por isso, não
lhes deve ser conferido.

RESPOSTA À SEGUNDA. ─ O batismo não requer o ato do livre arbítrio, porque é conferido
principalmente como remédio do pecado original. Do contrário, este sacramento requer um tal ato.
Logo, não há símile. Além disso, o batismo é um sacramento necessário à salvação, mas não a extrema
unção.

## Art. 4 — Se este sacramento deve ser conferido às crianças.
O quarto discute-se assim. ─ Parece que este sacramento deve ser conferido às crianças.

1. ─ Pois, das mesmas enfermidades podem sofrer tanto as crianças como os adultos. Ora, à mesma
doença se deve aplicar o mesmo remédio. Logo, este sacramento deve ser conferido tanto aos adultos
como às crianças.

2. Demais. ─ Este sacramento é ministrado para purificar das relíquias do pecado, como se disse ─ tanto
das do pecado original como das do atual. Ora, as crianças também sofrem as consequências do pecado
original. Logo, deve-lhes ser conferido este sacramento.
Mas, em contrário, a ninguém deve ser ministrado este sacramento, a quem não seja susceptível da
forma dele. Ora, às crianças, que não pecaram pela vista e pelos ouvidos, como reza a fórmula, esta não
se lhes aplica. Logo, não lhes deve ser ministrado este sacramento.

SOLUÇÃO. ─ Este sacramento exige, como a Escritura, a devoção atual em quem o recebe. Por onde,
assim como a Eucaristia não deve ser dada às crianças, assim nem este sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ As doenças não são causadas, nas crianças, como nos
adultos, pelo pecado atual. Ora, este sacramento é sobretudo ministrado como remédio contra os que
são uns como restos dos pecados que as causaram.

RESPOSTA À SEGUNDA. ─ Este sacramento não é conferido contra as relíquias do pecado original, senão
enquanto de certo modo fortificadas pelos pecados atuais. Por isso é o principalmente conferido contra
os pecados atuais, como resulta da própria forma; e esses não existem nas crianças.

## Art. 5 — Se neste sacramento deve ser ungido todo o corpo.
O quinto assim se discute. ─ Parece que, neste sacramento, deve ser ungido todo o corpo.

1. ─ Pois, segundo Agostinho, a alma está toda em todo o corpo. Ora, este sacramento é ministrado
sobretudo para curar a alma. Logo, todo o corpo deve ser o ungido.

2. Demais. ─ Onde está a doença aí se deve aplicar o remédio. Ora, às vezes o mal, como a febre, é geral
e está em todo corpo. Logo, todo ele deve ser ungido.

3. Demais. ─ No batismo todo o corpo é imerso. Logo, também deve ser todo ungido.
Mas, em contrário, é costume da Igreja universal, pelo qual, neste sacramento, o enfermo não é ungido
senão em determinadas partes do corpo.

SOLUÇÃO. ─ Este sacramento é aplicado como remédio. Ora, a cura do corpo não é preciso seja feita
pela aplicação do remédio a todo ele, mas só naquelas partes onde está a raiz do mal. Por onde,
também a unção sacramental deve ser feita só naquelas partes onde está a raiz do mal espiritual.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A alma embora esteja essencialmente em todas as partes
do corpo, não está porém desse modo em todas as potências dele, que é onde estão as raízes dos atos
pecaminosos. Por isso, hão de fazer-se as unções nas determinadas partes do corpo onde tem essas
potências a sua sede.

RESPOSTA À SEGUNDA. ─ Nem sempre se aplica o remédio onde está a doença; mas antes, e melhor,
onde está a raiz do mal.

RESPOSTA À TERCEIRA. ─ O batismo se faz sob a forma de ablução. Ora, a ablução corporal só purifica
da mancha a parte do corpo onde se faz; por isso o batismo é aplicado a todo o corpo. Diferente é o
caso da extrema unção, como dissemos.

## Art. 6 — Se estão bem determinadas as partes onde o doente deve ser ungido: os olhos, o nariz, os ouvidos, os lábios, as mãos e os pés.
O sexto discute-se assim. ─ Parecem mal determinadas as partes onde o doente deve ser ungido: os
olhos, o nariz, os ouvidos, os lábios, as mãos e os pés.

1. ─Pois, o médico perito cura a doença na raiz. Do coração vem as causas que fazem o homem imundo,
diz o Evangelho. Logo, a unção deve ser feita no peito.

2. Demais. ─ A pureza da alma não é menos necessária aos que saem da vida que aos que nela entram.
Ora, os que entram o sacerdote os unge na cabeça com o crisma, para significar a pureza da alma. Logo,
também aos moribundos que recebem este sacramento, se lhe deve ungir na cabeça.

3. Demais. ─ O remédio deve ser aplicado onde é maior a força da doença. Ora, a doença espiritual tem
a sua sede principal nos rins, e nas mulheres no umbigo, como diz a Escritura: A sua fortaleza está nos
seus lombos, segundo a exposição de Gregório. Logo, aí devia ser feita a unção.

4. Demais. ─ Assim como pecamos com os pés, assim com os demais membros do corpo. Logo, assim
como são ungidos os pés, assim também devem sê-lo os demais membros.

SOLUÇÃO. ─ Os princípios do pecado, em nós, são os mesmos que os do agir pois o pecado é um ato.
Ora, os princípios dos nossos atos são três: o dirigente, que é a faculdade cognoscitiva; o imperante, que
é a potência apetitiva; e o exequente, que é a potência motiva. Ora, todos os nossos conhecimentos tem
a sua fonte nos sentidos. E como onde está em nós a origem primeira do pecado, aí deve aplicar-se a
unção, por isso se ungem as sedes dos cinco sentidos: os olhos, por causa da vista; os ouvidos, por causa
da audição; as narinas, por causa do olfato; a boca, por causa do gosto; as mãos, por causa do tato, que
se exerce sobretudo pelas pontas dos dedos. Certos porém ungem os rins, por causa da potência
apetitiva. Por causa da motiva, se ungem os pés, principal instrumento dela. E como o princípio primeiro
da ação é a potência cognoscitiva, por isso todos observam a prática de ungir os órgãos dos cinco
sentidos, como necessária à validade do sacramento. Outros porém não observam as outras práticas;
outros, ainda, fazem a unção nos pés e não nos rins, por serem as potências apetitiva e motiva os
princípios secundários da ação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O pensamento não se manifesta fora do coração senão
por uma certa imaginação, que é um movimento originado do sentido, como diz Aristóteles. Por onde,
no coração não a tem o pensamento a sua raiz primeira, mas nos órgãos dos sentidos; salvo, enquanto é
o coração o princípio de todo o corpo. Mas esse princípio é uma raiz remota.

RESPOSTA À SEGUNDA. ─ Os que entram na vida devem adquirir a pureza da alma; ao passo que os que
dela saem devem purificá-la. Por isso, os que dela saem devem ser ungidos nas partes onde pode ser
inquinada a pureza da alma.

RESPOSTA À TERCEIRA. ─ Certos tem o costume de fazer a: unção nos rins, porque aí, se exerce
sobretudo o apetite concupiscível. Ora, a potência apetitiva não é a raiz primeira da ação, como se disse.

RESPOSTA À QUARTA. ─ Os órgãos do corpo, pelos quais se exercem os atos pecaminosos, são os pés,
as mãos e a língua, onde também se faz a unção; e os membros genitais, onde, por serem partes
pudendas, não se deve ela fazer.

## Art. 7 — Se os mutilados devem ser ungidos com as unções que convêm a essas partes.
O sétimo discute-se assim. ─ Parece que os mutilados não devem ser ungidos com as unções que
convêm a essas partes.

1. Pois, assim como este sacramento exige uma determinada disposição em quem o recebe, isto é, que
esteja enfermo, assim também deve ser ministrado numa parte determinada. Ora, quem não sofre de
nenhuma enfermidade não pode ser ungido. Logo, também não o deve quem não tem a parte onde
deve ser feita a unção.

2. Demais. ─ O cego de nascença não pode pecar com a vista. Ora, quando se faz a unção nos olhos, faz-
se menção do pecado pela vista. Logo, tal unção não deve ministrar-se ao cego de nascença. E assim em
casos semelhantes.
Mas, em contrário, uma deficiência corpórea não impede a recepção de nenhum dos outros
sacramentos. Logo, também não deve ser impedimento a este. Ora, este sacramento exige
necessariamente uma unção. Logo, todas se devem fazer nos mutilados.

SOLUÇÃO. ─ Também os mutilados devem ser ungidos, nas partes as mais próximas possíveis daquelas
onde a unção devia ser feita. Pois, embora não tenham os membros, têm contudo as potências da alma
correspondentes, ao menos radicalmente, a esses membros. E podem pecar interiormente, embora não
exteriormente pelas potências da alma correspondentes a essas partes.
Donde se deduzem as respostas às objeções.