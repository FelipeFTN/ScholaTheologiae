# Questão 97: Da pena dos condenados.
Em seguida devemos tratar do concernente aos condenados, depois do juízo. E, primeiro, da pena dos
condenados e do fogo que lhes atormentará o corpo. Segunda, do que lhes concerne ao afeto e ao
intelecto. Terceiro, da justiça e da misericórdia de Deus para com eles.
Na primeira questão discutem-se sete artigos:

## Art. 1 — Se os condenados no inferno são atormentados só pela pena do fogo.
O primeiro discute-se assim. ─ Parece que os condenados no inferno são atormentados só pela pena
do fogo.

1. ─ Pois, o Evangelho, quando se refere à condenação deles, faz menção só do fogo: Apartai-vos de
mim, malditos, para o fogo eterno.

2. Demais. ─ Assim como a pena do purgatório é a merecida pelo pecado venial, assim a do inferno é a
merecida pelo pecado mortal. Ora, a Escritura não nos diz que haja no purgatório outra pena além da do
fogo. Assim, aquilo do Apóstolo: Qual seja a obra de cada um o fogo o provará. Logo, também no
inferno não haverá outra pena além da do fogo.

3. Demais. ─ A variedade das penas causa um certo refrigério ao sofrimento; assim como quando
alguém é transferido do calor para o frio. Ora, nenhum refrigério haverá para os condenados. Logo, não
haverá no inferno, penas diversas, mas só a do fogo.
Mas, em contrário, a Escritura: O fogo, o enxofre e as tempestades são a parte que lhes toca.

2. Demais. ─ Diz ainda a Escritura: Passará das águas da neve para um excessivo calor.

SOLUÇÃO. ─ Segundo Basílio, na última purificação do mundo, haverá a separação dos elementos: o que
for puro e nobre permanecerá na região superior, para glória dos bem-aventurados; e tudo o que for
ignóbil e grosseiro será precipitado no inferno para pena dos condenados. De modo que, assim como
toda criatura será para os santos, matéria de alegria, assim todas concorrerão para aumentar o
tormento dos condenados, segundo aquilo da Escritura: Todo o universo pelejará da parte dele contra
os insensatos. ─ E também entra no plano da divina justiça que, assim como, abandonando o bem único,
pelo pecado, constituíram o seu fim nas causas materiais, que são muitas e varias, assim também sejam
atormentados de muitos modos e por muitas causas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O fogo, pela sua grande virtude ativa, é capaz de nos
causar os maiores suplícios. Por isso serve o seu nome para designar sofrimentos veementes, quaisquer
que sejam.

RESPOSTA À SEGUNDA. ─ O fim principal das penas do purgatório não é atormentar, mas purificar. Por
isso devem ser causadas só pelo fogo, cuja virtude é essencialmente purificadora. Ora, as penas dos
condenados não se ordenam a purificá-las. Não há, pois, símile.

RESPOSTA À TERCEIRA. ─ Os condenados passarão de um veementíssimo calor para um frio
veementíssimo sem gozarem com isso de nenhum refrigério. Porque o sofrimento dos condenados,
provocado por agentes externos, não será como o que causam em nós, alterando a disposição natural,
que encontrou em nosso corpo, de modo a reduzi-la a um estado proporcionado de equilíbrio,
procurando-nos assim um refrigério: Mas será por ação espiritual, pela qual os sensíveis atuam sobre os
sentidos, fazendo-se sentir pela impressão no órgão das suas formas, no seu ser espiritual, e não no
material.

## Art. 2 — Se o verme que tortura os condenados é material.
O segundo discute-se assim. ─ Parece que o verme que tortura os condenados é um verme material.

1. ─ Pois, a carne não pode ser atormentada por um verme espiritual. Ora, a carne dos condenados será
atormentada por um verme, conforme a Escritura: Fará vir sobre as suas carnes o fogo e os bichos. E
noutro lugar: A vingança da carne do ímpio será o toga e o bicho. Logo, esse verme será material.

2. Demais. ─ Agostinho diz: Ambos ─ fogo e verme ─ serão penas da carne. Donde a mesma conclusão
anterior.
Mas, em contrário, Agostinho: o fogo inextinguível e o verme imperecível, que serão a pena dos maus,
uns os entendem de um modo e outros, de outro. Uns dizem que serão ambos suplícios do corpo;
outros, da alma; uns aplicam o fogo no seu sentido próprio ao corpo e, em sentido figurado, à alma, o
verme ─ o que é mais aceitável.

SOLUÇÃO. ─ Depois do dia do juízo, no mundo renovado, não haverá mais nenhum animal, nem
nenhum corpo misto além do homem. Porque de um lado tais seres ─ animais e corpos mistos ─ não são
destinados à incorrupção de outro, depois do juízo não mais haverá geração nem corrupção. Por onde, o
verme, suplício dos condenados, não deve ser entendido como um verme material, mas espiritual, como
o remorso da consciência. Chamado verme por nascer da podridão do pecado e ser o suplício da alma,
assim como o verme corpóreo nasce da podridão da matéria e faz sofrer com as suas punções.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A alma dos condenados a Escritura lhes chama carnes,
por se terem em vida escravizado à carne. Ou também podemos dizer que o verme espiritual
atormentará a carne, pela redundância no corpo dos sofrimentos da alma, tanto nesta vida como na
futura.

RESPOSTA À SEGUNDA. ─ Agostinho fala em sentido comparativo. Pois, não pretende afirmar que esse
verme seja, absolutamente considerado, material; mas que deveríamos, antes, admitir verme e fogo
entendidos em sentido material, do que os entender a ambos em sentido puramente espiritual. Porque,
neste último caso, os condenados não sofreriam nenhuma pena corporal. Essa interpretação resulta
clara a quem refletir no contexto do santo doutor.

## Art. 3 — Se o pranto que chorarão os condenados o será em sentido material.
O terceiro discute-se assim. ─ Parece que o pranto que chorarão os condenados o será em sentido
material.

1. ─ Pois, a Glosa diz que o pranto, com que o Senhor ameaça os réprobos, pode provar
verdadeiramente a ressurreição dos corpos. O que não se daria se esse pranto fosse puramente
espiritual.

2. Demais. ─ A tristeza causada pela pena corresponde ao prazer culposo gozado, conforme aquilo do
Apocalípse: Quanto ela se tem glorificado e tem vivido em deleites tanto lhe dai de tormento e prantos.
Ora, os pecadores se deleitaram culposamente interior e exteriormente. Logo, também hão de
derramar prantos exteriores.
Mas, em contrário. ─ O pranto corporal consiste numa secreção de lágrimas. Ora, o corpo dos
condenados não é susceptível de uma perpétua secreção, pois, não podem restaurar-se pela
alimentação; e todo ser finito se consome se perde continuamente da sua natureza. Logo, os
condenados não chorarão um pranto material.

SOLUÇÃO. ─ O pranto material implica duas cousas, ─ Uma, o derramamento de lágrimas. E, por aí, os
condenados não no poderão chorar. Porque depois do dia do juízo, cessado o movimento do primeiro
móvel, não mais haverá geração nem corrupção nem alteração corpórea. Ora, para se poderem
derramar as lágrimas é necessária a geração do humor que nelas se resolve. Donde o não poderem os
condenados chorar um pranto material. ─ Além disso, o pranto material supõe também uma certa
comoção e turbação da cabeça e dos olhos. E, por este lado, os condenados poderão chorar, depois da
ressurreição. Pois, os seus corpos serão atormentados, não só por causas externas, mas também
internas, pela alteração agradável ou penosa da alma e nele redundante. E a esta luz, o pranto do corpo
é uma prova da ressurreição e corresponde ao prazer culposo, gozado pela alma e pelo corpo.
Donde se deduzem as respostas às objeções.

## Art. 4 — Se os condenados são rodeados de trevas materiais.
O quarto discute-se assim. ─ Parece que os condenados não são rodeados de trevas materiais.

1. - Pois, aquilo de Job ─ Mas aí habita um sempiterno horror ─ diz Gregório: Embora o fogo do inferno
não traga com a sua luz nenhuma consolação, contudo luzirá para mais atormentar, fazendo, com a
ilustração da sua chama, os réprobos verem os sequazes que consigo arrastaram. Logo, as trevas do
inferno não serão materiais.

2. Demais. ─ Os condenados vêem a sua pena, o que lhes contribuirá para o aumento dela. Ora, nada
podemos ver sem luz. Logo, as trevas do inferno não serão materiais.

3. Demais. ─ Os condenados no inferno terão o sentido da vista, depois de terem reassumido o corpo.
Ora, esse sentido lhes seria inútil se nada vissem. Logo, como não é possível ver nada senão mediante a
luz, parece que de nenhum modo estarão rodeados de trevas.
Mas, em contrário, o Evangelho: Atai-os de pés e mãos e lançai-os nas trevas exteriores. Ao que diz
Gregório: Se o fogo do inferno desse luz, nunca o Evangelho diria que foram atirados nas trevas
exteriores.

2. Demais. ─ Aquilo do salmista ─ Voz do Senhor, que divide a chama do fogo ─ diz Basílio: O poder de
Deus fará com que a luz do fogo se lhe separe da sua virtude adustiva, de modo que a sua claridade
redundará em alegria dos santos e a sua virtude adustiva em tormento dos condenados. Logo, os
condenados estarão rodeados de trevas materiais.
Quanto ao mais, atinente à pena dos condenados, já tratamos antes.

SOLUÇÃO. ─ A disposição do inferno será tal como especialmente convém à miséria dos condenados. A
luz, pois, e as trevas que nele houver serão as mais aptas para entreter essa miséria. Ora, a visão, em si
mesma, nos é uma causa de prazer; pois, como diz Aristóteles, o sentido da vista é o mais amável,
porque nos dá muitos conhecimentos. Mas, por acidente, pode a visão ser causa de sofrimento, como
quando vemos o que nos pode ser nocivo ou repugnante à nossa vontade. Por isso o inferno deve ser
um lugar disposto de modo aos condenados poderem ver, tanto na luz como nas trevas; de maneira que
aí nada enxerguem à plena luz, mas apenas distingam, envolto numa certa umbrosidade, tudo o que
lhes puder aumentar a aflição do coração. É, pois, absolutamente falando, a mansão das trevas, mas,
por disposição divina, banhada de luz suficiente para fazer-lhe divisar o que lhes pode torturar a alma. E
para isso suficientemente contribui a natural situação do lugar que o inferno ocupa, no meio da terra,
onde não pode existir senão um fogo sombrio, turbido e como fumoso.
Outros porém explicam a causa dessas trevas pelo acúmulo em massa dos corpos dos condenados, cuja
multidão encherá de tal modo o receptáculo do inferno, que expulsará daí todo o ar. Não haverá
portanto nele nada de diáfano, susceptível de ser o sujeito da luz e das trevas, senão os olhos dos
condenados, obscurecido por elas.
Donde se deduzem as respostas às objeções.

## Art. 5 — Se o fogo do inferno, que cruciará os corpos dos condenados, será um fogo corpóreo.
O quinto discute-se assim. ─ Parece que o fogo do inferno, que cruciará os corpos dos condenados,
não será um fogo corpóreo.

1. ─ Pois, diz Damasceno: O diabo, os demônios e o seu homem, o Anticristo, os ímpios e os pecadores
serão precipitados no fogo eterno, não material, como o nosso, mas de natureza que Deus sabe. Ora,
tudo o corpóreo é material. Logo, o fogo do inferno não será corpóreo.

2. Demais. ─ As almas dos condenados, separadas dos corpos, serão transportadas ao fogo do inferno.
Ora, Agostinho diz: O lugar para onde a alma será transportada depois da morte, penso que é um lugar
espiritual e não corpóreo. Logo, o fogo do inferno não será um fogo corpóreo .

3. Demais. ─ Um fogo corpóreo nada tem de análogo, no modo da sua ação, à culpa daquele que nele
arde; mas antes age ao modo do úmido e do seco: pois, vemos que o mesmo fogo corpóreo tortura
tanto o justo como o ímpio. Ao contrário, o fogo do inferno acompanha, no seu modo de supliciar ou de
atuar o modo da culpa do punido. Por isso diz Gregório: certo, um só é o fogo da geena, mas não crucia
do mesmo modo a todos os pecadores; pois, cada um tanto sentirá de pena quanto lh’o exige a culpa.
Mas, em contrário, diz ainda Gregório: Não duvido que o toga da geena seja um toga corpóreo, onde é
certo que os corpos serão cruciados.

2. Demais. ─ A Escritura diz: Todo o universo pelejará da parte dele contra os insensatos. Ora, todo o
universo não pelejaria contra os insensatos, se fossem punidos por uma pena só espiritual e não
corporal. Logo, serão punidos por um fogo corpóreo.

SOLUÇÃO. ─ Sobre o fogo do inferno há muitas opiniões.
Assim, certos filósofos, como Avicena, não acreditando na ressurreição, crêem que só a alma é a punida,
depois da morte. Mas como viam o absurdo de ser a alma, incorpórea, punida por um fogo corpóreo,
negaram a natureza corpórea do fogo com que os maus são punidos, ensinando que devemos tomar em
sentido metafórico todas as punições de natureza corpórea atribuídas à alma depois da morte. Pois,
assim como o prazer e a felicidade das almas boas não consistirá em nada de corpóreo, mas num bem
espiritual, que é a consecução do seu fim, assim também o suplício dos maus será somente espiritual e
consistirá na tristeza de se verem separados do fim, de que têm um desejo natural imanente. Por onde,
assim como todos os prazeres de natureza material atribuídos à alma depois da morte, como o repouso,
o riso e outros devem ser entendidos em sentido metafórico, assim todas as torturas que supõem
punição corpórea, como a de arderem ao fogo, de sofrerem odores fétidos e outras, devem ser
entendidas no mesmo sentido. Pois, o prazer e o sofrimento espirituais, sendo incompreendidos da
multidão é necessário lhe figurarmos mediante prazeres e penas materiais, para mover com eficácia os
homens ao desejo ou ao temor. ─ Mas esse modo de explicar a punição não é suficiente porque a pena
dos condenados não será só a do dano, correspondente à aversão que houve na culpa, mas também a
do sentido, correspondente à conversão da culpa.
Por isso o próprio Avicena acrescenta outra explicação, dizendo que as almas dos maus depois da morte
não serão punidas por meios materiais, mas por semelhanças. Assim, nos sonhos, por tais semelhanças,
existentes na imaginação, pode-se nos afigurar que somos torturados por penas diversas. E também
Agostinho parece admitir esse modo de punição, como o demonstrar o lugar supra-citado. ─ Mas isto
não é admissível. Porque a imaginação é uma potência que se serve de um órgão corpóreo , por isso não
é possível a alma separada do corpo ter, como a de quem sonha, essas visões imaginárias.
Razão por que ainda Avicena, para evitar esse inconveniente, disse que as almas separadas do corpo
usam, como de órgão, de uma parte do corpo celeste, a que há de o corpo humano conformar-se para
ter perfeição a alma racional, semelhante aos motores do corpo celeste. E nisto seguiu de certo modo a
opinião dos antigos filósofos, que ensinavam a volta das almas aos corpos celestes a elas semelhantes. ─
Mas isto é absolutamente absurdo, segundo a doutrina do Filósofo. Porque a alma se serve de um
determinado órgão corpóreo, como a arte de um determinado instrumento. Por isso não pode passar
de um corpo para outro, como o ensina Pitágoras. ─ Quanto ao que diz Agostinho, responderemos mais
adiante.
Seja, porém, o que for que se pense do fogo que crucia as almas separadas, quanto ao fogo, que
atormentará os corpos dos condenados depois da ressurreição, devemos dizer que é um fogo corpóreo.
Porque a um corpo não pode convenientemente adaptar-se senão uma pena corpórea. Donde a prova
de Gregório que o fogo do inferno é de natureza corpórea, por isso mesmo que os réprobos, depois da
ressurreição, nele serão precipitados. E também Agostinho, conforme o Mestre das Sentenças, declara
manifestamente que o fogo atormentador dos corpos é um fogo corpóreo. Ora, é disto que agora se
trata. ─ Quanto a saber como as almas dos condenados são punidas por esse fogo corpóreo, já o
dissemos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Damasceno não nega, absolutamente falando, que o fogo
do inferno seja material, mas que não o é como o é o nosso, por se distinguir deste por certas
propriedades. ─ Ou devemos responder que o fogo do inferno não alterando materialmente os corpos,
mas atuando sobre eles, para os punir por uma ação espiritual, por isso dizemos que não é material.
Não quanto à sua substância, mas quanto ao efeito punitivo que exerce sobre os corpos e, muito mais
ainda, sobre as almas.

RESPOSTA À SEGUNDA. ─ As palavras de Agostinho podem ser interpretadas do modo seguinte. Que
não é corpóreo o lugar para onde as almas serão transportadas depois da morte no sentido em que elas
aí não estarão de modo material, como um corpo está materialmente num lugar, mas do modo
espiritual pelo qual os anjos ocupam lugar. ─ Ou devemos responder que Agostinho dá apenas uma
opinião, sem nada decidir, como frequentemente faz nesses livros citados.

RESPOSTA À TERCEIRA. ─ O fogo do inferno será um instrumento de punição da divina justiça. Ora, um
instrumento age, não só por virtude própria e de um modo próprio, mas também por obra do agente
principal e enquanto dirigido por ele . Por onde, embora o fogo não possa, por virtude própria, cruciar o
pecador mais ou menos, conforme a gravidade do seu pecado, pode-o porém se tiver a sua ação
modificada por ordem da divina justiça. Assim como também o fogo de uma fornalha pode ser
modificado na sua ação por indústria do ferreiro, a fim de produzir o efeito que ele na sua arte se
propõe.

## Art. 6 — Se o fogo do inferno é da mesma espécie que o nosso fogo material.
O sexto discute-se assim. ─ Parece que o fogo do inferno não é da mesma espécie que o nosso fogo
material.

1. ─ Pois, Agostinho diz, conforme o Mestre: Qual seja a natureza do fogo eterno, penso que ninguém
sabe senão talvez aquele a quem o Espírito divino o revelar. Ora, a natureza do nosso fogo todos ou
quase todos conhecem. Logo, o fogo do inferno não é da mesma espécie ou natureza que o nosso.

2. Demais. ─ Expondo aquilo de Job ─ Devorá-lo-á o fogo que não se acende, diz Gregório: O fogo
corpóreo precisa, para manter-se, de alimentos materiais; e nem pode existir senão aceso, apagando-se
se não for entretido. Pelo contrário, o fogo da geena, apesar de corpóreo e de queimar corporalmente
os réprobos nele lançados, nem precisa ser aceso por cuidado humano nem de ser alimentado com
lenha. Mas, uma vez criado, perdura inextinguível; nem necessita de ser acendido, nem o seu ardor se
enfraquece. Logo, não tem a mesma natureza que o nosso fogo.

3. Demais. ─ O eterno e o corruptível não tem a mesma essência, pois, nem comunicam pelo mesmo
gênero, segundo o Filósofo. Ora, o nosso fogo é corruptível, ao passo que o do inferno é eterno,
conforme aquilo do Evangelho: Apartai-vos de mim, malditos, para o fogo eterno. Logo, não são da
mesma natureza.

4. Demais. ─ E da natureza do nosso fogo luzir. Ora, o fogo do inferno não luz; por isso pergunta Job:
Porventura a luz do ímpio não se apagará? Logo, não é da mesma natureza que o nosso.
Mas, em contrário. ─ Segundo o Filósofo, as águas são todas da mesma espécie. Logo e pela mesma
razão, os fogos são todos da mesma espécie.

2. Demais. ─ A Escritura diz: pelas cousas em que alguém peca, por essas é também atormentado. Ora,
os homens pecam pelas cousas sensíveis deste mundo. Logo, é justo sejam também por elas punidos.

SOLUÇÃO. ─ O fogo, por ser de todos os elementos o de maior virtude ativa, tem os outros corpos como
a sua matéria, como diz Aristóteles. Daí os dois modos da sua existência: na sua matéria própria, quando
está na sua esfera; e na matéria estranha, quer terrestre, como o carvão, quer aérea, como na chama.
Ora, de qualquer modo que exista, é sempre especificamente o mesmo, pelo que lhe concerne à
natureza; pode porém ser de espécie diferente, quanto aos corpos que lhe constituem a matéria. Por
isso, a chama e o carvão diferem especificamente; assim como a madeira em brasa, do ferro em brasa.
Nem importa tenha sido o fogo aceso por força de um agente externo, como se dá com o ferro, ou por
um princípio intrínseco natural, como no caso do enxofre. ─ Ora, é manifesto que o fogo do inferno, pela
sua natureza de fogo, é da mesma espécie que o nosso fogo. Se porém esse fogo existe em matéria
própria sua ou, se estranha, de que natureza seja, isso nos é desconhecido. E assim, pode,
materialmente considerado, diferir em espécie do nosso fogo. Mas tem certas propriedades diferentes
das do nosso, pois, nem precisa de ser acendido, nem de ser alimentado com lenha. Essas diferenças
porém não o constituem em espécie diferente, considerada a sua natureza de fogo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Agostinho se refere ao que o fogo do inferno tem de
material, e não à sua natureza ígnea.

RESPOSTA À SEGUNDA. ─ O nosso fogo alimenta-se de lenha e precisa ser acendido pelo homem,
porque é artificial e violentamente introduzido em matéria estranha. Mas o fogo eterno não necessita
de ser entretido, porque ou existe na sua matéria própria, ou em matéria estranha, mas não por
violência, mas pela natureza e por um princípio intrínseco. Por isso não foi aceso pelo homem, mas por
Deus, instituidor dessa natureza. Talo diz a Escritura: O assopro do Senhor, como uma torrente de
enxofre é o que acende.

RESPOSTA À TERCEIRA. ─ Os corpos dos condenados serão da mesma espécie que o são nesta vida,
embora presentemente sejam corruptíveis, e então incorruptíveis por disposição da divina justiça e por
causa de ter cessado o movimento do céu. Ora, o mesmo se dá com o fogo do inferno, pelo qual esses
corpos serão punidos.

RESPOSTA À QUARTA. ─ Luzir não é propriedade do fogo sob qualquer forma da sua existência. Assim,
quando existe na sua matéria própria não luz; por isso não luz quando na sua esfera própria, como
ensinam os filósofos. Do mesmo modo, quando existe em matéria estranha também não luz; assim
quando na matéria opaca terrestre, como no enxofre. Também e semelhantemente, quando a sua
claridade fica ofuscada por um fumo espesso. Por onde, o fato de o fogo do inferno não luzir não é
argumento suficiente a provar que não seja da mesma espécie que o nosso.

## Art. 7 — Se o fogo do inferno está no interior da terra.
O sétimo discute-se assim. ─ Parece que o fogo do inferno não está no interior da terra.

1. ─ Pois, do homem condenado diz a Escritura: Do mundo o transportará Deus. Logo, o fogo que punirá
os condenados não está no interior da terra, mas fora dela.

2. Demais. ─ Nada de violento e acidental pode ser sempiterno. Ora, o fogo do inferno é sempiterno.
Logo, não está lá por violência, mas naturalmente. Ora, no interior da terra o fogo não pode estar senão
por violência. Logo, o fogo do inferno não está no interior da terra.

3. Demais. ─ No fogo do inferno serão atormentados todos os corpos dos condenados, depois do dia de
juízo. Ora, esses corpos ocuparão lugar. Logo, colho será enorme a multidão dos condenados, porque
infinito é o número dos estultos, será necessariamente um espaço máximo o que conterá o fogo eterno.
Ora, não é admissível que haja no interior da terra uma tão grande concavidade, porque as suas partes
são naturalmente levadas para o centro. Logo, o fogo do inferno não estará no interior da terra.

4. Demais. ─ A Escritura diz: pelas cousas em que alguém peca, por essas é também atormentado. Ora,
os maus pecaram na terra. Logo, o fogo que os pune não deve estar no interior da terra.
Mas, em contrário, a Escritura: O inferno se viu lá em baixo todo turbado para te sair ao encontro. Logo,
o fogo do inferno está debaixo dos nossos pés.

2. Demais. ─ Gregório diz: Não vejo o que obsta acreditarmos estar o inferno debaixo da terra.

3. Demais. ─ Aquilo da Escritura ─ Tu me lançaste no profundo até o coração do mar, diz a Glosa: Isto é,
no inferno, correspondente à expressão do Evangelho ─ no coração da terra; porque, como o coração
ocupa a parte central no corpo do animal, assim dizemos estar o inferno no centro da terra.

SOLUÇÃO. ─ Diz Agostinho, citado pelo Mestre: penso que ninguém sabe em que parte do mundo está o
inferno, salvo quem obtiver revelação do Espírito divino. Por isso, Gregório, interrogado sobre essa
questão, respondeu: Nesta matéria seria temeridade, que não ouso fazer qualquer afirmação
categórica. Porque uns pensaram estar o inferno numa parte da superfície da terra; outros, no interior
dela. Mas julga esta última opinião a mais provável, por duas razões. ─ Primeiro, pela etimologia mesma
do nome: Assim, escreve: Se dissermos que o inferno é assim chamado por ocupar a parte inferior, o
que é a terra para o céu isso mesmo deve ser o inferno para a terra. ─ Segundo, pelo que diz o
Apocalipse: Ninguém podia, nem no céu, nem na terra, nem debaixo da terra, abrir o livro. Onde, a
expressão ─ no céu ─ refere-se aos anjos; a expressão ─ na terra, aos que ainda vivem neste mundo; e a
outra ─ debaixo da terra, as almas que estão no inferno.
E Agostinho também parece indicar duas razões que corroboram a opinião de estar o inferno no interior
da terra. ─ A primeira é que, como as almas dos mortos pecaram pelo amor da carne, são tratadas como
a carne morta, i. é, enterradas no solo. ─ A outra é que como está a gravidade para o corpo, assim a
tristeza para o espírito, do qual a alegria é como a leveza para o corpo. Por onde, assim como, os corpos,
se obedecerem à lei do seu peso, os mais graves ocuparão os lugares inferiores, assim, na ordem dos
espíritos, os inferiores são os mais acabrunhados pela tristeza. E assim, como o lugar apropriado à
felicidade dos eleitos é o céu empírio, assim, o lugar apropriado à tristeza dos condenados é o lugar
ínfimo da terra. ─ Nem nos deve causar embaraço o que diz Agostinho no mesmo lugar: É crença ou
suposição que o inferno está debaixo da terra. Porque o santo Doutor retratou-se desse dito quando
escreveu: Eu deveria ter ensinado, antes, que o inferno está debaixo da terra, do que dar a razão por
que crêem ou supõem que é esse o seu lugar.
Certos filósofos porém ensinaram que o inferno está localizado sob o globo terrestre, mas sobre a
superfície da terra que nos é oposta. E este parece ter sido o sentir de Isidoro, quando disse: O sol e a
lua permanecerão nos lugares onde foram criados, a fim de os ímpios, presa dos tormentos, não lhes
gozarem da luz. Razão que seria nula se se colocasse o inferno debaixo da terra. Que sentido, porém,
podemos dar a estas palavras já o dissemos. ─ Pitágoras, por seu lado, colocou o lugar das penas na
esfera do fogo, que, na sua opinião, está no centro do universo, como o refere o Filósofo.
Mas, concorda melhor com o ensinamento da Escritura colocar o inferno debaixo da terra.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Essas palavras de Job ─ Do mundo o transportará Deus,
deve entender-se do globo terrestre, i. é, deste mundo. É essa a exposição de Gregório, nestas palavras:
É transportado fora do globo, quando, ao aparecer o soberano juiz, for retirado a este mundo, em que
desvairadamente se glorificou. Nem se deve entender este globo pelo universo, como se o lugar das
penas estivesse totalmente fora do universo.

RESPOSTA À SEGUNDA. ─ O fogo do inferno durará eternamente por disposição da justiça divina;
embora, pela sua natureza, não possa nenhum elemento durar fora do seu lugar, sobretudo enquanto
os seres estiverem sujeitos à lei da geração e da corrupção. E aí esse fogo desprenderá um calor
intensíssimo, porque esse calor será no inferno concentrado de todos os lados, por causa do frio da
terra que de todas as partes o rodeia.

RESPOSTA À TERCEIRA. ─ O inferno nunca será tão pequeno que não baste a conter os corpos dos
condenados; pois, ele está colocado entre as três causas insaciáveis. Nem é nenhum inconveniente
haver no interior da terra, por obra do poder divino, uma concavidade bastante grande para conter o
corpo de todos os condenados.

RESPOSTA À QUARTA. ─ O lugar da Escritura ─ Pelas cousas em que alguém peca, por essas é também
atormentado, não se verifica necessariamente senão em relação aos principais instrumentos de pecado.
Pois, é por pecar pela alma e pelo corpo que o homem será punido em ambos. Mas nenhuma
necessidade há de ser o pecador punido no mesmo lugar em que pecou; pois, o lugar que ocupa o
homem nesta vida é diferente daquele onde estão os condenados. ─ Ou devemos responder que esse
passo se refere às penas com que somos punidos nesta vida, onde cada culpa tem a sua pena
correspondente, pois, cada Clima que vive na desordem é para si mesma o seu castigo, como diz
Agostinho.