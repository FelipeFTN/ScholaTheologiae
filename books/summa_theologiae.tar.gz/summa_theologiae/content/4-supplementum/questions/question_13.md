# Questão 13: Da possibilidade da satisfação.
Em seguida devemos tratar da possibilidade da satisfação.
Sobre o que dois artigos se discutem:

## Art. 1 — Se o homem pode satisfazer a Deus.
O primeiro discute-se assim. ─ Parece que o homem não pode satisfazer a Deus.

1. ─ Pois, a satisfação deve ser igual à ofensa, como do sobre dito resulta. Ora, a ofensa cometida contra
Deus é infinita, porque esta se quantifica pela pessoa contra quem é cometida ofendendo mais quem
ataca o chefe que qualquer outro. Logo, não podendo a ação humana ser infinita, resulta que o homem
não pode satisfazer.

2. Demais. ─ O servo, tendo do senhor tudo o que tem, nenhuma compensação lhe pode dar. Ora, nós
somos servos de Deus e todo o bem que temos dele o recebemos. Logo, sendo a satisfação uma
compensação pela ofensa passada, parece que não podemos satisfazer a Deus.

3. Demais. ─ Quem tendo o que tem não basta para pagar o que deve não pode satisfazer por nenhuma
outra dívida. Ora, tudo o que somos, podemos e temos, não basta a pagar o débito do benefício da
nossa condição; por isso diz a Escritura ─ Não bastarão as árvores do Líbano para um holocausto. Logo,
de nenhum modo podemos satisfazer pelo débito da ofensa cometida.

4. Demais. — O homem deve empregar todo o seu tempo em servir. Ora, o tempo perdido não pode ser
recuperado; por isso grave coisa é desperdiçar o tempo, como diz Sêneca. Logo, não podemos dar a
Deus nenhuma compensação. Donde se conclui o mesmo que antes.

5. Demais. ─ O pecado mortal atual é mais grave que o original. Ora, pelo original ninguém pode
satisfazer, salvo o homem Deus. Logo, nem pelo atual.
Mas, em contrário. ─ Jerônimo diz: Quem disser que Deus mandou ao homem algo de impossível seja
anátema. Ora, a satisfação é de preceito: Fazei frutos dignos de penitência. Logo, é possível satisfazer a
Deus.

2. Demais. ─ Deus é mais misericordioso que qualquer homem. Ora, ao homem é possível satisfazer.
Logo, também a Deus.

3. Demais. ─ A devida satisfação é a que iguala a pena com a culpa; porque a justiça é o mesmo que o
que sofremos como retribuição, conforme o diziam os Pitagóricos. Ora, podemos sofrer uma pena igual
ao gozo que tivemos com o pecado. Logo, podemos satisfazer a Deus.

SOLUÇÃO. ─ De dois modos podemos ser devedores a Deus ─ em razão do benefício recebido e em
razão do pecado cometido. E assim como a ação de graças ou latria, ou qualquer ato semelhante,
respeita o débito do benefício recebido, assim também a satisfação respeita o do pecado cometido. ─
Mas quanto à honra devida a Deus e aos pais, também segundo o Filósofo, é impossível restituir em
quantidade idêntica, bastando dar o que pudermos; pois, a amizade não exige o equivalente, senão só o
possível. O que de certo modo também é o igual, isto é, segundo uma proporcionalidade; pois, assim
como o devido a Deus está para Deus, assim o que podemos restituir, para nós. E eis como de certo
modo se salva a forma da justiça. ─ O mesmo se dá relativamente à satisfação. Por onde, não podemos
satisfazer a Deus, se satis implica uma igualdade quantitativa; podemo-la porém se importa numa
igualdade de proporção, como dissemos. E isto, como basta à realização da justiça, também basta à da
satisfação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Assim como a ofensa terá uma certa infinidade da
infinidade da majestade divina, assim também certa infinidade terá a satisfação da infinidade da divina
misericórdia, enquanto informada pela graça, pela qual é recebido o que o homem pode dar. ─ Certos
porém dizem que ela tira a sua infinidade da a versão e assim é perdoada gratuitamente; é finita porém
da parte da conversão, e assim podemos satisfazer por ela. ─ Mas isto não é verdade, pois a satisfação
não responde ao pecado senão como ofensa de Deus; e isso não lhe advém da conversão, mas só da
aversão. ─ Outros porém dizem que, mesmo quanto à aversão, podemos satisfazer pelo pecado em
virtude dos méritos de Cristo, que de certo modo foram infinitos. O que vem a dar no mesmo que já foi
dito; pois, pela fé do mediador a graça foi dada aos crentes. Se porém tivesse dado a graça de outro
modo, bastaria a satisfação da maneira referida.

RESPOSTA À SEGUNDA. ─ O homem, feito à imagem de Deus, participa algo da liberdade, enquanto
senhor dos seus atos pelo livre arbítrio. Portanto, agindo com o seu livre arbítrio, pode satisfazer a Deus;
pois, embora o livre arbítrio pertença a Deus, que lh'o outorgou, deu-Ih'o porém livremente para que
dele fosse senhor. O que não cabe ao servo.

RESPOSTA À TERCEIRA. — A objeção conclui que não podemos dar uma satisfação digna de Deus; mas
não que lh'a não possamos dar suficiente. Pois, embora todo o seu poder o homem o deva a Deus, não
lhe é porém necessariamente exigido que faça tudo quanto pode. Porque lhe seria impossível, no
estado da vida presente, concentrar todo o seu poder num só objeto, ele que deve aplicar a sua
solicitude a muitos. Mas uma certa medida lhe é prescrita e dele exigida, a saber, cumprir os
mandamentos de Deus; e nessa medida o homem pode dar do que lhe pertence, de modo a satisfazer.

RESPOSTA À QUARTA. ─ Embora não possamos recuperar o tempo passado, podemos porém dar uma
compensação no futuro daquilo que no passado devêramos ter feito; pois, não devíamos, por uma
obrigação de preceito, tudo o que podíamos, como dissemos.

RESPOSTA À QUINTA. ─ O pecado original, embora tenha menos da natureza do pecado que o atual,
contudo é mais grave mal, pois, contaminou a própria natureza humana. Por isso não podia ser expiado
pela satisfação de um puro homem, como o pode o atual.

## Art. 2 — Se um pode cumprir por outro uma pena satisfatória.
O segundo discute-se assim. ─ Parece que um não pode cumprir por outro uma pena satisfatória.

1. ─ Pois, a satisfação exige o mérito. Ora, ninguém pode merecer ou desmerecer por outrem, conforme
está escrito: Tu retribuirás a cada um segundo as suas obras. Logo, não pode um satisfazer por outro.

2. Demais. ─ A satisfação se separa, por oposição, da contrição e da confissão. Ora, um não pode ter
contrição e confessar por outro. Logo, nem satisfazer.

3. Demais. ─ Quem ora por outrem também para si merece. Se, pois, pudesse um satisfazer por outro,
satisfazendo por este por si satisfaria. E assim, de quem satisfaz por outrem não lhe é exigida nenhuma
outra satisfação pelos seus pecados próprios.

4. Demais. ─ Se um pode satisfazer por outro, por isso desde que um tomou sobre si o débito da pena, o
outro fica imediatamente livre do pecado. Portanto, morrendo depois de toda a pena que devia ter sido
cumprida pelo outro, entrará imediatamente no céu. Ou se ainda fosse punido, dupla seria a pena por
um mesmo pecado ─ a daquele que começou a satisfazer e a do punido no purgatório.
Mas, em contrário. ─ O Apóstolo diz: Levai as cargas uns dos outros. Logo, pode um levar por outro a
carga da penitência a este imposta.

2. Demais. ─ A caridade vale mais perante Deus que perante os homens. Ora, um pode, perante os
homens e por amor de outrem, pagar-lhe o débito. Logo, com muito maior razão pode isso fazer-se no
tribunal divino.

SOLUÇÃO. ─ A pena satisfatória foi ordenada para dois fins: pagar o devido e como remédio para nos
fazer evitar o pecado. — Enquanto, pois, é remédio ao pecado futuro, a satisfação de um não pode
aproveitar a outro; pois, o jejum deste não pode sujeitar a carne de aquele; nem pelos atos de um
acostumou-se o outro a proceder bem, senão acidentalmente, isto é, enquanto pelas nossas boas obras
podemos merecer a outrem o aumento da graça, remédio eficasíssimo para evitar o pecado. Mas isto é
a modo de mérito, mais que de satisfação. ─ Quanto porém à solução do débito, um pode satisfazer por
outro, contanto que tenha a caridade, que lhe torne as obras satisfatórias. ─ Nem é necessário seja
imposta a quem satisfaz por outrem pena maior que a que o seria ao agente principal, como dizem
certos, levados da razão que a pena própria satisfaz melhor que a alheia. Pois, a pena tira o seu poder
máximo de satisfazer, da caridade, que no-la induz a sofrer. E como manifestamos caridade maior
satisfazendo por outro em lugar de o fazermos por nós, por isso requer-se em quem satisfaz por outro
menor pena do que este sofreria. Por onde, como se diz nas Vidas dos Padres, a caridade que leva um a
fazer penitência pelo pecado de seu irmão, que não cometeu, o pecado por esse cometido lhe fica
perdoado. ─ Nem ainda é necessário, quanto à solução do débito, que aquele por quem satisfazemos
seja incapaz de o fazer, pois, mesmo sendo capaz, fica desonerado do débito se por ele satisfazemos. É
porém necessário quando a pena satisfatória é um remédio. Por isso não se deve permitir faça um
penitência por outro, senão por incapacidade do penitente mesmo que o que sofremos como
retribuição, conforme o diziam os Pitagóricos. Ora, podemos sofrer uma pena igual ao gozo que tivemos
com o pecado. Logo, podemos satisfazer a Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O prêmio essencial é dado segundo a capacidade de cada
um; pois, segundo a capacidade dos que gozam da visão divina assim será ela. E portanto, assim como a
disposição de um não lhe advém do ato de outro, assim não pode um merecer por outro o prêmio
essencial; salvo se o seu mérito tiver uma eficácia infinita, como o de Cristo, por cujo mérito unicamente
as crianças alcançam a vida eterna. Mas a pena temporal devida ao pecado não é determinada, depois
da remissão da culpa, pela disposição de quem a mereceu; e assim às vezes, ao melhor, é maior o reato
da pena. Por onde, quanto à remissão da pena, pode um merecer por outro; e o ato de um vem a se
tornar do outro, mediante a caridade, pela qual todos somos um em Cristo.

RESPOSTA À SEGUNDA. ─ A contrição é ordenada contra a culpa, relativa à nossa boa ou má disposição.
Por isso a contrição de um não libera da culpa ao outro. ─ Semelhantemente, pela confissão sujeitamo-
nos aos sacramentos da Igreja. Mas não pode um receber o sacramento por outro, porque no
sacramento a graça é dada A quem a recebe e não ao outro. ─ Por onde, não se dá o mesmo com a
satisfação, a contrição e a confissão.

RESPOSTA À TERCEIRA. ─ Na solução do débito se leva em conta a intensidade da pena; ao passo que no
mérito se considera a raiz da caridade. Por onde, quem pela caridade merece por outrem, ao menos
pelo mérito de congruência, ainda mais merece por si. Mas quem satisfaz por outrem não satisfaz ao
mesmo tempo por si, porque a intensidade da pena sofrida não basta ao pecado de ambos. Contudo
para si merece a vida eterna, que é mais que o perdão da pena.

RESPOSTA À QUARTA. ─ Se nós mesmos nos sujeitássemos a uma pena, não ficaríamos livres do débito
antes de havê-la sofrido. Por consequência, o outro deverá sofrer no purgatório enquanto não tivermos
dado satisfação por ele. E se não o fizermos, seremos ambos devedores da mesma pena ─ um pelo
cometido, o outro pelo omitido. Donde porém se não segue, que o pecado de um seja punido duas
vezes.