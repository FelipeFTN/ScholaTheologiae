# Questão 52: Do impedimento da condição servil.
Em seguida devemos tratar do impedimento da condição servil.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se a condição servil impede o matrimônio.
O primeiro discute-se assim. ─ Parece que a condição servil não impede o matrimônio.

1. Pois, nada impede o matrimônio senão o que tem com ele alguma contrariedade. Ora, a escravidão
nada tem de contrário ao casamento, porque então os escravos não poderiam casar-se. Logo, a
escravidão não impede o matrimônio.

2. Demais. ─ O contrário à natureza não pode impedir o natural. Ora, a escravidão é contra a natureza;
pois, é contrário à natureza querer um homem dominar outro. E também vai contra o que lhe foi dito: o
qual presida aos peixes do mar ─ e não aos homens. Logo, não pode impedir o matrimônio o que é
natural.

3. Demais. ─ Se o impedisse sê-lo-ia por direito natural, ou por direito positivo. Ora, não por direito
natural, porque por direito natural todos os homens são iguais, como diz Gregório. E no princípio do
Digesto se diz, que a escravidão não é de direito natural. Ora, o direito positivo procede do natural,
como diz Túlio. Logo, por nenhum direito a escravidão pode impedir o matrimônio.

4. Demais. ─ O impedimento ao matrimônio tanto o é sabido como ignorado, conforme o demonstra o
parentesco. Ora, a escravidão conhecida, de uma das partes, não impede a outra de casar-se. Logo, não
devia ser considerada como impedimento ao matrimônio, distinto dos outros.

5. Demais. ─ Assim como o objeto do erro pode ser a escravidão, de modo que se considere livre quem é
escravo; assim pode recair sobre a liberdade, de modo a reputar-se escravo quem é livre. Ora, a
liberdade não se considera como impedimento ao matrimônio. Logo, também não deve ser considerada
tal a escravidão.

6. Demais. ─ Mais difícil torna a sociedade conjugal e mais impede o bem da prole a doença da lepra que
a escravidão, Ora, a lepra não é considerada impedimento ao matrimônio. Logo, nem deve sê-lo a
escravidão.
Mas, em contrário, dispõe uma decretal, que o erro sobre a condição impede contrair matrimônio e
dirime o já contraído.

2. Demais. ─ O casamento, enquanto bem honesto, é dos que são dignos de ser buscados por si
mesmos. Ora, a escravidão é um dos males que, em si mesmos, devemos evitar. Logo, casamento e
escravidão são contrários. E assim, a escravidão impede o matrimônio.

SOLUÇÃO. ─ Pelo contrato do matrimônio fica um cônjuge obrigado a cumprir para com o outro o dever
conjugal. Por onde, se quem assume essa obrigação é incapaz fisicamente de cumpri-la, a ignorância
dessa incapacidade por parte do outro cônjuge anula para este o contrato. Ora, como a impotência
física torna incapaz de cumprir a obrigação conjugal, absolutamente falando, assim também a
escravidão impede o livre cumprimento desse dever. Por onde, assim como a impotência física ignorada
impede o matrimônio, não porém quando conhecida, assim a condição de escravo ignorada também o
impede, mas não quando conhecida.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A escravidão contraria o ato do matrimônio a que um se
obriga para com o outro e que não pode livremente cumprir; e também o bem da prole, que se torna de
pior condição pela escravidão dos pais. Mas, como podemos de nossa livre vontade sofrer detrimento
em nosso direito, quando um cônjuge sabe da escravidão do outro, o matrimônio assim contraído é
válido. ─ Semelhantemente, como no matrimônio ambas as partes têm a mesma obrigação de cumprir o
dever matrimonial, não pode uma impor a outra maior obrigação que a própria. Por onde, se um
escravo casar com escrava, que julgava livre, não fica por isso nulo o matrimônio. E assim, é claro que a
escravidão não impede o matrimônio, a não ser quando ignorada pelo outro cônjuge, e se este for de
condição livre. Portanto, nada impede ser válido o casamento contraído por escravos ou entre um
escravo e uma livre.

RESPOSTA À SEGUNDA. ─ Pode haver contrariedade com a natureza, na sua intenção primeira, sem
haver com a sua intenção segunda. Assim, toda corrupção, todo defeito, a velhice são, conforme
Aristóteles, contrárias à intenção primeira da natureza, porque a natureza visa o ser e a perfeição. Mas
não lhe contrariam a intenção segunda. Pois, quando a natureza não pode manter a existência num
serela a conserva em outro, gerado da corrupção do primeiro. E quando não pode levar a uma perfeição
maior, conduz, a outra, menor; assim, não podendo criar um macho, cria uma fêmea, que é um macho
degenerado, na expressão de Aristóteles, ─ Ora o mesmo dizemos da escravidão; é contra a primeira
intenção da natureza, mas não contra a segunda. Porque a razão natural inclina e a natureza apete que
cada um seja bom; mas quando alguém peca, a natureza também exige uma pena sofrida pelo pecado.
Assim, a escravidão foi introduzida como tal pena. Nem há inconveniente em uma coisa natural ser
impedida por uma outra contrária à natureza; assim, o matrimônio fica impedido pela impotência física,
contrária à natureza, de modo referido.

RESPOSTA À TERCEIRA. ─ O direito natural dita que a uma culpa se deve infligir uma pena e que
ninguém deve ser punido sem culpa. Mas determinar a pena pela condição da pessoa e da culpa é de
direito positivo. Por onde, a escravidão, que é uma pena, foi determinada pelo direito positivo e tem a
sua origem em a natureza, como o determinado no indeterminado. E o mesmo direito positivo
determinadamente estabeleceu, que a escravidão ignorada empidia o matrimônio, a fim de não ser
ninguém punido sem culpa; pois, seria uma pena 'para a mulher ter um marido escravo, e inversamente.

RESPOSTA À QUARTA. ─ Certos impedimentos tornam o matrimônio ilícito. E como não é da nossa
vontade que depende o lícito ou o ilícito, mas da lei, a que a vontade deve obedecer, por isso a referida
ignorância, que destrói o voluntário ou a ciência em nada contribuem para o matrimônio valer ou não.
Impedimento tal é a afinidade ou o voto e outros semelhantes. Outros impedimentos porém tornam o
matrimônio ineficaz, para o cumprimento do dever conjugal. Mas como da nossa vontade depende
desistir do que nos é devido, por isso tais impedimentos, sendo conhecidos, não anulam o casamento,
senão só quando a ignorância exclui o voluntário. Ora, tal impedimento é a escravidão e a impotência
física. Mas, além do erro, admitem-se certos impedimentos especiais, porque de certo modo o são. Não
se considera porém a mudança de pessoa como um impedimento especial diferente do erro, porque a
pessoa que veio substituir a primeira não constitui um impedimento senão na intenção do contraente.

RESPOSTA À QUINTA. ─ A liberdade não impede o ato do matrimônio, ainda mesmo quando ignorada.

RESPOSTA À SEXTA. ─ A lepra não impede o matrimônio no seu ato principal; pois, os leprosos podem
cumprir livremente o dever conjugal, embora tragam um certo gravame para o casamento, quanto aos
seus efeitos secundários. Por isso não impede o matrimônio, como o impede a escravidão.

## Art. 2 — Se o escravo pode contrair matrimônio sem o consentimento do senhor.
O segundo discute-se assim. ─ Parece que o escravo não pode contrair matrimônio sem a licença do
senhor.

1. Pois, ninguém pode dar a outrem o bem alheio sem o consentimento do dono. Ora, o escravo é coisa
do senhor. Logo, não pode, contraindo o matrimônio, dar à mulher poder sobre o seu corpo sem
consentimento do senhor.

2. Demais. ─ O escravo esta obrigado a obedecer ao senhor. Ora, o senhor pode ordenar-lhe que não
consinta no matrimônio. Logo, sem esse consentimento não pode contrair matrimônio.

3. Demais. ─ Depois do contrato do matrimônio, o escravo está obrigado a cumprir o dever conjugal
para com a mulher, mesmo por preceito de direito divino. Ora, pode acontecer que, no momento em
que a mulher lhe pedir o cumprimento desse dever, o senhor imponha ao escravo um serviço de modo a
impedi-lo da conjunção carnal. Logo, se sem o consentimento do senhor o escravo pode contrair
matrimônio, o senhor ficaria privado do serviço dele sem culpa do mesmo. E isso não pode ser.

4. Demais. ─ O Senhor pode vender os seus escravos para regiões longínquas, onde a mulher não o
possa acompanhar, quer por doença do corpo, quer por perigos eminentes à sua fé ─ por exemplo, se
fosse ele vendido a infiéis; quer ainda por não lho permitir o dono, sendo escrava. E assim, o
matrimônio se dissolveria. O que é inconveniente. Logo, não pode o escravo contrair matrimônio sem
licença do senhor.

5. Demais. ─ Mais elevada é a obrigação pela qual alguém se consagra ao serviço divino, que pela qual se
submetesse ao serviço de sua esposa. Ora, o escravo não pode, sem o consentimento do senhor, entrar
em religião ou ser promovido às ordens. Logo, com maior razão, não pode sem o seu consentimento,
contrair matrimônio.
Mas, Apóstolo: Em Jesus Cristo não há servo nem livre. Logo, para contrair matrimônio, na fé de Jesus
Cristo, a mesma liberdade tem os escravos que os livres.

2. Demais. ─ A escravidão é de direito positivo. Ora, o matrimônio é de direito natural e divino. Logo,
como o direito positivo não pode contrariar o natural nem o divino, parece que o escravo pode contrair
matrimônio sem o consentimento do senhor .

SOLUÇÃO. - O direito positivo, como dissemos, procede do natural. Por onde, a escravidão, que é de
direito positivo, não pode prejudicar às exigências do direito natural. Pois, assim como a natureza tende
à conservação do indivíduo, assim, pela geração, visa à conservação da espécie. Ora, o escravo não está
sujeito ao senhor a ponto de não ter liberdade de comer, dormir e praticar atos semelhantes exigidos
pelas necessidades do corpo, sem os quais a natureza não pode subsistir. Assim, também não lhe está
sujeito a ponto de não poder contrair livremente o matrimônio, mesmo sem o conhecimento e a
permissão do senhor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O escravo é propriedade do senhor no concernente ao
que se acrescenta à natureza; porque por natureza todos os homens são iguais. Por isso, em relação aos
atos naturais, o escravo pode, pelo matrimônio, dar a outrem poder sobre seu corpo, contra a vontade
do senhor.

RESPOSTA À SEGUNDA. ─ O escravo está obrigado a obedecer ao seu senhor em tudo o que este lhe
pode licitamente mandar. Ora, assim como o senhor não tem o direito de lhe mandar que não coma ou
não durma, assim também não pode ordenar-lhe abster-se do matrimônio. Pois, o legislador deve velar
pelo modo com que cada qual usa do seu direito. Portanto, se o senhor proíbe ao escravo de contrair
matrimônio, não está obrigado este a lhe obedecer.

RESPOSTA À TERCEIRA. ─ O escravo que contraiu matrimônio com permissão do dono, deve por isso
mesmo deixar de fazer o serviço que lhe manda ele e cumprir o dever conjugal para com a mulher, Pois,
tendo-lhe o senhor permitido contrair matrimônio, entende-se que também anuiu a todas as exigências
do casamento. Se porém o escravo casou, ignorando-o o dono ou lh'o tendo proibido, não está obrigado
ao dever conjugal e tem, antes, de obedecer ao dono, se ambas as coisas não puder fazer. Mas, nesta
matéria, como em todos os atos humanos, devem levar-se em conta muitas circunstâncias particulares.
Assim, o perigo que correrá a mulher de pecar contra a castidade, o prejuízo resultante para o dono, de
o escravo não lhe fazer o serviço mandado e outro semelhante. E só depois: de todas bem ponderadas
será possível decidir a quem deve o escravo obedecer de preferência ─ ao dono ou à mulher

RESPOSTA À QUARTA. ─ Em tal caso fica o dono obrigado a vender o escravo de modo a não lhe tornar
mais pesado o ônus do matrimônio; sobretudo que não lhe faltará oportunidade de vendê-lo em
qualquer parte, por um justo preço.

RESPOSTA À QUINTA. ─ Quem entra em religião ou recebe uma ordem se consagra ao serviço divino por
toda a sua vida. Ao passo que um esposo está obrigado ao dever conjugal para com a esposa, não
sempre, mas em tempos determinados. Logo, não colhe o símile. Além disso, quem entra em religião e
recebe uma ordem obriga-se a certas obras que se lhe acrescentam às obrigações naturais, no
concernente às quais está sujeito ao senhor. Mas este nenhum direito tem sobre as obrigações naturais
a que se obrigou pelo matrimônio o escravo. Portanto não poderá quem é escravo fazer voto de
continência sem o consentimento do senhor.

## Art. 3 — Se a escravidão pode sobrevir ao matrimônio por ter-se o marido vendido a outrem como escravo.
O terceiro discute-se assim. ─ Parece que a escravidão não pode sobrevir ao matrimônio por ter-se o
marido vendido a outrem como escravo.

1. Pois, a ação feita em fraude e detrimento de outrem não deve ser ratificada. Ora, o marido que se
vendeu como escravo fá-lo-á às vezes em fraude do matrimônio, e pelo menos em detrimento da
esposa. Logo, não deve ser válida essa venda para produzir a escravidão.

2. Demais. ─ Duas instituições protegidas pelo direito sobrelevam a uma dele não protegida. Ora, o
matrimônio e a liberdade são assim protegidos e repugnam à escravidão, não protegida pelo direito.
Logo, a escravidão sobreveniente ao matrimônio deve anulá-lo totalmente.

3. Demais. ─ No matrimônio o marido e a mulher estão no mesmo pé de igualdade. Ora, a mulher não
pode vender-se como escrava, contra a vontade do marido. Logo, nem o marido, contra a da mulher.

4. Demais. ─ O obstáculo na ordem natural à geração de um ser, destrói também o ser já produzido. Ora,
a escravidão do marido, com a ignorância da mulher, impede o matrimônio de ser contraído. Logo
sobrevindo-lhe, destrui-lo-á, O que é inadmissível.
Mas, em contrário. ─ Todos podemos dar a quem quisermos o que nos pertence. Ora, o marido, sendo
livre, pode dispor da sua pessoa. Logo, pode ceder a outrem o seu direito.

2. Demais. ─ O escravo pode casar contra a vontade do dono, como se disse. Logo e pela mesma razão, o
marido poderá fazer-se escravo de um senhor, contra a vontade da mulher.

SOLUÇÃO. ─ O marido está sujeito à mulher só no concernente ao ato natural do casamento, por onde
são iguais e a que não se estende a sujeição da escravidão. Logo, o marido pode vender-se como
escravo, mesmo contra a vontade da mulher. O que, pois, não dissolve o casamento, porque nenhum
impedimento superveniente pode fazê-lo, como se disse.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A fraude bem pode prejudicar a quem a cometeu; não
pode porém causar dano a terceiros. Por onde, o marido que se vender como escravo a outrem, em
fraude da esposa, sofrerá ele o dano, perdendo o dom inestimável da liberdade. A mulher porém
nenhum dano poderá advir daí, pois continuará o marido obrigado ao dever conjugal e a todas as mais
exigências do matrimônio. Pois, a elas não pode eximir-se por ordem do senhor.

RESPOSTA À SEGUNDA. ─ Repugnando ao matrimônio, há de a escravidão por força prejudicá-lo; pois,
então, o escravo continuará obrigado a cumprir o dever conjugal para com a mulher, mesmo contra a
vontade do senhor.

RESPOSTA À TERCEIRA. ─ Em relação ao ato matrimonial e às funções naturais, o marido e a mulher são
considerados iguais e isentos das condições da escravidão. Contudo, quanto ao governo da casa e ao
mais que se acrescenta ao matrimônio, o marido é a cabeça da mulher e deve governá-la; mas não do
inverso. Portanto, a mulher não pode vender-se como escrava, contra a vontade do marido.

RESPOSTA À QUARTA. ─ A objeção colhe quanto às coisas susceptíveis de corrupção; pois, nessa ordem,
há muitas causas impeditivas da geração e que contudo não bastam a destruir o ser já produzido. Para
os seres perpétuos, porém, pode um obstáculo impedir a um deles a existência, mas não que deixe de
existir. Tal o caso da alma racional. Ora, o mesmo se dá com o matrimônio, que é um vínculo perpétuo e
perdura enquanto perdurar a vida.

## Art. 4 — Se os filhos devem seguir a condição do pai.
O quarto discute-se assim. ─ Parece que os filhos devem seguir a condição do pai.

1. Pois, um ser recebe a sua denominação do princípio mais nobre donde procede. Ora, o pai, na
geração, é mais nobre que a mãe. Logo, etc.

2. Demais. ─ A existência de um ser mais depende da sua matéria que da forma. Ora, na geração o pai
dá a forma e a mãe, a matéria, como diz Aristóteles. Logo, devem os filhos seguir, antes, as condição da
mãe que a do pai.

3. Demais. ─ Um ser deve seguir principalmente aquilo a que mais se assemelha. Ora, o filho se
assemelha mais ao pai que à mãe; assim como a filha, mais à mãe que ao pai. Logo, e pelo menos, deve
o filho seguir antes a condição do pai que a da mãe.

4. Demais. ─ Na Sagrada Escritura não se contam as gerações pelas mulheres, mas pelos varões. Logo, os
filhos devem seguir antes a condição paterna que a materna.
Mas, em contrário. ─ Quem semeia na terra alheia, os frutos pertencem ao dono da terra. Ora, o ventre
da mulher, relativamente ao semem do marido, é como a terra em relação à semente. Logo, etc.

2. Demais. ─ Nos animais nascidos de espécies diversas, o parto obedece mais a natureza materna que à
paterna. Assim, muitos animais, dos nascidos de égua e jumento, mais se assemelham às éguas, que os
nascidos de jumenta e cavalo. Logo, o mesmo deve dar-se com os homens.

SOLUÇÃO. ─ Segundo as leis civis, o parto segue a condição do ventre. E racionalmente. Porque se o
filho recebe do pai o complemento da forma, da mãe recebe a substância do corpo. Ora, a escravidão é
uma condição a que está o corpo sujeito; pois, o escravo é um quase instrumento com que obra o
senhor. Por isso, o filho, tanto em relação à liberdade como à escravidão, segue a condição materna. No
concernente porém à dignidade, por proceder da forma do ser, segue a condição paterna; tal o que se
dá com as honras, as funções civis, a herança e coisas semelhantes. Com o que concordam os cânones e
a lei de Moisés.
Em certas terras porém, não regidas pelo direito civil, o parto segue a condição pior. Assim, sendo o pai
escravo, embora livre a mãe, os filhos serão escravos. Não porém se, depois de feito o casamento, o pai
se vendeu como escravo, sem o consentir a mulher; e do mesmo modo no caso contrário. Se ambos
forem de condição servil e pertencentes a donos diversos, estes dividirão entre si os filhos, se forem
vários; mas sendo único, um dos senhores pagará ao outro uma indenização e tomará o filho nascido
como escravo seu. ─ Contudo, não é crível que um tal costume possa ser tão racional como o
estabelecido pelo diuturno consenso de tantos sábios.
Por outro lado, é um princípio de ordem natural, que a coisa recebida está no recipiente ao modo deste,
e não ao daquela. Por isso é racional que o semem recebido pela mulher depende da condição dela,

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora seja o pai um princípio mais digno que a mãe,
contudo esta é quem dá a substância do corpo, donde depende a condição servil.

RESPOSTA À SEGUNDA. ─ No concernente à essência especifica, o filho mais se assemelha ao pai, que à
mãe. Mas quanto às condições materiais deve assemelhar-se mais à mãe que ao pai. Porque um ser
recebe a sua existência especifica da forma; mas da matéria, as condições materiais.

RESPOSTA À TERCEIRA. ─ O filho se assemelha ao pai em razão da forma, que tem como complemento,
como a tem o pai. Por isso a objeção não colhe no caso proposto.

RESPOSTA À QUARTA. ─ Dependendo a honra do filho mais do pai que da mãe, por isso nas genealogias
da Sagrada Escritura, e segundo o costume comum, os filhos recebem o nome do pai e não da mãe.
Contudo. no concernente à escravidão, seguem antes a condição materna.