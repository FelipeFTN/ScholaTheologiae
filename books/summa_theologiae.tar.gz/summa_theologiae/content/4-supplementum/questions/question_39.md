# Questão 39: Dos impedimentos a este sacramento.
Em seguida devemos tratar dos impedimentos a este sacramento.
Sobre o que discutem-se seis artigos:

## Art. 1 — Se o sexo feminino impede receber a ordem.
O primeiro discute-se assim. ─ Parece que o sexo feminino não impede receber a ordem.

1. ─ Pois, o ofício de profeta é mais elevado que o do sacerdote, porque o profeta é medianeiro entre
Deus e os sacerdotes, como o sacerdote o é entre Deus e o povo. Ora, às vezes o ofício de profeta foi
concedido a mulheres, como lemos na Escritura. Logo, também podem elas exercer o ofício do
sacerdócio.

2. Demais. ─ Assim como a ordem implica uma certa eminência, assim também o ofício de prelado, o de
testemunha da fé e o do estado religioso. Ora, a prelatura pode, no regime do Novo Testamento, ser
conferida a mulheres, como é o caso das abadessas; e no Testamento Velho há o exemplo de Débora,
que julgou Israel. Podem também ser testemunhas da fé e professar no estado religioso. Logo, também
podem receber as ordens eclesiásticas.

3. Demais. ─ O poder das ordens se radica na alma. Ora, o sexo não tem a alma. Logo, a diversidade de
sexo não obra nenhuma distinção para o efeito de se receberem as ordens.
Mas, em contrário, o Apóstolo: Eu não permito à mulher que ensine na Igreja, nem que tenha domínio
sobre o marido.

2. Demais. ─ Os ordenandos hão de ter coroa, embora não seja ela necessária para a validade do
sacramento. Ora, coroa ou tonsura não na podem ter as mulheres, como o diz o Apóstolo. Logo, nem
podem receber as ordens.

SOLUÇÃO. ─ Certas condições requerem-se necessariamente de quem recebe um sacramento para a
validade deste; e se faltarem não pode ninguém receber o sacramento e nem a realidade dele. Outras
condições porém não são necessárias à validade do sacramento, mas são impostas por um preceito e
por conveniência para com o sacramento. E sem essas podemos receber o sacramento, mas não a
realidade dele. Ora, o sexo masculino é uma condição necessária para a suscepção das ordens, não só
do segundo modo referido, mas também do primeiro. Por onde, embora a uma mulher se lhe fizessem
todas as cerimônias próprias da ordenação, contudo não receberia a ordem. Porque, sendo o
sacramento um sinal, nos que o vão receber há de existir não só a realidade mas também a significação
dela. Assim, como dissemos, a extrema unção só pode ser ministrada a um doente, a fim de significar
que tem necessidade de cura. Ora, não poderia o sexo feminino exprimir uma situação de eminência,
porque a mulher vive num estado de sujeição, por isso não pode receber o sacramento da ordem.
Certos, porém, ensinaram, que o sexo masculino é de necessidade de preceito, mas não é necessário
para ser conferido o sacramento, pois as próprias Decretais se referem à diaconisa e à presbitera. ─ Mas,
diaconisa aí se chama à que participa de algum ato do diácono, isto é, a que lê as homílias na Igreja; e
presbítera, à viúva, porque presbiter é a mesma coisa que mais velho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A profecia não é um sacramento, mas um dom de Deus.
Por isso, não se exige dela uma significação mas só a realidade. E como no concernente à realidade da
alma a mulher não difere do homem, pois até mesmo às vezes uma mulher tem alma melhor que a de
muitos homens, por isso o dom da profecia e outros semelhantes pode a mulher recebê-los, mas não o
sacramento da ordem.
Donde se deduz a resposta à segunda e à terceira objeções.
Das abadessas porém se diz que não tem a prelatura ordinária, mas como em comissão, por causa do
perigo da convivência entre homens e mulheres. ─ Quanto à Débora, teve um poder temporal e não
sacerdotal; e assim, ainda agora podem as mulheres exercer o poder.

## Art. 2 — Se as crianças e os que carecem do uso da razão podem receber a ordem.
O segundo discute-se assim. ─ Parece que as crianças e os que carecem do uso da razão não podem
receber as ordens.

1. ─ Pois, como diz o Mestre, os sagrados cânones estatuíram uma determinada e certa idade para se
receberem as ordens. Ora, isso não se daria se as crianças pudessem receber o sacramento da ordem.

2. Demais. ─ O sacramento da ordem é mais digno que o do matrimônio. Ora, as crianças e os privados
da razão não podem contrair matrimônio. Logo, nem receber as ordens.

3. Demais. ─ A potência e o ato são correlativos, como diz o Filósofo. Ora, o ato de exercer as ordens
requer o uso da razão. Logo, também o poder das ordens.
Mas, em contrário. ─ Quem foi promovido às ordens, antes da idade de razão, pode às vezes exercê-las
sem que precise de as ter renovadas. Ora, tal não se daria se não tivesse recebido a ordem. Logo, uma
criança pode receber as ordens.

2. Demais. ─ Os outros sacramentos que imprimem caráter, como o batismo e a confirmação, as
crianças podem recebê-los. Logo, pela mesma razão, as ordens.

SOLUÇÃO. ─ A puerícia e outras deficiências, que privam do uso da razão, impedem a ação. Por onde,
todos aqueles sacramentos, que supõem uma atividade por parte de quem os recebe, não podem
receber os privados do uso da razão. Tal a penitência, o matrimônio e outros. Mas, por um lado as
potências infusas, como as naturais, são anteriores aos atos, embora as adquiridas lhes sejam
posteriores. Por outro lado, removido o posterior, não fica por isso removido o anterior. Por onde, todos
os sacramentos, que não requerem, para serem válidos, nenhuma cooperação da parte de quem os
recebe, por lhes ser dado por Deus um poder espiritual, podem as crianças recebê-los e os demais
carecentes do uso da razão. Deve-se porém fazer notar que para receber as ordens menores, é
necessária a discrição racional, pelo respeito que a dignidade do sacramento exige, embora não seja ela
necessária, nem por necessidade de preceito, nem para a validade do sacramento. Por isso, urgindo a
necessidade e havendo esperança de aproveitamento espiritual, os que ainda não chegaram à idade de
discernimento podem ser promovidos, sem pecados, às ordens menores; porque, embora não sejam
ainda idôneos para o exercício das funções que lhe são cometidas, o costume contudo os tornará tais.
Mas, para se receberem as ordens maiores, é necessário o uso da razão, tanto por causa da dignidade
delas, como por ser de necessidade de preceito. Pois, implicam elas o voto de continência; e além disso,
é nos cometido o poder de conferir os sacramentos. Quanto ao episcopado, como o poder que ele
confere se exerce, ademais, sobre o corpo místico de Jesus Cristo, sua colação demanda concurso ativo
de quem o recebe, por causa da cura pastoral das almas. Por isso, a consagração episcopal supõe
necessariamente o uso da razão.
Mas certos dizem, que todas as ordens implicam o uso da razão, para a validade do sacramento. Mas
essa opinião não é corroborada pela razão nem por nenhuma autoridade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Nem tudo o que é de necessidade de preceito o é para a
validade do sacramento, como dissemos.

RESPOSTA À SEGUNDA. ─ O matrimônio supõe o consentimento que não pode existir sem o uso da
razão. Ora, para receber a ordem não é necessária nenhuma cooperação da parte de quem a recebe. O
que é demonstrado pelo fato de não mencionar nenhuma cooperação deles o cerimonial da
consagração. Logo, não há símile.

RESPOSTA À TERCEIRA. ─ Ato e potência são correlativos, contudo às vezes a potência precede, como
no caso do livre arbítrio e do uso da razão. Tal o caso proposto.

## Art. 3 — Se a escravidão impede de receber o sacramento da ordem.
O terceiro discute-se assim. ─ Parece que a escravidão não impede de receber o sacramento da
ordem.

1. ─ Pois, a sujeição corporal não repugna à prelatura espiritual. Ora, o escravo vive em sujeição
corporal. Logo, não fica impedido de receber a prelatura espiritual, conferida pela ordem.

2. Demais. ─ Uma ocasião de se praticar a humildade não deve impedir a suscepção de nenhum
sacramento. Ora, tal é a escravidão; por isso o Apóstolo aconselha que quem puder prefira viver servo.
Logo, não deve ficar impedido de ser promovido à dignidade da ordem.

3. Demais. ─ Mais vexatório seria um clérigo ser vendido como escravo, que um escravo ser promovido a
clérigo. Ora, um clérigo pode ser licitamente vendido como escravo; assim, o bispo de Nola, Paulino,
vendeu-se a si mesmo como escravo. Logo, e com maior razão, pode um escravo ser promovido a
clérigo.
Mas, em contrário. ─ Parece que ser escravo é impedimento para a validade do sacramento. ─ Pois, a
mulher não pode, em razão da sua sujeição, receber o sacramento da ordem. Ora, maior sujeição é a do
escravo; pois, a mulher não se torna escrava do seu marido, sendo por isso que lhe não foi tirada dos
pés. Logo, também o escravo não recebe o sacramento.

2. Demais. ─ Quem recebe a ordem está por isso mesmo obrigado a ministrá-la. Ora, ninguém pode ao
mesmo tempo servir, como escravo ao seu dono, e exercer o ministério espiritual. Logo, parece que não
pode receber a ordem, porque os interesses do seu dono seriam lesados.

SOLUÇÃO. ─ Quem recebe a ordem se destina ao serviço divino. E como ninguém pode dar o que não é
seu, o escravo, que não pode dispor de si, não pode ser promovido às ordens. Mas, se o for, recebe-las-
à: porque a liberdade não é necessária à validade do sacramento, embora seja de necessidade de
preceito; pois, a falta de liberdade impede, não de receber uma faculdade, senão apenas de exercê-la. E
o mesmo se dá com todos os obrigados para com outrem, como os que se ocupam com cálculos e
pessoas tais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Quem recebe um poder espiritual assume a obrigação de
exercer uma certa atividade corporal. Fica por isso impedido se tem o seu corpo sujeito.

RESPOSTA À SEGUNDA. ─ Podemos aproveitar de muitas outras ocasiões para praticar a humildade, que
não as impedientes à recepção do sacramento da ordem. Por onde, a objeção não colhe.

RESPOSTA À TERCEIRA. ─ S. Paulino procedeu assim por abundância de caridade e guiado pelo Espírito
de Deus. E os acontecimentos o provam, pois, pela sua escravidão muitos do seu rebanho foram livrados
dela. Não devemos portanto, argumentar com esse exemplo, porque onde está o Espírito do Senhor aí
está a liberdade.

RESPOSTA À QUARTA. ─ Os sinais sacramentais representam por semelhança natural. Ora, a mulher é
sujeita por natureza, mas não o escravo. Logo, o símile não colhe.

RESPOSTA À QUINTA. - O escravo promovido à dignidade das ordens, com ciência do dono e sem
reclamação dele, por isso mesmo fica livre. Se porém o dono não o souber, então o bispo e quem
apresentou o escravo a ser ordenado, estão obrigados a lhe pagar o dobro do valor do escravo, se
sabiam que era escravo. Ou, tendo o escravo pecúlio deve remir-se a si mesmo; do contrário voltaria ao
domínio do seu senhor, embora não pudesse assim exercer a ordem.

## Art. 4 — Se o homicídio é causa impediente de receber as ordens sacras.
O quarto discute-se assim. ─ Parece que o homicídio não é causa impediente de se receber as ordens
sacras.

1. ─ Pois, as nossas ordens começaram pelo ofício dos Levitas, como se estabeleceu na distinção
precedente. Ora, os Levitas consagraram as suas mãos na efusão do sangue dos seus irmãos, como o
refere a Escritura. Logo, também no regime do Novo Testamento ninguém deve ser impedido de
receber as ordens por causa de efusão de sangue.

2. Demais. ─ Por um ato de virtude ninguém deve ficar impedido de receber qualquer sacramento. Ora,
às vezes o sangue é derramado para cumprir a justiça, como quando o ordena o juiz; e quem tem a
obrigação de o fazer pecaria não a cumprindo. Logo, isso não impede de receber o sacramento.

3. Demais. ─ A pena só é devida à culpa. Ora, pode alguém cometer um homicídio sem culpa; por
exemplo, defendendo-se, ou ainda casualmente. Logo, não deve incorrer na pena de irregularidade.
Mas, em contrário, várias determinações canônicas. E o costume da Igreja.

SOLUÇÃO. ─ Todas as ordens visam o sacramento da Eucaristia, sacramento de paz que Jesus Cristo nos
instituiu com a efusão do seu sangue. Ora, como o homicídio é tudo o que é de mais contrário à paz, e o
homicida muito mais se assemelha aos que mataram a Cristo do que devem assemelhar-se os ministros
do referido sacramento, por isso e por necessidade de preceito, não pode ser homicida quem vai ser
promovido à dignidade das ordens, embora não seja isso exigido para a validade do sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A Lei Antiga infligia a pena de sangue, mas não a Nova.
Não há pois símile entre os ministros da Lei Velha e os da Nova, cujo jugo é suave e o peso leve.

RESPOSTA À SEGUNDA. ─ A irregularidade não é incorrida só por causa de pecado, mas principalmente
quando a pessoa se torna inidônea para ministrar o sacramento da Eucaristia. Por isso o juiz, e todos os
que com ele participaram numa causa de sangue, são irregulares porque derramar sangue não convém
aos ministros do sacramento.

RESPOSTA À TERCEIRA. ─ Nós não fazemos senão o de que somos causa, o que procede da nossa
vontade. Por onde, quem por ignorância e casualidade mata a outrem não se pode chamar homicida
nem incorre em qualquer irregularidade. Salvo se se tiver entregue à prática de atos ilícitos ou não
houver empregado a diligência devida; porque então já o seu ato é de certo voluntário. Nem a razão de
não haver irregularidade é a ausência de culpa, porque também podemos incorrer nela sem culpa. Por
onde, embora não peque aquele que, em circunstâncias determinadas, mata para se defender, contudo
é irregular.

## Art. 5 — Se os filhos ilegítimos devem ser impedidos de receber a ordem.
O quinto discute-se assim. ─ Parece que os filhos ilegítimos não devem ser impedidos de receber a
ordem.

1. ─ Pois, os filhos não devem carregar com a iniquidade dos pais. Ora, carregariam se por serem
ilegítimos estivessem impedidos de receber as ordens. Logo, etc.

2. Demais. ─ Maior impedimento é o nosso defeito próprio, que o alheio. Ora, um concúbito ilícito não
torna ninguém impedido de receber as ordens. Logo, nem o concúbito paterno ilícito. Mas, em
contrário, a Escritura: O bastardo, isto é, o que nasceu de mulher pública, não entrará na congregação
do Senhor até a décima geração. Logo e com maior razão, não deve ser promovido às ordens.

SOLUÇÃO. ─ Os ordenados são constituídos superiores aos mais, em dignidade. Por isso e pela honra
devida à dignidade, devem ter um certo lustre, não para a validade do sacramento, mas por exigência de
preceito; isto é, devem ter um bom nome, ser ornados de bons costumes e não ser penitentes públicos.
E como uma origem viciosa obscurece esse lustre, por isso também os nascidos de foro ilegítimo ficam
impedidos de receber as ordens, salvo quando dispensados. E tanto mais difícil lhes é obter dispensa
quando mais indigna a sua origem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A irregularidade não é uma pena imposta à iniquidade.
Por onde é claro, que os filhos ilegítimos não carregam com a iniquidade paterna, pelo fato de serem
irregulares.

RESPOSTA À SEGUNDA. ─ Os nossos atos próprios podemos anulá-los pelo ato contrário da penitência;
mas não o que recebemos por natureza. Não há portanto símile entre o ato pecaminoso e a origem
viciosa.

## Art. 6 — Se pode alguém ser impedido por mutilação de algum membro.
O sexto discute-se assim. ─ Parece que ninguém deve ser impedido por mutilação de um membro.

1. ─ Pois, não se deve aumentar a aflição ao aflito. Logo, não deve ser privado do grau da ordem, como
pena de uma mutilação corpórea.

2. Demais. ─ Para o exercício da ordem é mais necessária uma discreção íntegra que uma integridade
corpórea. Ora, certos podem ser promovidos à ordem antes da idade de razão. Logo, também com
qualquer mutilação corporal.
Mas, em contrário. ─ Esses tais estavam impedidos de exercer o ministério do Velho Testamento. Logo e
com maior razão, a Lei Nova deve excluí-los. ─ Do bígamo diremos no tratado do matrimônio.

SOLUÇÃO. ─ Como do sobre dito se colhe, torna-se alguém inidôneo para receber as ordens ou por
alguma ação que cometeu ou por falta de dignidade pessoal. Por onde, os mutilados nalgum membro
ficam impedidos de receber a ordem, se a mutilação for tal que cause um defeito notável, como a
decepação do nariz, que torna a pessoa disforme; ou se houver risco de virem a exercer mal as suas
funções. Do contrário não ficam impedidos. E essa integridade é exigida por necessidade de preceito,
mas não para a validade do sacramento.
Donde se deduzem claras as respostas às objeções.