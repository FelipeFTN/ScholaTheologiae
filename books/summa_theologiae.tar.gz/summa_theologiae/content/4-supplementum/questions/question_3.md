# Questão 3: Da intensidade da contrição.
Em seguida devemos tratar da intensidade da contrição.
Sobre a qual se discutem três artigos:

## Art. 1 — Se a contrição é a maior dor de que a natureza é susceptível.
O primeiro discute-se assim. ─ Parece que a contrição não é a maior dor de que a natureza é
susceptível.

1. ─ Pois, a dor é o senso de uma lesão. Ora há certas lesões, como a de um ferimento, que se sentem
mais que a do pecado. Logo, a contrição não é a dor máxima.

2. Demais. ─ Pelo efeito formamos o nosso juízo sobre a causa. Ora, o efeito da dor são as lágrimas. Ora,
como às vezes o contrito não derrame materialmente lágrimas pelos pecados, que contudo derrama
quando lhe morre um amigo, ou quando sofre um ferimento ou coisa semelhante, resulta que a
contrição não é a dor máxima.

3. Demais. ─ Quanto mais uma coisa sofre aimixão do seu contrário, tanto menos intensidade tem. Ora,
a dor da contrição vai de mistura com muita alegria; pois, o contrito se alegra com a liberação, a
esperança do perdão e de muitas coisas semelhantes. Logo, é uma dor mínima.

4. Demais. ─ A dor da contrição é uma espécie de displicência. Ora, há muitas coisas que desagradam
mais ao contrito, que os pecados passados; assim, não preferiria sofrer as penas do inferno a deixar de
pecar; nem tão pouco ter sofrido, ou ainda sofrer todas as penas temporais; do contrário se achariam
poucos contritos. Logo, a dor da contrição não é máxima.
Mas, em contrário. ─ Segundo Agostinho, toda dor é fundada no amor. Ora, o amor da caridade, em que
se funda a dor da contrição, é o máximo. Logo, também máxima é a dor da contrição.

2. Demais. ─ Temos dor do mal. Logo, do maior mal devemos ter maior dor. Ora, a culpa é maior dor que
a pena. Logo, a dor da culpa, que é a contrição, excede todas as outras dores.

SOLUÇÃO. ─ Na contrição há duas sortes de dor. ─ Uma está na vontade mesma, e tal dor é
essencialmente a contrição, que outra causa não é senão a displicência dos pecados passados. E tal dor,
na contrição, excede todas as outras dores. ─ Pois, quanto mais uma causa agrada, tanto mais o seu
contrário desagrada. Ora, o fim último agrada sobre todas as coisas, pois, todas são desejadas por causa
dele. Por onde, o pecado, que afasta do fim último, deve desagradar sobre todas as causas. ─ Outra dor
é a da parte sensitiva, causada pela dor que acabamos de ver; ou por necessidade natural, enquanto
que as potências inferiores seguem o movimento das superiores; ou por eleição, segundo que a pessoa
penitente provoca em si mesmo essa dor, para ter contrição dos pecados. E de nenhum modo será essa
a dor máxima. Pois, as potências inferiores se movem mais veementemente pelos seus objetos próprios
do que pela redundância das potências superiores. Por onde, quanto mais a operação das potências
superiores agir sobre os objetos das inferiores, tanto mais estas obedecerão ao movimento daquelas.
Por isso, maior dor é a que sofre a parte sensitiva por uma lesão sensível, que a que nela redunda, da
razão. E semelhantemente, maior é a redundante da razão que delibera sobre causas corpóreas, do que
a redundante da razão quando considera o espiritual. Por onde, a dor da parte sensitiva, proveniente da
displicência que a razão tem do pecado, não é maior dor que as outras de que ela é susceptível. E
semelhantemente, nem a dor voluntàriamente assumida, quer porque o afeto interior não obedece
discricionariamente ao superior, de modo que no apetite inferior resulte uma paixão tão intensa e tal,
como ordena o superior; quer também porque das paixões se serve a razão, nos atos das virtudes,
segundo uma certa medida, que às vezes a dor, não acompanhada da virtude, não observa mas excede.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Assim como a dor sensível é provocada pelo sofrimento
de uma lesão, assim a dor interior pelo conhecimento do que é nocivo. Por onde embora a lesão do
pecado não seja percebida pelos sentidos externos, contudo o senso interior da razão percebe que é
máxima.

RESPOSTA À SEGUNDA. ─ As alterações corpóreas resultam imediatamente das paixões da parte
sensitiva e, mediante estas, das afeições da parte apetitiva superior. Donde vem que, da dor sensível, ou
ainda do sensível vizinho mais prontamente defluem as lágrimas corpóreas, do que da dor da contrição
espiritual.

RESPOSTA À TERCEIRA. ─ Essa alegria, que o penitente tem da dor, não diminui a displicência, por lhe
não ser contrária; mas a aumenta, porque todas as atividades se intensificam com o prazer que lhes é
próprio, segundo Aristóteles. Assim, quem se compraz em aprender uma ciência melhor a aprende. E
semelhantemente, quem se compraz com a displicência tem-na mais veemente. Mas bem pode ser que
essa alegria tempere a dor resultante da razão para a parte sensitiva.

RESPOSTA À QUARTA. ─ A intensidade da displicência de alguma causa deve ser correlata à quantidade
da malícia da mesma. Ora, a malícia da culpa mortal se mede por aquele contra quem se peca, enquanto
não merecedor dele ; e por quem peca, enquanto lhe é nociva. E como devemos amar mais a Deus que
a nós mesmos, por isso devemos odiar mais a culpa, enquanto ofensa de Deus, que enquanto nos é
nociva. ─ Ora, é-nos nociva principalmente por nos separar de Deus. E por aí, essa separação de Deus,
que é uma certa pena, deve nos desagradar mais que a própria culpa, pois é aquela a que produz este
mal; pois, o odiado por causa de outra causa é menos odiado; mas menos que a culpa, enquanto ofensa
de Deus. ─ Ora, entre todas as penas a ordem da malícia depende da quantidade do mal. Por onde,
sendo o mal máximo o que nos priva do bem máximo, a máxima das penas será a separação de Deus.
Mas há outra quantidade de malícia, acidental, a que deve a displicência atender, segundo a razão de
presente e de pretérito; pois, o que é pretérito já não existe; e por isso implica noção de menor malícia
e bondade. Donde vem que o homem refoge, antes, sofrer um mal presente ou futuro, do que ter
horror do pretérito. Por isso, nenhuma paixão da alma responde diretamente ao pretérito, assim como
a dor responde do mal presente e o temor, ao futuro. Por onde, de dois males passados a nossa alma
aborrece mais aquele cujo efeito permanece maior no presente ou é mais temido no futuro, mesmo se
no passado foi menor. E como o efeito da culpa precedente não é percebido às vezes como efeito de
uma pena passada ─ quer por ser a culpa mais perfeitamente sanada, que uma determinada pena; quer
por ser uma deficiência corporal mais manifesta que a espiritual ─ por isso também o homem bem
disposto às vezes concebe em si maior horror da pena precedente, que da culpa precedente, embora
estivesse preparado, antes, a sofrer a mesma pena, que a cometer a mesma culpa. - Mas também
devemos considerar, comparando a culpa com a pena, que certas penas vão inseparavelmente unidas à
ofensa de Deus, como a separação dele; e certas outras acrescentam a perpetuidade, como a pena do
inferno. Logo, da pena que tem anexa a ofensa, dessa devemos nos acautelar, do 'mesmo modo que da
culpa. Mas a que acrescenta a perpetuidade deve, absolutamente falando, ser mais fugida, que a culpa.
Se porém, delas separarmos a idéia de ofensa e só considerarmos a de pena, têm menos malícia que a
culpa, enquanto ofensa de Deus. E por isso devem desagradar menos. - E devemos também saber que
embora tal deva ser a disposição do contrito, não deve contudo sobre ela ser interrogado. Porque não
podemos nós facilmente medir os nossos afetos: e às vezes o que menos nos desagrada parece nos
desagradar mais, por estar mais próximo ao dano sensível, que nos é mais conhecido.

## Art. 2 — Se a dor da contrição pode ser excessiva.
O segundo discute-se assim. ─ Parece que a dor da contrição não pode ser excessiva.

1. ─ Pois, nenhuma dor pode ser mais imoderada que a que destrói o seu sujeito próprio. Ora, a dor da
contrição sendo tão intensa a ponto de acarretar a morte ou a corrupção do corpo, é louvável. Assim,
diz Anselmo: Oxalá as entranhas de minh'alma engordem de modo a dessecarem a medula de meus
ossos! E Agostinho se confessa digno de perder a vista, chorando os seus pecados. Logo, a dor da
contrição não pode ser excessiva.

2. Demais. ─ A dor da contrição procede do amor da caridade. Ora, o amor de caridade não pode ser
excessivo. Logo, nem a dor da contrição.
Mas, em contrário. ─ Toda virtude moral se corrompe por excesso e por defeito. Ora, a contrição é um
ato da virtude moral da penitência, sendo parte da justiça. Logo, a dor dos pecados pode ser excessiva.

SOLUÇÃO. ─ A contrição, enquanto dor racional de displicência, pela qual o pecado desagrada enquanto
ofensa de Deus, não pode ser excessiva; assim como nem o amor de caridade, que aumenta essa
displicência, pelo seu acréscimo mesmo, pode ser excessivo. Mas o pode, quanto à dor sensível, assim
como também excessiva pode ser a aflição exterior do corpo. Pois, em todos esses casos devemos
tomar como medida a conservação do sujeito e da boa disposição suficiente para fazermos o que
devemos. Donde o dizer o Apóstolo: o vosso culto racional.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Anselmo desejava que o desenvolvimento da devoção lhe
dessecasse a medula do corpo, não quanto ao humor natural, mas quanto aos desejos e as
concupisciências corpóreas. ─ E quanto a Agostinho, embora se reconhecesse digno de perder os olhos
do corpo, por causa do pecado, porque todo pecador é digno não só da morte eterna, mas também da
temporal, contudo não queria que os olhos se lhe cegassem.

RESPOSTA À SEGUNDA. ─ A objeção colhe, da dor existente na razão. Quanto à terceira, procede da dor
da parte sensitiva.

## Art. 3 — Se deve ser maior a dor de um pecado que de outro.
O terceiro discute-se assim. ─ Parece que não deve ser maior a dor de um pecado, que de outro.

1. ─ Pois, Jerônimo louva a Paula porque chorava os mínimos pecados como se fossem grandes. Logo,
não devemos ter dor, antes de um, que de outro.

2. Demais. ─ O movimento da contrição é súbito. Ora, um movimento súbito não pode ser
simultaneamente mais intenso e mais remisso ─ Logo, a contrição não deve ser maior, de um, que de
outro pecado.

3. Demais. ─ A contrição tem por objeto o pecado, sobretudo porque afasta de Deus. Ora, todos os
pecados mortais convêm pela aversão pois, todos nos privam da graça, pela qual nos unimos a Deus.
Logo, devemos ter igual contrição de todos pecados mortais.
Mas, em contrário. ─ A Escritura diz: o número dos golpes regular-se-á pela qualidade do pecado. Ora,
os golpes se regulam pela contrição dos pecados; pois, a contrição vai junto com o propósito de
satisfazer. Logo, devemos ter mais contrição de um pecado, que de outro.

2. Demais. ─ Devemos ter contrição do que devíamos ter evitado. Ora, devemos evitar de preferência o
pecado mais grave, se temos necessidade de cometer um, de dois. Logo e semelhantemente, ter maior
dor do pecado mais grave.

SOLUÇÃO. ─ Podemos encarar a contrição a dupla luz. ─ Primeiro, enquanto responde a cada pecado em
particular. E assim, quanto à dor do afeto superior, é necessário termos dor maior do pecado maior; por
haver maior razão, que é a ofensa de Deus, de termos mais dor de um, que de outro; pois, Deus mais se
ofende de um ato mais desordenado. E também semelhantemente, devendo uma culpa maior ter maior
pena, também a dor da parte sensitiva, enquanto assumida, por eleição, para expiar o pecado, sendo
uma como pena dele, deve ser maior, do pecado maior. Mas enquanto por Impressão do apetite
superior, nasce no interior, a intensidade da dor depende da disposição da parte inferior, para receber a
impressão da superior, e não da extensão do pecado. ─ De outro modo podemos encarar a contrição,
enquanto recai simultaneamente sobre todos os pecados, como no ato da justificação. E essa contrição,
ou procede da consideração de cada pecado em particular e então, embora seja um só ato, contudo
nele subsiste virtualmente a distinção dos pecados; ou pelo menos vai junto com o propósito de pensar
em cada um deles e então habitualmente é maior de um, que de outro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Paula não foi louvada por ter tido dor igual de todos os
pecados, mas porque tinha tal dor dos pecados pequenos como se fossem grandes, por comparação
com a dor que outros têm dos pecados. Mas, ela própria teria dor maior de pecados maiores.

RESPOSTA À SEGUNDA. ─ Nesse movimento subitâneo da contrição, embora não se possa descobrir
uma intenção atual, correspondente aos diversos pecados, contudo há aí uma intenção ao modo que já
foi dito. E também de outro modo, enquanto que cada pecado se relaciona com que, nessa contrição
geral, o contrito faz objeto da sua dor, a saber, a ofensa de Deus. Pois, quem ama um todo, lhe ama
também parcialmente as partes, embora não em ato; e, deste modo, enquanto elas se ordenam para o
lado, certas mais, certas menos. Assim, quem ama uma comunidade, ama a cada um, virtualmente, mais
e menos, segundo cada qual concorre para o bem comum. E semelhantemente, quem tem dor de haver
ofendido a Deus, sente Implicitamente dor de cada pecado cometido de modos diversos, enquanto por
ofender mais ou menos a Deus.

RESPOSTA À TERCEIRA. ─ Embora qualquer pecado mortal afaste de Deus e prive da graça, contudo uns
mais afastam, que outros, quanto maior for a dissonância que, mais que outros, causam com a sua
desordem, relativamente à bondade divina.