# Questão 55: Do impedimento da afinidade.
Em seguida devemos tratar do impedimento da afinidade.
Sobre o que se discutem onze artigos:

## Art. 1 — Se a afinidade pode resultar do matrimônio com um parente.
O primeiro discute-se assim. ─ Parece que a afinidade não pode resultar do casamento com um
parente.

1. Pois, quem transmite a outrem uma qualidade a possui em grau eminente. Ora, a mulher casada não
contrai parentesco com terceiro senão mediante o marido. Logo, como se torna afim do mando também
não terá parentesco por afinidade com nenhum dos parentes dele.

2. Demais. ─ Quando dois seres são independentes um do outro, unir-se a um não implica
necessariamente em unir-se ao outro. Ora, os parentes são independentes uns dos outros. Logo, o fato
de uma mulher ter casado com um homem não implica necessariamente que venha a ser parenta por
afinidade de todos os parentes dele.

3. Demais. - As relações entre pessoas nascem de sua união mútua. Ora, do fato de um homem ter-se
casado não resulta nenhuma união entre os seus consangüíneos. Logo, não nasce entre eles nenhuma
relação de afinidade.
Mas, em contrário. ─ Marido e mulher não constituem senão uma mesma carne. Se, pois, o marido fica
unido a todos os seus parentes carnais, pela mesma razão também com eles ficará unida a mulher.

2. Demais. ─ As autoridades citadas pelo Mestre provam o mesmo.

SOLUÇÃO. ─ Toda amizade natural se funda numa comunicação natural. Ora, esta, segundo o Filósofo,
pode proceder de dupla origem: da geração carnal ou da união contraída em vista da geração carnal.
Por isso diz ele no mesmo lugar, que a amizade entre o homem e a mulher é natural. Por onde, assim
como uma pessoa unida a outra em virtude da geração carnal é causa de um vínculo de amizade natural,
assim também o será quando unida em vista dessa mesma geração. Há porém a diferença seguinte. A
pessoa unida a outra, em virtude da geração carnal, como o filho do pai, participa da mesma origem e
do sangue comum. Por isso, a consangüinidade é o vínculo do mesmo gênero que, ligando o pai, liga
também o filho aos consangüíneos dele, embora em grau diferente, por causa da maior distância do
tronco. A pessoa chegada, porém, pelos laços da carne não se prende ao mesmo tronco, senão por uma
união extrínseca. Donde, um vínculo de gênero diverso chamado afinidade. E tal é o que diz o verso:
A casada muda de gênero, mas a gerada, de grau.
Porque uma pessoa gerada de outra contrai o mesmo parentesco, mas em outro grau; ao passo que a
casada contrai um parentesco de gênero diverso.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora a causa seja superior ao efeito, daí não se conclui
que ambos hão de ter o mesmo nome. Pois, o que está no efeito pode também estar na causa, mas não
do mesmo modo, senão de modo mais elevado; e portanto, não convirá o mesmo nome à causa e ao
efeito, nem pela mesma razão; tal o que se dá com todas as causas equívocas. Ora, neste sentido, a
união do marido e da mulher é superior à da mulher com os parentes do marido. Por isso não deve
chamar-se afinidade, mas, matrimônio, que é uma espécie de união, assim também o homem é idêntico
a si mesmo, mas não é seu próprio parente.

RESPOSTA À SEGUNDA. ─ Os parentes são de certo modo independentes uns dos outros e unidos uns
aos outros. E em virtude da união se dá, que uma pessoa unida a um fica de certa maneira unida com
todos. Mas, por causa da independência e da distância, pode se dar que a ligada a um, de certo modo,
esteja ligada a outro, de outro modo, quer por gênero diferente de união ou por um outro grau.

RESPOSTA À TERCEIRA. ─ A relação pode originar-se do movimento dos dois extremos, como no caso da
paternidade e da filiação. E essa relação está então realmente em cada um dos termos. Pode porém a
relação nascer do movimento de um só dos extremos, e isto de dois modos. Primeiro, quando a relação
se origina do movimento de um, sem o movimento de outro, quer precedente, quer concomitante. Tal a
relação entre o Criador e a criatura, entre o sensível e o sentido, entre a ciência e o seu objeto. ─ De
outro modo, quando a relação nasce do movimento de um extremo, sem o movimento simultâneo do
outro, que porém já se moveu precedentemente. Assim, dois homens se tornam da mesma altura
quando um cresce, sem que o outro cresça nem diminua; mas o primeiro chegou ao seu
desenvolvimento atual por um determinado movimento ou mutação. Por isso tal relação se funda
realmente em cada um dos extremos. Ora, o mesmo se dá com a consangüinidade e a afinidade. Pois, a
relação de fraternidade, nascida entre um recém-nascido e um homem já de idade provecta, é causada
sem nenhuma mudança neste último, que já mudou anteriormente, isto é, desde quando nasceu; por
isso a relação, de que é um dos termos, lhe resulta da mudança sofrida pelo outro termo.
Semelhantemente, do fato de um homem descender, pela sua geração, do mesmo tronco de um
homem casado, resulta a afinidade entre êle e a esposa desse homem, sem sofrer ela nenhuma
mudança.

## Art. 2 — Se a afinidade subsiste, depois da morte do marido, entre os consangüíneos do marido e da mulher.
O segundo discute-se assim. ─ Parece que a afinidade não subsiste, depois da morte do marido, entre
os consangüíneos do marido e da mulher.

1. Pois, desaparecida a causa, desaparece o efeito. Ora, a causa da afinidade foi o matrimônio, que
desaparece com a morte do marido; porque, então, a mulher fica solta da lei do marido, na expressão
do Apóstolo. Logo, também não subsiste a referida afinidade.

2. Demais. ─ A consangüinidade causa a afinidade. Ora, a consangüinidade entre o marido e os seus
parentes desaparece com a morte dele. Logo, também desaparece a afinidade entre elas e eles.
Mas, em contrário. ─ A afinidade é causada pela consangüinidade. Ora, a consangüinidade é um vínculo
perpétuo, enquanto vivem as pessoas. Logo, também a afinidade. Portanto, a afinidade não desaparece
com a dissolução do casamento pela morte de um dos esposos.

SOLUÇÃO. ─ Uma relação pode desaparecer de dois modos: pela disposição do sujeito ou pela
eliminação da causa. Assim, a semelhança deixa de existir quando um dos semelhantes desaparece, ou
quando desaparece a qualidade que era a causa da semelhança. Ora, certas relações tem como causa
uma ação, uma paixão ou um movimento, como diz Aristóteles. E dessas umas são causadas pelo
movimento atual de um ser; assim, a relação existente entre o motor e o movido. Outras nascem da
aptidão dos seres ao movimento; tal a relação entre um motor e o imóvel, entre, um senhor e o seu
escravo. Outras, ainda, nascem de um movimento já realizado; assim, a relação entre o pai e o filho,
unidos, não por existir ainda a geração, mas por ter-se realizado antes. Ora, a aptidão para o movimento
desaparece, como desaparece o fenômeno mesmo do movimento; ao passo que o ato de um ser se ter
movido subsiste sempre, porque o já feito não deixa nunca de o ser. Por isso, a paternidade e a filiação
não desaparecem nunca pela eliminação da causa, mas só pela disposição do sujeito, como sendo o
outro extremo. E o mesmo devemos dizer da afinidade, causada não pela união atual dos cônjuges, mas
do fato da sua união passada. Por onde, não desaparece enquanto existirem as pessoas que contraíram
a afinidade, embora venha a morrer a pessoa por causa da qual ela foi contraída.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A união conjugal causa a afinidade não só por unir
atualmente os esposos, mas também pelos ter já unido no passado.

RESPOSTA À SEGUNDA. ─ A consangüinidade não é a causa próxima da afinidade; mas, a união com o
consangüíneo, não só a atual, mas também a passada. Por isso, a objeção não colhe.

## Art. 3 — Se o concúbito ilícito causa a afinidade.
O terceiro discute-se assim. ─ Parece que o concúbito ilícito não causa a afinidade.

1. Pois, a afinidade é uma coisa honesta. Ora, coisas honestas não podem ter causas desonestas. Logo, a
afinidade não pode ser causada por um concúbito desonesto.

2. Demais. ─ Onde há consangüinidade não pode também haver afinidade; porque a afinidade é a
proximidade entre pessoas, proveniente da união carnal, sem haver nenhum parentesco. Ora, se o
concúbito ilícito causasse a afinidade, poderíamos contraí-la com os nossos parentes ou conosco
mesmo; assim, no caso de quem tivesse relação incestuosa com uma parenta. Logo, a afinidade não
pode resultar de um concúbito ilícito.

3. O concúbito ilícito pode ser natural ou contra a natureza. Ora, um concúbito ilícito contra a natureza
não gera a afinidade, como dispõe o direito. Logo, nem o concúbito ilícito segundo a natureza.
Mas, em contrário, o que se ajunta com a prostituta faz-se um mesmo corpo com ela, na expressão do
Apóstolo. Ora, esta era uma causa de o matrimônio gerar a afinidade. Logo, pela mesma razão, o
concúbito ilícito.

2. Demais. ─ A conjunção carnal é causa da afinidade, como resulta da seguinte definição: A afinidade é
a proximidade entre pessoas proveniente da união carnal, sem haver nenhum parentesco. Ora,
conjunção carnal também há no concúbito ilícito. Logo, o concúbito ilícito causa a afinidade.

SOLUÇÃO. ─ Segundo o Filósofo, a união entre o homem e a mulher é chamada natural, principalmente
por causa da procriação dos filhos e, secundariamente por causa dos encargos comuns dos esposos.
Ora, a procriação resulta do casamento em razão da conjunção carnal; e os encargos comuns, enquanto
ele é uma associação fundada em vista de uma vida em comum. Quanto ao primeiro efeito, resulta de
qualquer conjunção carnal onde há mixtão seminal, porque de tal conjunção podem nascer filhos,
embora daí não provenha o segundo resultado. Por onde, como o matrimônio causa a afinidade,
enquanto conjunção carnal, também o concúbito fornicário, pois é também uma união carnal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ No concúbito fornicário há algo de natural, comum à
fornicação e ao matrimônio; e por aí causa a afinidade. Implica porém, uma desordem, que o diferencia
do matrimônio; e por aí não causa a afinidade. Por isso a afinidade sempre permanece honesta, embora
a sua causa seja de certo modo desonesta.

RESPOSTA À SEGUNDA. ─ Duas relações opostas podem fundar-se no mesmo sujeito em razão de
causas diferentes. Por isso, entre duas pessoas determinadas pode haver afinidade e consangüinidade,
não só em virtude de um concúbito ilícito, mas também de um lícito. Assim, quando um meu
consangüíneo por parte de pai casou com uma consangüínea por parte de mãe. Eis porque as palavras
da definição da afinidade ─ sem haver nenhum parentesco ─ devem ser entendidas como significando ─
como tal. Nem daí se segue, que quem cometer um incesto com uma consangüínea venha a ser afim de
si mesmo; porque tanto a afinidade como a consangüinidade implicam, como a semelhança,
diversidade.

RESPOSTA À TERCEIRA. ─ No concúbito contra a natureza não há mistura seminal, que possa ser causa
da geração. Por isso, tal concúbito não gera a afinidade.

## Art. 4 — Se dos esponsais pode resultar alguma afinidade.
O quarto discute-se assim. ─ Parece que dos esponsais nenhuma afinidade pode resultar.

1. Pois, a afinidade é um vínculo perpétuo. Ora, os esponsais podem ser votos. Logo, não podem ser
causa da afinidade.

2. Demais. ─ Quem violentou uma mulher, mas não conseguiu consumar o ato, não contrai com ela
nenhuma afinidade. Mais próximo contudo está da conjunção carnal, que quem contraiu esponsais.
Logo, os esponsais não causam a afinidade.

3. Demais. ─ Outra coisa não são os esponsais senão a promessa de núpcias futuras. Ora, pode-se fazer
uma promessa de núpcias futuras sem dela resultar nenhuma afinidade; assim, se for feita antes do sete
anos; ou se o for por quem prometer casamento futuro a uma mulher e tenha um perpétuo
impedimento, que exclui a potência física; ou se a promessa foi feita entre pessoas, cujo casamento é
ilícito em virtude de um voto; ou de outro modo qualquer. Logo, os esponsais não podem ser causa de
afinidade.
Mas, em contrário, Alexandre Papa proibiu à mulher casar com o irmão do seu ex-noivo. O que não faria
se os esponsais nenhuma afinidade tivessem produzido. Logo, etc.

SOLUÇÃO. ─ Assim como os esponsais não constituem um verdadeiro casamento, mas são apenas urna
preparação para êle, assim, os esponsais não geram a afinidade, como o matrimônio, mas uma
semelhança de afinidade chamada justiça da honestidade pública. E esta impede o matrimônio, como a
afinidade e a consangüinidade, e nos mesmos graus. E assim se define: A justiça da honestidade pública
é uma proximidade proveniente dos esponsais, que, por causa da sua honestidade, tira a sua força da
instituição da Igreja. Por onde é clara a significação do nome e a causa desse impedimento: essa
proximidade foi instituída pela Igreja em virtude da honestidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Os esponsais causam o gênero de afinidade chamado
justiça da honestidade pública, não por si mesmos, mas em razão do fim a que se ordenam. Por isso,
assim como o vínculo do matrimônio é perpétuo, assim o referido modo de afinidade.

RESPOSTA À SEGUNDA. ─ O marido e a mulher, na conjunção carnal, tornam-se uma só carne, pela
mistura seminal. E assim, por mais que um homem violente uma mulher e a brutalize, se não houver
consumação do ato sexual, nenhuma afinidade resultará daí. Ora, o matrimônio causa a afinidade, não
só em virtude da conjunção carnal, mas ainda por causa da sociedade conjugal, a qual também torna o
matrimônio natural. Por isso, também a afinidade resulta do contrato mesmo do matrimônio, por
palavras de presente antes da cópula carnal. Semelhantemente, os esponsais, pelos quais se pacta a
sociedade conjugal, dão lugar à contração de um símile da afinidade, a saber, a justiça da honestidade
pública.

RESPOSTA À TERCEIRA. ─ Todos os impedimentos, que anulam os esponsais, não permitem nascer
nenhuma afinidade do fato de se ter pactado o casamento. Por onde, quem contrair esponsais, apesar
da sua falta de idade, de ter feito voto solene de continência, ou de algum semelhante impedimento,
não dá lugar a qualquer afinidade, por serem nulos os esponsais.
Se porém, um menor impotente por natureza ou por malefício e portanto vítima de um impedimento
perpétuo contrair, antes da puberdade e depois dos sete anos, esponsais com uma adulta, desse
contrato nasce um impedimento da justiça da honestidade pública. Contudo, o impedimento não podia
ainda produzir o seu efeito, porque em tal idade os menores, imponentes ou não; são igualmente
incapazes do ato matrimonial.

## Art. 5 — Se a afinidade pode ser causa da afinidade.
O quinto discute-se assim. ─ Parece que a afinidade também pode ser causa da afinidade.

1. Pois, Júlio Papa dispõe: Ninguém possa desposar a viúva de um dos parentes a quem sobreviver. E no
capítulo seguinte: As mulheres de dois primos não podem desposar, uma após outra, o mesmo homem.
Ora, isto não se dá senão por causa da afinidade contraída pela união com uma pessoa afim. Logo, a
afinidade é causa da afinidade.

2. Demais. ─ O parentesco resulta das relações carnais como da geração carnal; pois do mesmo modo se
contam os graus da afinidade como os da consangüinidade. Ora, a consangüinidade é causa da
afinidade. Logo, também a afinidade.

3. Demais. ─ Duas coisas iguais a uma terceira são iguais entre si. Ora, a esposa está ligada pelo mesmo
parentesco com todos os consangüíneos do seu marido. Logo, também todos os consangüíneos do
marido estão ligados do mesmo modo com todos os que tem atinência com a mulher por afinidade.
Portanto, é a afinidade causa da afinidade.
Mas, em contrário. ─ Se a afinidade causa a afinidade, então quem tivesse tido relação com duas
mulheres não poderia casar com nenhuma delas; porque, nesse caso, uma se tornaria afim de outra.
Ora, isto é falso. Logo, a afinidade não gera a afinidade.

2. Demais. ─ Se a afinidade nascesse da, afinidade, quem casasse com uma viúva ficaria afim de todos os
parentes do seu primeiro marido, com os quais a mulher tem afinidade. Ora, tal não pode se dar,
porque então do primeiro marido defunto é que o segundo seria sobretudo afim. Logo, etc.

3. Demais. ─ A consangüinidade é vínculo mais forte que a afinidade. Ora, os consangüíneos da esposa
não se tornam afins dos consangüíneos da mulher. Logo, e com maior razão, os afins da mulher não se
tornam afins deles. Donde a mesma conclusão anterior.

SOLUÇÃO. ─ De dois modos pode uma coisa proceder de outra. Ou ao modo pelo qual uma procede de
outra por semelhança específica, como no caso de um homem que gera outro. Ou o modo de
procedência não específica; e este modo de proceder sempre é para uma espécie inferior, como no caso
de todos os agentes equívocos. Ora, o primeiro modo de processão, por mais que se reitere, a espécie
permanece a mesma sempre. Assim, se de um homem é gerado outro por ato da virtude geratriz, desse
mesmo também outro poderá ser gerado, e assim por diante. Mas, do segundo modo, assim como já de
início dá lugar a uma nova espécie, por mais reiterado que seja fará sempre uma espécie nova; assim, se
o movimento de um ponto produz a linha e não o ponto, porque o movimento deste é o produto
daquela, também do movimento lineal da linha não procede a linha, mas a superfície, e da superfície o
corpo; e ulteriormente, por esse modo de processão, nada mais pode resultar.
Ora, encontramos na geração do parentesco dois modos pelos quais pode produzir-se o laço do
parentesco. Um pela geração carnal; e esse sempre produz a mesma espécie de parentesco. Outro pela
conjunção matrimonial; e este logo de início produz outra espécie; assim, a esposa de um parente por
consangüinidade não se torna consanguínea, mas afim. Por isso, mesmo que se reitere esse modo de
proceder, não haverá afinidade, mas outro gênero de parentesco. E assim, a pessoa unida pelo
matrimônio com um parente afim se torna afim deste, mas contrai um outro gênero de afinidade
chamado de segundo grau. Do mesmo modo, quem se unir por matrimônio com um afim de segundo
grau não lhe será afim em segundo grau, mas em terceiro. Tal o que ensina o verso citado:
A casada muda de gênero, mas a gerada, de grau.
E antigamente esses dois gêneros constituíam impedimentos, mais pela justiça da honestidade pública
do que pela afinidade. Pois, diferem da verdadeira afinidade, como aquele parentesco contraído pelos
esponsais. Mas, atualmente cessou essa proibição. E só constitui proibição o primeiro gênero de
afinidade, que é realmente afinidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O consangüíneo da esposa torna-se afim do marido, pelo
primeiro gênero de afinidade e a mulher desse consangüíneo, pelo segundo. Por onde, morto o parente
afim, a viúva não poderá ser desposada pelo marido da sua parente por afinidade por causa do segundo
gênero de afinidade. Semelhantemente, quem casar com uma viúva, o consangüíneo do primeiro
marido, afim da mulher pelo primeiro gênero de afinidade, torna-se afim do segundo marido pelo
segundo gênero de afinidade; e a esposa desse consangüíneo , afim da mulher deste pelo segundo
gênero de afinidade, torna-se afim do segundo marido pelo terceiro gênero de afinidade. Mas, como o
terceiro gênero de afinidade dava lugar a uma proibição, mais por uma razão de honestidade pública do
que por causa da afinidade, por isso o canon determina: Uma razão de honestidade pública proíbe às
esposas de dois primos se casarem em seguida, uma após outra, com o mesmo homem. Mas, essa
proibição já não vigora.

RESPOSTA À SEGUNDA. ─ Embora a conjunção carnal seja causa de união, contudo essa união é de
gênero diferente da produzida pela geração.

RESPOSTA À TERCEIRA. ─ A esposa contrai com os parentes do marido um parentesco do mesmo grau,
mas não do mesmo gênero.
Mas como as objeções opostas parecem concluir, que a afinidade não causa nenhum vínculo, devemos
lhes responder, a fim de que não se julgue irracional a antiga proibição da Igreja.

RESPOSTA À QUARTA. ─ A mulher não se torna afim, pelo primeiro gênero de afinidade, do homem com
que se uniu sexualmente, como do sobredito se colhe. Por consequência não se toma afim, pelo
segundo gênero de afinidade, de outra mulher com quem esse mesmo homem tivesse tido relações. Se,
pois, tal homem casar com uma dessas mulheres, a outra não se torna afim dessa, pelo terceiro gênero
de afinidade. Eis porque o direito antigo não proibia um mesmo homem casar sucessivamente com duas
mulheres com as quais tivesse tido relação carnal.

RESPOSTA À QUINTA. ─ Assim como o marido não é afim da sua esposa pelo primeiro gênero de
afinidade, assim também o é do segundo marido da mesma mulher, pelo segundo gênero de afinidade.
Por isso a objeção não colhe.

RESPOSTA À SEXTA. ─ Não pode uma pessoa se unir comigo por meio de outra, senão enquanto unida
com esta. Por onde, mediante a mulher, que me é afim, nenhuma pessoa contrai parentesco comigo
senão a que for aparentada com essa mulher. E isso não pode ser senão pela geração carnal, dela
proveniente, ou pela união matrimonial com ela. E de ambos esses modos, mediante essa mulher,
contraia eu parentesco com ela, conforme o direito antigo; pois, o filho dela nascido, ainda que de outro
homem, torna-se meu afim no mesmo gênero. Mas, em outro grau, como resulta da regra dada em
primeiro lugar. Além disso, o seu segundo marido torna-se meu afim, pelo segundo gênero de afinidade.
Mas, os outros parentes dessa mulher nenhuma união tem com o seu marido: ela porém, contrai união
com eles, como com o pai e a mãe, dos quais procede; ou com os irmãos, com quem tem o mesmo
princípio de vida. Por onde, o irmão de uma afim minha, ou o pai, não se torna meu afim em nenhum
grau.

## Art. 6 — Se a afinidade impede o matrimônio.
O sexto discute-se assim. ─ Parece que a afinidade não impede o matrimônio.

1. Pois, só impede o matrimônio o que lhe é contrário. Ora, a afinidade sendo efeito do matrimônio, não
o contraria, Logo, não o impede.

2. Demais. ─ Pelo matrimônio a mulher se torna uma como coisa do marido. Ora, os parentes do marido
defunto lhe sucedem nos bens. Logo, podem também receber como sucessão a viúva. E contudo
mantém afinidade com ela como se demonstrou. Logo, a afinidade não impede o matrimônio.
Mas, em contrário, a Escritura: Não descubrirás a fealdade da mulher de teu pai. Ora, essa esposa é
somente afim. Logo, a afinidade impede o matrimônio.

SOLUÇÃO. ─ A afinidade precedente ao matrimônio impede-o de ser contraído e diminui o já contraído,
pela mesma razão por que o faz o parentesco. Pois, a necessidade leva os consangüíneos a habitarem
juntos assim como os afins. E como há um certo vinculo de amizade entre os consangüíneos: assim
também entre os afins. Mas, a afinidade sobreveniente ao casamento, não pode dirimi-lo, como
dissemos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A afinidade não se opõe ao matrimônio que a causa; mas
sim ao que se contraísse com um afim, porque impediria a multiplicação da amizade e a repressão da
concupiscência, fins visados pelo matrimônio.

RESPOSTA À SEGUNDA. ─ Os bens possuídos por um homem não fazem um só corpo com ele, no
sentido em que se diz que sua mulher forma com ele uma mesma carne. Por onde, assim como a
consangüinidade impede a união carnal com o marido, impedi-lo-á também com a sua mulher.

## Art. 7 — Se a afinidade em si mesma também tem graus.
O sétimo discute-se assim. ─ Parece que em si mesma também a afinidade tem graus.

1. Pois, todo parentesco comporta, em si mesmo, certos graus. Ora, a afinidade é um parentesco. Logo,
tem em si mesma graus, independente dos graus do parentesco que a geram.

2. Demais. ─ O mestre diz, que os filhos do segundo casamento não podem unir-se com os parentes
afins do primeiro marido. Ora, isto não se daria se os filhos de pais, por afinidade, também não se
tornassem afins entre si. Logo, a afinidade, em si mesma, tem graus.
Mas, em contrário. ─ A afinidade é causada pela consangüinidade. Logo, todos os graus de afinidade são
causados pelos graus de consangüinidade. Portanto, não tem em si mesma graus.

SOLUÇÃO. ─ Uma coisa não é susceptível de divisão essencial, senão em razão do que lhe convém
genericamente; assim, o animal se divide em racional e irracional e não em branco e preto. Ora, a
geração carnal é essencial à consangüinidade, porque por ela imediatamente se contrai o vínculo do
parentesco; ao passo que a afinidade não respeita à geração senão mediante a consangüinidade, que é
a sua causa. Por onde, como os graus de parentesco dependem do número das gerações, a distinção dos
graus, essencial e imediatamente depende da consangüinidade; e, mediante esta, da afinidade.
Portanto, a regra geral para se determinar o grau de afinidade é a seguinte: tantos graus de
consangüinidade me separam do marido, quantos me separam da sua mulher.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Os graus de parentescos não podem ser contados senão
tomando em consideração as linhas ascendente e descendente, a que não se refere a afinidade senão
mediante a consangüinidade. Logo, a afinidade não tem em si mesma graus, senão tomados em
conjunto com os de consangüinidade.

RESPOSTA À SEGUNDA. ─ O filho, por segundo matrimônio, com uma mulher minha afim, era
considerada meu afim, pelo direito antigo, não essencialmente falando, senão só por acidente. Por isso,
não podia casar com os parentes do primeiro marido, mais por uma razão de honestidade pública do
que por afinidade. Por isso, também essa proibição deixou atualmente de existir.

## Art. 8 — Se os graus de afinidade tem a mesma extensão que os de consangüinidade.
O oitavo discute-se assim. ─ Parece que os graus de afinidade não tem a mesma extensão que os de
consangüinidade.

1. Pois, o vínculo da afinidade é mais forte que o da consangüinidade; porque a afinidade é causada pela
consangüinidade, mas dela difere segundo a sua espécie, como o efeito de uma causa equívoca. Ora,
quanto mais forte é um vínculo tanto mais diuturna é a sua duração. Logo, o vínculo da afinidade não se
estende até o mesmo número de graus a que se a consangüinidade estende.

2. Demais, ─ O direito humano deve imitar o divino. Ora, segundo o direito divino, certos graus de
consangüinidade impediam o matrimônio, e contudo esses mesmos graus na afinidade não o impediam.
Tal o caso do homem que, podendo casar com a mulher de seu irmão, não podia, porém fazê-lo com a
sua própria irmã. Logo, também agora não deveriam constituir proibições iguais a afinidade e a
consangüinidade.
Mas, em contrário. ─ O fato mesmo de uma mulher ser casada com um meu parente a torna minha afim.
Logo, qualquer grau de parentesco existente entre mim e o seu marido também a torna minha afim. E
assim, os graus de afinidade devem contar-se no mesmo número que os de consangüinidade.

SOLUÇÃO. ─ Desde que os graus de afinidade se fundam no da consangüinidade, resulta
necessariamente serem tantos os daquela quantos os desta. Contudo, sendo a afinidade um vínculo
menos forte que o da consangüinidade, mais fácil tanto outrora como atualmente, é dispensar nos graus
remotos da afinidade que nos mesmos, da consangüinidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O ser menos forte o vínculo da afinidade, que o da
consangüinidade é causa das variedades do gênero do parentesco, mas não dos graus. Logo, a objeção
feita não vem a propósito.

RESPOSTA À SEGUNDA. ─ Um irmão não podia casar com a viúva de seu irmão, senão no caso de este
morrer sem filhos, a fim de se lhe não extinguir a posteridade. Isso era então necessário, quando pela
geração carnal se multiplicava o culto da religião, o que já se não dá agora. Por onde é claro não a
desposava, como em seu próprio nome, mas quase por suprir a falta do irmão.

## Art. 9 — Se o casamento contraído entre afins ou consangüíneos deve sempre ser rompido.
O nono discute-se assim. ─ Parece que nem sempre deve ser rompido o casamento contraído entre
afins ou consangüíneos.

1. Pois, não separe o homem o que Deus ajuntou. Ora, como devemos pensar que Deus faz o que faz a
Igreja, que bem pode unir esses tais, sem o saber, parece que se depois vier a sabê-lo, não deve o
casamento ser roto.

2. Demais. ─ Mais privilegiado é o vínculo do matrimônio que o do domínio. Ora, pela prescrição de
longo tempo, adquirimos o domínio daquilo de que não éramos dono. Logo, um tempo diuturno ratifica
o matrimônio, mesmo se antes não estava ratificado.

3. Demais. ─ Devemos julgar do mesmo modo coisas semelhantes. Ora; se o matrimônio devesse ser
dirimido por causa de parentesco, então no caso de dois irmãos terem casado com duas irmãs, se um
deve separar-se da mulher por motivo de parentesco, também o deverá o outro, pela mesma razão.
Ora, tal não se dá. Logo, o matrimônio não deve ser roto, por afinidade ou consangüinidade.
Mas, em contrário. ─ A consangüinidade e a afinidade impedem contrair matrimônio e dirimem o
matrimônio contraído. Logo, provada a afinidade ou a consangüinidade, devem ser separados os
esposos, mesmo depois de casados.

SOLUÇÃO. ─ Todo comércio carnal, fora do matrimônio lícito é pecado mortal, e a Igreja de todos os
modos procura impedi-lo. Por isso lhe compete separar aqueles que não podiam ter contraído
verdadeiro casamento, sobretudo se consangüíneos e afins, que sem incesto não podem praticar a
conjunção carnal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A Igreja, embora, fundada no dom e na autoridade de
Deus, contudo, enquanto sociedade de homens, pode sofrer na sua atividade da deficiência humana,
sem que se possa por isso acusar a Deus. Por isso, a união celebrada à face da Igreja, mas ignorando-lhe
ela o impedimento, não se torna inseparável por autoridade divina; pois, foi ela induzida em erro
humano, contra a autoridade divina; o que escusa de pecado, enquanto esse erro subsiste, por ser de
fato. Por onde, quando o impedimento chegar ao conhecimento da Igreja, essa união deve ser rôta.

RESPOSTA À SEGUNDA. ─ Obras que não podem ser feitas sem pecado nenhuma prescrição é capaz ele
as justificar. Porque, como diz Inocêncio III, a diuturnidade temporal, longe de diminuir o pecado, o
aumenta. Nem aproveitam em nada, no caso, as prerrogativas do matrimônio, que não pode subsistir
entre pessoas inábeis para contraí-lo.

RESPOSTA À TERCEIRA. ─ Atos praticados entre umas ou mais pessoas não podem prejudicar a
terceiros, no foro contencioso. Por isso, quando de dois irmãos o matrimônio de um não é válido, que
casou com uma, de duas irmãs por causa de parentesco; nem por isso a Igreja anula o matrimônio do
outro, que não foi acusado. Mas no foro da consciência, também não há de necessariamente e sempre
ser, por isso, o outro irmão obrigado a repudiar sua mulher. Porque frequentemente tais acusações
procedem da malevolência e são provadas por testemunhas falsas. Esse homem não fica portanto
obrigado a formar a sua consciência, pelo que se passou com o casamento de seu irmão. Mas aqui é
preciso distinguir. Pois, ou conhece de modo certo o impedimento ao matrimônio, ou o suspeita, ou o
ignora. No primeiro caso não deve exigir nem cumprir o dever conjugal, no segundo, deve cumprir, mas
não exigir, no terceiro, tanto pode cumprir como exigir.

## Art. 10 — Se para dirimir o casamento contraído entre afins e consangüíneos, deve-se proceder por via de acusação.
O décimo discute-se assim. ─ Parece que para dirimir o casamento contraído entre afins e
consangüíneos, não deve-se proceder por via de acusação.

1. Pois, a acusação é precedida pela inscrição que obriga a sofrer a pena de talião ao acusador, se não
conseguir provar a acusação. Ora, isto não é necessário fazer-se, quando se trata de dirimir um
casamento.

2. Demais. ─ Nas causas matrimoniais só se ouvem os parentes, como diz o Mestre. Ora, nas acusações
se ouvem também os estranhos. Logo, numa causa de ruptura do casamento não se deve proceder por
via de acusação.

3. Demais. ─ Se numa causa matrimonial se devesse proceder por via de acusação, então isso se deveria
fazer sobretudo quando menos difícil fosse a ruptura. Ora, tal se dá enquanto os esponsais estão
simplesmente contraídos. Ora, não é nesse momento que o matrimônio é impugnado. Logo, não se
deverá mais tarde proceder por via de acusação.

4. Demais. ─ Ninguém fica proibido de fazer uma acusação pelo fato de não havê-la feito
imediatamente. Ora, tal se dá no casamento; pois, quem se calou quando se contraía o matrimônio, não
pode depois acusá-lo de se ter tornado suspeito. Logo, etc.
Mas, em contrário. ─ Tudo o que é ilícito pode ser atacado. Ora, o matrimônio entre afins e
consangüíneos é ilícito. Logo, pode ser objeto de uma acusação.

SOLUÇÃO. ─ A acusação foi instituída, para não ser tratado como inocente quem tem culpa. Ora, assim
como por ignorância de fato pode vir a ser reputado inocente quem é culpado, assim, por ignorância de
uma circunstância também podemos considerar lícito um fato ilícito. Logo, como um homem pode ser
acusado, também o pode um fato. E assim o matrimônio é acusado quando, por ignorância de
impedimento, considera-se legítimo o ilegítimo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A obrigação de sofrer a pena de talião tem lugar quando
se acusa uma pessoa por um crime cometido; porque então se trata de punir o criminoso. Mas quando
se acusa um fato, então não se trata de impor uma pena ao seu autor, mas de impedir o ilícito. Por isso
quem acusa um matrimônio a nenhuma pena se obriga; mas tal acusação pode ser feita tanto
verbalmente como por escrito, de modo que fique expressa a pessoa que acusa o matrimônio e o
impedimento por causa do qual é ele acusado.

RESPOSTA À SEGUNDA. ─ Os estranhos não podem saber de um parentesco, senão mediante os
consangüíneos, dos quais é mais provável que saibam. E assim de calarem-se esses nasce a suspeita que
o estranho procede por malevolência, salvo se quiser recorrer, na sua prova, aos consangüíneos. Por
isso sua acusação é rejeitada, quando os parentes se calam, eles mediante quem a prova não pode ser
feita. Os parentes porém, por mais parentes que sejam, não tem a sua acusação rejeitada, quando
impugnam um matrimônio, fundados num impedimento perpétuo, que o impede de ser contraído e o
dirimem quando já contraído. Mas quando se acusa um casamento, alegando como razão, que não foi
contraído, então devem ser afastados os parentes, como suspeitos; salvo se uma das partes está em
situação mais inferior em dignidade e riquezas, e dos quais se pode pensar com probabilidade que
preferiram antes que o matrimônio subsistisse.

RESPOSTA À TERCEIRA. ─ Quando o matrimônio ainda não foi contraído, mas só os esponsais, não pode
ser acusado; pois, não se acusa o que não existe. Mas pode ser denunciado o impedimento, a fim de não
ser ele contraído.

RESPOSTA À QUARTA. ─ Quem primeiro se calou, ora é admitido a acusar mais tarde o matrimônio, se
quiser fazê-lo, ora não. O que resulta de uma decretal, que determina: Aparecendo um acusador, depois
de contraído o matrimônio, que não veio a público quando o casamento tinha os seus bandos
publicados na Igreja, segundo o costume, podemos com razão perguntar se a sua voz acusadora deve
ser ouvida. A isso respondemos que, se no tempo da referida publicação quem impunha o matrimônio
estava fora da diocese, ou não pode essa publicação chegar ao seu conhecimento, por estar nesse
momento gravemente doente, ou por não estar no uso das suas faculdades, ou por não estar em
condições de compreender tais coisas por causa da sua idade pouco avançada ou em virtude de outro
obstáculo, deve-se lhe então ouvir a acusação. Do contrário deve ser, sem nenhuma dúvida, repelido
como suspeito; salvo se afirmar sob juramento, que soube mais tarde do impedimento, que denuncia, e
que não procede por malícia.

## Art. 11 — Se em tal causa, como nas outras se deve proceder à audição de testemunhas.
O undécimo discute-se assim. ─ Parece que em tal causa não se deve, como nas outras, proceder à
audição de testemunhas.

1. Pois, nas outras causas são trazidos a testificar os que estão acima de toda suspeita. Ora, aqui não se
admitem estranhos, embora acima de toda suspeita. Logo, etc.
2 . Demais. ─ As testemunhas suspeitas de ódio ou amor particular não se lhes aceita o testemunho.
Ora, os parentes, sobretudo, podem ser suspeitos de amor por uma parte e de ódio por outra. Logo, não
se lhes devem ouvir os testemunhos.

3. Demais. ─ O matrimônio goza do favor do direito mais que as outras causas, que recaem sobre coisas
puramente corpóreas. Ora, nessas ninguém pode ser ao mesmo tempo testemunha e acusador. Logo,
nem no matrimônio. Logo, não parece bem que nessa causa se proceda por audição de testemunhas.
Mas, em contrário. ─ Chamam-se testemunhas num processo a fim de poder o juiz formar o seu juízo
sobre o objeto dele. Ora, o juiz dever formar seu juízo, nesta causa, do mesmo modo por que forma em
todas as outras; pois, não deve dar sentença precipitada em matéria ainda não esclarecida. Logo, deve-
se proceder nesta causa, como nas outras, por audição de testemunhas.

SOLUÇÃO. ─ Nesta causa, como nas outras, é preciso tornar patente a verdade pela audição de
testemunhas. Contudo, esta como dizem os juristas, é susceptível de muitas regras particulares. Assim,
pode uma, mesma pessoa ser acusador e testemunha; não há necessidade de jurar que não se dirá
nenhuma calúnia, por ser um processo espiritual; os parentes podem ser admitidos a testificar; não se
observa com exatidão o processo judiciário, pois, feita a denúncia, o réu contumaz pode ser
excomungado, embora a lide não tenha ainda sido contestada; é aceito o testemunho por ouvir dizer; e
depois de publicados os nomes das testemunhas outras ainda podem ser convocadas. E tudo isto é feito
por se impedir o pecado, fácil de ser cometido num contrato de casamento.