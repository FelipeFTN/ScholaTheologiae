# Questão 87: Do conhecimento que terão os ressuscitados, no juízo, no
concernente aos méritos e aos deméritos.
Em seguida ao que fica dito, devemos tratar do que sucederá à ressurreição. E, primeiro, devemos
considerar sobre o conhecimento que terão os ressuscitados, no juízo, no concernente aos méritos e aos
deméritos. Segundo, do juízo universal em si mesmo, e do seu tempo e lugar. Terceiro, dos julgadores e
dos julgados. Quarto, da forma em que virá o juiz a julgar. Quinto, do estado do mundo e dos
ressuscitados depois do juízo.
Na primeira questão discutem-se três artigos:

## Art. 1 — Se depois da ressurreição cada qual conhecerá todos os pecados que cometeu.
O primeiro discute-se assim. ─ Parece que depois da ressurreição não conhecerá cada qual todos os
pecados que cometeu.

1. ─ Pois, tudo o conhecemos ou o recebemos de uma primeira impressão dos sentidos ou o tiramos do
tesouro da memória. Ora, os ressuscitados não terão a percepção sensível dos seus pecados, por serem
já passados e os sentidos só perceberem os objetos presentes. Além disso, muitos pecados já foram
esquecidos e não poderão mais ser extraídos do tesouro da memória. Logo, o ressuscitado não terá
conhecimento de todos os pecados que cometeu.

2. Demais. ─ Como diz o Mestre, nos chamados livros de consciência hão de ler-se os méritos de cada
um. Ora, num livro não se podem ler senão os sinais nele escritos. Ora, os pecados deixam certos sinais
na consciência, conforme a Glosa, e que outra cousa não são senão o reato ou a mácula. Logo, como a
muitos a mácula e o reato de diversos pecados lhes foram delidos pela graça, resulta que não poderão
ler na consciência todos os pecados cometidos. Donde a mesma conclusão anterior.

3. Demais. ─ Aumentando a causa aumenta o efeito. Ora, a causa, que nos faz deplorar os pecados
presentes à nossa memória, é a caridade. Mas, os santos ressuscitados tem caridade perfeita e, por isso,
deplorarão sumamente os pecados cometidos, sempre que à memória se lhes apresentem. O que não é
possível, porque não lhes haverá mais choro nem mais gritos, diz a Escritura. Logo, não terão presentes
à memória os pecados cometidos.

4. Demais. ─ Assim estão os ressurgidos condenados para o bem que em vida fizeram, como os bem-
aventurados para os pecados que em vida cometeram. Ora, os ressurgidos condenados, segundo
parece, não terão conhecimento dos bens que outras praticaram; do contrário, muito se lhes aliviaria a
pena. Logo, nem os bem-aventurados terão conhecimento dos pecados que cometeram.
Mas, em contrário, diz Agostinho, por um efeito especial do poder divino todos os seus pecados os terão
presentes à memória.

2. Demais. ─ Assim está o juízo humano para o testemunho externo como o juízo divino para o
testemunho da consciência, conforme aquilo da Escritura: O homem vê o que aparece, mas Deus
perscruta o coração. Mas nenhum juízo humano pode ser perfeito sem o depoimento de testemunhas
sobre tudo o que deve ser julgado. Logo, sendo o juízo divino perfeitíssimo, há de a consciência deponha
fielmente sobre o objeto do juízo. Ora, o juízo recairá sobre todas as obras boas e más, conforme aquilo
do Apóstolo: Importa que todos nós compareçamos diante do tribunal de Cristo, para que cada um
receba o galardão segundo o que tem feito, ou bom ou mau, estando no próprio corpo. Logo, é
necessário a consciência de cada um ter presente todas as obras que praticou, boas ou más.

SOLUÇÃO. ─ Diz o Apóstolo: Naquele dia o Senhor julgará dando testemunho a cada um a sua mesma
consciência e os pensamentos de dentro, que umas vezes os acusam e outras os defendem. Ora, em
todo juízo, é necessário a testemunha, o acusador e o defensor terem conhecimento do que vai ser
debatido em juízo. Logo, como esse juízo universal constituirá o objeto de todas as obras humanas,
necessariamente cada um terá conhecimento de tudo o que praticou. Por isso as consciências de todos
serão uns como livros contendo todas as obras praticadas, objeto do juízo, É desses livros que diz a
Escritura: Foram abertos os livros; e foi aberto outro livro, que é o da vida; e foram julgados os mortos
pelas causas que estavam escritas nos livros segundo as suas obras. E tais livros assim abertos, diz
Agostinho significarem os santos do Novo e do Velho Testamento, nos quais o Senhor exarou os
mandamentos que queria que fossem praticados. Por isso diz Ricardo Vitorino: Os corações deles serão
uns como decretos canônicos. Quanto ao livro da vida, de que se fala em seguida, significa as
consciências de cada um, chamadas no singular ─ um livro, porque um mesmo poder divino fará todos
terem presentes na memória as suas obras. E esse poder, que fará com que cada homem se represente
na memória os seus atos, se chama livro da vida. ─ Ou, os primeiros livros significam as consciências; o
segundo, a sentença do juiz já proferida na sua providência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora da memória se tenham dissipado muitos méritos
e muitos deméritos, nenhum deles contudo haverá que de certo modo não permaneça no seu efeito.
Pois os méritos cujo valor se conservou intacto se substituirão pelo prêmio que lhes for devido; e os que
foram reduzidos a nada permanecerão no reato de ingratidão, agravada pelo pecado cometido depois
de recebida a graça. Também e do mesmo modo, os deméritos não apagados pela penitência
permanecem no reato da pena que lhes é devida. E os delidos pela penitência permanecerão na
memória mesma dessa penitência, de que terão as almas conhecimento simultâneo com o dos outros
méritos. Por onde, todo homem terá meio de tornar as suas obras presentes à memória. ─ Contudo,
como diz Agostinho, esse efeito será principalmente devido ao poder divino.

RESPOSTA À SEGUNDA. ─ Nas consciências de todos perdurarão certos sinais das obras praticadas. Nem
é mister sejam esses sinais só constitutivos do reato, como do sobre dito resulta.

RESPOSTA À TERCEIRA. ─ Embora nesta vida a caridade seja a causa de deplorarmos os nossos pecados,
contudo os santos na pátria estarão de modo imersos na felicidade, que não poderão sofrer nenhuma
dor. Por isso não terão de deplorar pecados; ao contrário, se regozijarão com a providência divina, que
lh'os perdoou; assim como os anjos do céu se comprazem com a justiça divina, que permite que aqueles
a quem guardam abandonem ia graça e caiam no pecado; e contudo velam solicitamente pela salvação
deles.

RESPOSTA À QUARTA. ─ Os maus conhecerão todas as boas obras que praticaram, o que, longe de lhes
mitigar a pena, a aumenta; porque a dor máxima é ter perdido muitos bens. Donde o dizer Boécio que o
sumo gênero de infortúnio é ter sido feliz.

## Art. 2 — Se cada um poderá ler tudo o que outro tem na consciência.
O segundo discute-se assim. ─ Parece que não será possível a um ler tudo o que outro tem na
consciência.

1. ─ Pois, os ressuscitados não terão um conhecimento mais puro que o dos anjos, com os quais lhes é
prometida a igualdade, como o diz o Evangelho. Ora, os anjos não podem ler no coração uns dos outros
o que lhes depende do livre arbítrio; para terem disso conhecimento, é preciso que lhes seja revelado
pela palavra. Logo, os ressuscitados não poderão ler o que os outros tem na consciência.

2. Demais. ─ Tudo o que conhecemos o é em si mesmo ou na sua causa ou no seu efeito. Ora, os méritos
ou deméritos que alguém tem na consciência não pode outro conhecê-los em si mesmos, porque só
Deus penetra os corações e lhes perscruta os segredos. Nem na sua causa, porque nem todos verão a
Deus, que só pode influir sobre o afeto, donde procedem os méritos, ou os deméritos. Enfim nem no
efeito, porque muitos deméritos haverá de que nenhum efeito há de restar, delidos que foram
totalmente pela penitência. Logo, não poderá um ler tudo o que esta na consciência de outro.

3. Demais. ─ Crisóstomo diz, segundo o cita o Mestre das Sentenças: Se neste mundo tiveres na
memória os teus pecados, se os confessares presentemente na presença de Deus, se pedires que te
sejam perdoados, mais depressa os deliras. Se porém os esqueceres, então deles terás que te recordar
contra a vontade quando sei tornarem públicos e forem manifestos à vista de todos teus amigos e
inimigos, e dos santos anjos. Donde se conclui que preteriu a confissão. Logo, os pecados confessados
não se tornarão públicos.

4. Demais. ─ Será uma consolação saber alguém que tem muitos companheiros no pecado e, por isso,
menos se envergonhar dele. Ora, o pecador, cujos pecados fossem conhecidos de outrem, menos se
envergonharia deles. O que não é admissível. Logo, nem todos conhecerão os pecados de todos.
Mas, em contrário. ─ Aquilo do Apóstolo ─ Porá às claras o que se acha escondido ─ diz a Glosa: As obras
e os pensamentos, bons e maus, serão então públicos e conhecidos de todos.

2. Demais. ─ Os pecados passados de todos os bons serão igualmente perdoados. Ora, conhecemos os
pecados de certos santos, como Madalena, Pedro e David. Logo e pela mesma razão serão conhecidos
os pecados dos outros eleitos. E muito mais, dos condenados.

SOLUÇÃO. ─ No último dia e no juízo universal é necessário a justiça divina manifestar-se a todos, com
evidência, ela que nesta vida fica muitas vezes oculta. Ora, uma sentença que premeia ou castiga não
pode ser justa, senão proferida de acordo com os méritos ou deméritos. Por onde, assim como o juiz e o
seu assessor devem conhecer o mérito da causa, para poderem proferir uma sentença justa, assim
também é preciso para uma sentença se manifestar como tal, que todos os que dela tiverem
conhecimento conheçam também os méritos que a fundamentam. Por onde, como cada um conhecerá
o seu prêmio e a sua condenação do mesmo modo por que serão conhecidos de todos, assim também,
do mesmo modo por que cada um trará à memória os seus méritos e deméritos também conhecerá os
méritos e os deméritos alheios. ─ E esta é a opinião mais provável e comum, embora o Mestre diga o
contrário, i. é, que os pecados já delidos pela penitência não se publicarão aos outros, no juízo. Mas de
aqui resultaria que também não seria perfeitamente conhecida a penitência desses pecados, o que seria
muito em detrimento da glória dos santos e da glória de Deus, que tão misericordiosamente lhes
perdoou.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Todos os méritos ou deméritos precedentes contribuirão
para aumentar a glória ou a miséria do ressuscitado. Será portanto do que exteriormente se vir que se
poderá deduzir tudo o que esta nas consciências. Sobretudo se o poder divino cooperar para que a justa
sentença do juiz seja conhecida de todos.

RESPOSTA À SEGUNDA. ─ Os méritos ou os deméritos poderão ser manifestados aos outros nos seus
defeitos, como do sobredito se colhe. Ou ainda em si mesmos, por permissão divina, embora o intelecto
criado não seja capaz de tanto.

RESPOSTA À TERCEIRA. ─ A publicação dos pecados para ignomínia do pecador é efeito da negligência
cometida na omissão da confissão. Mas o serem revelados os pecados dos santos não poderá lhes
redundar em pejo e vergonha, assim como não reverte em confusão de Maria Madalena serem
narrados publicamente na Igreja os seus pecados. Porque a vergonha é o temor da desonra, como diz
Damasceno, o que não poderá ter lugar com os bem-aventurados. Essa publicidade lhes redundará, ao
contrário, em grande glória, por causa da penitência que fizeram, assim como um confessor aprova
quem corajosamente confessa graves crimes. Mas se diz que os pecados foram delidos por que Deus
não mais deles se lembra para os punir.

RESPOSTA À QUARTA. ─ O fato de um pecador conhecer os pecados dos outros em nada lhe diminuirá a
confusão; ao contrário, a aumentará fazendo-o pesar melhor o seu vitupério pelo comparar com o
alheio. E se isso é causa de diminuir a confusão é porque a vergonha leva em conta a apreciação
humana, que vai perdendo da sua importância com o costume. Mas, no juízo final a confusão depende
da apreciação de Deus, fundada no conhecimento exato de cada pecado, de um só pecador ou de
muitos.

## Art. 3 — Se todos os méritos ou deméritos, próprios e alheios, serão conhecidos num rápido olhar.
O terceiro discute-se assim. ─ Parece que nem todos os méritos ou deméritos, próprios e alheios,
serão conhecidos num rápido olhar.

1. Pois, o que consideramos separadamente não podemos ver de um só olhar. Ora, os condenados
considerarão os seus pecados cada um em separado e os deplorarão. Por isso exclamarão: De que nos
aproveitou a nós a soberba? etc. Logo, nem tudo verão de um só olhar.

2. Demais. ─ O Filósofo ensina, que não podemos inteligir muitas cousas ao mesmo tempo. Ora, os
méritos e os deméritos, próprios e alheios, não poderão ser vistos sem serem compreendidos. Logo, não
poderão todos ser vistos ao mesmo tempo.

3. Demais. ─ O intelecto dos condenados, depois da ressurreição, não será mais penetrante do que o dos
bons anjos, quanto ao conhecimento natural com que conhecem as cousas por meio de idéias inatas.
Ora, com esse conhecimento os anjos não podem ver várias cousas simultaneamente. Logo, nem no
juízo poderão os condenados ver simultaneamente todas as obras.
Mas, em contrário. ─ Aquilo de Job ─ Serão cobertos de confusão ─ diz a Glosa: A vista do juiz, todos os
males surgirão aos olhos da alma. Ora, verão o juiz subitamente. Logo, também assim os males que
cometeram. E pela mesma razão todos os outros.

2. Demais. ─ Agostinho rejeita a hipótese de ser lido no juízo um livro material, onde estarão escritas as
ações de cada um, porque ninguém poderia avaliar o tamanho desse livro nem o tempo necessário para
o ler. Mas semelhantemente, também ninguém poderia avaliar o tempo necessário para alguém pesar
todos os méritos e deméritos, próprios e alheios, se os visse a todos simultaneamente. Logo, devemos
admitir que cada um verá tudo ao mesmo tempo.

SOLUÇÃO. ─ Nesta matéria duas são as opiniões.
Uns dizem que cada um verá num instante todos os méritos e deméritos, próprios e alheios. ─ O que dos
bem-aventurados poderemos facilmente crê-lo, porque verão tudo no Verbo e assim não é impossível
verem muitas coisas simultaneamente. Mas é difícil admitir essa explicação para os condenados cujo
intelecto não foi elevado a ponto de poderem ver a Deus e nele todas as cousas.
Por isso outros pretendem que os maus verão simultaneamente todos os gêneros dos pecados que
cometeram, e isso basta para a acusação ou absolvição que deve resultar do juízo, Mas não verão tudo
simultaneamente, considerada cada cousa em particular. ─ Mas também esta explicação não concorda
com as palavras de Agostinho, quando diz que enumerarão todas as cousas num só ato da inteligência;
pois, o que se conhece genericamente não se enumera.
Podemos por isso escolher uma via média: conhecerão cada cousa em particular, mas não num instante,
senão num tempo brevíssimo, com a coadjuvação do poder divino. E tal o diz Agostinho, no mesmo
lugar, quando afirma que as cousas eles as enumerarão com espantosa celeridade. Nem há nisso
impossível, porque em qualquer tempo, por pequeno que seja, há infinitos instantes em potência.
Donde se deduzem claras as respostas às objeções de ambas as partes.