# Questão 19: Dos ministros das chaves.
Em seguida devemos tratar dos ministros das chaves e do uso delas.
E nesta questão discutem-se seis artigos:

## Art. 1 — Se o sacerdote da Lei Velha tinha o poder das chaves.
O primeiro discute-se assim. — Parece que o sacerdote da Lei Velha tinha o poder das chaves.

1. Pois, a chave é uma sequela da ordem. Ora, os sacerdotes da Lei Velha, como tais, tinham a ordem.
Logo, também tinham o poder das chaves.

2. Demais. — Como o Mestre disse antes, duas são as chaves: a ciência do discernimento e o poder de
julgar. Ora, os sacerdotes da Lei Velha tinham a autoridade para ambos. Logo, tinham o poder das
chaves.

3. Demais. — Os sacerdotes da Lei Velha tinham um certo poder sobre o demais povo. Não temporal,
porque então o poder real não se distinguiria do sacerdotal. Logo, o espiritual, que é o poder das
chaves. Portanto, tinham este poder.
Mas, em contrário. — As chaves servem para abrir o reino dos céus, que não podia ser aberto antes da
paixão de Cristo. Logo, o sacerdote da Lei Velha não tinha o poder das chaves.

2. Demais. — Os sacerdotes da Lei Velha não conferiam a graça. Ora, as portas do reino celeste não
podem abrir-se senão pela graça. Logo, não podiam abrir-se por esses sacramentos. E assim, também o
sacerdote, ministro deles, não tinha as chaves do reino dos céus.

SOLUÇÃO. — Certos disseram, que os sacerdotes da Lei Velha tinham as chaves, porque lhes foi
cometido impor penas pelos delitos, como lemos na Escritura — o que implica o poder das chaves; este
porém era então incompleto, ao passo que agora, por Cristo, os sacerdotes da Lei Nova o têm perfeito.
— Mas isto vai contra a intenção do Apóstolo, quando diz que o sacerdócio de Cristo é mais excelente
que o da Lei, porque Cristo está presente como pontífice dos bens vindouros, e entrou no tabernáculo
celeste pelo seu próprio sangue; tabernáculo não feito por mão de homem, ao qual introduziam os
sacerdotes da Lei Velha, por sangue de bodes e de bezerros. Por onde é claro que o poder desses
sacerdotes não se estendia às realidades celestes, mas às figuras delas. — Por isso, segundo outros,
devemos pensar que não tinham as chaves, senão as figuras delas.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As chaves do reino celeste são dadas com o sacerdócio,
pelo qual somos introduzidos nos céus; ora, tal não era a ordem do sacerdócio Levítico. Por isso os
sacerdotes da Lei Velha não tinham as chaves do céu, mas só as do tabernáculo terrestre.

RESPOSTA À SEGUNDA. — Os sacerdotes da Lei Velha tinham a autoridade de discernir e de julgar; mas
não que fosse o homem julgado por eles admitido no céu, mas só a figura das coisas celestes.

RESPOSTA À TERCEIRA. — Tinham o poder espiritual porque pelos sacramentos da Lei os homens se
purificavam, não das culpas, mas de certas irregularidades, a fim de se lhes abrir aos purificados a
entrada do tabernáculo feito por mão de homem.

## Art. 2 — Se Cristo tinha o poder das chaves.
O segundo discute-se assim. — Parece que Cristo não tinha o poder das chaves.

1. — Pois, o poder das chaves resulta do caráter da ordem. Ora, Cristo não tinha esse caráter. Logo, não
tinha o poder das chaves.

2. Demais. — Cristo tinha nos sacramentos o poder de excelência, de modo que podia conferir o efeito
deles sem os sacramentos. Ora, as chaves são um sacramental. Logo, não precisava delas. E assim, teria
inutilmente esse poder.
Mas, em contrário, a Escritura: Isto diz o que tem a chave de David, etc.

SOLUÇÃO. — O poder de agir reside ao mesmo tempo no instrumento e no agente principal; mas não
do mesmo modo, porque no agente principal reside mais perfeitamente. Ora, o poder das chaves, que
nós temos, assim como o de conferir os outros sacramentos é um poder instrumental. Mas Cristo o tem
como o agente principal da nossa salvação; pela sua autoridade, como Deus; e pelo seu mérito, como
homem. Ora, a chave, por sua natureza, exprime o poder de abrir e de fechar, quer quem abra o faça
como agente principal, quer como ministro. Por onde. Cristo deve ter o poder das chaves; mas de modo
mais elevado pelo qual o tem os seus ministros. Por isso se diz que tem a chave da excelência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O caráter, por natureza, significa uma impressão
recebida de outrem. Por isso o poder das chaves, que nós recebemos de Cristo, resulta do caráter com
que com Cristo nos conformamos. Ora, Cristo tem o referido poder não em virtude do caráter, mas
como agente principal.

RESPOSTA À SEGUNDA. — Essa chave que Cristo tinha não era sacramental, mas princípio da chave
sacramental.

## Art. 3 — Se só os sacerdotes têm o poder elas chaves.
O terceiro discute-se assim. — Parece que não só os sacerdotes têm o poder das chaves.

1. — Pois, diz Isidoro, que o ostiário deve julgar entre os bons e os maus, recebendo aqueles e
rejeitando estes. Ora, esta é a definição das chaves, como do sobre dito resulta. Logo, não só os
sacerdotes, mas também os ostiários, tem o poder das chaves.

2. Demais. — O poder das chaves é dado aos sacerdotes quando são ungidos por Deus. Ora, os reis
também tem de Deus o poder sobre o povo fiel, e são santificados pela unção. Logo, nem só os
sacerdotes tem o poder das chaves.

3. Demais. — O sacerdócio é uma ordem que cabe só a uma pessoa em particular. Ora, às vezes é toda
uma congregação que tem o poder das chaves; pois, certos capítulos podem impor a excomunhão, o
que pertence ao poder das chaves. Logo, nem só os sacerdotes tem o poder das chaves.

4. Demais. — A mulher, não podendo ensinar nas igrejas, como o afirma o Apóstolo, não pode também
receber a ordem sacerdotal. Ora, certas mulheres tem o poder das chaves; assim as abadessas tem
poder espiritual sobre as suas súditas. Logo, nem só os sacerdotes tem o poder das chaves.
Mas, em contrário, diz Ambrósio: este direito, isto é, de ligar e absolver, é permitido só aos sacerdotes.

2. Demais, — O poder das chaves estabelece um mediador entre o povo e Deus. Ora, isso cabe somente
aos sacerdotes, constituídos naquelas causas que tocam a Deus, para que ofereçam dons e sacrifícios
pelos pecados, no dizer do Apóstolo. Logo, só os sacerdotes tem o poder das chaves.

SOLUÇÃO. — Duplo é o poder das chaves, — Um tem por fim imediato de remover os obstáculos à
entrada no céu, pela remissão dos pecados, E este se denomina chave da ordem, que só os sacerdotes
tem, porque só eles se ordenam ao povo naquelas coisas que tocam diretamente a Deus. — Outra é a
chave que não tem por objeto direto abrir o céu, mas só mediante a Igreja militante, que nos torna
possível entrar nele; pois, por esse poder das chaves somos excluídos do consórcio da Igreja militante,
ou nele admitidos, pela excomunhão e pela absolvição. E essa se chama a chave da jurisdição no foro
das causas. Por onde, também os não sacerdotes podem tê-la; assim, os arquidiáconos, os prelados
eleitos e outros, que podem excomungar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Os ostiários tem o poder das chaves, a fim de guardar as
coisas contidas no templo material; e podem julgar os que devem ser excluídos desse templo ou nele
admitidos. Não que julguem por natureza própria, quais sejam os dignos ou os indignos, mas devem
cumprir as decisões dos sacerdotes, de modo que sejam assim de certo modo executores do poder
sacerdotal.

RESPOSTA À SEGUNDA. — Os reis, não tendo nenhum poder na ordem espiritual, não recebem a chave
do reino celeste; mas o poder deles é puramente temporal, o qual também não pode provir senão de
Deus, segundo o Apóstolo. Nem recebem unção que lhes conferisse qualquer ordem sacra; o serem
ungidos significa apenas que a excelência do poder deles vem de Cristo, para reinarem, sujeitos a Cristo,
sobre o povo cristão.

RESPOSTA À TERCEIRA. — Assim como na ordem política o governo pode ser confiado ora a um só juiz,
como na monarquia: ora a muitos constituídos, mesmo por igual, em diversos oficias, assim também a
jurisdição espiritual pode ser exercida por um só, como pelo bispo, e por vários ao mesmo tempo, como
pelo capitulo. E assim todos têm simultaneamente a chave da jurisdição, mas não a da ordem.

RESPOSTA À QUARTA. — A mulher, segundo o Apóstolo, vive em estado de sujeição. Por isso não pode
exercer nenhuma jurisdição espiritual; pois, o próprio Filósofo também diz que a ordem da cidade se
corrompe quando o poder vem a cair em mãos de mulher. Eis porque ela não tem a chave da ordem
nem a da jurisdição. É-lhes porém cometido um certo uso das chaves, de modo que possa governar
outras mulheres, por causa do perigo que podia advir de homens conviverem com elas.

## Art. 4 — Se também os varões santos não sacerdotes tem o uso das chaves.
O quarto discute-se assim. — Parece que também os varões santos não sacerdotes tem o uso das
chaves.

1. — Pois, a absolvição e a ligação, feitas pelas chaves, tiram a sua eficácia do mérito da paixão de Cristo.
Ora, aqueles por excelência se conformam com a paixão de Cristo que pela paciência e pela prática das
outras virtudes sofrem com ele. Logo, parece que mesmo sem a ordem sacerdotal, podem ligar e
absolver.

2. Demais. — O Apóstolo diz: Sem nenhuma contrição, o que é inferior recebe a bênção do superior.
Ora, na ordem espiritual, segundo Agostinho, ser superior é ser melhor. Logo, os melhores, isto é, os
que tem mais caridade podem abençoar os outros, absolvendo-os. Donde, a mesma conclusão anterior.
Mas, em contrário. — Quem tem o poder também tem a ação, segundo o Filósofo. Ora, as chaves, que
são o poder espiritual, só cabem aos sacerdotes. Logo, só os sacerdotes podem ter o uso delas.

SOLUÇÃO. — O agente essencial e o instrumental diferem em que este não infunde no efeito a sua
semelhança, mas a do agente principal, o qual, sim, nele infunde a sua semelhança. Por onde, é agente
principal o que tem uma forma que pode transfundir em outro; não constitui isso porém o agente
instrumental, mas o ser aplicado pelo agente principal para produzir um certo efeito. Ora, como no
exercício do poder das chaves o agente principal é Cristo, pela sua autoridade, como Deus e pelo seu
mérito, como homem, resulta da plenitude mesma da divina bondade e da perfeição da sua graça, que
pode exercer o poder das chaves. Mas, nenhum outro homem pode exercer esse poder como agente
principal; pois nenhum pode dar a outrem a graça, pela qual se remitem os pecados, nem merecer
suficientemente. Por isso não pode agir senão como agente instrumental. Assim, aquele que recebe o
efeito do poder das chaves, não se assemelha a quem usa desse poder, mas a Cristo. E por isso, seja qual
for a graça que alguém tenha, não pode alcançar o efeito das chaves; se a ela não for chamado na
qualidade de ministro mediante a recepção da ordem.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Assim como entre o instrumento e o efeito não é
necessária a semelhança por uma conveniência formal, mas segundo uma proporção entre o
instrumento e o efeito, assim também nem entre o instrumento e o agente principal. E tal semelhança
existe entre os varões santos e Cristo padecente; mas essa não lhes confere o poder das chaves.

RESPOSTA À SEGUNDA. — Embora um simples homem não possa merecer a outro a graça de condigno,
contudo o mérito de um pode cooperar para a salvação de outro. Donde uma dupla bênção. — Uma,
desse homem, puro e simples, como merecedor, pelo seu ato próprio. Essa qualquer varão santo, em
quem Cristo habita pela graça, pode conferi-la; e requer dum tal varão maior bondade, pelo menos
enquanto confere a bênção. — Outra é a bênção pela qual quem a dá não age senão como instrumento,
e em virtude do mérito de Cristo. E essa implica superioridade em ordem, mas não em virtude.

## Art. 5 — Se os maus sacerdotes têm o uso das chaves.
O quinto discute-se assim. — Parece que os maus sacerdotes não têm o uso das chaves.

1. — Pois, como lemos no Evangelho, antes de dar aos apóstolos o uso das chaves, Cristo lhes conferiu o
Espírito Santo. Ora, os maus não tem o Espírito Santo. Logo, não tem o uso das chaves.

2. Demais. — Nenhum rei sábio comete a um inimigo a dispensação do seu tesouro. Ora, o uso das
chaves consiste na dispensação do tesouro do Rei celeste, que é a sabedoria mesma. Logo, os maus, que
pelo pecado se lhe tornaram inimigos, não tem o uso das chaves.

3. Demais. — Agostinho diz que o sacramento da graça Deus o confere também pelos maus; mas a
graça, só por si mesmo ou pelos seus santos; daí o perdoar por si mesmo o pecado, ou pelos membros
da Pomba (da Igreja). Ora, o perdão dos pecados é o uso das chaves. Logo, os pecadores, que não são
membros da Pomba, não têm o uso das chaves.

4. Demais. — A intercessão do mau sacerdote não tem nenhuma eficácia para reconciliar; porque,
segundo Gregório, buscar, como intercessor, quem desagrada, é provocar ainda mais a cólera da pessoa
ofendida. Ora, o uso das chaves supõe de certo modo a intercessão, como o demonstra a forma da
absolvição. Logo, os maus sacerdotes não têm um uso eficaz das chaves.
Mas, em contrário. — Ninguém pode saber se outrem está em estado de graça. Se portanto ninguém
pudesse usar das chaves para absolver, senão quem estivesse em estado de graça, ninguém poderia
saber se foi absolvido; o que é inadmissível.

2. Demais. — A iniquidade do ministro não pode anular a liberalidade do senhor. Ora, o sacerdote é só
ministro. Logo, não pode com a sua malícia privar-nos do dom que Deus nos faz por ele.

SOLUÇÃO. — Assim como participar da forma, que deve ser infundida no efeito, não é o que faz o
instrumento; assim, nem a privação dessa forma tem o uso do instrumento. Por onde, agindo o homem
apenas como instrumento no uso das chaves, embora esteja privado da graça pelo pecado, pela qual se
faz a remissão dele, de nenhum modo porém fica privado do uso das chaves.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O dom do Espírito Santo é necessário para o uso das
chaves; não porque sem ele não possa haver esse uso; mas porque, nessas condições, quem delas usa
mal, embora, sujeitando-se a elas, consiga-lhes o efeito.

RESPOSTA À SEGUNDA. — Um rei terreno pode ser defraudado no seu tesouro e enganado; por isso
não lhe confia a dispensação a um inimigo. Mas o Rei celeste não pode ser defraudado. Pois, tudo lhe
redunda em honra, mesmo o usar alguém mal das chaves; porque sabe fazer nascer o bem, do mal, e
fazer muitos bens mesmo por meio dos maus. Por onde, o símile não colhe.

RESPOSTA À TERCEIRA. Agostinho se refere à remissão dos pecados, enquanto os varões santos para ela
cooperam, não em virtude das chaves mas pelo mérito ex congruo. Por isso diz que mesmo pelos maus
Deus confere os sacramentos; e entre os outros sacramentos também a absolvição deve ser computada,
ela que é o uso das chaves. Mas, pelos membros da Pomba, isto é, pelos varões santos, obra a remissão
dos pecados, pelos remitir por intercessão deles. — Ou podemos dizer que pelos membros da Pomba
entende todos os que não estão separados da Igreja. Pois, os que deles recebem os sacramentos
alcançam a graça. Não porém os que os recebem dos separados da Igreja, pois, pelo fazerem pecam;
exceto o batismo, que em caso de necessidade é lícito receber mesmo de um excomungado.

RESPOSTA À QUARTA. — A intercessão, exercida por um sacerdote mau e pela sua pessoa própria, não
tem eficácia; tem-na porém o que exerce como ministro da Igreja e pelo mérito de Cristo. Mas, de
ambos os modos deve a intercessão do sacerdote ser útil ao povo que lhe está sujeito.

## Art. 6 — Se os cismáticos, os heréticos, os excomungados, os suspensos e os degradados têm o uso das chaves.
O sexto discute-se assim. — Parece que os cismáticos, os heréticos, os excomungados, os suspensos e
os degradados têm o uso das chaves.

1. — Pois, assim como o poder das chaves depende da ordem, assim também o poder de consagrar.
Ora, os sacerdotes não podem perder o uso do poder de consagrar; pois, o que consagraram
consagrado esta, mesmo que pequem os que o fizeram. Logo, também não podem perder o uso das
chaves.

2. Demais. — Toda potência espiritual ativa, de quem tem o uso do livre arbítrio pode exercer-se
quando quiser. Ora, nos supra-referidos subsiste o poder das chaves; pois, como não é este dado senão
com a ordem, se o tivessem perdido, seria necessário reordená-los quando voltassem ao grêmio da
Igreja. Logo, sendo uma potência ativa, podem exercê-la quando quiserem.

3. Demais. — A graça espiritual sofre maior impedimento da culpa que da pena. Ora, a ex-comunhão, a
suspensão, a degradação não são nenhumas penas. Logo, como pela culpa não se perde o uso das
chaves, parece que nem pelas três razões que se acabam de dar.
Mas, em contrário. — Agostinho diz, que a caridade da Igreja perdoa os pecados. Ora, a caridade é a que
obra a união da Igreja. Logo, como os supra-referidos estão fora da união da Igreja, parece que não têm
o uso das chaves para perdoar os pecados.

2. Demais. — Ninguém pode ser absolvido do pecado por um ato que também não pudesse ser
praticado, sem pecado. Ora, se um dos referidos desse a absolvição dos pecados a quem lh'a pedisse,
iria contra o preceito da Igreja. Logo, por eles não pode ser absolvido. Donde se conclui o mesmo que
antes.

SOLUÇÃO. — Em todos os casos referidos subsiste na sua essência o poder das chaves; mas o uso fica
impedido por falta de matéria. Pois, como quem exerce o poder das chaves deve ser superior àquele
sobre quem o exerce, conforme dissemos, a matéria própria sobre quem se exerce o uso das chaves é a
pessoa a ele sujeita. E como pela condenação da Igreja um esta sujeito a outro, por isso também pelos
superiores eclesiásticos pode ser desligado da obediência a alguém, quem a ele estava sujeito. Por onde,
a Igreja exclui os heréticos e os cismáticos e outros tais, desligando-lhes os súditos, da obediência, total
ou parcialmente; e por ficarem assim privados do exercício da ordem não podem ter o uso das chaves.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A matéria do sacramento da Eucaristia, sobre a qual o
sacerdote exerce o seu poder, não é o homem, mas o pão de trigo; e no batismo, o homem como tal.
Por onde, assim como se privasse o herético do pão de trigo, não poderia ele consagrar, assim tirada ao
prelado a sua prelatura, não poderá absolver. Pode porém batizar e consagrar, embora para sua
condenação.

RESPOSTA À SEGUNDA. — A proposição é verdadeira, quando não falta a matéria, como se dá no caso
vertente.

RESPOSTA À TERCEIRA. — Não é da culpa em si mesma que resulta a privação da matéria, como o
resultaria da pena. Por isso a pena não impede, por contrariedade, a produção do efeito, mas pela razão
aduzida.