# Questão 70: Da qualidade da alma separada do corpo, e da pena do fogo corpóreo, que lhe é infligida.
Em seguida devemos tratar da qualidade geral da alma separada do corpo, e da pena do fogo corpóreo
que lhe é infligida.
E nesta questão discutem-se três artigos:

## Art. 1 — Se na alma separada subsistem as potências sensitivas.
O primeiro discute-se assim. ─ Parece que na alma separada subsistem as potências sensitivas.

1. - Pois, Agostinho diz: A alma, ao separar-se do corpo, leva tudo consigo ─ os sentidos, a imaginação, a
razão, o intelecto, a inteligência, o concupiscível e o irascível. Ora, os sentidos e a imaginação, a
potência irascível e a concupiscível são potências da alma. Logo, na alma separada subsistem as
potências sensitivas.

2. Demais. ─ Agostinho diz: Cremos que só o homem tem alma substancial, que continua a viver
separado do corpo e conserva vivazes os sentidos e o engenho. Logo, a alma separada do corpo
conserva as suas potências sensitivas.

3. Demais. ─ As potências da alma ou nela existem substancialmente, como certos dizem, ou pelo menos
são propriedades naturais dela. Ora, o que existe essencialmente num ser não pode separar-se dele;
nem é possível um sujeito perder as suas propriedades naturais. Logo, não pode a alma, separada do
corpo, perder nenhuma das suas potências.

4. Demais. ─ Não tem a sua total integridade o ser a que falta uma parte. Ora, as potências da alma se
consideram partes dela. Se, pois, a alma perder, depois de separada do corpo, alguma das suas partes,
não subsistirá na sua integridade, depois da morte. O que é inadmissível.

5. Demais. ─ As potências da alma concorrem mais para o mérito, do que o corpo; este é apenas o
instrumento da ação, ao passo que a alma é o princípio do agir. Ora, necessariamente, há de o corpo ser
premiado junto com a alma, pois com ela cooperou para o mérito. Logo e com muito maior razão, hão
de as potências da alma ser premiadas simultaneamente com ela. Portanto, não nas perde a alma
separada.

6. Demais. ─ Se a alma, separada do corpo, perde a potência sensitiva, há de por força essa faculdade
ser reduzida ao nada; pois, não se pode dizer que se resolva numa determinada matéria, porque não
tem matéria nenhuma como parte de si. Ora, o ser totalmente reduzido ao nada não pode voltar à
existência, de modo a vir a ser numericamente o mesmo que antes. Logo, a alma não terá, na
ressurreição, a mesma potência sensitiva que antes tinha. Ora, segundo o Filósofo, assim está a alma
para o corpo como as potências da alma para as partes do corpo ─ tal a vista, para os olhos. Mas, não
sendo a alma, que voltará a unir-se ao corpo, numericamente a mesma de antes, o homem não será já o
mesmo numericamente, que antes fora. Portanto, já não teria os mesmos olhos que teve, se a potência
visual não é a mesma de antes. ─ Pela mesma razão, parte nenhuma ressurgirá numericamente a
mesma. Por consequência, o homem ressurrecto não será, na sua totalidade, o mesmo de antes. Logo,
não é possível a alma separada perder as suas potências sensitivas.

7. Demais. ─ Se as potências sensitivas desaparecessem com a disparição do corpo, também deviam,
enfraquecendo-se ele, enfraquecerem-se. Ora, tal não se dá; pois, como ensina Aristóteles, se um velho
recobrasse a vista de um moço, enxergaria absolutamente como este. Logo, nem com a disparição do
corpo hão de desaparecer as potências sensitivas.
Mas, em contrário, Agostinho diz: Só de duas substâncias consta o homem ─ alma e corpo; a alma
racional e o corpo sensível. Ora, as potências sensitivas pertencem ao corpo. Logo, desaparecido o
corpo, já não subsistem na alma as potências sensitivas.

2. Demais. ─ O Filósofo, tratando da separação da alma, diz: Quanto a saber se alguma cousa subsiste
depois da dissolução do composto, devemos examiná-lo. Pois, para certos seres nada a isso se opõe. A
alma, p. ex., esta nesse caso; não a alma inteira, mas o intelecto, porque para a alma inteira isso é talvez
impassível. Donde se conclui que a alma não se separa totalmente do corpo, mas só as potências da
alma intelectiva, não as da sensitiva ou vegetativa.

3. Demais. ─ O Filósofo diz, falando do intelecto: O intelecto se separa do corpo como o incorruptível, do
corruptível. Quanto às outras partes da alma, é claro pelo que dissemos, que não são separáveis, como
afirmam certos. Logo, as potências sensitivas não subsistem na alma separada.

SOLUÇÃO. ─ Nesta matéria variam as opiniões. Assim, uns, julgando estarem todas as potências na
alma, ao modo por que o calor está no corpo, ensinam que a alma, separada do corpo, leva consigo
todas as suas potências. Pois, se alguma lhe faltasse, ficaria necessariamente alterada nas suas
propriedades naturais que, enquanto subsiste o seu sujeito, não podem variar. ─ Mas essa opinião é
falsa. Pois, sendo em virtude da potência, que dizemos agirem ou sofrerem os seres dela dotados; e,
sendo o mesmo ser o que pode agir e sofrer a ação, resulta necessariamente que a potência há de
pertencer ao sujeito, que é agente ou paciente. Por isso o Filósofo diz, que a potência pertence ao
mesmo ser a que pertence a ação. Ora, como é manifesto, certas operações, de que as potências da
alma são os princípios, não procedem dela, propriamente falando, mas do composto; pois, não se
exercem senão mediante o corpo, como ver, ouvir e semelhantes. Por onde e necessariamente, essas
potências tem no composto o seu sujeito; mas procedem da alma como do princípio influente, assim
como a forma é o princípio das propriedades do composto. Outras operações porém a alma as exerce
sem a mediação de nenhum órgão corpóreo, como compreender, raciocinar e querer. Por onde, sendo
tais atos próprios da alma, as potências, que são os princípios delas, pertencerão à alma não só como o
princípio, mas ainda como o sujeito delas. Ora, permanecendo o sujeito próprio, necessariamente hão
de subsistir a paixões próprias dele; e desaparecido ele, também estas desaparecerão. Portanto e
necessariamente, aquelas potências que não precisam, para agir, de usar de um órgão corpóreo, hão de
subsistir na alma separada. Ao contrário, aquelas que só se exercem mediante tal órgão, desaparecerão
com a disparição do corpo. E tais são todas as potências pertencentes à alma sensível e vegetativa.
Por isso certos distinguem duas potências da alma sensível. Umas são atos dos órgãos, afluem da alma
para o corpo, e essas desaparecem com ele. Outras, origens das primeiras, tem sua sede na alma,
fazem-na tornar o corpo capaz de ver, de ouvir e de atos semelhantes; e essas potências originais
subsistem na alma separada. ─ Mas esta opinião é inadmissível. Porque a alma é, pela sua essência
mesma, e não mediante quaisquer potências, a origem das potências, que são os atos dos órgãos; assim
como qualquer forma, por isso mesmo que pela sua essência informa a matéria, é a origem das
propriedades naturalmente resultantes do composto. Portanto, se devêssemos admitir na alma outras
potências, mediante as quais as que dão aos órgãos a sua perfeição de fluíssem da essência dela, pela
mesma razão devíamos admitir ainda outras, mediante as quais da essência da alma de fluíssem essas
potências médias, e assim ao infinito. Se, pois, devemos parar em algum ponto, melhor será pararmos
no primeiro.
Por isso outros dizem, que as potências sensitivas e as outras semelhantes não subsistem na alma
separada, a não ser ao modo pelo qual os principiados subsistem nos seus princípios como na raiz. Pois,
a alma separada conserva o poder de influir de novo nas outras potências, se de novo vier a unir-se ao
corpo; nem é necessário seja esse poder nada de acrescentado à essência, como se disse. E essa opinião
é mais racional.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ As palavras citadas de Agostinho devem entender-se
como significando, que a alma leva consigo e atualmente certas dessas potências, a saber, a inteligência
e o intelecto; outras, radicalmente, como dissemos.

RESPOSTA À SEGUNDA. ─ Os sentidos que acompanham a alma, não são os sentidos externos atuais,
mas os internos, pertencentes à parte intelectiva; pois, o intelecto às vezes é chamado sentido, como
vemos em Basílio e no Filósofo. ─ Ou, se o entendermos dos sentidos externos, devemos responder o
mesmo que à primeira objeção.

RESPOSTA À TERCEIRA. ─ Como do sobredito resulta, as potências sensitivas não estão para a alma
como as paixões naturais para o seu sujeito, mas como para a sua origem. Por isso a objeção não colhe.

RESPOSTA À QUARTA. ─ As potências da alma não se consideram como partes integrantes dela senão
como partes potenciais. Ora, a natureza da alma como um todo é tal, que a virtude do todo se acha
integralmente numa das partes e incompleta, nas outras. Assim, a virtude da alma está toda na potência
intelectiva, e parcialmente nas outras potências. Por onde, como na alma separada permanecem as
potências da parte intelectiva, íntegra continuará ela e não diminuída, embora as potências sensitivas
não permaneçam em ato, assim como o poder do rei fica diminuído, se morre o preposto dele
participante.

RESPOSTA À QUINTA. ─ O corpo contribui para o mérito, como parte essencial do homem que merece.
Ora, assim, não cooperam as potências sensitivas, por pertencerem ao gênero dos acidentes. Logo, o
símil não colhe.

RESPOSTA À SEXTA. ─ As potências sensitivas da alma não se consideram atos dos órgãos, como formas
essenciais deles, independentes da alma, a que pertencem; mas são atos deles pelos aperfeiçoar para as
suas operações próprias, assim como o calor é ato do fogo que lhe dá o poder de aquecer. Por onde,
assim como o fogo permanece numericamente o mesmo, embora se lhe mudasse numericamente o
calor; e como uma água fria permanece a mesma, embora a sua frigidez não se restabeleça na sua
identidade anterior, depois de ter sido aquecida, assim também numericamente os mesmos
continuarão os órgãos, depois da ressurreição, embora outras venham a lhes ser as faculdades.

RESPOSTA À SÉTIMA. ─ No lugar citado o Filósofo se refere a essas potências, enquanto subsistem na
alma como na sua raiz. O que resulta claro das suas palavras: A velhice não consiste no que a alma sofra,
mesmo que sofre o corpo. Portanto, nem por enfraquecer-se o corpo hão de também enfraquecer-se as
potências da alma.

## Art. 2 — Se na alma separada subsistem também os atos das potências sensitivas.
O segundo discute-se assim. ─ Parece que na alma separada subsistem também os atos das potências
sensitivas.

1. ─ Pois, diz Agostinho: A alma separada do corpo é susceptível de felicidade e de pena, segundo o seu
mérito, mediante a imaginação, concupiscível e o irascível. Ora, a imaginação, concupiscível e o irascível
são potências sensitivas. Logo, a alma separada pode ser afetada nas suas potências sensitivas e
portanto, depois da morte, nela subsistem os atos dessas faculdades.

2. Demais. ─ Agostinho diz, que não sente o corpo, mas a alma por meio dele. E ainda: Certas sensações
tem a alma, como o temor e outras, independentes do corpo e, portanto, sem a mediação dele. Ora, o
que convém à alma separada do corpo pode nela subsistir no estado de separação. Logo, a alma pode
sentir atualmente.

3. Demais. ─ Ver as semelhanças dos objetos, como as vemos no sono, só pode sê-la por uma visão
imaginária, cuja sede é a parte sensitiva. Ora, ver essas semelhanças dos corpos, como se dá no sono, a
alma separada o pode. Por isso diz Agostinho: Se a alma tem a semelhança do seu corpo, como vários o
narraram, quando o corpo está deitado num leito de dores, a ponto de exalar o último suspiro e privado
de toda sensibilidade, não vejo porque não teria dele a imagem a alma totalmente separada pela morte.
Ora, não podemos compreender que a alma conserve a imagem do corpo, senão pela visão material.
Por isso Agostinho disse antes, dos que jazem sem sentidos: Conservam uma certa imagem do seu corpo
pela qual podem transportar-se para lugares afastados e sentirem as mesmas sensações como se vissem
as causas. Logo, a alma separada pode exercer os atos das potências sensitivas.

4. Demais. ─ A memória é uma potência da parte sensitiva, como o prova Aristóteles. Ora, as almas
separadas terão a lembrança atual do que fizeram neste mundo. Assim ao rico que se banqueteava diz o
Evangelho: Lembra-te que recebeste os teus bens em tua vida. Logo, a alma separada exercerá os atos
da potência.

5. Demais. ─ Segundo o Filósofo, o irascível e o concupiscível pertencem à parte sensitiva. Ora, o
irascível e o concupiscível são as sedes da alegria e da tristeza, do amor e do ódio, do temor e da
esperança e de outros afetos, que a fé nos autoriza a atribuir às almas separadas. Logo, as almas
separadas não ficarão privadas dos atos das potências sensitivas.
Mas, em contrário. ─ O que é comum à alma e ao corpo não pode permanecer na alma separada. Ora,
todas as operações das potências sensitivas são comuns à alma e ao corpo; o que se conclui do fato de
nenhuma potência sensitiva poder exercer os seus atos senão mediante um órgão corpóreo. Logo, a
alma separada estará privada dos atos das potências sensitivas.

2. Demais. ─ O Filósofo diz, que desaparecido o corpo, a alma não pode mais lembrar-se nem amar. E o
mesmo se dará com todos os outros atos das potências sensitivas. Logo, não pode a alma separada
exercer qualquer ato das potências sensitivas.

SOLUÇÃO. ─ Certos distinguem um duplo ato das potências sensitivas: os externos, que a alma exerce
mediante o corpo e não subsistem na alma separada; e os internos, que a alma exerce por si mesma e
existirão nela quando separada do corpo. Essa opinião parece provir da doutrina de Platão, que
ensinava estar a alma unida ao corpo como uma substância perfeita em nada dependente dele, como
um motor está unido ao móvel; e prova disso é a metempsicose, que admitia. Mas como, na sua
opinião, só o movido move, dizia, para não proceder ao infinito, que o motor primeiro a si mesmo se
move, e ensinava que a alma se movia a si própria. Há assim dois movimentos na alma: O pelo que a si
mesmo se move e o pelo qual move o corpo. Assim a alma exerce, p. ex., o ato da visão, primeiro em si
mesma, enquanto se move; e segundo, num órgão corpóreo, enquanto move o corpo.
Mas o Filósofo refuta essa opinião, mostrando que a alma não se move a si mesma, e que de nenhum
modo é movida por atos tais como ver, sentir e outros; e que esses atos são movimentos só do
composto. Donde devemos concluir, que os atos das potências sensitivas de nenhum modo subsistem
na alma separada, senão talvez como na sua raiz remota.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Certos negam seja essa obra de Agostinho, e pensam ter
sido composta por um Cisterciense, que a compilou com palavras de Agostinho, acrescentando algo de
seu. Por isso o que nele se diz não constitui autoridade. ─ Mas se tal autoridade lhe deva ser atribuída, é
nosso sentir que não devemos entender as palavras citadas como significando, que a alma separada
exerce atos pela imaginação e pelas outras potências sensíveis, como pertencentes a essas potências.
Mas no sentido em que os atos operados por ela no corpo, com o auxílio da imaginação e das potências
sensíveis, esses mesmos a afetam, para seu bem ou para seu mal, na vida futura. De modo que essas
faculdades sensitivas, como a imaginação, não produzem as sensações da alma, senão só as obras
corpóreas que as merecem.

RESPOSTA À SEGUNDA. ─ O dizer Agostinho que a alma sente mediante o corpo, não significa que o ato
de sentir seja peculiar à alma isoladamente, mas que pertence ao composto em razão da alma, pelo
mesmo modo de falar com que dizemos que o calor aquece. Quanto ao que acrescenta, que a alma
sente certas cousas, como o temor e outras, devemos entendê-lo sem o movimento exterior do corpo,
que acompanha os atos próprios dos sentidos; pois, o temor e paixões semelhantes não se exercem sem
ser acompanhados do movimento do corpo. Ou podemos dizer que Agostinho fala segundo a opinião
dos Platônicos, que assim o ensinavam, como dissemos.

RESPOSTA À TERCEIRA. ─ No lugar citado Agostinho antes procura do que afirma a verdade, como o faz
em, quase todo o livro. Pois, é claro que não se dá com a alma do adormecido o mesmo que com a alma
separada. A alma do adormecido se serve do órgão da imaginação onde se imprimem as imagens dos
corpos, o que não se pode dizer da alma separada. ─ Ou devemos responder que as imagens das cousas
estão na alma pelas potências sensitiva, imaginativa e intelectiva, conforme a maior ou menor abstração
da matéria e das condições materiais. Mas a comparação de Agostinho colhe quanto ao seguinte: assim
como as imagens das cousas corpóreas estão na alma de quem sonha ou se separa do corpo em
imaginação, assim estão também na alma separada por um conceito intelectual, mas não por ato da
imaginação.

RESPOSTA À QUARTA. ─ Como diz o Mestre das sentenças, a memória pode ser tomada em duplo
sentido. Ora, como potência da parte sensitiva, tendo então por objeto os fatos passados, E nesta
acepção a alma separada não será susceptível de memória. Por isso diz o Filósofo que, desaparecido o
corpo, a alma não é capaz de lembrar-se. ─ Noutro sentido, a memória é tomada como parte da
imaginação, e pertencente à potência intelectiva; i. é, enquanto abstrai de toda diferença de tempo, não
se referindo só aos fatos passados, mas também aos presentes e aos futuros, como diz Agostinho. E
neste sentido, na alma separada pode existir a memória.

RESPOSTA À QUINTA. ─ O amor, a alegria, a tristeza e paixões semelhantes são susceptíveis de duplo
sentido. ─ Ora, são paixões do apetite sensitivo. E então não podem existir na alma separada; pois, neste
sentido implicam um determinado movimento do coração. ─ Ora são tomados como atos da vontade,
que residem na parte intelectiva, E então existirão na alma separada; assim como também o prazer, que
de certo modo é uma paixão da parte sensitiva, tomando-o em outro sentido o Filósofo o atribui a Deus,
quando diz que Deus se compraz numa deleitação simples.

## Art. 3 — Se a alma separada pode sofrer a ação do fogo corpóreo.
O terceiro discute-se assim. ─ Parece que a alma separada não pode sofrer a ação do fogo corpóreo.

1. ─ Pois, Agostinho diz: Não são cousas corpóreas, mas semelhantes às corpóreas as que afetam, para
bem ou mal delas, as almas separadas do corpo. Logo, a alma separada não pode ser punida pelo fogo
material.

2. Demais. ─ Agostinho, no mesmo livro diz, que o agente é sempre mais nobre que o paciente. Ora, é
impossível um corpo mais nobre que a alma separada. Logo, não pode ela sofrer a ação de nenhum
corpo.

3. Demais. ─ Segundo o Filósofo e segundo Boécio, só podem ser ativos e passivos uns em relação aos
outros os seres que comunicam pela matéria. Ora, a alma e o fogo corpóreo não comunicam pela
matéria, porque não há nada de material comum entre os seres espirituais e os corpóreos. Por isso não
podem transformar-se uns nos outros. Logo, a alma separada não pode sofrer nada do fogo corpóreo.

4. Demais. ─ Tudo o que sofre uma ação recebe alguma cousa do agente. Se, pois, a alma sofrer a ação
do fogo corpóreo, dele receberá alguma coisa. Ora, tudo o que um ser recebe de outro ao seu modo o
recebe. Logo, o que a alma receber, do fogo, nela não existirá materialmente, mas espiritualmente. Ora,
formas das causas existentes na alma espiritualmente constituem perfeições dela. Logo, admitindo-se
que a alma pode sofrer uma ação fogo corpóreo, não o será para sua pena, mas, antes, para a sua
perfeição.

5. Demais. ─ Se se disser que a alma punida pelo fogo só pelo ver, como parece ser a opinião de
Gregório, objeta-se em contrário. ─ Pois, se alma vê o fogo do inferno, não no poderá ver senão por uma
visão intelectual, porque não tem órgãos por onde se exerça a visão sensitiva ou a imaginativa. Ora, a
visão intelectual não pode ser causa de tristeza, porque ao prazer da contemplação nenhuma tristeza
contrária, segundo o Filósofo. Logo, por essa visão a alma não será punida.

6. Demais. ─ Se se disser que a alma sofre a ação do fogo material, por ficar encerrada nele como o está
no corpo, enquanto vivo unida a este, objeta-se em contrário. - Pois, a alma enquanto unida ao corpo
está encerrada nele porque dela e do corpo resulta uma unidade, como da matéria e da forma. Ora, a
alma não será a forma desse fogo corpóreo. Logo, não poderá, ao modo sobredito ser nele encerrada.

7. Demais. ─ Todo agente material age por contato. Ora, nenhum contato pode haver entre o fogo
corpóreo e a alma, pois contato só pode existir entre corpos cujas extremidades se tocam. Logo, a alma
não pode sofrer a ação de um tal fogo.

8. Demais. ─ Um agente instrumental não pode atuar sobre os corpos afastados senão atuando sobre os
que estão no meio; e assim pode agir numa determinada distância proporcionada à sua virtude. Ora, as
almas, ou pelo menos os demônios, que se acham nas mesma condições, podem achar-se fora do lugar
inferno, e às vezes aparecem aos homens neste mundo. Mas nem por isso ficam imunes da pena; pois,
assim como a glória dos santos nunca se interrompe, assim também não a pena dos demônios
condenados. Ora, não vemos que o fogo do inferno se faça sentir em todos lugares intermediários que
separam os demônios, da sua eterna morada. Nem além disso é crível que um elemento de natureza
corpórea tenha tão grande energia, que possa alcançar uma tão grande distância. Logo, as penas
sofridas pelas almas condenadas não são causadas por nenhum fogo corpóreo.
Mas, em contrário. ─ O mesmo se dá com as almas separadas e com os demônios, quanto a sofrerem a
ação de um fogo corpóreo. Ora, os demônios sofrem a ação dele, pois são punidos pelo fogo onde serão
precipitados os corpos dos condenados depois da ressurreição, fogo que há de ser de natureza
corpórea, como se conclui da sentença do Senhor: Apartai-vos de mim, malditos, para o jogo eterno,
que está aparelhado para o demônio e para os seus anjos. Logo, também as almas separadas podem
sofrer a ação do fogo corpóreo.

2. Demais. ─ A pena deve corresponder à culpa. Ora, pela culpa a alma, arrastada pela gravidade da
concupiscência, sujeitou-se ao corpo. Logo, é justo que, como pena, sofra a ação de um agente
corpóreo.

3. Demais. ─ Mais íntima é a união entre a forma e a matéria do que entre o agente e o paciente. Ora, a
diversidade da natureza espiritual e corporal não impede seja a alma a forma do corpo. Logo, também
não impede que possa sofrer a ação de um agente material.

SOLUÇÃO. ─ Suposto que o fogo do inferno não seja simplesmente metafórico nem imaginário, mas um
verdadeiro fogo material, é forçoso admitir que a alma sofrerá as penas desse fogo. Pois, segundo as
palavras do Senhor, esse fogo está aparelhado para o demônio e para os seus anjos. Ora, estes são
incorpóreos, como a alma. Mas, como pode a alma sofrer a ação de tal fogo, é variamente explicado.
Assim, certos ensinaram que já o simples fato de a alma ver o fogo implica em sofrer-lhe a ação. Por isso
Gregório diz: Por isso mesmo que a alma vê o jogo, já lhe sofre a ação. ─ Mas esta explicação é
insuficiente. Porque a visão de qualquer objeto constitui por si mesma uma perfeição do agente que vê.
Por isso não pode o fogo, só enquanto visto, constituir uma pena para quem o vê. Pode porém, por
acidente, ser o fogo, simplesmente visto, uma causa de punição e de dor, enquanto apreendido como
nocivo. Por onde e necessariamente, para esse fogo poder causar à alma um sofrimento, não basta que
ela o veja, mas deve ainda ter um certo contato com ele.
Por isso outros disseram, que embora um fogo material não possa queimar a alma, contudo esta o
apreende como nocivo para si; e dessa apreensão lhe resulta o temor e a dor, de modo a cumprir-se o
dito da Escritura: Ali tremerão de medo onde não havia que teme?. Donde o dizer Gregório, que a alma
é realmente queimada pelo só fato de se ver queimar. ─ Mas também esta explicação não é suficiente.
Porque então, a alma sofreria a ação do fogo, não realmente, mas só como apreensão. Pois, embora,
como diz Agostinho, uma falsa imaginação possa ser causa de tristeza ou de dor reais, contudo não se
pode dizer que esse sofrimento assim imaginário provenha de um agente real, senão só da imagem da
realidade concebida. Além disso, esse modo de sofrer mais diferiria de um sofrimento real, que o
causado por visões imaginárias; porque seria este derivado de imagens verdadeiras de objetos, se
concebidas pela alma, ao passo que o primeiro resultaria de falsas concepções que alma em si
enganosamente formou. ─ Além disso, não é provável que as almas separadas ou os demônios, dotados
de subtileza de engenho, pensassem que um fogo material lhes pudesse causar mal, se nenhum
sofrimento dele recebessem.
Por isso ensinam outros ser forçoso admitir que a alma sofre realmente pelo fogo material. Donde o
dizer também Gregório: podemos coligir, das expressões do Evangelho, que a alma arde, não só por ver
o jogo, mas também por lhe experimentar a ação. E assim explicam como isso pode ser. Esse fogo
material, dizem, pode ser considerado a dupla luz. Primeiro, como um ser corpóreo; e então não pode
exercer nenhuma ação sobre a alma. Segundo, como instrumento da vingança da justiça divina. Pois, a
ordem da divina justiça exige que a alma que se apegou pelo pecado às causas materiais, também sofra
a pena causada por elas. Ora, um instrumento age não só por virtude da própria natureza, mas também
por virtude do agente principal. Não há portanto absurdo em esse fogo, atuando em virtude de um
agente espiritual, produzir o seu efeito no homem ou no demônio, ao modo por que também
explicamos a santificação da alma pelos sacramentos.
Mas também esta opinião é insuficiente. Porque todo instrumento, quando funciona como tal, tem uma
ação própria e conatural sobre o ser que a sofre, além daquela que exerce por influência do agente
principal. E até mesmo, quando exerce a sua ação própria, há de também necessariamente exercer a
segunda. Assim a água, lavando o corpo no batismo, santifica a alma; e a serra, cortando a madeira,
produz a forma da casa. Por onde, é forçoso atribuir ao fogo uma certa ação sobre a alma, que lhe seja
conatural a ele, para ser instrumento da justiça divina vingadora dos pecados.
Devemos, pois, pensar que um corpo não pode agir naturalmente sobre o espírito, nem se lhe opor ou
gravá-la de qualquer maneira, senão enquanto o espírito está de algum modo unido ao corpo; assim,
como diz a Escritura, o corpo que se corrompe, jaz pesada a alma. Ora, um espírito pode estar unido ao
corpo, de dois modos. ─ Primeiro, como a forma à matéria, donde resulte uma completa unidade. E
assim o espírito está unido ao corpo e o vivifica, sendo também de algum modo gravado por ele, Ora,
neste sentido, o espírito do homem ou do demônio não está unido ao fogo material. ─ Segundo, como o
motor ao móvel, ou como o localizado ao lugar, modo por que os seres incorpóreos ocupam um lugar. E
neste sentido, os espíritos incorpóreos criados são circunscritos pelo lugar, de modo que estando em
um não estarão em outro. Embora, pois, um ser corpóreo, pela sua natureza mesma, circunscreva num
lugar o espírito incorpóreo, não pode contudo, por essa natureza, reter o espírito incorpóreo, preso a
um lugar, de modo ligado a este que não possa ocupar outro: porque um espírito não ocupa nenhum
lugar, tão naturalmente que fique a ele ligado. O fogo corpóreo porém, enquanto instrumento da justiça
divina vindicante, recebe a propriedade especial de ligar o espírito. E assim lhe constitui uma pena,
impedindo-lhe obedecer à sua vontade própria, de modo a não poder agir quando quer e como quer.
Tal a explicação que oferece Gregório. Assim, expondo como a alma pode arder por ação do fogo, diz:
Desde que a própria verdade nos ensina, que o mau rico é condenado ao fogo do inferno, que homem
sábio ousaria negar que as almas dos réprobos são presas das chamas? E isso mesmo ensina Juliano,
segundo o refere o Mestre: Se o nosso espírito incorpóreo esta unido ao corpo, enquanto vivemos,
porque não poderá depois da morte sofrer a ação de um fogo corpóreo? E Agostinho também diz, que
como na condição humana a alma esta unida ao corpo, sendo-lhe assim o princípio da vida, embora seja
ela espiritual e ele material; e dessa união resulte o seu veemente amor pelo corpo, assim esta ligada ao
fogo, de modo a lhe sofrer a pena, e dessa união concebe um verdadeiro horror.
Assim, pois, reduzindo todas essas explicações a uma só, a fim de compreendermos perfeitamente
como a alma pode sofrer a ação de um fogo material, dizemos o seguinte: Ao fogo, por natureza, pode-
se-lhe unir o espírito incorpóreo, como o localizado com o lugar. Mas enquanto instrumento da justiça
divina, pode de certo modo retê-lo ligado; e assim a alma será cruciada pelo fogo vendo-se como lhe é
nocivo. Por isso Gregório passa em revista todas essas explicações, como se vê dos seus lugares supra-
citados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Agostinho se exprime como indagando. Por isso, noutro
lugar se exprime como quem resolve, conforme do sobredito se colhe. ─ Ou devemos responder que
Agostinho entende que as causas imediatas de dor ou de tristeza para a alma são causas espirituais;
pois, não sofreria se não apreendesse o fogo como capaz de lhe causar dano. Assim, o fogo apreendido
como doloroso é a causa próxima do tormento, e o fogo material exterior à alma é a causa remota desse
mesmo tormento.

RESPOSTA À SEGUNDA. ─ Embora a alma, em si mesma considerada, seja de natureza mais nobre que o
fogo, de certo modo porém o fogo, enquanto instrumento da justiça divina, é mais nobre que ela.

RESPOSTA À TERCEIRA. ─ O Filósofo e Boécio se referem aquela ação pela qual o paciente se transforma
em a natureza do agente. Ora, tal não é a ação do fogo sobre a alma. Por isso objeção não colhe.

RESPOSTA À QUARTA. ─ O fogo que age sobre a alma, não a modo de agente influente, mas retendo-a
presa, como do sobre dito resulta. Por isso a objeção não vem a propósito.

RESPOSTA À QUINTA. ─ Para a visão intelectual, nenhuma pena pode resultar de um objeto visto; pois,
nenhum objeto visto pode como tal, ser contrário ao intelecto. Tratando-se porém da visão corpórea,
um objeto, pela ação mesma que exerce sobre os olhos, de modo a ser visto, pode fazer mal à vista,
acidentalmente, destruindo a harmonia do órgão. Com tudo, a visão intelectual pode ser causa de pena
quando apreendemos como nociva a causa vista não por causar qualquer dor só pelo fato de ser vista,
mas de qualquer outro modo. Ora, neste sentido, a alma sofre pela só vista do fogo.

RESPOSTA À SEXTA. ─ O símile não é total, mas parcial, como do sobredito resulta.

RESPOSTA À SÉTIMA. ─ Embora não haja contato corpóreo entre a alma e o corpo, há contudo entre
ambos um certo contato espiritual. Assim como o motor do céu, sendo espiritual move o céu por um
contato espiritual com ele ao modo por que se diz que um objeto contristante nos toca, conforme o
ensina Aristóteles. E este modo de contato basta para agir.

RESPOSTA À OITAVA. ─ Os espíritos condenados nunca saem do inferno senão por divina permissão,
para instrução ou exercício dos eleitos. Mas onde quer que estejam, fora do inferno, sempre tem à vista
o fogo como pena que lhes foi aparelhada. Por onde, sendo essa visão uma causa imediata de
sofrimento, conforme se disse, estejam onde estiverem, são sempre atormentados pelo fogo do inferno.
Assim como os presos, mesmo quando fora do cárcere, de certo modo lhe sofrem as agruras, vendo-se
condenados a ele. Por isso, assim como a glória do eleitos não se lhes diminui, quanto ao prêmio
essencial nem quanto ao acidental, mesmo que possam vir a sair do céu empíreo, o que de certo modo
lhes redunda em glória, assim também em nada fica diminuída a pena dos condenados quando saem
temporariamente do inferno para permissão divina. Tal o que diz a Glosa, aquilo da Escritura ─ Tisna a
roda do nosso nascimento, etc.: O diabo, esteja onde estiver, sob o ar ou sob a terra, leva, consigo os
tormentos das suas chamas. A objeção porém procederia se o fogo corpóreo fosse uma causa próxima
de tormento para os espíritos, como o é para os corpos.
