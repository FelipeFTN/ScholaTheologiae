# Questão 22: Dos que podem excomungar e ser excomungados.
Em seguida devemos tratar dos que podem excomungar e ser excomungados.
E nesta questão discutem-se seis artigos:

## Art. 1 — Se qualquer sacerdote pode excomungar.
O primeiro discute-se assim. — Parece que qualquer sacerdote pode excomungar.

1. — Pois, a excomunhão é um ato de quem tem o poder das chaves. Ora, qualquer sacerdote tem esse
poder. Logo, qualquer sacerdote pode excomungar.

2. Demais. — É mais absolver e ligar no foro da penitência, que no foro judicial. Ora, qualquer sacerdote
pode absolver e ligar no foro da penitência os que lhe estão sujeitos. Logo, também pode qualquer
sacerdote excomungar os seus súbditos.
Mas, em contrário. — É preciso reservar aos mais elevados em dignidade as funções expostas a maiores
perigos. Ora, a pena de excomunhão é muito perigosa, não sendo aplicada com moderação. Logo, não
deve ser cometida a qualquer sacerdote.

SOLUÇÃO. — No foro da consciência a causa de decide entre o homem e Deus; ao passo que no foro do
juízo exterior, a causa se decide entre um homem e outro. Por onde, a absolvição ou a ligação, que
obriga um homem só para com Deus, pertence ao foro da penitência; mas a que obriga para com os
outros homens pertence ao foro público do juízo exterior. E o homem pela excomunhão fica separado
da comunhão dos fiéis, por isso a excomunhão pertence ao foro exterior. Por isso só podem
excomungar os que tem a jurisdição no foro judicial. Donde vem que os bispos, por autoridade própria,
e os prelados maiores podem, segundo uma opinião mais comum, excomungar; ao passo que os
sacerdotes párocos só o podem quando isso lhes é cometido; ou em certos casos, como o de furto, de
roubo e semelhantes, nos quais lhes é concedido por direito, que possam excomungar. — Outros porém
disseram que também os sacerdotes párocos podem excomungar. Mas a opinião referida antes é mais
racional.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A excomunhão não é menos um ato que implique o uso
direto do poder das chaves, que um ato do juízo exterior. Ora, a sentença de excomunhão, embora
promulgada pelo juízo exterior, como porém de certo modo respeita à entrada no Reino, pois que a
Igreja militante é a via para a triunfante, por isso também essa jurisdição, que da o direito de
excomungar, pode chamar-se poder das chaves. Donde o distinguirem certos a chave da ordem, que
todos os sacerdotes tem, da chave da jurisdição no foro judicial, que tem só os juízes do foro exterior. E
ambas essas chaves Deus concedeu a Pedro; e deles derivam esses poderes, naqueles que o tem.

RESPOSTA À SEGUNDA. — Os sacerdotes párocos tem certa jurisdição sobre os seus súditos, quanto ao
foro da consciência, mas não quanto ao foro judicial, porque não podem convir na presença deles nos
negócios contenciosos. Por isso não podem excomungar, mas podem absolver no foro da penitência. E
embora o foro da penitência seja mais digno, contudo o foro judicial demanda maior solenidade; porque
nele há de satisfazer-se não só a Deus mas também ao homem.

## Art. 2 — Se os não-sacerdotes podem excomungar.
O segundo discute-se assim. — Parece que os não-sacerdotes não podem excomungar.

1. — Pois, a excomunhão é um ato de poder das chaves, como diz o Mestre das Sentenças. Ora, os não-
sacerdotes não tem o poder das chaves. Logo, não podem excomungar.

2. Demais. — Maior poder é necessário para excomungar, do que para absolver no foro da penitência.
Ora, o não sacerdote não pode absolver no foro da penitência. Logo, nem proferir excomunhão.
Mas, em contrário, os arquidiáconos, os legados e os prelados eleitos, excomungam, estes que às vezes
não são sacerdotes. Logo, nem só os sacerdotes podem excomungar.

SOLUÇÃO. — Os sacramentos pelos quais é conferida a graça, dispensá-los só o podem os sacerdotes.
Por isso só eles podem absolver e ligar no foro da penitência. Ora, a excomunhão não diz respeito à
graça, diretamente, senão só por consequência, enquanto o excomungado fica separado dos sufrágios
da Igreja que dispõem para a graça ou nela conservam. Por isso também os não sacerdotes, contanto
que tenham jurisdição no foro contencioso, podem excomungar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora os não-sacerdotes não tenham a chave da
ordem, tem contudo a da jurisdição.

RESPOSTA À SEGUNDA. — A excomunhão e a absolvição estão entre si como o excedente para o
excedido. Por isso o que cabe a um não cabe ao outro.

## Art. 3 — Se um excomungado ou um suspenso pode excomungar.
O terceiro discute─se assim. — Parece que um excomungado ou um suspenso pode excomungar.

1. — Pois, o excomungado ou o suspenso não perde a ordem nem a jurisdição; porque nem precisa de
reordenar-se, depois de absolvido, nem precisa ser de novo instalado no seu curato. Ora, a excomunhão
não demanda nem a ordem nem a jurisdição. Logo, também o excomungado e o suspenso podem
excomungar.

2. Demais. — Maior poder é necessário para consagrar o corpo de Cristo que para excomungar. Ora, os
de que se trata podem consagrar. Logo, podem também excomungar.
Mas, em contrário. — Quem está corporalmente ligado não pode ligar a outrem. Ora, o vínculo
espiritual é mais forte que o corporal. Logo, um excomungado não pode excomungar outro, por ser a
excomunhão um vínculo espiritual.

SOLUÇÃO. — O uso da jurisdição é relativo a outrem. Por onde, todo excomungado ficando separado da
comunhão dos fiéis, fica privado do uso da jurisdição. E como a excomunhão é um ato de jurisdição, um
excomungado não pode excomungar. — E o mesmo se dá com o que tem a sua jurisdição suspensa. Se
pois, está suspenso apenas da ordem, então não pode exercê-la ou aplicá-la, mas pode exercer a
jurisdição. E ao contrário, se está suspenso da jurisdição e não da ordem. E se de ambas, então nada
poderá fazer.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora o excomungado ou o suspenso não perca a
jurisdição, perde contudo o uso desta.

RESPOSTA À SEGUNDA. — Consagrar depende do poder resultante do caráter, que é indelével. Por
onde, o sacerdote, desde que tem o caráter da ordem, sempre pode consagrar, embora nem sempre
isso lhe seja lícito. Outra coisa porém se passa com a excomunhão, resultante da jurisdição, que pode
ser perdida ou suspensa.

## Art. 4 — Se alguém pode excomungar a si mesmo, ao seu igual, ou ao superior.
O quarto procede-se assim. — Parece que alguém pode excomungar a si mesmo, ao seu igual ou ao
superior.

1. — Pois, o anjo de Deus era maior que Paulo, segundo aquilo do Evangelho: O que é menor no reino
dos céus é maior do que ele, pois entre os nascidos de mulheres não se levantou outro maior. Ora,
Paulo excomungou um anjo do céu. Logo, pode um homem excomungar o seu superior.

2. Demais. — O sacerdote excomunga às vezes em geral, por causa de furto ou coisa semelhante. Ora,
pode dar-se que o culpado fosse ele próprio ou o superior ou o igual. Logo, pode alguém excomungar a
si ou ao igual ou ao superior.

3. Demais. — Alguém pode absolver o seu superior no foro da penitência, ou o seu igual; tal o bispo que
se confessa a seus súditos, e quando um sacerdote confessa a outros pecados veniais. Logo, parece que
também pode alguém excomungar o superior ou o igual.
Mas, em contrário. — A excomunhão é um ato de jurisdição. Ora, ninguém pode exercer jurisdição
sobre si mesmo, porque ninguém pode ser juiz e réu na mesma causa. Nem tão pouco sobre um
superior ou um igual. Logo, não pode ninguém excomungar um superior, um igual ou a si mesmo.

SOLUÇÃO. — Como a jurisdição, fazendo de quem a exerce o juiz daquele sobre quem a exerce, o
constitui num estado de superioridade sobre este, por isso ninguém pode ter jurisdição sobre si mesmo
ou sobre o superior ou sobre o igual. E por consequência, ninguém pode excomungar a si mesmo nem
ao superior nem ao igual.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O Apóstolo fala hipoteticamente, isto é, suposto que o
anjo pecasse; porque então superior não seria ao Apóstolo, mas inferior. Ora, nada há de contraditório
que, nas proposições condicionais, cujos antecedentes são impossíveis; impossíveis também sejam os
consequentes.

RESPOSTA À SEGUNDA. — Em tal caso ninguém é excomungado, porque um igual não tem jurisdição
sobre o seu igual.

RESPOSTA À TERCEIRA. — A absolvição e a ligação no foro da confissão são relativas só a Deus, perante
quem o superior torna-se inferior por causa do seu pecado. Ora, a excomunhão concerne o juízo
externo, onde ninguém perde a superioridade, porque peca. Por onde, não há semelhança de razão
num e noutro foro. – E contudo, mesmo no foro da confissão ninguém pode absolver-se a si mesmo,
nem ao superior nem ao igual, em matéria de pecado mortal, senão lhe foi isso confiado. Mas, em
matéria de pecado venial o pode, porque os pecados veniais ficam perdoados por qualquer dos
sacerdotes que conferem a graça; por onde, a remissão dos pecados veniais resulta do poder da ordem.

## Art. 5 — Se contra alguma corporação inteira pode ser proferida sentença de excomunhão.
O quinto discute-se assim. — Parece que contra uma corporação interna pode ser proferida sentença
de excomunhão.

1. — Pois, pode uma corporação constituir-se para um mau fim. Ora, a excomunhão deve ser aplicada a
quem é contumaz na malícia. Logo, pode ser proferida a excomunhão contra uma corporação inteira.

2. Demais. — O gravíssimo na excomunhão é a separação dos sacramentos da Igreja. Ora, pode se dar
que a toda uma cidade seja interdita a celebração dos sacramentos. Logo, também uma corporação
inteira pode ser excomungada.
Mas, em contrário, a Glosa de Agostinho, que diz que nem o príncipe nem o povo devem ser
excomungados.

SOLUÇÃO. — Ninguém deve ser excomungado senão por um pecado mortal. Ora, o pecado consiste
num ato; e este não é prática de uma comunidade, mas de cada um em particular, no mais das vezes.
Por isso cada membro da comunidade de per si pode ser excomungado, mas não a comunidade mesma.
E se por vezes se dá que o autor do ato é toda a multidão em si mesma — como quando muitos puxam
um barco, o que cada um por si só não poderia fazer — contudo não é provável que uma comunidade
consinta toda ela no mal a ponto de dele não discernir nenhum dos membros da mesma. E como não é
próprio de Deus, juiz de toda a terra, condenar o justo com o ímpio, no dizer da Escritura, por isso a
Igreja, que deve imitar o juízo de Deus, bastante providente estatuiu, que uma comunidade não seja
excomungada, para que talvez não suceda que, arrancando a cizânia, arranqueis juntamente com ela
também o trigo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A solução se deduz do que foi dito.

RESPOSTA À SEGUNDA. — A suspensão não é tão grande pena como a excomunhão; porque os
suspensos não ficam privados dos sufrágios da Igreja, como os excomungados. Por onde, pode um ser
suspenso sem ser por pecado próprio; assim como todo um reino pode ser posto sob interdito pelo
pecado do rei. Portanto, não há símile entre a excomunhão e a suspensão.

## Art. 6 — Se quem já foi excomungado uma vez pode sê-lo de novo.
O sexto discute-se assim. — Parece que quem já foi excomungado uma vez não pode sê-lo de novo.

1. — Pois, pergunta o Apóstolo: Que me vai a mim julgar de aqueles que estão fora? Ora, os
excomungados estão fora da Igreja. Logo, sobre eles já a Igreja não tem que formar nenhum juízo, de
modo a poder de novo excomungá-las.

2. Demais. — A excomunhão é uma separação da vida da Igreja e da comunhão dos fiéis. Ora, quem já
foi privado de uma coisa não pode tornar a sê-la. Logo, um excomungado não pode sê-lo de novo.
Mas, em contrário. — A excomunhão é uma pena e é um remédio curativo. Ora, todas as penas e
remédios são renovados quando as circunstâncias o exigem. Logo, a excomunhão pode ser renovada.

SOLUÇÃO. — Quem já sofreu uma excomunhão pode ser excomungado de novo, quer pela reiteração
da mesma excomunhão, para mais confundir-se o excomungado e assim ser levado a afastar-se do
pecado; ou por outras causas. E assim são tantas as excomunhões principais quantas as causas por que
alguém é excomungado.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O apóstolo se refere aos pagãos e aos outros infiéis, que
não receberam o caráter que os torne membros do povo de Deus. Mas, como o caráter batismal, que
torna cada um membro do povo de Deus, é indelével, por isso o batizado sempre pertence de certo
modo à Igreja. E assim, a Igreja sempre tem o poder de o julgar.

RESPOSTA À SEGUNDA. — Embora a privação não seja em si mesma susceptível de mais nem de menos,
é o porém na sua causa. E assim, a excomunhão pode ser renovada. E mais afastado está dos sufrágios
da Igreja quem foi várias vezes excomungado, que quem só uma vez o foi.