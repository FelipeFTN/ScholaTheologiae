# Questão 17: Do poder das chaves.
Em seguida devemos tratar do poder dos ministros deste sacramento, concernente às chaves. Sobre o
que, primeiro devemos tratar do poder das chaves. Segundo, da excomunhão. Terceiro, da indulgência.
Pois, essas duas coisas estão anexas ao poder das chaves.
No primeiro ponto há quatro questões a se considerarem. Primeiro, da entidade e da quididade do
poder das chaves. Segundo, do seu efeito. Terceiro, dos ministros das chaves. Quarto, daqueles sobre os
quais pode exercer-se o uso das chaves.
Na primeira questão discutem-se três artigos:

## Art. 1 — Se deve ter a Igreja o poder das chaves.
O primeiro discute-se assim. ─ Parece que não deve ter a Igreja o poder das chaves.

1. ─ Pois, não se precisam chaves para entrar numa casa cuja porta está aberta. Ora, a Escritura diz:
Olhei e vi uma porta aberta no céu, que é Cristo, o qual falando de si mesmo, disse: Eu sou a porta.
Logo, para a entrada no céu não é necessário ter a Igreja o poder das chaves.

2. Demais. ─ Uma chave serve para abrir e fechar. Ora, isto só Cristo o pode fazer, que abre e ninguém
fecha, fecha e ninguém abre. Logo, a Igreja não tem, pelos seus ministros o poder das chaves.

3. Demais. ─ A quem quer que seja fechado o céu, a esse se lhe abre o inferno; e ao contrário. Logo,
quem tiver as chaves do céu terá também as do inferno. Ora, não se diz que a Igreja tem as chaves do
inferno. Logo, nem as do céu.
Mas, em contrário, o Evangelho: Dar-te-ei as chaves do reino dos céus.

2. Demais. ─ Todo dispensador deve ter as chaves daquilo que dispensa. Ora, os ministros da Igreja são
os dispensa dores dos divinos mistérios, conforme o Apóstolo. Logo, devem ter as chaves.

SOLUÇÃO. ─ Na ordem material chamamos chave ao instrumento com que abrimos uma porta. Ora, o
reino dos céus nos foi fechado pelo pecado, tanto quanto à mácula como quanto ao reato da pena. Por
isso, o poder que remove esse obstáculo se chama poder das chaves. Ora, esse poder o tem, pela sua
autoridade, a Divina Trindade; donde o dizerem certos, que tem a chave da autoridade. Mas, Cristo
homem, teve o poder de remover o referido obstáculo pelo mérito da paixão, poder também chamado
o de abrir a porta. Por isso certos dizem que êle tem as chaves da excelência. E como dos lados de Cristo
morto na cruz manaram os sacramentos, pelos quais foi a Igreja instituída, por isso nos sacramentos da
Igreja permanece a eficácia da paixão. Por onde, foi conferido também aos ministros da foi a Igreja
instituída, por isso nos sacramentos um certo poder de remover o referido obstáculo, não por virtude
própria, mas por virtude divina e da paixão de Cristo. E esse poder se chama metaforicamente poder das
chaves da Igreja, que é o do ministério das chaves.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A porta do céu está, em si mesma, sempre aberta; mas
dizemos estar fechada a quem está impedido de nele entrar. Ora, o impedimento universal da natureza
humana, consequente ao pecado do primeiro homem, foi removido pela paixão de Cristo. Por isso João,
depois da paixão, viu aberta a porta do céu. Mas ainda até agora essa porta nos permanece fechada, por
causa do pecado original contraído, ou do atual, que cometemos. Eis porque precisamos dos
sacramentos e do poder das chaves da Igreja.

RESPOSTA À SEGUNDA. ─ O lugar citado se entende da clausura do limbo, para ninguém mais descer a
ele; e da abertura do paraíso, removido o impedimento da natureza, pela sua paixão.

RESPOSTA À TERCEIRA. ─ As chaves do inferno, que o abrem e fecham, é o poder de conferir a graça,
pela qual se nos abre o inferno, para sermos tirados do pecado, que é a porta dele; e o fecha, para não
cairmos mais no pecado sustentados pela graça. Ora, o poder de conferir a graça só Deus o tem. Por
isso, reservou só para si a chave do inferno. Mas, a chave do Reino é o poder de perdoar também o
reato da pena, que nos impede de ai entrar. Por isso, ao homem podia ser dado, antes, a chave do Reino
que a do inferno; pois não são as mesmas, como do sobredito se colhe. Pode porém um ser tirado do
inferno, pela remissão da pena eterna, que nem por isso é logo introduzido no Reino, por causa do reato
da pena temporal, que permanece. ─ Ou devemos responder, como certos, que também se chama
chave do inferno e do céu, porque o fato mesmo de ser uma aberta a alguém implica em ser fechada a
outra; mas a denominação se tira da mais digna.

## Art. 2 — Se o poder das chaves é o poder de ligar e de desatar pelo qual o juiz eclesiástico deve receber no reino os dignos e dele excluir os indignos.
O segundo discute-se assim. ─ Parece que o poder das chaves não é o poder de ligar e de desatar, pelo
qual o juiz eclesiástico deve receber no Reino os dignos e dele excluir os indignos.

1. ─ Pois, o poder espiritual conferido no sacramento é o mesmo que o caráter. Ora, o poder das chaves
e o caráter não são o mesmo, porque pelo caráter o homem é comparável a Deus; mas pelo poder das
chaves, aos súbditos. Logo, não é um poder.

2. Demais. ─ Juiz eclesiástico só é considerado aquele que tem jurisdição, e esta não é dada
simultaneamente com a ordem. Ora, o poder das chaves é conferido quando o é a ordem. Logo, não se
devia fazer menção do juiz eclesiástico na definição do poder das chaves.

3. Demais. ─ Ao que temos por nós mesmos não havemos necessidade de nenhum poder ativo para nos
mover ao ato. Ora, só pelo fato de sermos dignos, já somos admitidos no Reino. Logo, não pertence ao
poder das chaves admitir no Reino os dignos dele.

4. Demais. ─ Os pecadores são indignos do Reino. Ora, a Igreja ora pelos pecadores, a fim de alcançarem
o Reino. Logo, longe de excluir os indignos, os admite, na medida do possível.

5. Demais. ─ Em todos os agentes ordenados, o último fim é o do agente principal, não o do agente
instrumental. Ora, o agente principal na salvação do homem é Deus. Logo, a ele pertence admitir no
Reino, que é o fim último: e não a quem tem o poder das chaves, que é como o instrumento ou
ministro.

SOLUÇÃO. ─ Segundo o Filósofo, as potências se definem pelos atos. Ora, sendo o poder das chaves uma
potência, há de definir-se pelo seu uso ou ato; e há de pelo ato ser expresso o seu objeto, pelo qual o
ato se especifica, e o modo de agir, donde resulta a potência ordenada. Ora, o ato da potência espiritual
não é abrir o céu, absolutamente falando, que já está aberto, como dissemos; mas abri-lo a uma
determinada pessoa. E isso não pode fazer-se ordenadamente, senão depois de pesada a Idoneidade
daquele a quem o céu deva ser aberto. Por isso, na referida definição do poder das chaves, se põe o
gênero, isto é, o poder; e o sujeito do poder, isto é, o juiz eclesiástico; e o ato, isto é, excluir e receber,
segundo os dois atos materiais da chave ─ abrir e fechar; e a definição toca no objeto quando diz ─ do
Reino; e enfim no modo, quando se refere à ponderação de dignidade e indignidade, daqueles sobre
quem se exerce o ato.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Uma potência se ordena a dois fins, dos quais um é a
causa do outro; assim o calor do fogo se ordena a aquecer e a dissolver. E como toda graça e todo
perdão, num corpo místico, vêm da sua cabeça, pelo mesmo poder essencial o sacerdote pode
consagrar, absolver e ligar, desde que tenha jurisdição; e esses poderes não diferem entre si senão
racionalmente, enquanto comparados aos seus diversos efeitos; assim também o fogo, num ponto de
vista, aquece e, em outro, liquefaz. E como o caráter da ordem sacerdotal não é senão o poder de
exercer aquilo que constitui a principal finalidade dessa ordem, sustentando-se que ela é idêntica ao
poder espiritual, por isso o caráter e o poder de consagrar e o poder das chaves são um mesmo poder
essencialmente, mas diferem racionalmente.

RESPOSTA À SEGUNDA. ─ Todo poder espiritual é dado junto com alguma consagração. Por isso o poder
das chaves é dado em conjunto com a ordem. Mas a execução do poder das chaves precisa da matéria
devida, que é o povo sujeito à jurisdição. Por isso, antes de ter a jurisdição, sacerdote tem o poder das
chaves, embora não tenha em ato. E como esse poder se define pelo seu ato, por isso na definição dele
se introduz um elemento pertinente à jurisdição.

RESPOSTA À TERCEIRA. ─ Podemos ser dignos de alguma coisa de dois modos. Ou por termos o direito
de a possuir: e assim, quem é digno já tem o céu aberto. Ou porque essa coisa nos é devida, por uma
certa congruência. E assim, o poder das chaves concerne aos dignos de entrarem no céu, mas aos quais
ele ainda não foi aberto.

RESPOSTA À QUARTA. ─ Assim como Deus não endurece o pecador infundindo-lhe a malícia, mas, não
lhe conferindo a graça, assim também dizemos que o sacerdote exclui do reino dos céus, não por causar
impedimento à entrada nele mas porque não remove o impedimento posto, pelo não poder remover
antes de o remover Deus. Por isso pede a Deus que absolva o pecador, de modo que assim possa
produzir efeito a sua absolvição.

RESPOSTA À QUINTA. ─ O ato do sacerdote não tem o Reino por objeto imediato; mas os sacramentos,
pelos quais chegamos ao Reino.

## Art. 3 — Se há duas chaves ou uma só.
O terceiro discute-se assim. ─ Parece que não há duas chaves, mas uma só.

1. ─ Pois, para uma fechadura não é necessária senão uma chave. Ora, a fechadura, obstáculo que a
Igreja deve remover pelas chaves, é o pecado. Logo, para remover um só pecado não precisa a Igreja de
duas chaves.

2. Demais. ─ As chaves são conferidas na calação da ordem. Ora, a ciência não resulta sempre infusa,
mas é às vezes adquirida; nem é possuída por alguns ordenados, com exclusão de outros. Logo, chave
não é a ciência. E assim, só há uma chave, a saber, o poder de julgar.

3. Demais. ─ O poder que tem o sacerdote sobre o corpo místico de Cristo depende do poder que ele
tem sobre o verdadeiro corpo de Cristo. Ora, o poder de consagrar o verdadeiro corpo de Cristo é um
só. Logo, a chave, que é o poder concernente ao corpo místico de Cristo, é uma só.

4. ─ Parece que há mais de duas chaves, pois, assim como um ato humano supõe a ciência e o poder,
assim também a vontade. Ora, a ciência de discernir é considerada uma chave, e do mesmo modo o
poder de julgar. Logo, a vontade de absolver também deve ser considerada uma chave.

5. Demais. ─ É toda a Trindade que perdoa o pecado. Ora, o sacerdote, pelas chaves, é o ministro do
perdão dos pecados. Logo, deve ter três chaves, para assemelhar-se à Trindade.

SOLUÇÃO. ─ Em todo ato que requer disposições da parte daquele sobre quem ele exerce, duas coisas
são necessárias naquele que o deve exercer:o juízo sobre as disposições do sujeito passivo e a prática
ato. Por onde, também ao ato de justiça, pelo qual atribuímos a alguém o de que é digno, é necessário;
de um lado o juízo, pelo qual discernamos se é digno, e de outro, o ato mesmo da atribuição. ─ E para
ambos é necessária uma autoridade ou um poder; pois, não podemos dar senão o que está em nosso
poder; nem pode haver juízo sem a força coativa, porque o juízo tem um objeto determinado. Essa
determinação se faz, na ordem especulativa, por virtude dos primeiros princípios, a que não podemos
fugir; e na ordem prática, pela força imperativa, atributo de quem julga. E como o poder das chaves
exige certas disposições em quem o exerce, porque o juiz eclesiástico recebe, por elas, os dignos e exclui
os indignos, segundo resulta da definição dada, por isso precisa ter o juízo de discernimento, pelo qual,
julga das disposições e de praticar o ato mesmo de absolver; e para ambas essas coisas é necessário um
poder ou autoridade. Por isso se distinguem duas chaves, uma relativa ao juízo sobre as disposições de
quem deve ser absolvido; e a outra, à, absolvição mesma. E essas duas chaves não se distinguem
essencialmente da autoridade, que as torna ambas do ofício do sacerdote; senão só relativamente aos
atos, dos quais um pressupõe o outro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Para abrir uma fechadura basta imediatamente uma só
chave; mas não há inconveniente em se ordenar uma ao ato da outra. Tal é o que se dá no caso
vertente. Pois, a segunda chave, chamada poder de ligar e de absolver, é a que imediatamente abre a
fechadura do pecado; mas a chave chamada ciência mostra a quem essa fechadura deve ser aberta.

RESPOSTA À SEGUNDA. ─ Sobre a ciência das chaves há duas opiniões. ─ Certos disseram que a ciência,
enquanto hábito, adquirido ou infuso, se chama aqui chave; mas não é chave principal, senão
dependente de outra; por isso não se chama chave, quando existe independente de outro, como se
pudesse ter um varão letrado, que não fosse sacerdote. Semelhantemente, também há sacerdotes que
não têm essa chave, porque não têm a ciência adquirida nem a infusa, pela qual pudessem absolver e
ligar; e o fazem então por uma certa indústria natural, que, segundo a opinião vertente, se chama
clavíola. E assim, a chave da ciência, embora não conferida juntamente com a ordem, esta faz com que
se torne chave o que antes não o era. E parece ter sido esta a opinião do Mestre das Sentenças. ─ Mas
não concorda com as palavras do Evangelho, que prometem haverem as chaves de ser dadas a Pedro; e
assim, são dadas, não só uma, mas duas e ordenadamente. ─ Por isso, outra opinião diz, que a ciência,
sendo um hábito, não é chave, mas a autoridade para exercer o ato da ciência. E essa às vezes existe
sem a ciência; às vezes, a ciência, sem ela. Como o demonstram também os juízos seculares; assim, um
juiz secular tem a autoridade de julgar, que não tem a ciência do direito; outro, ao contrário, tem a
ciência do direito, que não tem a autoridade de julgar. E como o ato de julgar, a que está o juiz obrigado
pela autoridade assumida, mas não pela ciência que tem, sem ambos os elementos referidos não pode
exercer-se bem, por isso a autoridade de julgar, que é a chave da ciência, não na podemos receber, sem
a ciência, sob pena de pecado; mas, sem pecar, podemos receber a ciência, sem a autoridade de juiz.

RESPOSTA À TERCEIRA. ─ O poder de consagrar implica só um ato de outro gênero. Por isso não faz
parte do poder das chaves; nem se multiplica como esse poder, que abrange atos diversos. Embora seja
uno quanto à essência do poder ou da autoridade, conforme se disse.

RESPOSTA À QUARTA. ─ A vontade de cada um de nós é livre. Por isso, não é preciso autoridade para
querermos. Eis porque a vontade não é considerada chave.

RESPOSTA À QUINTA. ─ Toda a Trindade, como uma pessoa, é a que perdoa os pecados. Por isso não é
necessário que o sacerdote, ministro da Trindade, tenha três chaves. Sobretudo que a vontade,
apropriada ao Espírito Santo, não exige uma chave, como se disse.