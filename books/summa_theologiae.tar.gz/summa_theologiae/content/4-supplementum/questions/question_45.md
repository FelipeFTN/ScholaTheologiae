# Questão 45: do consentimento matrimonial em si mesmo considerado.
Em seguida devemos tratar do consentimento. E então devemos, primeiro, tratar do consentimento em
si mesmo considerado. Segundo, do consentimento conformado por juramento ou pela conjunção
carnal. Terceiro do consentimento coato e condicional. Quarto, do objeto do consentimento. Na
primeira questão discutem-se cinco artigos:

## Art. 1 — Se o consentimento é causa eficiente do matrimônio.
O primeiro discute-se assim. ─ Parece que o consentimento não é a causa eficiente do matrimônio.

1. Pois, os sacramentos não dependem da vontade humana, mas se fundam numa instituição divina.
Ora, o consentimento depende da vontade humana. Logo, não é a causa do matrimônio, como não o é
de nenhum dos sacramentos.

2. Demais. ─ Nada não pode ser causa de si mesmo. Ora, o matrimônio parece que outra coisa não é
senão o consentimento, pois, é o consentimento mesmo que significa a união de Cristo e da Igreja. Logo,
o consentimento não é a causa do matrimônio.

3. Demais. ─ Cada efeito deve ter a sua causa. Ora, o matrimônio consiste numa relação única entre
duas pessoas, como se disse. Mas, o consentimento de duas pessoas são diversos, por serem elas
diversas e terem objetos diversos; pois, um dos consentimentos é dado ao homem e o outro, à mulher.
Logo, o mútuo consentimento não é a causa do matrimônio.
Mas, em contrário, diz Crisóstomo: Não é na conjunção carnal que consiste o matrimônio, mas no
consentimento da vontade.

2. Demais. ─ Ninguém tem poder sobre o que é de outrem, salvo por consentimento deste. Ora, pelo
matrimônio cada cônjuge recebe poder sobre o corpo do outro, como lemos no Apóstolo; pois, antes,
cada um podia dispor livremente do seu corpo. Logo, o consentimento produz o matrimônio.

SOLUÇÃO. ─ Todos os sacramentos produzem um efeito espiritual, mediante a ação material que tem
como sinal. Assim, a ablução corporal, no batismo, produz a ablução interior e espiritual. Ora, um efeito
do matrimônio, como sacramento é a união espiritual; e a união corporal, enquanto instituição da
natureza e da vida civil. Por onde é necessariamente, como auxílio da virtude divina, produzirá o seu
efeito espiritual graças ao seu efeito material. Logo, como a união material dos contratos se faz pelo
consentimento mútuo, forçoso é que também desse modo se faça a união matrimonial.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A causa primeira do sacramento é a virtude divina, que
neles obra a salvação. Mas as causas segundas instrumentais são as operações materiais, que tiram a
sua eficácia da instituição divina. E assim, o consentimento é a causa do matrimônio.

RESPOSTA À SEGUNDA. ─ O matrimônio não consiste no consentimento mesmo, mas na união de duas
pessoas em vista de um fim comum. E esse é o efeito do consentimento. Nem, no seu sentido próprio,
significa ele a união de Cristo e da Igreja; mas antes, a vontade de Cristo, que quis realizar esta união.

RESPOSTA À TERCEIRA. ─ Assim como o matrimônio é uno em virtude do objeto da união, embora
múltiplo por parte dos cônjuges, assim também o consentimento é uno por parte do objeto sobre que
recai, isto é, a referida união, embora seja múltiplo por parte dos que nele consentiram. Nem o objeto
direto do consentimento da mulher é o varão, mas a união; semelhantemente, o objeto do
consentimento do varão é a união com a esposa.

## Art. 2 — Se é necessário ser o consentimento expresso por palavras.
O segundo discute-se assim. ─ Parece que não é necessário ser o consentimento expresso por
palavras.

1. Pois, assim como pelo matrimônio o homem se sujeita ao poder alheio, assim também pelo voto. Ora,
o voto, mesmo quando não verbalmente expresso, obriga perante Deus. Logo, o consentimento, mesmo
sem ser verbal, torna o matrimônio obrigatório.

2. Demais. ─ Podem contrair matrimônio certos, como os mudos ou os que falam línguas diversas, que
não podem consentir mutuamente por palavras. Logo, a expressão verbal do consentimento não é
necessária para haver matrimônio.

3. Demais. ─ A omissão, por qualquer causa, do necessário à validade do sacramento torna-o não
existente. Ora, o matrimônio pode ser válido, mesmo sem a expressão verbal do consentimento, em
certos casos; assim quando a donzela se cala por pudor, no momento em que os pais a entregarem ao
marido. Logo, a expressão verbal do consentimento não é necessária à validade do matrimônio.
Mas, em contrário, o matrimônio é um sacramento. Ora, todo sacramento supõe um sinal sensível.
Logo, também o matrimônio. Portanto, o casamento supõe um consentimento dado verbalmente.

2. Demais. ─ No matrimônio realiza-se um contrato entre o homem e a mulher. Ora, em qualquer
contrato é necessária a expressão por palavras, pelas quais os contratantes obrigam-se mutuamente.
Logo, também no matrimônio é necessário um consentimento verbal.

SOLUÇÃO. ─ Como do sobredito se colhe, a união matrimonial reveste a mesma forma que as
obrigações contratuais da vida civil. E como esses contratos não podem fazer-se sem os contratantes
manifestarem mutuamente e por meio de palavras a sua vontade, também é necessário que quem faz o
contrato matrimonial manifeste o seu consentimento por palavras. De modo que a expressão verbal
exerça no matrimônio a mesma função que a ablução exterior no batismo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O voto não implica nenhuma obrigação sacramental, mas
só espiritual, Por isso não é necessário, ao contrário do que se dá com o matrimônio que se faça ao
modo dos contratos civis, para obrigar.

RESPOSTA À SEGUNDA. ─ Embora esses tais não possam exprimir por palavras o consentimento
recíproco, podem contudo fazê-lo por meio de sinais. E estes se consideram como se foram palavras.

RESPOSTA À TERCEIRA. ─ Como diz Hugo Vitorino, os que se unem pelo matrimônio hão de consentir de
modo que se recebam mútua e espontaneamente; e presume-se que o fizeram se não se opuserem aos
desposórios. Por isso, as palavras dos pais se consideram, nesse caso, como pronunciadas pela noiva;
desde que não se lhes opõe, dá sinal evidente que as faz suas.

## Art. 3 — Se o consentimento expresso sob forma de promessa para o futuro tem como efeito o matrimônio.
O terceiro discute-se assim. ─ Parece que o consentimento expresso sob forma de promessa para o
futuro tem como efeito o matrimônio.

1. Pois, assim está o presente para o presente como o futuro para o futuro. Ora, o consentimento por
palavras de presente causa imediatamente o casamento. Logo, o consentimento expresso verbalmente
para um casamento futuro, tem-no como efeito futuro.

2. Demais. ─ Assim como as palavras que exprimem o consentimento tornam obrigatório o matrimônio,
o mesmo também se dá com os outros contratos civis. Ora, nos outros contratos não importa se a
obrigação nasce imediatamente depois de o consentimento verbal ser dado, ou se só no futuro. Logo,
nem ao matrimônio o importa.

3. Demais. ─ Pelo voto de religião o homem contrai um matrimônio espiritual com Deus. Ora, o voto de
religião se faz por palavras que implicam promessa futura, e obriga. Logo e semelhantemente, o
matrimônio carnal pode fazer-se por palavras que prometem uma obrigação futura.
Mas, em contrário, quem promete casar-se futuramente com uma determinada mulher e depois
consente, por palavras de presente, a casar-se com outra, deve, pelo direito, receber como esposa a
última. Ora, tal não se daria se a promessa consecutiva de um casamento futuro causasse o matrimônio
; pois, desde que o matrimônio foi contraído com uma, não pode, durante a vida dela, ser contraído com
outra. Logo, o consentimento numa promessa de casamento futuro não causa o matrimônio.

2. Demais. - Quem promete que fará alguma coisa ainda não o fez. Ora, quem verbalmente consente
numa promessa de casamento futuro, promete contrair casamento com uma determinada mulher.
Logo, é que ainda com ela não o contraiu.

SOLUÇÃO. ─ Os sacramentos, como causas, são sinais eficazes: por isso realmente causam o que
significam. Ora, quem exprime o seu consentimento verbalmente de realizar no futuro um casamento,
não significa com isso que contrai o matrimônio, mas sim que há de contraí-lo. Por isso, tal expressão do
consentimento não causa o matrimônio, mas só a sua promessa, que se chama esponsais.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Quando o consentimento se exprime por palavras de
presente, tanto as palavras se pronunciam, no presente, como o consentimento é dado para o mesmo
tempo presente, mas quando se consente verbalmente num compromisso futuro, as palavras se
pronunciam, no presente, mas o consentimento se refere ao futuro. Logo, não coincidem os tempos, E
portanto o símile não colhe.

RESPOSTA À SEGUNDA. ─ Mesmo nos outros contratos, falando do futuro não transmitimos a outrem
nenhum direito sobre o que é nosso como se dissermos ─ Eu te darei; mas só quando falamos no tempo
presente.

RESPOSTA À TERCEIRA. ─ No voto de profissão, o ato do casamento espiritual é expresso por palavras,
que exprimem uma realização futura, a saber, a obediência ou a observância da regra; e não o
matrimônio mesmo espiritual. Se porém o voto for de um casamento espiritual futuro, não existirá tal
matrimônio; porque quem o fez não fica sendo monge por isso, mas promete apenas que o será no
futuro.

## Art. 4 — Se o consentimento, mesmo expresso por palavras de presente, produz o matrimônio embora falte e consentimento interior.
O quarto discute-se assim. ─ Parece que o consentimento, mesmo expresso por palavras de presente,
produz o matrimônio embora falte o consentimento interior.

1. Pois, o direito proíbe que se tire proveito da fraude e do dono. Ora, quem exprime verbalmente um
consentimento, que não tem a intenção de dar, pratica o dolo. Logo, não pode valer-se disso para fugir à
obrigação de casar.

2. Demais. ─ O nosso consentimento mental de ninguém pode ser conhecido, senão se o exprimirmos
verbalmente. Se, pois, á expressão verbal não basta, sendo além dela necessário o consentimento
anterior de cada cônjuge, então nenhum deles poderá saber com certeza se esta verdadeiramente
casado. Portanto, praticará a fornicação todas as vezes que usar do matrimônio.
3 . Demais. ─ Provando-se de alguém, que consentiu em se casar com uma mulher, por palavras de
presente, ficará obrigado, sob pena de sentença de excomunhão, a tê-la como esposa, embora alegue
falta de consentimento interior; ainda se depois tiver dado o seu consentimento mental expresso
verbalmente, de se casar com outra. Ora, tal não se daria se para haver matrimônio fosse necessário o
consentimento mental. Logo, não é necessário.
Mas, em contrário, determina Inocêncio III numa decretal, referindo-se a este caso: sem o
consentimento, tudo o mais não vale nada para estabelecer o vínculo conjugal.

2. Demais. ─ Todos os sacramento supõem a intenção de os receber. Ora, quem mentalmente não
consente não tem a intenção de contrair matrimônio. Logo, sem esse consentimento não existe o
matrimônio.

SOLUÇÃO. ─ Assim está a solução exterior para o batismo, como a expressão das palavras para este
sacramento. Ora, quem se submetesse à ablução exterior, sem a intenção de receber o sacramento,
procederia irrisória e dolosamente e não ficaria batizado. Do mesmo modo, pronunciar apenas as
palavras, que exprimem o consentimento, sem o dar interiormente, não produz o liame matrimonial.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ No caso proposto devemos distinguir duas coisas. A falta
de consentimento, que aproveita no foro da consciência, para o efeito de o eximir-se ao vínculo
matrimonial, embora não se aproveite no foro eclesiástico, onde se julga de acordo com o alegado. E o
dolo verbal, que não lhe aproveita nem no foro da consciência nem no eclesiástico, pois em ambos será
punido.

RESPOSTA À SEGUNDA. ─ Faltando o consentimento interno por parte de um, não haverá matrimônio
de lado a lado, pois este consiste na união mútua, somo dissemos. Contudo, podemos crer com
probabilidade, que não houve dolo, antes de se este manifestar por sinais evidentes. Pois, de todos
devemos presumir o bem, até prova em contrário. Por onde, a parte não culpada de dolo fica, por
ignorância, escusada do pecado.

RESPOSTA À TERCEIRA. ─ Nesse caso, a Igreja o compelirá a ficar com a primeira esposa, pois o tribunal
eclesiástico julga pelo que exteriormente se manifesta. Nem se engana em matéria de justiça e de
direito, embora possa enganar-se quanto ao fato. Mas o marido deve, antes, sofrer a excomunhão, que
retomar a primeira mulher, ou então fugir para uma região longínqua.

## Art. 5 — Se o consentimento dado às ocultas por palavras de presente dá lugar ao matrimônio.
O quinto discute-se assim. ─ Parece que o consentimento dado às ocultas por palavras de presente
não dá lugar ao matrimônio.

1. Pois, uma coisa não pode ser transferida das mãos do seu dono para outrem, senão com o
consentimento daquele. Ora, uma donzela está sob o poder do pai. Logo, não pode pelo casamento
passar para o poder do marido senão com o consentimento do pai. Portanto, se o consentimento foi
dado às ocultas, mesmo expresso por palavras de presente, não haverá matrimônio.

2. Demais. ─ Tanto no matrimônio como na penitência, o nosso ato ir exigido pela essência mesma do
matrimônio. Ora; o sacramento da penitência requer a intervenção dos ministros da Igreja, dispensa
dores dos salvamentos. Logo, nem o matrimônio pode ser celebrado às ocultas, sem a bênção
sacerdotal.

3. Demais. ─ O batismo, que pode ser ministrado tanto às ocultas como em público, a Igreja não proíbe
que o seja às ocultas. Ora, a Igreja proíbe os matrimônios clandestinos, Logo, não podem fazer-se às
ocultas.

4. Demais. ─ Parentes em segundo grau não podem contrair matrimônio, porque a Igreja o proíbe. Ora,
a Igreja também proíbe os matrimônios clandestinos. Logo, não podem ser estes verdadeiros
matrimônios.
Mas, em contrário. ─ Posta a causa, segue-se o efeito. Ora, a causa do matrimônio é o consentimento.
Logo, quer em público, quer às ocultas, o matrimônio é valido.

2. Demais. ─ Todo sacramento é valido desde que foi ministrado com a matéria e a forma devidas. Ora,
mesmo quando celebrado às ocultas o matrimônio tem a sua matéria própria, que são as pessoas
capazes de o contrair; e a forma devida, que são as palavras de presente, expressivas do consentimento.
Logo, tal casamento verdadeiramente o é.

SOLUÇÃO. ─ Os outros sacramentos requerem, em essência, certos elementos sem os quais não
existem; e certas solenidades, sem as quais contudo o sacramento é válido, embora peque aquele que
as omitiu. Assim também, o consentimento expresso por palavras de presente, entre pessoas idôneas
para contrair o matrimônio, têem-no realmente por feito, porque essas duas são condições essenciais à
validade desse sacramento. O mais constitui apenas solenidades dele, acrescentadas para que se
celebre mais convenientemente. Por isso, embora omitidas, o matrimônio é verdadeiro, não obstante
pecarem os que assim o contraírem; salvo havendo a escusa de uma causa legítima.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A donzela não está em poder do pai como escrava, de
modo a não poder dispor do seu corpo, mas para, como filha, receber educação. Logo, como livre que é,
pode entregar-se ao poder de outrem, sem o consentimento paterno. Assim como também qualquer
moça ou moço pode sendo pessoa livre, entrar em religião, sem o consentimento dos pais.

RESPOSTA À SEGUNDA. ─ Embora o nosso ato seja da essência do sacramento da penitência, não basta
contudo para produzir a absolvição dos pecados, efeito próximo desse sacramento. Por isso, é
necessária a intervenção do sacerdote, para a perfeição do sacramento. Ora, no matrimônio os nossos
atos são suficientes para produzir o liame matrimonial, efeito próximo do sacramento. Pois, quem pode
dispor de si pode obrigar-se para com outrem. Por isso a bênção do sacerdote não é da essência do
sacramento.

RESPOSTA À TERCEIRA. ─ Também é proibido receber-se o batismo de outrem que não o sacerdote,
salvo em artigo de necessidade. Ora, o matrimônio não é um sacramento de necessidade para a
salvação. Logo, não há semelhança de razões. ─ Quanto aos matrimônios clandestinos, são proibidos
pelos perigos que daí costumam resultar. Pois frequentemente há neles fraude de uma das partes.
Frequentemente também os contraentes passam a outras núpcias, arrependidos do que fizeram sem
reflexão. E muitos outros males ainda sobrevêm, além de terem algo de repugnante.

RESPOSTA À QUARTA. ─ Os matrimônios clandestinos não são proibidos, por encontrarem o que é da
essência do matrimônio, como o são os de pessoas inidôneas, matéria imprópria deste sacramento.
Logo, não há símile.