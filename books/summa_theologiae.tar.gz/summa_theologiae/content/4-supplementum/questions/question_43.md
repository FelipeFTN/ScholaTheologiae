# Questão 43: Do matrimônio e dos esponsais.
Em seguida devemos tratar do matrimônio absolutamente considerado. E a propósito, devemos tratar
primeiro dos esponsais. Segundo, da definição do casamento. Terceiro, do consentimento como sua
causa eficiente. Quarto, dos seus bens. Quinto, dos seus impedimentos. Sexto, das segundas núpcias.
Sétimo, de certos anexos do matrimônio.
Na primeira questão discutem-se três artigos:

## Art. 1 — Se se definem bem os esponsais, dizendo que são a promessa das núpcias futuras.
O primeiro discute-se assim. ─ Parece que não se definem bem os esponsais, dizendo que são a
promessa de núpcias futuras, como se conclui das palavras do Papa Nicolau I.

1. Pois, como diz Isidoro, não é esposo quem promete mas quem afiança (spondet) e dá fiadores
(sponsores). Ora, esposo vem de esponsais. Logo, é definir mal dizer promessa.

2. Demais. ─ Quem faz uma promessa deve ser obrigado a cumpri-la. Ora, os que contraíram esponsais
não os obriga a Igreja a contrair matrimônio. Logo, os esponsais não são promessa.

3. Demais. ─ Muitas vezes os esponsais não constituem só uma promessa, mas se lhe acrescenta um
juramento e se dão arras. Logo, parece que não deviam ser definidos apenas como promessa.

4. Demais. ─ O casamento deve ser livre e sem condições. Ora, os esponsais às vezes se fazem
condicionalmente, mesmo com a condição de receber uma soma de dinheiro. Logo, não é acertado falar
em promessa de núpcias.

5. Demais. ─ Fazer promessa de coisas futuras é digno de censuras, diz o Apóstolo Tiago. Ora, os
sacramentos nada devem ter de censurável. Logo, não deve ser feita promessa de futuras núpcias.

6. Demais. ─ Ninguém se chama esposo senão por causa dos esponsais. Ora, pode chamar-se esposo
também quem celebra o seu casamento, segundo o Mestre das Sentenças. Logo, os esponsais nem
sempre são a promessa das núpcias futuras.

SOLUÇÃO. ─ Consentir na união conjugal, por compromisso a se realizar no futuro, não constitui
sacramento, mas só promessa dele. E essa promessa se chama esponsais, do verbo latino spondeo.
Assim, diz Isidoro: anteriormente ao uso de se tornar público o casamento, davam cauções e fiadores os
que queriam casar-se, comprometendo dessa maneira mutuamente a contrair matrimônio. Ora, esse
compromisso se faz de dois modos: absoluta e condicionalmente. Absolutamente, de quatro modos.
Primeiro, com uma simples promessa, como quando se diz: Eu te receberei como esposa minha, e vice-
versa. Segundo, dando-se arras esponsalicias, como dinheiro ou coisas semelhantes. Terceiro, por meio
do juramento. Se porém a referida promessa é feita condicionalmente, devemos distinguir ou a
condição é honesta, como quando se diz: Eu te receberei se aprouver a meus pais; e então, vigorando a
condição vigora a promessa, e não vigorando aquela também não pode vigorar a última. Ou é
desonesta, e de dois modos o pode ser. Ou é contrária aos bens do casamento, como se disser: Eu te
receberei se me deres um veneno para que fique estéril. ─ e então os esponsais não se contraem. Ou
não é contrária aos bens do matrimônio, como se disser: Eu te receberei se consentires nos meus furtos,
e então a promessa subsiste, mas não deve ser cumprida a condição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Os próprios esponsais e a dação de fiadores é
confirmação da promessa. Por isso se chamam esponsais a essa promessa, indicando assim o que há
nela de mais perfeito.

RESPOSTA À SEGUNDA. ─ Por força dessa promessa fica um obrigado a contrair matrimônio com o
outro; e peca mortalmente quem não a cumprir, salvo se intervier um legítimo impedimento. Por isso, a
Igreja obriga ao cumprimento da promessa, impondo penitência em caso contrário, pelo pecado
cometido. Não há porém nenhuma coação no foro contencioso, porque os matrimônios coactos
costumam dar maus resultados. ─ Salvo se intervier o juramento. Porque então, na opinião de certos,
quem prometeu deve ser coagido a cumprir a promessa. Embora isso não pareça a outros, pela razão
sobredita, sobretudo se se teme um uxoricídio.

RESPOSTA À TERCEIRA. ─ Esses acréscimos à promessa não servem senão de confirmá-la. Por isso não
diferem dela.

RESPOSTA À QUARTA. ─ Essa condição acrescentada não elimina do matrimônio a liberdade. Pois,
sendo desonesta, deve ser rejeitada. Se honesta, ou é em si mesma um bem, como quando se diz ─ Eu
te receberei, se aprouver a meus pais, e essa condição não tira a liberdade aos esponsais e, antes,
aumenta-lhes a honestidade. Ou representa um interesse, como quando se diz ─ Contrairei matrimônio
contigo se me deres cem; e então essa condição não se entende como venda do consentimento ao
matrimônio, mas como promessa de dote; por onde, não priva o casamento de ser livre. Às vezes porém
acrescenta-se uma condição a modo de pena. E então, como o matrimônio deve ser livre, essa condição
não tem valor; nem se pode exigir o cumprimento dessa pena, de quem não quiser realizá-lo.

RESPOSTA À QUINTA. ─ Tiago não tem a intenção de proibir a ninguém fazer qualquer promessa, a ser
cumprida no futuro; mas de a fazermos como se estivéssemos certos de viver sempre. Ensina por isso,
que se deve acrescentar a condição ─ se Deus quiser, a qual embora não expressa por palavras deve sê-
lo contudo de coração.

RESPOSTA À SEXTA. ─ No casamento podemos distinguir duas coisas: a união matrimonial em si mesma
e o seu ato. A promessa verbal de consentir mais tarde na união matrimonial ou esponsais, deu origem
ao nome de esposo. A segunda espécie de promessa torna esposo mesmo quem contratou casamento
por palavras presentemente ditas; pois, por isso mesmo promete o ato do matrimônio. Contudo, os atos
da primeira espécie é que produzem os esponsais propriamente ditos, que são uns sacramentais do
matrimônio, como o exorcismo, do batismo.

## Art. 2 — Se a idade de sete anos foi acertadamente determinada para se poderem contrair esponsais.
O segundo discute-se assim. ─ Parece que a idade de sete anos não foi acertadamente determinada
para se poderem contrair esponsais.

1. Pois, contratos que se podem fazer por meio de terceiros não exigem idade de discernimento nos
interessados. Ora, os esponsais podem fazer-se por meio dos pais, sem que eles saibam quem os
contratam. Logo, podem fazer-se, tanto antes como depois dos sete anos.
2 . Demais. ─ Assim como o contrato de esponsais requer um certo uso da razão, assim também esse
uso é necessário para que se possa consentir no pecado. Ora, como o narra Gregório, uma criança de
cinco anos foi morta pelo diabo por causa de um pecado de blasfêmia. Logo, também antes dos sete
anos podem-se contratar esponsais.

3. Demais. ─ Os esponsais se ordenam para o matrimônio. Ora, a idade própria para contrair matrimônio
não é a mesma para o homem e para a mulher. Logo, também não se deve marcar a idade ele sete anos,
para se poderem contrair esponsais, para ambos os sexos.

4. Demais. ─ Podem contrair esponsais os que podem se inclinar a núpcias futuras. Ora, essa inclinação
frequentemente se manifesta em crianças antes dos sete anos. Logo, antes dessa idade podem contrair
esponsais.

5. Demais. ─ Consideram-se como existentes os esponsais entre os que os contraíram antes dos sete
anos; e depois, o tornam o contrair por palavras de presente, mas antes da idade de puberdade. Mas
essa validade não resulta do segundo contrato, porque então tinham a intenção de contrair, não
esponsais, mas o matrimônio. Logo, também tinham essa intenção quando primeiro os contraíram.
Portanto, podem contrair esponsais antes dos sete anos.

6. Demais. ─ Quando uma ação é realizada por vários agentes, a falha de um é suprida por outro; por
exemplo, quando vários puxam um navio. Ora, o ato dos esponsais é um ato comum entre vários
contratantes. Logo, sendo um púbere, pode contrair esponsais com uma menina que ainda não tem
sete anos; e assim, a idade que falta a esta é suprida pelo outro.

7. Demais. ─ Considera-se como válido o matrimônio contraído por palavras de presente, entre os que
ainda não estão na idade de puberdade, embora estejam próximos dela. Logo, e pela mesma razão, se o
fizerem antes dos sete anos, mas próximo deles, e tendo em vista um casamento futuro, consideram-se
como realmente existentes entre eles os esponsais.

SOLUÇÃO. ─ A idade de sete anos é o tempo determinado por direito, e bastante racionavelmente, para
se poderem contrair esponsais. Pois, sendo os esponsais umas promessas para o futuro, como dissemos,
necessariamente, podem fazê-lo só aqueles que de certa maneira podem prometer. E isto não é possível
senão aos que de algum modo podem prever o futuro, o que implica o uso da razão. Ora, no uso da
razão há três graus, segundo o Filósofo. No primeiro, a criança não pode compreender nem por si nem
ajudada por outro. No segundo, pode o homem compreender por ajuda de outro, mas ainda não é
capaz de por si mesmo o fazer. No terceiro, pode compreender por meio de outrem e por si mesmo
refletir. E como a razão humana se desenvolve gradualmente, na medida em que se aquietam os
movimentos as variações dos humores, por isso, a primeira fase da vida da razão do homem é antes da
idade de sete anos, idade em que não tem capacidade para fazer nenhum contrato e, por consequência,
nem esponsais. Na segunda fase já ele vai chegando, ao fim do primeiro setênio e é nessa idade que as
crianças são mandadas à escola. A terceira fase é aquela a que o homem chega ao termo do segundo
setênio, quando já pode assumir obrigações pessoais e quando a razão natural mais depressa se
desenvolve. Mas se se trata de obras externas o homem não chega a raciocinar bem senão ao cabo do
terceiro setênio. Por isso, antes do primeiro setênio não é apto a fazer nenhum contrato. Mas, ao cabo
do primeiro setênio já começa a ser apto a se comprometer para o futuro, em matéria a que sobretudo
a razão natural inclina. Como porém ainda não lhe é firme a vontade, não pode obrigar-se a vínculo
perpétuo. Por isso, nessa idade pode contrair esponsais. Mas no fim do segundo setênio já pode assumir
as obrigações pessoais, de entrar em religião ou contrair matrimônio. E no fim do terceiro setênio pode
assumir também outras obrigações. Por isso as leis lhe dão o poder de dispor dos seus bens depois dos
vinte e cinco anos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Se o contrato de esponsais for feito por terceiro antes de
os contraentes chegarem à idade de pubedade, ambos podem reclamar, ou um só. Fica então tudo nulo,
a ponto que nenhuma afinidade daí resultará. Por isso os esponsais contraídos por interpostas pessoas
valem só se os contraentes, chegados a idade própria, não reclamarem. Se não o fizerem então, são
considerados como tendo consentido no que por outros foi feito.

RESPOSTA À SEGUNDA. ─ Certos dizem que essa criança a que se refere Gregório não se condenou nem
pecou mortalmente, sendo essa visão só para contristar o pai, que nesse filho pecou pelo não corrigir.
Mas isso vai expressamente contra a intenção de Gregório que diz: O pai da criança descuidando da
alma de seu filhinho, criou para o fogo do inferno um pecador não pequeno. ─ Por onde, devemos
concluir que para haver pecado mortal basta o consentimento para a prática imediata de um ato. Mas o
consentimento nos esponsais visa o futuro. Ora, é preciso maior discernimento da razão para prever o
futuro, do que para consentir num ato presente. Por onde, pode pecar mortalmente quem ainda não
pode obrigar-se para o futuro.

RESPOSTA À TERCEIRA. ─ Para se contrair matrimônio é não só necessário um certo desenvolvimento
da razão, mas também do corpo, de modo que este seja apto à geração. Ora, a mulher aos doze anos já
é apta para a geração, e o homem ao fim do segundo setênio, como ensina o Filósofo. Mas chegam
simultâneamente à idade de discernimento racional, condição exigida para poderem contrair esponsais.
Por isso a mesma idade é determinada para ambos os poderem contrair, não sendo porém a mesma
para poderem contrair matrimônio.

RESPOSTA À QUARTA. ─ Essa inclinação das crianças antes dos sete anos, não procede do perfeito uso
da razão, pois ainda não são nessa idade capazes de plena instrução; mas tal inclinação procede antes
do movimento da natureza que de qualquer reflexão. Por isso não basta ela para se poderem contrair
esponsais.

RESPOSTA À QUINTA. ─ Embora no caso referido não contraiu o matrimônio pelo segundo contrato,
mostram contudo por si que ratificam a promessa anterior. Por isso o primeiro contrato fica reforçado
pelo segundo.

RESPOSTA À SEXTA. - Os que puxam um barco agem como se fossem uma só causa; por isso o que falta
a um pode ser suprido por outro. Ao contrário, os que contraem esponsais agem como pessoas
distintas, pois não podem eles existir senão entre dois. Por isso é necessário sejam ambos capazes de
contratar. E assim, a incapacidade de um impede os esponsais, nem pode ser suprida por outro.

RESPOSTA À SÉTIMA. ─ O mesmo se dá com os esponsais: se os contraentes já se aproximam dos sete
anos o contrato de esponsais é válido. Pois, segundo o Filósofo, faltar pouco é quase como não faltar
nada. Quanto a essa proximidade, certos a determinam como sendo o tempo de seis meses Mas é
melhor determiná-la pela condição dos contraentes, pois certos tem um desenvolvimento mais precoce
da razão que outros.

## Art. 3 — Se os esponsais podem ser dirimidos.
O terceiro discute-se assim. ─ Parece que os esponsais não podem ser dirimidos, quando uma das
partes entra em religião.

1. Pois quem prometeu uma soma de dinheiro a alguém não pode de novo se obrigar a dá-la a outrem.
Ora, quem contrai esponsais prometeu o seu corpo a uma mulher. Logo, não pode depois oferecer-se a
Deus em religião.

2. Do mesmo modo. ─ Não podem os esponsais ser dirimidos, segundo parece, quando um dos
contraentes se transfere para uma região longínqua. Porque, na dúvida devemos seguir sempre o
partido mais seguro. Ora, mais seguro seria esperar a volta do ausente. Logo, há obrigação de o esperar.

3. Do mesmo modo. ─ Nem se dirimem os esponsais por motivo de doença sobreveniente depois de
contraídos. Porque por doença ninguém deve ser punido. Ora, o varão, se enfermar, sofre uma pena
ficando privado do direito que tenha sobre aquela com que já havia contraído esponsais. Logo, as
doenças do corpo não dirimem os esponsais.

4. Do mesmo modo. ─ Nem pela afinidade superveniente; por exemplo, se o esposo teve concúbito
ilícito com uma irmã da esposa. Porque então a esposa seria punida pelo pecado do esposo. O que não é
admissível.

5. Do mesmo modo. ─ Os esposos também não podem se desobrigar mutuamente. Pois, seria o cúmulo
da leviandade contrair esponsais para depois os romper. Nem a Igreja pode permitir tais abusos. Logo,
etc.

6. Do mesmo modo. ─ Nem a fornicação de um dos esposos é razão para se romperem os esponsais.
Pois, os esponsais não dão ainda direito a um dos esposos sobre o corpo do outro. Donde, nenhum peca
contra o outro cometendo fornicação. Razão pois não é essa para se dirimirem os esponsais.

7. Do mesmo modo. ─ Nem parece que se dirimem por contrato que o esposo fizer com outra por
palavras de presente. Pois, uma segunda venda não anula a anterior. Logo, nem um segundo contrato
pode derrogar o anterior.

8. Do mesmo modo. ─ Nem por falta de idade podem dirimir-se. Pois, o inexistente não pode ser
dissolvido. Ora, antes da idade própria nenhuns esponsais existem, Logo, não podem ser dirimidos.

SOLUÇÃO. ─ Em todos os casos referidos os esponsais se dirimem, mas de modos diversos. Assim, nos
dois primeiros ─ quando um entra em religião, e quando um contrata com outro por palavras de
presente, os esponsais se dirimem de pleno direito. Nos outros casos porém podem dirimir-se segundo
o juízo da Igreja.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Essa promessa sendo puramente espiritual, se dissolve
pela morte espiritual.

RESPOSTA À SEGUNDA. ─ Essa dúvida fica resolvida desde que uma das partes não comparece no
tempo determinado, para realizar o matrimônio. Por onde, a parte que não teve culpa de não se realizar
o matrimônio, pode licitamente e sem nenhum pecado casar com outro. Se porém teve culpa da não
realização do casamento, deve fazer penitência pelo pecado de quebra da promessa ou do juramento,
se houve juramento; e poderá contrair casamento com outra pessoa, se quiser, conforme juízo da Igreja.

RESPOSTA À TERCEIRA. ─ Pode acontecer que, antes de contraído o matrimônio, um dos que
contraíram esponsais tenha incorrido em doença grave; por exemplo, a epilepsia ou a paralisia, e caído
em estado de extrema fraqueza; tenha sofrido uma deformidade, como a amputação do nariz, a
privação da vista ou coisa semelhante. Ou ainda uma doença contra o bem da prole, como a lepra que
de ordinário contamina os filhos. Em tais casos os esponsais podem ser dirimidos a fim de não ser um
esposo objeto de repugnância ao outro e não produzir más consequências o casamento contraído em
tais condições. Nem se segue daí que haja punição por causa de uma doença, que apenas causa um
dano não injusto. E nisso não há nenhum inconveniente.

RESPOSTA À QUARTA. ─ Se o esposo teve relação ilícita com irmã da esposa, ou ao contrário, os
esponsais devem ser dirimidos. E para o provar basta o rumor público, pois é necessário evitar
escândalo. Porquanto, uma causa, que deve produzir os seus efeitos no futuro, fica impedida de os
produzir não só por um obstáculo presente, mas também por obstáculos futuros. Por onde, assim como
a afinidade, se já houvesse idade para o contrato esponsalício, impediria esse contrato; assim também,
intervindo antes do matrimônio, que é um dos efeitos dos esponsais, fica o primeiro contrato impedido
de produzir o seu efeito. Nem por isso prejudica a uma das partes, ao contrário, a favorece, porque fica
liberada pela outra que, cometendo a fornicação, torna-se odiosa a Deus.

RESPOSTA À QUINTA. ─ Certos não admitem esse caso. Mas em contrário é uma decretal, que dispõe
expressamente: Por semelhança, diz, com aqueles que depois de ser terem constituído em sociedade,
prometendo-se fidelidade recíproca, vieram rompê-la, pode-se também pacientemente tolerar, que
rompam os seus esponsais os que os contraíram. E para fundamentar este juízo, dizem que a Igreja o
suporta, preferindo não recatar um ponto de direito, para evitar maior mal. Mas esta razão não condiz
com o exemplo aduzido pelas decretais. É por isso melhor concluir que nem sempre é leviandade não
cumprir o que foi prometido; pois, são incertas as nossas providências, como diz a Escritura.

RESPOTA À SEXTA. ─ Embora os que contraíram esposais ainda não tenham conferido reciprocamente
poder sobre seus corpos, contudo, já o fato de terem faltado ao prometido, um ou outro, faz suspeitar
que não serão fiéis no futuro. Por isso um toma precauções contra o outro, dirimindo os esponsais.

RESPOSTA À SÉTIMA. ─ A objeção colheria se ambos os contratos tivessem o mesmo fundamento. Ora,
o segundo contrato, o de casamento, tem mais força que o primeiro. Por isso o anula.

RESPOSTA À OITAVA. ─ No caso, embora não houvesse verdadeiramente esponsais, houve contudo
uma certa modalidade deles. Por isso, para não parecer que o aprovaram, uma vez chegados à idade
legítima devem os esposos, para dar bom exemplo, pedir ao juiz eclesiástico a ruptura dos esponsais.