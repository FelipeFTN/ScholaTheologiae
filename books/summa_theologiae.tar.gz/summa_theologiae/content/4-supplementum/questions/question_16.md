# Questão 16: Dos que recebem o sacramento da penitência.
Em seguida devemos tratar dos que recebem o sacramento da penitência.
E nesta questão discutem-se três artigos:

## Art. 1 — Se pode haver penitência para os inocentes.
O primeiro discute-se assim. ─ Parece que não pode haver penitência para os inocentes.

1. ─ Pois, a penitência consiste em chorar os pecados cometidos. Ora, os inocentes não cometeram
nenhum pecado. Logo, não devem fazer penitência.

2. Demais. ─ A penitência, como o próprio nome o indica, implica a pena. Ora, os inocentes não
merecem nenhuma pena. Logo, não deve haver penitência para eles.

3. Demais. ─ A penitência significa o mesmo que a justiça vindicativa. Ora, se todos fossem inocentes,
não haveria lugar para a justiça vindicativa. Logo, nem a penitência. E portanto não a devem fazer os
inocentes.
Mas, em contrário. ─ Todas as virtudes são infundidas simultaneamente. Ora, a penitência é uma
virtude. Logo, como pelo batismo se infundem nos inocentes as outras virtudes, infunde-se-lhes
também a da penitência.

2. Demais. ─ Todo homem que nunca esteve doente é, não obstante, susceptível de ser curado. Logo,
por semelhança, também aquele que nunca esteve doente espiritualmente. Ora, a cura atual das chagas
do pecado não é possível senão pelo ato da penitência; e portanto, também a susceptibilidade de o ser
só é possível pelo hábito. Logo, quem nunca contraiu a enfermidade do pecado tem o hábito de
penitência.

SOLUÇÃO. ─ O hábito é uma mediedade entre a potência e o ato. Mas, como removido o anterior
removido também fica o posterior, não porém inversamente, por isso, removida a potência para o ato,
removido fica o hábito, mas não se for removido o ato. E como a disparição da matéria faz desaparecer
o ato, porque o ato não pode existir sem a matéria sobre a qual recai, por isso o hábito de uma virtude
pode existir em a matéria, mas pode atualizar-se desde que a matéria exista. Assim, um pobre pode
praticar a magnificência habitual, mas não atualmente, por não ter a abundância das riquezas, que são a
matéria da magnificência; mas pode tê-la. Por onde, os inocentes no estado de inocência não tendo
cometido pecados, que são a matéria da penitência, mas podendo cometê-los, não podem praticar a
penitência atualmente, mas só habitualmente. E isso se tiverem a graça com a qual se infundem todas
as virtudes.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora os inocentes não tenham cometido o pecado
poderão contudo cometê-lo. Por isso lhes cabe o hábito da penitência. Mas esse hábito não poderá
nunca atualizar-se senão talvez em relação aos pecados veniais, porque os mortais o destroem. Mas
nem por isso é vão, pois é a perfeição de uma potência natural.

RESPOSTA À SEGUNDA. ─ Embora aos inocentes não seja devida uma pena atual, pode contudo neles
haver qualquer causa pela qual mereçam uma pena.

RESPOSTA À TERCEIRA. ─ Enquanto existir o poder de pecar, ainda haverá lugar para a Justiça
vindicativa quanto ao hábito; embora não quanto ao ato, se não havendo pecados atuais.

## Art. 2 — Se os santos que estão na glória são susceptíveis de penitência.
O segundo discute-se assim. ─ Parece que os santos que estão na glória não são susceptíveis de
penitência.

1. ─ Pois, diz Gregório: Os bem aventurados recordam-se dos pecados, assim como quando estamos
sãos e sem dores nos recordamos das dores. Ora, a penitência é a dor do coração. Logo, os bem
aventurados na pátria não são susceptíveis de penitência.

2. Demais. ─ Os santos na pátria se conformam com Cristo. Ora, Cristo não era susceptível de penitência,
por que não o era da fé que é o princípio da penitência. Logo, os santos na pátria também não são
susceptíveis de penitência.

3. Demais. ─ Vão é o hábito que não se reduz ao ato. Ora, os santos na pátria não farão penitência de
nenhum ato, porque então teriam algum desejo contrariado. Logo, não haverá neles o hábito da
penitência. Mas, em contrário. ─ A penitência faz parte da justiça. Ora, a justiça é perpétua e imortal e
permanecerá na pátria. Logo, também a penitência.

4. Demais. ─ Nas Vidas dos Padres se lê ter dito um deles, que o próprio Abraão se penitenciara por não
ter feito mais bem. Ora devemos nos penitenciar, antes, do mal cometido que do bem omitido, ao qual
não estávamos obrigados pois, desse bem é que se trata. Logo haverá no céu penitência pelos males
cometidos.

SOLUÇÃO. ─ As virtudes cardeais continuarão a existir na pátria, mas como atos cujo fim já foi atingido.
Por onde, sendo a virtude da penitência parte da justiça, que é uma virtude cardeal, quem quer que
tenha o hábito da penitência nesta vida te-lo-á também na futura; mas não praticará o mesmo ato que
então praticava, senão outro, isto é, o de dar graças a Deus pela misericórdia com que perdoou os
pecados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A autoridade citada prova que não praticam o mesmo ato
que é, nesta vida, o da penitência. E isso o concedemos.

RESPOSTA À SEGUNDA. ─ Cristo não podia pecar. Por isso não lhe cabia a matéria desta virtude, nem
em ato nem em potência. E por isso não há semelhança entre ele e os demais.

RESPOSTA À TERCEIRA. ─ Fazer penitência, propriamente falando, enquanto significa o ato da
penitência como nesta vida o praticamos, tal não haverá na pátria. Nem por isso contudo o hábito dela
terá sido vão, porque lhe corresponderá outro ato.
A quarta concedemos.
Mas, como a quinta objeção diz, que na pátria o ato de penitência será o mesmo desta vida, por isso
respondamos à quinta. ─ A nossa vontade na pátria será absolutamente conforme com a vontade de
Deus. Por onde, como Deus, por uma vontade antecedente, quer que todas as coisas sejam boas, e por
consequência não quer nenhum mal, não o querendo porém por uma vontade consequente, o mesmo
se dá com os bem aventurados. E essa vontade é impropriamente chamada penitência pelo referido
santo Padre.

## Art. 3 — Se também o anjo, bom ou mau, é susceptível da penitência.
O terceiro discute-se assim. ─ Parece que também o anjo, bom ou mal, é susceptível da penitência.

1. ─ Pois, o temor é o início da penitência. Ora, neles há temor, conforme aquilo da Escritura: os
demônios crêem e temem. Logo, são susceptíveis de penitência.

2. Demais. ─ O Filósofo diz que os maus estão cheios de arrependimento, e essa lhes é a pena máxima.
Ora, os demônios são os maus por excelência, nem lhes falta nenhuma pena. Logo, podem fazer
penitência.

3. Demais. ─ Um ser se move mais facilmente para o que lhe é natural que para o que lhe contraria a
natureza; assim, a água, aquecida, por violência, também por si mesmo volta à sua propriedade natural.
Ora, os anjos podem cair em pecado, o que lhes contraria a natureza comum. Logo, com maior razão,
podem voltar ao que lhes é natural. E isso o fazem pela penitência. Logo, são susceptíveis de penitência.

4. Demais. ─ Segundo Damasceno, o que dizemos dos anjos podemos também dizer das almas
separadas. Ora, como certos dizem, as almas separadas ─ tais as almas bem aventuradas que estão na
pátria ─ podem fazer penitência. Logo, também o podem os anjos.
Mas, em contrário. ─ A penitência nos restitui a vida, provado o pecado. Ora; isto é impossível aos anjos.
Logo, não são susceptíveis de penitência.

2. Demais. ─ Damasceno diz, que se fazemos penitência é por causa da fraqueza do nosso corpo. Ora, os
anjos são incorpóreos. Logo, não são susceptíveis de penitência.

SOLUÇÃO. A nossa penitência pode ser apreciada a dupla luz. Enquanto paixão, e como tal não é senão
a dor ou a tristeza pelo mal cometido. E embora como paixão exista apenas no concupiscível, contudo a
um ato de vontade chamamos, por semelhança, penitência, pelo qual detestamos o que fizemos; assim
também dizemos mos que o amor e as outras paixões existem no apetite intelectivo. ─ A outra luz, a
prudência é considerada virtude. E, neste sentido, o seu ato é detestar o mal cometido com o propósito
de emenda e a intenção de expiar ou aplacar a Deus pela ofensa cometida.
Ora, a detestação do mal devemo-la ter enquanto ordenada a um bem natural. E como em nenhuma
criatura essa ordenação ou inclinação pode desaparecer totalmente, por isso permanece, mesmo nos
condenados; e por conseqüência também neles permanece a paixão da penitência ou algo de
semelhante, como diz a Escritura: Dentro de si tocados do arrependimento. Mas esta penitência, não
sendo um hábito, mas paixão ou ato, de nenhum modo pode existir nos santos anjos, que não tiveram
antes cometido pecados; existe porém nos maus anjos, pois com eles se dá o mesmo que com as almas
condenadas, porque, segundo Damasceno, a morte, para os homens, corresponde à queda, para os
anjos. Mas o pecado deles é irremissível. E como o pecado, enquanto remissível ou expiável, é a matéria
mesma da virtude chamada penitência, por isso não podendo eles ter matéria, não têm a penitência de
sair à prática do ato. Por onde, também não pode existir neles o hábito. Portanto, os anjos não são
susceptíveis da virtude de penitência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O temor neles gera um certo movimento para a
penitência: mas não tal que seja uma virtude.
E o mesmo devemos responder, à SEGUNDA OBJEÇÃO.

RESPOSTA À TERCEIRA. ─Tudo o que neles é natural é totalmente bom e inclina para o bem; mas o livre
arbítrio lhes está obstinado no mal. E como o movimento da virtude e do vício não segue à inclinação da
natureza, mas antes ao movimento do livre arbítrio, por isso não há de necessariamente neles existir ou
poder existir o movimento da virtude, embora se inclinem naturalmente para o bem.

RESPOSTA À QUARTA. ─ Não se dá o mesmo com os santos anjos e as almas bem aventuradas; pois,
nesta precedeu ou podia ter precedido o pecado remissível, mas não nos anjos. E assim, embora
semelhantes quanto ao estado presente, não o são pelo estado passado, a que diretamente concerne a
penitência.