# Questão 61: Do impedimento ao matrimônio, que é o voto solene.
Em seguida devemos tratar do impedimentos sobrevenientes ao casamento. E primeiro, do provemente
do casamento não consumado, a saber, o voto solene. Segundo; do proveniente do casamento
consumado, a saber a fornicação.
Na primeira questão discutem-se três artigos:

## Art. 1 — Se um dos cônjuges, mesmo depois da cópula carnal, pode, contra a vontade do outro, entrar em religião.
O primeiro discute-se assim. ─ Parece que um dos cônjuges, mesmo depois da cópula carnal, pode,
contra a vontade do outro, entrar em religião.

1. Pois, a lei divina deve ser mais favorável às causas espirituais que a lei humana. Ora,a lei humana o
permite. Logo e com maior razão, também a lei divina deve permiti-lo.

2. Demais. ─ Um bem menor não pode impedir um maior. Ora, o estado do matrimônio é menor bem
que o de religião, como o diz o Apóstolo. Logo, pelo matrimônio não deve o homem ficar impedido de
poder entrar em religião.

3. Demais. ─ Toda religião supõe um matrimônio espiritual. Ora, é permitido passar de uma religião
mesmo rigorosa para outra mais rigorosa. Logo, também deve ser lícito deixar o matrimônio carnal, de
jugo menos pesado, pelo matrimônio espiritual, de mais pesado jugo, mesmo contra a vontade da
mulher.
Mas, em contrário, como ensina o Apóstolo, os esposos não devem nem mesmo vacar à oração, sem ser
que se abstenham de usar o matrimônio, com mútuo consentimento.

2. Demais. ─ Ninguém pode fazer licitamente o que contraria a outro, sem a vontade deste. Ora, o voto
de religião, emitido por um dos cônjuges, redunda em prejuízo do outro, porque um tem poder sobre o
corpo do outro. Logo, não pode um emitir o voto de entrar em religião, sem o consentimento do outro.

SOLUÇÃO. - Ninguém pode fazer oblação a Deus do bem alheio. Por onde, como pelo matrimônio
consumado o corpo do marido passou a pertencer à mulher, não pode sem o consentimento dela
oferecê-lo a Deus, pelo voto de continência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A lei humana considera o matrimônio só enquanto lei da
natureza. Ora, a lei divina o considera como sacramento, que lhe confere a sua omnímoda
indivisibilidade. Logo, não há símile.

RESPOSTA À SEGUNDA. - Nenhum inconveniente há em um bem maior ficar impedido por um menor,
que o contrarie; assim como o bem pode ficar impedido pelo mal.

RESPOSTA À TERCEIRA. ─ Em toda religião o matrimônio é contraído com a só pessoa de Cristo, para
com quem, contudo, uma religião impõe maiores obrigações que outra. Ao contrário, o matrimônio
carnal não é feito com a mesma pessoa com que o é o espiritual. Logo, o símile não colhe.

## Art. 2 — Se um dos cônjuges pode, antes da cópula carnal e contra a vontade do outro, entrar em religião.
O segundo discute-se assim. ─ Parece que não o pode, nem mesmo antes da cópula carnal.

1. Pois, a indivisibilidade do matrimônio resulta de ser ele um sacramento, i é, como significativo da
perpétua união entre Cristo e a Igreja. Ora, antes da cópula carnal e depois do consentimento, expresso
por palavras de presente, existe verdadeiramente o sacramento do matrimônio. Logo, não pode haver
nenhuma divisão pelo fato de entrar um em religião.

2. Demais. ─ Pelo próprio consentimento expresso por palavras de presente, um dos cônjuges transfere
para o outro poder sobre o seu corpo. Logo, pode um exigir o cumprimento do dever conjugal quando o
quiser, do outro, que a tal esta obrigado. Logo, não pode um entrar em religião, contra a vontade do
outro.

3. Demais. ─ O Evangelho diz: não separe o homem o que Deus ajuntou. Ora, a união existente, mesmo
antes da cópula carnal, se funda na lei divina. Logo, não pode ser dissolvida por vontade humana.
Mas, em contrário, segundo Jerônimo, Deus chamou a João para seu discípulo, apesar de casado.

SOLUÇÃO. ─ Antes da cópula carnal entre os cônjuges só existe um vínculo espiritual; depois, porém, há
também um vínculo carnal. Por onde, assim como depois da cópula carnal o matrimônio fica dissolvido
pela morte carnal, assim também dissolvido fica pelo ingresso em religião, antes da cópula carnal.
Porque a religião é uma morte espiritual, pela qual se morre ao século, a fim de viver para Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O matrimônio, antes da cópula carnal, significa a união
entre Cristo e a alma, pela graça. União que fica dissolvida pela disposição contrária resultante do
pecado mortal. Mas depois da cópula carnal simboliza a união entre Cristo e a Igreja pela assunção da
natureza humana na unidade de pessoa; e essa união é absolutamente indivisível.

RESPOSTA À SEGUNDA. ─ Antes da cópula carnal não houve absolutamente transferência do corpo de
um para o poder de outro, mas só condicional: salvo se um dos cônjuges convolar à perfeição de uma
vida melhor. Pela cópula carnal, porém a referida transferência se perfaz; porque então entra cada um
na posse corpórea do poder que lhe foi conferido. Por onde, mesmo antes da cópula carnal não há
obrigação de cumprir o dever conjugal, depois de contraído o matrimônio por palavras de presente; mas
é dado ao cônjuge que quer entrar em religião o tempo de dois meses, por três razões. Primeiro, para
poder nesse ínterim deliberar se deve entrar ou não. Segundo, para preparar o necessário às
solenidades nupciais. Terceiro, a fim de o marido não julgar de pouco preço uma esposa, pela qual não
suspirou dilatadamente.

RESPOSTA À TERCEIRA. ─ A união matrimonial, antes da cópula carnal, é, certo, perfeita quanto ao seu
ser primeiro; mas não consumada, quanto ao ato segundo, que é uma operação, e é assimilada à posse
corpórea. Por onde, não tem omnimoda indivisibilidade.

## Art. 3 — Se uma mulher pode casar com outro, por ter o seu marido entrado em religião, antes da cópula carnal.
O terceiro discute-se assim. ─ Parece que uma mulher não pode casar com outro, por ter o seu marido
entrado em religião, antes da cópula carnal.

1. Pois, o que pode coexistir com o matrimônio não rompe o vínculo matrimonial. Ora, o vínculo
matrimonial ainda perdura entre os que professavam, por voto igual, em religião. Logo, o entrar um em
religião não o absolve do vínculo matrimonial. Mas, enquanto esse vínculo liga a um, não pode a mulher
casar com outro. Logo, etc.

2. Demais. ─ O homem, depois de entrado em religião, pode, antes da profissão, voltar ao século. Se
pois, uma mulher pode casar com outro, tendo o marido entrado em religião, também ele poderá casar
com outra, voltando ao século. O que é absurdo.

3. Demais. ─ Pela nova decretal, a profissão feita antes de um ano é considerada nula. Logo, se depois
de uma tal profissão, o marido voltar a viver com a mulher, está obrigada esta a recebê-lo. Portanto,
nem pela entrada do marido em religião, nem pelo voto, é dado à mulher o poder de casar com outro.
Mas, em contrário. ─ Ninguém pode obrigar outrem a praticar obras de perfeição. Ora, a continência é
uma obra de perfeição. Logo, não pode a mulher ficar adstrita à continência, pelo fato de seu marido
entrar em religião. E portanto, pode casar com outro.

SOLUÇÃO. ─ Assim como a morte corporal do marido dissolve o vínculo matrimonial, a ponto de poder a
mulher casar com quem quiser, na expressão do Apóstolo, assim também depois da morte espiritual do
marido, pelo ingresso em religião, poder ela casar com quem quiser.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Quando cada um dos cônjuges faz por igual o voto de
continência então nenhum renuncia ao vínculo conjugal que, por isso, continua a subsistir. Mas quando
um só o fez, então de sua parte renuncia a esse vínculo. Logo, também o outro fica liberado do mesmo.

RESPOSTA À SEGUNDA. ─ Não se entende morto ao século pelo ingresso em religião quem ainda não
emitiu os votos. Logo, até esse tempo está obrigada a esposa a esperar, para se decidir.

RESPOSTA À TERCEIRA. ─ Da profissão assim feita antes do tempo determinado pelo direito, devemos
fazer o mesmo juízo que do voto simples. Por onde, assim como, depois do voto simples do marido, a
mulher não mais está adstrita para com ele ao dever conjugal, contudo nem por isso teria ela o poder de
casar com outro ─ assim o mesmo se dá no caso vertente.