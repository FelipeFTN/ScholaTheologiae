# Questão 75: Da ressurreição.
Em seguida devemos tratar do que acompanha e segue a ressurreição. Mas, em primeiro lugar,
devemos tratar da ressurreição em si mesma. Segundo, da sua causa. Terceiro, do seu tempo e modo.
Quarto, do seu termo original. Quinto, da condição dos resurrectos.
Na primeira questão discutem-se três artigos:

## Art. 1 — Se haverá a ressurreição dos corpos.
O primeiro discute-se assim. ─ Parece que não haverá ressurreição dos corpos.

1. ─ Pois, a Escritura diz: O homem, quando dormir, não ressurgirá, menos que o céu seja consumido.
Ora, o céu será consumido, porque a terra, cuja nobreza é menor, permanece sempre firme, como diz a
mesma Escritura. Logo, o homem, depois de morto, nunca ressurgirá.

2. Demais. ─ O Senhor prova a ressurreição por aquela autoridade: Eu sou o Deus de Abraão, e o Deus
de Isaac e o Deus de Jacó, porque Deus não no é de mortos, mas de vivos. Ora, sabemos que, quando
essas palavras foram pronunciadas, Abraão, Isaac e Jacó não tinham a alma unida ao corpo, a qual
existia separada. Logo, a ressurreição não será dos corpos, mas só das almas.

3. Demais. ─ O Apóstolo prova a ressurreição como recompensa dos trabalhos, que nesta vida sofreram
os santos; os quais, se tivessem as suas esperanças limitadas à vida presente, seriam os mais miseráveis
de todos os homens. Ora, a alma só por si pode receber suficiente remuneração de todos os trabalhos
desta vida. Pois, nenhuma necessidade há de o instrumento ser remunerado simultaneamente com o
agente, que o empregou. Ora, o corpo é instrumento da alma. Por isso, também no purgatório, onde as
almas serão punidas pelo que fizeram, quando estavam unidas ao corpo, a alma é só a punida, sem o
corpo. Logo, não é de nenhum modo necessária a ressurreição dos corpos, bastando a ressurreição das
almas, consistente em passarem do estado de culpa e de miséria para a vida da graça e da glória.

4. Demais. ─ O último estado de um ser é o seu estado mais perfeito, porque por ele atinge o seu fim.
Ora, o estado mais perfeito da alma é existir separada do corpo, porque então mais se assemelha a Deus
e aos anjos e é mais pura, assim desligada de toda natureza estranha. Logo, existir separada do corpo é
o seu último estado. Portanto, desse estado não mais voltará a se unir ao corpo, como um adulto não se
torna mais em criança.

5. Demais. ─ A morte do corpo é uma pena imposta ao homem por causa da prevaricação primitiva,
como lemos na Escritura; assim como a morte espiritual, consistente em separar-se a alma, de Deus, foi
infligida ao homem pelo pecado mortal. Ora, da morte espiritual nunca mais o homem volta à vida,
depois de recebida a sentença da condenação. Logo, também não mais voltará da morte para a vida do
corpo. Portanto, não haverá ressurreição.
Mas, em contrário, a Escritura: Eu sei que o meu Remidor vive e que eu no derradeiro dia ressurgirei da
terra e serei novamente revestido da minha pele, etc. Logo, haverá ressurreição dos corpos.

2. Demais. ─ O dom de Cristo é maior que o pecado de Adão. Ora, a morte foi introduzida pelo pecado,
pois se este não fosse, aquela não existiria. Logo, pelo dom de Cristo, da morte o homem ressurgirá para
a vida.

3. Demais. ─ Os membros devem servir à cabeça. Ora, a nossa cabeça vive e viverá eternamente em
corpo e alma, porque tendo Cristo ressurgido dos mortos, já não morre. Logo, também os homens, que
são os seus membros, viverão em corpo e alma. Por onde, há necessariamente a ressurreição da carne.

SOLUÇÃO. ─ Conforme o que pensam sobre o fim último do homem, assim se diversificam as opiniões
dos que admitem ou negam a ressurreição. Ora, o fim último, que todos os homens naturalmente
desejam, é a felicidade. E esta, conforme ensinam alguns, o homem pode consegui-la ainda nesta vida.
Daí o não terem necessidade de admitir uma vida futura, onde o homem realizasse a sua perfeição
última. Negavam por isso a ressurreição. ─ Ora, esta opinião muito provavelmente a excluem as
vicissitudes da fortuna, as enfermidades do corpo humano, a imperfeição e a instabilidade da nossa
ciência e da nossa virtude. O que tudo impede a perfeição da felicidade, como o demonstra Agostinho.
Por isso outros ensinaram que há uma vida futura onde, depois da morte, só a alma viverá; e que esta
vida basta a satisfazer o desejo natural que o homem tem da felicidade. Por isso Porfírio, citado por
Agostinho, dizia: A alma para ser feliz há de separar-se o mais possível do corpo. Por onde, esses tais
não admitiam a ressurreição.
Desta opinião, porém, variam os fundamentos que lhe foram dados.
Assim, para certos heréticos, todos os seres corpóreos vêm do princípio do mal; e os espirituais, do
princípio bom. E então, necessariamente a alma só chegaria à sua perfeição suma quando desligada do
corpo, o qual a separa do seu princípio, cuja participação só pode torná-la feliz. Por isso todas as seitas
dos heréticos, de acordo com as quais todos os seres corpóreos foram criados ou formados pelo diabo,
negam a ressurreição dos corpos. ─ Ora, a falsidade deste fundamento já foi exposta no princípio do
livro 2. Outros porém opinaram, que a natureza total do homem é só a alma, de modo que esta usa do
corpo como de um instrumento, ou como um nauta do seu navio. Por onde, de acordo com esta
opinião, só a beatificação da alma já basta para não ficar o homem frustrado do seu desejo natural de
felicidade. Portanto, nenhuma necessidade há de ressurreição. ─ Mas este fundamento o Filósofo
suficientemente o refuta, mostrando que a alma está unida ao corpo como a forma à matéria. Por onde,
é claro que nesta vida o homem não podendo ser feliz, é forçoso admitir-se a ressurreição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O céu não será consumido nunca na sua substância, mas
no efeito da sua virtude, que é produzir a geração e a corrupção nos seres terrestres em razão do que
diz o Apóstolo: A figura deste mundo passa.

RESPOSTA À SEGUNDA. ─ A alma de Abraão não é, propriamente falando, Abraão mesmo, mas, como
nos outros homens, parte dele. Por onde, a vida da alma de Abraão não basta para fazer de Abraão um
ser vivo, ou para que o Deus de Abraão seja o Deus de um vivo. Mas é necessária a vida do conjunto
todo, i. é, da alma e do corpo. Cuja vida, embora não existisse em ato, quando as referidas palavras
foram pronunciadas, supunham porém que uma e outra parte se ordenavam à ressurreição. E assim o
Senhor, com essas palavras prova a ressurreição subtilissima e eficazmente.

RESPOSTA À TERCEIRA. ─ A alma não está para o corpo somente como um agente para o instrumento
de que se serve, mas também come a forma para a matéria. Por isso é todo o composto que opera e
não só a alma, como está claro no Filósofo. E como ao operário é devida a sua paga, é o homem mesmo,
composto de alma e de corpo, que há de necessariamente receber a recompensa dos seus atos. ─
Quanto aos pecados veniais, são assim considerados por serem umas como disposições para pecar, e
não que realizem absoluta e perfeitamente a noção de pecado. Por isso a pena a que dão lugar no
purgatório não é uma retribuição, absolutamente falando, mas antes uma purificação, sofrida
separadamente ─ o corpo pela morte e a redução a cinzas; a alma, pelo fogo do purgatório.

RESPOSTA À QUARTA. ─ Todas as circunstâncias iguais, mais perfeito é o estado da alma unida ao
corpo, que dele separada. Porque é parte de todo um composto; e toda parte integrante material o é
em relação a um todo. Embora a alma separada seja, de certo modo, mais semelhante a Deus. Contudo,
absolutamente falando, um ser mais se assemelha a Deus quando tem tudo o requerido pela condição
da sua natureza; pois então imita melhor a perfeição divina. Por isso, o coração de um ser vivo é mais
semelhante a Deus imóvel, quando se move, que quando está parado, porque a perfeição do coração
está em mover-se, sendo o repouso a sua destruição.

RESPOSTA À QUINTA. ─ A morte do corpo foi introduzida pelo pecado de Adão, que a morte de Cristo
deliu. Por isso a referida pena não é perpétua. O pecado porém, que pela impenitência acarreta a morte
eterna, não mais será expiado. Por isso tal morte será eterna.

## Art. 2 — Se a ressurreição será de todos em geral.
O segundo discute-se assim. ─ Parece que a ressurreição não será de todos geralmente.

1. - Pois, a Escritura diz: os ímpios não ressurgirão no juízo. Ora, a ressurreição da carne será no juízo
universal. Logo os ímpios de nenhum modo ressurgirão.

2. Demais. ─ A Escritura diz: Toda esta multidão, dos que dormem no pó da terra, acordarão. Ora, este
modo de falar supõe uma particularização. Logo nem todos ressurgirão.

3. Demais. ─ Pela ressurreição os homens se assemelharão a Cristo ressurrecto. Daí conclui o Apóstolo,
que se Cristo ressurgiu também nós ressurgiremos. Ora, só aqueles devem assemelhar-se a Cristo
ressurrecto, que lhe trouxeram a imagem, na expressão do Apóstolo. E isso se dá só com os bons. Logo,
também só eles ressurgirão.

4. Demais. ─ A pena só é perdoada quando delida a culpa. Ora, a morte do corpo é a pena do pecado
original. Logo, como nem a todos o pecado original é perdoado, nem todos ressurgirão.

5. Demais. ─ Assim como renascemos pela graça de Cristo, assim pela sua graça ressurgiremos. Ora, os
mortos no ventre materno nunca poderão renascer. Logo, nem ressurgir. E assim, nem todos
ressurgirão.
Mas, em contrário, o Evangelho: Todos os que se acham no sepulcro ouvirão a voz do Filho de Deus; e os
que a ouvirem viverão. Logo, todos os mortos ressurgirão. Além disso, diz ainda o Apóstolo: Todos
certamente ressuscitaremos, etc.

2. Demais. ─ A ressurreição é necessária a fim de os ressurrectos receberem a pena ou o prêmio,
conforme os seus méritos. Ora, a todos é devida uma pena ou um prêmio ─ ou por mérito próprio, como
no caso dos adultos; ou pelo mérito alheio, como no caso das crianças. Logo, todos ressurgirão.

SOLUÇÃO. ─ O que se funda em a natureza específica há de necessária e semelhantemente existir em
todos os seres da mesma espécie. Ora, tal é a ressurreição. A sua razão de ser, como dissemos, é que a
alma, separada do corpo, não pode atingir a perfeição última da espécie humana. Logo, é forçoso todos
ressurgirem e não um só.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O lugar citado se refere à ressurreição espiritual, de que
os ímpios não participarão no dia do julgamento das consciências, como expõe a Glosa. ─ Ou se refere
aos ímpios totalmente infiéis, que não ressurgirão para serem julgados, por já estarem julgados.

RESPOSTA À SEGUNDA. ─ Agostinho expõe que, no lugar citado, multidão significa todos. Modo de falar
de que mui frequentemente usa a Escritura Sagrada. ─ Ou a particularização pode entender-se, das
crianças condenadas no limbo, que, embora ressurjam, delas não se pode dizer propriamente que estão
acordadas; pois, nem sofrerão nenhuma pena e nem alcançarão a glória; porque estar acordado é, por
assim dizer, ter os sentidos livres.

RESPOSTA À TERCEIRA. ─ Todos, tanto os bons como os maus, se assemelham com Cristo, enquanto
vivem neste mundo, pelos atributos pertencentes à natureza da espécie; não porém pelo que respeita à
graça. Por onde, todos se lhe assemelharão pelo restabelecimento da vida natural: mas só os bons, pela
semelhança da glória.

RESPOSTA À QUARTA. ─ A morte é pena do pecado original; e os que nele morreram, pela morte o
expiaram. Por onde, não obstante a culpa original, poderão ressurgir da morte; porque a pena do
pecado original é, antes, morrer que ser preso da morte.

RESPOSTA À QUINTA. - Renascemos pela graça que Cristo nos dá; mas ressurgimos pela graça que nos
fez de assumir a nossa natureza, pois, pela encarnação é que nos assemelhamos com ele pela natureza.
Portanto, os mortos no ventre materno, embora não tenham renascido, pelo recebimento da graça,
contudo ressurgirão pela conformidade da sua natureza com a de Cristo, que obtiveram desde que
alcançaram a perfeição da espécie humana.

## Art. 3 — Se a ressurreição é natural.
O terceiro discute-se assim. ─ Parece que a ressurreição é natural.

1. ─ Pois, como diz Damasceno, os caracteres que geralmente notamos em todos os indivíduos,
pertence-lhes à espécie. Ora, todos os homens em geral hão de ressurgir. Logo, a ressurreição é natural.

2. Demais. ─ Gregório diz: Os que não crêem na ressurreição, por obediência, devem aceitá-la pela
razão. Pois, que outra cousa nos mostram todos os dias os elementos da natureza senão a nossa
ressurreição? E dá o exemplo da luz, que por assim dizer morre quando nos desaparece dos olhos, e
ressurge quando de novo acesa. Das arvores, que perdem as folhas para, como ressurrectas, de novo se
revestirem delas. Das sementes que morrem putrefactas, para de certa maneira ressurgirem pela
germinação, exemplo que também dá o Apóstolo. Ora, todos os fenômenos, que conhecemos pela
razão, são naturais. Logo, natural será a ressurreição.

3. Demais. ─ O que é contrário à natureza não pode durar, por ser violento. Ora, a vida renascida pela
ressurreição durará eternamente. Logo, a ressurreição será natural.

4. Demais. ─ O fim a que universalmente tende a natureza não pode deixar de ser natural. Ora, tal é a
ressurreição, a glorificação dos santos e cousas semelhantes, como diz o Apóstolo. Logo, a ressurreição
será natural.

5. Demais. ─ A ressurreição é uma espécie de movimento, cujo termo é a união perpétua da alma e do
corpo. Ora, o movimento é natural que termina no repouso natural, como diz Aristóteles. Logo, a união
perpétua da alma e do corpo será natural, porque, sendo a alma o motor próprio do corpo este há de
lhe ser proporcionado, e portanto pode perpétua e naturalmente ser animado por ela, que vive
perpetuamente. Portanto, a ressurreição será natural.
Mas, em contrário. ─ Não é possível, naturalmente, voltar da privação para o hábito. Ora, a morte é a
privação da vida. Logo, a ressurreição que é a volta da morte à vida, não é natural.

2. Demais. ─ Seres da mesma espécie tem uma origem determinada. Assim, os animais gerados da
putrefação, naturalmente, não são nunca da mesma espécie que os gerados por via seminal, como diz o
Comentador. Ora, o homem é naturalmente gerado por seres da mesma espécie; o que não se dá na
ressurreição. Logo, esta não será natural.

SOLUÇÃO. ─ Todo movimento e toda ação mantém com a natureza uma tríplice relação. ─ Assim, certos
movimentos ou ações não tem principio nem fim naturais. Porque ou se originam de um princípio
superior à natureza, como no caso da glorificação dos corpos; ou de outro princípio qualquer, como no
da pedra projetada para o alto por um movimento violento, e que vem a cair num repouso violento
também. ─ Outros movimentos há entretanto, cujo princípio e cujo termo é a natureza, como no caso
da pedra que cai. ─ Outros há enfim, cujo termo, mas não princípio, é a natureza. É às vezes a origem
deles um princípio superior à natureza, como na iluminação de um cego, a quem embora lhe seja
natural a vista, o princípio da iluminação contudo é sobrenatural. Outras vezes, um princípio de espécie
diferente, como no caso de uma flor ação ou frutificação acelerada artificialmente. ─ Mas não é possível
a natureza ser o princípio de um movimento sem lhe ser o termo; porque os princípios naturais tem
efeitos definidos e determinados, que não podem ultrapassar.
Ora, a operação ou o movimento, que mantém com a natureza a primeira espécie de relação, de
nenhum modo pode chamar-se natural. Mas ou é miraculosa, se proceder de um princípio superior à
natureza, ou violenta, se provier de um outro princípio qualquer. ─ A operação ou movimento relativo à
natureza, do segundo modo, é natural, absolutamente falando. ─ Mas a operação, que mantém com a
natureza a terceira espécie de relação, não pode chamar-se natural, absolutamente falando, mas
apenas de certo modo, i. é, enquanto conduz ao que é natural. E se chama milagrosa, ou artificial ou
violenta. Pois, natural propriamente dito é o que é segundo a natureza. Ora, diremos que é segundo a
natureza o que o tem e tudo quanto dela resulta, como está claro em Aristóteles. Por onde, o
movimento, absolutamente falando, não pode chamar-se natural, senão se o seu princípio for a
natureza.
Ora, o principio da ressurreição não pode ser a natureza, embora o seu termo seja a vida natural. Pois, a
natureza é o princípio do movimento do ser natural. Ou do movimento ativo, como no caso dos corpos
leves e graves, e nas alterações naturais do corpo animal; ou do passivo, como no caso da geração dos
corpos simples. Quanto ao princípio passivo da geração natural, é a potência passiva natural, a que
sempre corresponde em a natureza alguma potência ativa, como diz Aristóteles. Nem importa, a esta
luz, que corresponda ao princípio passivo um princípio ativo natural, causador da forma, perfeição
última do ser; ou causador de uma disposição necessitante da forma última, como se dá na geração do
homem, segundo o ensina a fé, ou mesmo em todos os outros seres, segundo a opinião de Platão e de
Avicena. Ora, em a natureza não existe nenhum princípio ativo de ressurreição causador da união da
alma e do corpo, nem de qualquer disposição que haja de necessariamente dar lugar a essa união,
porque uma tal disposição a natureza não na poderia produzir senão pelo modo determinado por via de
geração seminal. Por onde, embora admitamos a existência de uma potência passiva por parte do
corpo, ou mesmo uma inclinação qualquer para a sua união com a alma, não é ela tal que baste à
existência de um movimento natural. Por onde, a ressurreição, absolutamente falando, é miraculosa e
não natural, senão de certo modo, como do sobredito Se colhe.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Damasceno se refere às propriedades existentes em
todos os indivíduos produzidos pelos princípios criados da natureza. Pois, se por ação divina todos os
homens se tornassem brancos, ou fossem reunidos num mesmo lugar ─ como se deu no dilúvio, nem
por isso a brancura seria uma propriedade natural do homem, ou a existência num determinado lugar.

RESPOSTA À SEGUNDA. - Os seres naturais não nos dão uma razão demonstrativa das cousas que não
são naturais. Mas podem, por meio de razões persuasivas nos dar algum conhecimento do sobrenatural.
Porque as causas naturais nos representam uma certa semelhança das sobrenaturais. Assim, a união da
alma e do corpo representa a união da alma com Deus pela fruição da glória, como diz o Mestre. E do
mesmo modo, os exemplos aduzidos pelo Apóstolo e por Gregório ajudam a persuasão da fé na
ressurreição.

RESPOSTA À TERCEIRA. ─ A objeção colhe quanto à operação cujo termo não é natural, mas contrário à
natureza. Ora, tal não se dá na ressurreição. Logo, não vem a propósito.

RESPOSTA À QUARTA. ─ A operação da natureza depende totalmente da operação divina, assim como a
operação de um artífice inferior depende da do superior. Por onde, assim como toda operação de uma
arte inferior não pode atingir o seu fim senão pela operação de uma arte superior, que imprime a forma
ou aplica a obra, assim o fim último a que tende toda a natureza não na pode ela alcançar pela sua
operação própria. Por isso não na atinge por uma operação natural.

RESPOSTA À QUINTA. ─ Embora não possa o movimento ser natural, que termina num repouso
violento, pode contudo ser não-natural o movimento cujo termo é o repouso natural, como dissemos.