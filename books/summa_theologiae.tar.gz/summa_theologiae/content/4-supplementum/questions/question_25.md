# Questão 25: Da indulgência em si mesma.
Em seguida devemos tratar da indulgência.
E primeiro, em si mesma considerada. Segundo, dos que a concedem. Terceiro, dos que a recebem.
Na primeira questão discutem-se três artigos:

## Art. 1 — Se a indulgência pode remitir algo da pena satisfatória.
O primeiro discute-se assim. Parece que a indulgência nada pode remitir da pena satisfatória.

1. — Pois, aquilo do Apóstolo — Não pode negar-se a si mesmo— diz a Glosa: O que faria, se não
cumprisse o prometido. Ora, o próprio Senhor o disse: o número dos golpes regular-se-á pela qualidade
do pecado. Logo, nada pode ser perdoado da pena satisfatória, determinada conforme a quantidade da
culpa.

2. Demais. — O inferior não pode absolver daquilo a que o superior obrigou. Ora, Deus, quando absolve
da culpa, obriga à pena temporal, como diz Hugo Vitorino. Logo, ninguém pode absolver dessa pena,
perdoando alguma parte dela.

3. Demais. — Pertence ao poder da excelência conferir o efeito dos sacramentos, sem eles. Ora,
ninguém tem, a não ser Cristo, o poder de excelência sobre os sacramentos. Ora, sendo a satisfação
parte do sacramento da penitência, contribuindo para o perdão da pena devida, parece que nenhum
homem, como tal, pode perdoar o débito da pena, sem a satisfação.

4. Demais. — O poder não foi dado aos ministros da Igreja para a destruição, mas para a edificação. Ora,
seria para a destruição, se eliminasse a satisfação, dada como remédio à nossa utilidade. Logo, o poder
dos ministros da Igreja não se estende a tal.
Mas, em contrário. — Aquilo do Apóstolo: Pois eu também a indulgência de que usei, se de alguma
tenho usado, foi por amor de vós em pessoa de Cristo, diz a Glosa: isto é, como se Cristo a usasse. Ora,
Cristo podia perdoar, sem qualquer satisfação, a pena do pecado, como o fez à mulher adúltera. Logo,
também o podia Paulo. Portanto, também o pode o Papa, que não tem na Igreja menor poder que o que
tinha Paulo.

2. Demais. — A Igreja universal não pode errar; pois aquele que em tudo foi atendido pela sua
reverência, disse a Pedro, sobre cuja confissão foi fundada a Igreja: Eu roguei por ti para que a tua fé
não falte. Ora, a Igreja universal aprova e concede as indulgências. Logo, algum valor elas tem.

SOLUÇÃO. — Todos concedem o valor das indulgências, pois, seria ímpio dizer que a Igreja faz qualquer
coisa em vão. Certos porém afirmam, que não valem para absolver do reato da pena a ser expiada no
purgatório, pelo juízo de Deus; valem porém para absolver da obrigação, pela qual o sacerdote impôs ao
penitente uma certa pena, ou a que ele estava obrigado por determinação dos cânones.
Esta opinião porém não pode ser tida como verdadeira. — Primeiro, porque contraria expressamente o
privilégio dado a Pedro que seria perdoado no céu o que perdoasse na terra. Por onde, o perdão dado
no tribunal da Igreja vale também no tribunal de Deus. — Além disso, concedendo tais indulgências a
Igreja antes causaria dano do que auxílio; pois castigaria com as penas do purgatório, que são mais
graves, depois de ter perdoado as penitências impostas.
Por isso, devemos, de outro modo, afirmar que valem tanto no foro da Igreja quanto no tribunal de
Deus, para perdoar as penas restantes depois da contrição, da confissão e da absolvição, quer tenham
sido impostas, quer não. E a razão por que podem valer é a unidade do corpo místico na qual muitos
fizeram obras de penitência excedentes à medida dos seus débitos; e também sofreram com paciência
muitas tribulações injustas pelas quais poderiam expiar uma multidão de penas, se destas fossem réus.
E desses méritos tanta é a riqueza que excedeu o total das penas atuais devidas pelos vivos. Mas
sobretudo pelo mérito de Cristo que, embora obre nos sacramentos, não limita a eles contudo a sua
eficácia; mas pela sua infinidade excede a eficácia dos sacramentos.
Ora, como dissemos antes, um pode satisfazer por outro. Os santos porém, cujas obras encerram uma
superabundância de satisfação, não nas praticaram por ninguém que em particular precisasse de
perdão, pois do contrário, conseguiria esse o perdão sem necessidade de nenhuma indulgência; mas as
praticaram, em geral para toda a Igreja, como o Apóstolo diz de si, que cumpre o que resta a padecer a
Jesus Cristo pelo seu corpo, que é a Igreja, à qual escreve. E assim, os referidos méritos são comuns a
toda a Igreja. Ora, o que é comum a uma multidão distribui─se a cada membro dela segundo o arbítrio
de quem a governa. Por onde, assim como alcançaria o perdão dos pecados aquele por quem outrem
satisfizesse, assim também se a satisfação de outrem lhe fosse distribuída por quem tem o poder de o
fazer.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O perdão causado pelas indulgências não elimina a
proporção entre a pena e a culpa; pois, pela culpa de um, outro sofre voluntariamente uma pena.

RESPOSTA À SEGUNDA. — Quem ganha as indulgências não fica absolvido, simplesmente falando, do
débito da pena, mas recebe o com que pague esse débito.

RESPOSTA À TERCEIRA. — O efeito da absolvição sacramental é a diminuição do reato. E esse efeito não
no produzem as indulgências; mas quem lhe concede as indulgências absolve o pecador da pena devida,
em virtude dos bens comuns da Igreja, como do sobre dito se colhe.

RESPOSTA À QUARTA. — A graça, mais que as nossas obras habituais, dá o remédio para evitarmos os
pecados. E como o afeto, que quem ganha as indulgências concebe, em relação à causa pela qual a
indulgência é dada, dispõe para a graça, por isso também pelas indulgências é dado o remédio para se
evitarem os pecados. Por onde, a concessão de indulgências não concorre para a ruína das almas, salvo
se o forem desordenadamente. — Contudo deve-se aconselhar aos que as ganham, que nem por isso se
abstenham das obras de penitência prescritas; a fim de também nelas haurirem o remédio, embora
imunes do débito da pena, e sobretudo porque pode se dar sejam mais devedores do que crêem.

## Art. 2 — Se as indulgências valem tanto quanto o seu conteúdo.
O segundo discute-se assim. — Parece que as indulgências não valem tanto quanto o seu conteúdo.

1. — Pois, as indulgências não produzem o seu efeito senão em virtude do poder das chaves. Ora, quem
tem o poder das chaves não pode, em virtude dele, perdoar senão uma parte determinada da pena do
pecado, considerada a gravidade deste e a Intensidade da contrição do penitente. Logo, como as
indulgências são concedidas conforme à vontade de quem as institui, parece não valem tanto quanto o
seu conteúdo.

2. Demais. — Pelo débito da pena se nos restava a obtenção da glória, que devemos sumamente
desejar. Ora, se as indulgências valem tanto quanto o seu conteúdo, poderíamos, ganhando umas após
outras, nos tornarmos imunes de todo o reato da pena temporal. Logo, parece que devíamos empregar
todo o nosso estudo em ganhar as indulgências com prejuízo de quaisquer outras obras.

3. Demais. — As vezes é concedida a quem der auxílios para a ereção da fábrica de uma igreja, a
indulgência de alcançar a remissão da terça parte dos pecados. Se, pois, as indulgências valem tanto
quanto o seu conteúdo, então, quem desse um dinheiro, depois mais um e depois ainda um terceiro,
alcançaria a absolvição plena da pena de todos os pecados. O que é absurdo.

4. Demais. — As vezes é a indulgência concedida nos termos seguintes: quem entrar numa igreja
ganhará sete anos de perdão dos pecados. Se, pois, uma indulgência vale tanto quanto o seu conteúdo,
quem morar perto dessa igreja ou os clérigos da mesma, que a ela vão quotidianamente, ganharão
tanto como os que vem de longe — o que é injusto. E além disso, segundo parece, ganhará num dia
tantas vezes indulgências quantas entrar nessa igreja.

5. Demais. — Perdoar a alguém uma pena, além do merecido, é o mesmo que perdoar sem causa, pois
esse excesso por nada é recompensado. Ora, quem concede a indulgência não pode perdoar a ninguém
a sua pena, total ou parcialmente, sem causa; como se lhe dissesse o Papa: Eu te perdoo toda a pena
devida pelo pecado. Logo, parece que também não pode perdoar nada além da justa medida. Ora, as
indulgências às vezes são pregadas além da justa medida. Logo, não valem tanto quanto o seu
contendo.
Mas, em contrário. — A Escritura diz: Acaso necessita Deus das vossas mentiras para que em sua defesa
faleis dolosamente? Logo, a Igreja, quando prega as indulgências, não mente. Logo, valem tanto quanto
o por que são pregadas.

2. Demais. — O Apóstolo diz: Se é vã a nossa pregação também é vã a vossa fé. Logo, quem diz
falsidades na pregação torna vã, o quanto pode, a sua fé e portanto peca mortalmente. Logo, se as
indulgências não valem tanto quanto o por quê são pregadas, todos os que as pregam pecam
mortalmente. O que é absurdo.

SOLUÇÃO. — Nesta matéria várias são as opiniões. Uns dizem que tais indulgências não valem tanto
quanto o seu conteúdo, mas valem para cada um na medida da sua fé e devoção. Mas afirmam que a
Igreja usa de uma linguagem exagerada para, mediante uma pia fraude, aliciar à beneficência, como a
mãe que promete uma fruta ao filho para provocá-lo a andar. — Mas essa é uma opinião muito perigosa
de se professar. Pois, como diz Agostinho, se se encontrasse na Sagrada Escritura algo de falso, perderia
ela a força da sua autoridade. Semelhantemente, se descobríssemos alguma falsidade na pregação da
Igreja, nenhuma autoridade lhe teriam os ensinamentos, para roborar a fé.
Por isso outros disseram, que as indulgências valem tanto quanto o seu conteúdo, segundo uma justa
ponderação; não porém segundo a ponderação de quem a dá, que estima excessivamente a sua dádiva;
nem segundo a estimação de quem a recebe, que poderia avaliar em muito pouco o que foi dado; mas
segundo uma avaliação justa, justa pelo juízo dos bons, pesada a condição da pessoa, a utilidade e a
necessidade da Igreja, pois, num tempo ela pode necessitar mais que em outro. — Mas esta opinião não
pode sustentar-se, como passamos a expor. Primeiro, porque de acordo com ela, as indulgências não
valeriam para a remissão, mas só para uma certa comutação dos pecados. Além disso, a pregação da
Igreja não seria isenta de mentira. Pois, às vezes, uma indulgência seria pregada, muito maior que o que
poderia exigir uma justa estimativa, pesadas todas as condições referidas. Assim, quando o Papa
concede a indulgência de sete anos a quem entrar numa igreja; e tais indulgências também foram
instituídas por São Gregório nas estações de Roma.
Por isso outros dizem, que a extensão do perdão nas indulgências não se deve medir pela devoção de
quem as ganha somente, como professa a primeira opinião; nem pela quantidade do que é dado, como
quer a segunda; mas pela causa por que a indulgência é concedida, e que faz com que alguém seja digno
de a ganhar. Por onde, conforme o que se dá por essa causa, nessa medida se consegue o perdão
concedido pela indulgência, total ou parcialmente. — Mas, de novo, isto não pode salvar o costume da
Igreja que concede uma indulgência, ora maior, ora menor, pela mesma causa. Assim, nas mesmas
circunstâncias, ora dá a indulgência de um ano aos visitantes de uma igreja; ora, quarenta dias — como
se o Papa, concedendo uma indulgência, quisesse conferir uma graça. Por onde, a extensão do perdão
concedido pela indulgência não se deve medir pela causa, que tornou alguém digno dela.
Devemos, pois, opinar diferentemente, que a extensão do efeito depende da extensão da causa. Ora, a
causa da remissão da pena nas indulgências não é outra senão a abundância dos méritos da Igreja,
suficiente para fazer expiar totalmente a pena. E não é a causa efetiva dela nem a devoção, nem a pena,
nem o dom feito por quem a recebe, nem a causa por que é ela dada. Por isso, não há mister de
proporcionar a nada disso a extensão do perdão; mas aos méritos, da Igreja, que sempre
superabundam. Portanto na medida em que a cada um forem esses méritos aplicados, nessa mesma
conseguirá o perdão da culpa. Mas, a fim de serem aplicados a uma pessoa determinada, é necessária a
autoridade de dispensar o referido tesouro e a união daquele a quem é dispensado como aquele que
mereceu, o que se faz pela caridade. Necessária também é a razão da dispensa, pela qual se obedeça à
intenção dos autores de tais obras meritórias — pois as fizeram para a honra de Deus e a utilidade geral
da Igreja. Por onde, qualquer causa, que redunde em utilidade da Igreja e honra de Deus, é razão
suficiente de conceder indulgências.
E assim devemos, com outros, pensar que, absolutamente falando, as indulgências tanto valem quanto
o por que são pregadas. Contanto que tenha autoridade quem a concede; haja caridade da parte de
quem a recebe; e da parte da causa, a piedade, que compreende a honra de Deus e a utilidade do
próximo. Nem isso torna demasiado largo o tribunal de Deus ou derroga à justiça divina; porque nada é
perdoado da pena, mas a pena de um é atribuída a outro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O poder das chaves, como dissemos, é de duas espécies:
o da ordem e o da jurisdição. A chave da ordem é um sacramental. E como os efeitos dos sacramentos
não são determinados pelo homem, mas por Deus, o sacerdote não pode determinar quanto, pela
chave da ordem, é perdoado da pena devida, no foro da consciência; mas tanto será perdoado quanto
Deus tiver ordenado. A chave da jurisdição porém não é um sacramental e o seu efeito depende do
arbítrio humano. E o efeito dessa chave é a remissão operada pelas indulgências; pois, não depende
esse perdão da dispensa dos sacramentos, mas da dos bens comuns da Igreja. Por isso, também os
legados não-sacerdotes podem conferir indulgências. Portanto, no arbítrio de quem as concede está
determinada a quantidade da pena que pela indulgência será perdoada. Se porém o perdão for
desordenado, de modo que os fiéis venham, quase, por nada, a abandonar as obras de penitência: peca
quem tais indulgências concede; mas nem por isso deixará ninguém de ganhar uma indulgência
plenária.

RESPOSTA À SEGUNDA. — Embora as indulgências valham muito para a remissão da pena, contudo as
outras obras satisfatórias são mais meritórias para se ganhar o prêmio essencial — o que é
infinitamente melhor que a remissão da pena temporal.

RESPOSTA À TERCEIRA. — Quando é concedida uma indulgência determinadamente — a quem der
auxílio para a fábrica de uma igreja, entende-se esse auxílio como sendo proporcionado a quem o dá; e
conforme maior ou menor for ele, maior ou menor será a indulgência ganha. E assim, o pobre que só
der um dinheiro ganhará totalmente a indulgência; não porém o rico, que não deve para obra tão pia e
frutuosa dar tão pouco, que se poria no caso de um rei do qual não se disse que socorreu alguém por
lhe ter dado um óbulo.

RESPOSTA À QUARTA. - Quem mora perto da igreja, bem como os sacerdotes e os clérigos ganham
tanta indulgência como os que vêm de mil léguas de distância; porque o perdão não se proporciona ao
trabalho, como se disse, mas aos méritos aplicados. Mas quem mais penas se desse mais méritos
adquiriria. Mas isto se entende de indulgência dada indistintamente. As vezes porém faz-se distinção.
Assim o Papa, nas absolvições gerais, dá cinco anos aos que atravessam o mar; aos que atravessarem
montes, três; aos outros, um. — Contudo, os que visitam o lugar referido, no período durante o qual
podem ganhar a indulgência, tantas vezes quantas puderem, nem por isso ganharão outras tantas
indulgências. Pois, às vezes uma indulgência é concedida só num tempo determinado, como quando se
diz: Quem visitar a igreja tal em tal tempo ganhará tanto de indulgência; entendendo-se uma vez só.
Mas se numa igreja houver indulgência perene, como a de quarenta dias na igreja de S. Pedro, então
quantas vezes alguém a visitar, outras tantas indulgências ganhará.

RESPOSTA À QUINTA. — A causa da indulgência é necessária, não a fim de por ela dever medir-se o
perdão da pena, mas para que a intenção daqueles cujos méritos são comunicados possa aplicar-se a
quem ganhar a indulgência. Ora, o bem de um pode comunicar-se a outro de dois modos. Primeiro, pela
caridade; e então, mesmo sem indulgências podemos, se temos a caridade, participar de todos os bens
praticados. De outro modo, pela intenção de quem praticou a obra. E assim, pelas indulgências,
havendo causa legítima, poderá a intenção de quem praticou uma obra para utilidade da Igreja ser
aplicada a quem ganha a indulgência.

## Art. 3 — Se se deve conceder uma indulgência por um subsídio temporal.
O terceiro discute-se assim. — Parece que não se deve conceder indulgência por um subsídio
temporal.

1. — Pois, o perdão dos pecados é um bem espiritual. Ora, dar o espiritual pelo temporal é simonia.
Logo, tal não se deve fazer.

2. Demais. — Os socorros espirituais são mais necessários que os temporais. Ora, pelos socorros
espirituais não se concedem indulgências. Logo, muito menos se devem conceder por subsídios
temporais.
Mas, em contrário, o costume comum da igreja, que concede indulgências a quem fizer peregrinações
ou esmolas.

SOLUÇÃO. — Os bens temporais se ordenam aos espirituais, pois, por causa destes é que devemos usar
daqueles. Por onde, pelos temporais em si mesmos não se podem conceder indulgências, mas pelos
temporais ordenados para os espirituais; tal a repressão dos inimigos da Igreja, que lhe perturbam a
paz, ou para a construção de igreja, pontes e a concessão de esmolas tais.
Por onde é claro que não há, no caso vertente, simonia, porque não se dá o espiritual pelo temporal.
Donde se deduz clara a RESPOSTA À PRIMEIRA OBJEÇÃO.

RESPOSTA À SEGUNDA. — Mesmo em vista de bens puramente espirituais se podem conceder
indulgências, o que às vezes se faz. Assim, a todo aquele que orar pelo rei da França são-lhe concedidos
pelo Papa Inocêncio IV dez dias de indulgência. Semelhantemente, aos que pregam a cruzada se lhes
concede às vezes a mesma indulgência que aos que nela se inscrevem.