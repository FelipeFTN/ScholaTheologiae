# Questão 60: Do uxoricídio.
Em seguida devemos tratar do uxoricídio. E nesta questão discutem-se dois artigos:

## Art. 1 — Se é lícito ao marido matar a esposa apanhada no ato do adultério.
O primeiro discute-se assim. ─ Parece lícito ao marido matar a esposa apanhada no ato do adultério.

1. Pois, a lei divina manda as adúlteras serem lapidadas. Ora, quem cumpre a lei divina não peca. Logo,
nem quando mata a esposa adúltera.

2. Demais. ─ O permitido por lei o é também ao encarregado de a cumprir. Ora, a lei permite matar a
adúltera ou qualquer pessoa ré de morte, Logo, desde que a lei permitiu ao marido matar a mulher
apanhada em flagrante adultério, resulta que isso lhe é lícito.

3. Demais. ─ Maior poder tem o marido sobre a esposa adúltera, que o seu cúmplice no adultério. Ora, o
marido que matar um clérigo colhido em ato de adultério com a esposa, não fica excomungado. Logo,
parece que pode também matar a própria esposa apanhada em adultério.

4. Demais. ─ O marido está obrigado a corrigir a sua esposa. Ora, a correção se faz infligindo uma pena.
Logo, sendo a justa pena do adultério que é um crime capital, a morte, parece lícito ao marido matar a
esposa adúltera.
Mas, em contrário. ─ Diz o Mestre: A Igreja de Deus, nunca adstrita às leis do século, outro gládio não
tem senão o espiritual. Logo, quem quiser pertencer à Igreja, não lhe será lícito usar da lei que permite o
uxoricídio.

2. Demais. ─ Marido e mulher estão no mesmo pé de igualdade. Ora, à esposa não é lícito matar o
marido colhido em flagrante adultério. Logo, nem ao marido, a mulher.

SOLUÇÃO. ─ De dois modos pode um marido provocar a morte de sua mulher, ─ Primeiro, pelo juízo
civil. ─ E então nenhuma dúvida há: pode ele, sem pecado, por zelo da justiça e não movido pela paixão
da vingança ou do ódio, acusar criminalmente de adultério, perante o juízo secular, a esposa adúltera, e
pedir a pena de morte cominada pela lei; assim como também pode acusar alguém de homicídio ou de
outro crime. Mas essa acusação não pode ser feita perante o juízo eclesiástico; porque a Igreja não
dispõe de gládio material, como diz o Mestre. ─ De outro modo, pode matá-la de si mesmo, sem ter sido
citada perante a justiça. E então, não lhe é lícito, nem pelas leis civis, nem pela lei da consciência, matá-
la, fora do ato do adultério, por mais que a saiba adúltera. A lei civil porém julga lícito matá-la quando
apanhada em flagrante ato de adultério. Não que assim o ordene, mas porque não inflige a pena de
homicídio, por causa da veemente excitação por que o homem é levado no ato de matar a esposa.
Nesta matéria porém a Igreja não está adstrita às leis humanas, a ponto de declarar o marido isento do
reato da pena eterna, ou da pena a ser infligida pelo tribunal eclesiástico, a pretexto de não ter sido
condenado pelo tribunal civil. Portanto, em nenhum caso é lícito ao marido matar a esposa, por
autoridade própria.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Infligir essa pena a lei não o cometeu a nenhuma pessoa
privada, mas às pessoas públicas, a quem compete o exercício de tal função. Ora, o marido não é juiz da
sua esposa. Logo, não na pode matar, senão só acusá-la perante o juiz.

RESPOSTA À SEGUNDA. ─ A lei civil não cometeu ao marido que matasse a esposa, a modo de ordem
que lhe impusesse, porque então não pecaria ele, como não peca o ministro do juízo quando executa
um ladrão condenado à morte; mas só lho permitiu, desde que não lhe impôs nenhuma pena. Por isso,
também opôs certas dificuldades, com o fim de desviar os homens do uxoricídio.

RESPOSTA À TERCEIRA. ─ Daí não se deduz seja o uxoricídio lícito, absolutamente falando; mas só a
imunidade de uma certa pena, porque também pena é a excomunhão.

RESPOSTA À QUARTA. - Há duas espécies de sociedade: Uma, a doméstica, como a família; outra
política, como a cidade e o reino. Ora, o chefe da segunda espécie de sociedade, que é o rei, pode infligir
penas tanto consecutivas como exterminativas do culpado, a fim de purificar a sociedade cujo governo
lhe incumbe. Mas o chefe da primeira espécie de necessidade, que é o pai de família não pode infligir
senão uma pena corretiva, que não ultrapassa, diferentemente da pena de morte, os limites da
correção. Por onde, o marido, que tem o governo da sua mulher, não na pode matar, mas somente
castigar.

## Art. 2 — Se o uxoricídio impede o matrimônio.
O segundo discute-se assim. ─ Parece que o uxoricídio não impede o matrimônio.

1. Pois, mais diretamente se opõe o adultério ao matrimônio, que o homicídio. Ora, o adultério não
impede o matrimônio. Logo, nem o uxoricídio.

2. Demais. ─ É mais grave pecado matar a mãe que a esposa; pois não sendo nunca lícito açoitar a
própria mãe, o é açoitar a esposa. Ora, matricídio não impede o matrimônio. Logo, nem uxoricídio.

3. Demais. ─ Mais gravemente peca quem, por causa de adultério, mata a esposa alheia, que quem mata
a própria esposa; porque não teria excusa de uma paixão cega, nem tem o direito de corrigir a mulher
dos outros. Ora, quem mata a esposa alheia não fica impedido do matrimônio. Logo nem quem mata a
própria.

4. Demais. ─ Removida a causa, removido fica o efeito. Ora, o pecado de homicídio pode ser removido
pela penitência. Logo, também o impedimento ao matrimônio que ele causa. Portanto, parece que
depois de feita penitência, não perdura a proibição de contrair casamento.
Mas, em contrário, dispõe um cânone: Os assassinos de suas esposas deverão fazer penitência e não
mais poderão casar-se.

2. Demais. ─ Por onde alguém peca por aí também deve ser punido. Ora, peca contra o matrimônio
quem mata a esposa. Logo, deve ter como punição ficar privado do matrimônio.

SOLUÇÃO. ─ O uxoricídio, pela legislação da Igreja, impede o matrimônio. ─ Umas vezes porém impede
apenas de contraí-lo, sem anular o que já o foi; assim, quando por causa de adultério ou levado do ódio,
o marido mata a esposa. Contudo, se houver receio que não guarde continência, pode a Igreja dispensá-
lo e permitir que se case de novo. ─ Outras vezes porém dirime o casamento já contraído; assim, quando
o marido mata a esposa, para casar com aquela com quem vive em adultério. Então se torna
absolutamente incapaz de casar com esta, e se o fizer, nulo será o casamento. Mas isso não no torna
incapaz, absolutamente falando, de casar com qualquer outra mulher. E assim, casando com outra,
embora peque por proceder contra a lei da Igreja, contudo não fica por isso anulado o casamento
contraído.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O homicídio e o adultério em certos casos impedem
matrimônio de vez contraído e o anulam se já foi; tal o que se dá com o uxoricídio, como acabamos de
dizer e com o adultério, de que já tratamos. ─ Ou devemos responder, que o uxoricídio é contra a
essência do casamento, mas o adultério é contra a fidelidade conjugal que ele implica. Mas, o adultério
não se opõe mais diretamente ao matrimônio, do que o uxoricídio. Logo, a objeção procede de bases
falsas.

RESPOSTA À SEGUNDA. ─ Absolutamente falando, mais grave pecado é matar a própria mãe, que a
esposa, e mais contrário à natureza; porque naturalmente respeitamos a nossas mães. Por isso, é mais
desnaturado o matricida que o uxoricida. E é para reprimir qualquer tentação de uxoricídio, que a Igreja
proibiu o casamento aos culpados desse crime.

RESPOSTA À TERCEIRA. ─ Quem mata a mulher de outro não peca contra o matrimônio, como quem
matou a própria esposa. Logo, o símile não colhe.

RESPOSTA À TERCEIRA. ─ Delida a culpa daí não decorre necessariamente que fique delida toda a pena,
como bem o mostra a irregularidade. Pois, a penitência não restitui o pecador à sua dignidade primeira,
embora possa restituir-lhe o esta do anterior de graça, como dissemos.