# Questão 21: Da definição da excomunhão, da sua conveniência e da sua
causa.
Em seguida devemos tratar da excomunhão.
E então devemos, primeiro, examinar a definição de excomunhão, da conveniência e da causa. Segundo,
Quem pode excomungar e ser excomungado. Terceiro, da comunicação com os excomungados. Quarto,
a absolvição da excomunhão.
Na primeira questão discutem-se quatro artigos:

## Art. 1 — Se é boa a seguinte definição da excomunhão: a excomunhão é a separação da comunhão da Igreja, quanto ao fruto e aos sufrágios gerais.
O primeiro discute-se assim. — Parece má a seguinte definição da excomunhão, dada por certos: A
excomunhão é a separação da comunhão da Igreja, quanto ao fruto e aos sufrágios gerais.

1. — Pois, os sufrágios da Igreja aproveitam àqueles por quem se fazem. Ora, a Igreja reza pelos
separados dela, como os heréticos e os pagãos. Logo, pelos excomungados, que também estão fora
dela. Portanto, os sufrágios da Igreja lhes aproveitam.

2. Demais. — Ninguém perde, senão por culpa, os sufrágios da Igreja. Ora, a excomunhão não é culpa,
mas pena. Logo, por ela ninguém perde os sufrágios comuns da Igreja.

3. Demais. — Fruto da Igreja não há outro senão os sufrágios; pois, não podemos aplicar a definição ao
fruto das boas obras temporais, de que não ficam privados os excomungados. Logo, não se deviam
incluir os frutos e os bens temporais na definição.

4. Demais. — A excomunhão menor é uma excomunhão. Ora, por ela não se perdem os sufrágios da
Igreja. Logo, a definição não é boa.

SOLUÇÃO. — Quem pelo batismo entra na Igreja a duas coisas fica adstrito — à comunhão dos fiéis e à
participação dos sacramentos. Destes, a segunda pressupõe a primeira, porque na participação dos
sacramentos também os fiéis comunicam. Por onde, pode alguém ficar fora da Igreja pela excomunhão,
de dois modos. Primeiro, por ficar privado só da participação dos sacramentos, e essa será a
excomunhão menor. Segundo, por ser excluído tanto dessa participação como da comunhão dos fiéis, e
essa será a excomunhão maior ora definida. Não pode haver um terceiro caso — o de ser excluído da
comunhão dos fiéis mas não da participação dos sacramentos, pela razão já dada, a saber, porque os
fiéis comunicam nos sacramentos. Ora, a comunicação dos fiéis é dupla — uma espiritual, como nas
orações mútuas e nas reuniões para receber os sacramentos; outra, a em matéria temporal, suposto
que o seja por atos permitidos. E essas comunicações estão contidas nos versículos seguintes:
Quem se fizer anátema pelos seus delitos.
Negue-se-lhe a boca, a oração, o adeus e a mesa.
Pela negação da boca não se lhe dará o ósculo: pela da oração não se rezará com os excomungados;
pela do adeus não se lhe dará saudação; pela da comunhão, ninguém comunicará com ele nos
sacramentos; nega-se-lhe a mesa porque ninguém comerá com ele. — Ora, a definição referida implica
a separação dos sacramentos, quando diz — quanto ao fruto; da comunhão dos fiéis, na ordem
espiritual, quando diz — e dos sufrágios comuns da Igreja. — Há porém outra definição, fundada na
separação dos dois atos supra-referidos, e é a seguinte: A excomunhão é a separação de qualquer
comunhão ou ato legítimo.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Oramos pelos infiéis mas da oração não colhem eles o
fruto senão quando se converterem à fé. Também podemos orar pelos excomungados, embora não nas
orações que se fazem pelos membros da Igreja. Contudo, não lhes colhem os frutos Enquanto lhes dura
a excomunhão; mas oramos para que se lhes dê o espírito de penitência, a fim de serem absolvidos da
excomunhão.

RESPOSTA À SEGUNDA. — Os nossos sufrágios aproveitam a outrem na medida em que não lhe sofrem
solução de continuidade. Ora, pode haver continuidade entre a ação de um e o outro, a quem aproveita,
de dois modos. Primeiro, em virtude da caridade, que abrange todos os fiéis numa só unidade em Deus,
conforme o dito da Escritura: Eu sou participante, etc. E essa continuidade a excomunhão não a
interrompe. Pois, justamente ninguém pode ser excomungado senão por uma culpa mortal, pela qual já
se apartou da caridade, mesmo sem estar excomungado. Ora, uma excomunhão injusta a ninguém priva
da caridade; pois esta é dos bens máximos, que a ninguém podem ser tirados, contra a vontade. —
Segundo, pela intenção de quem faz os sufrágios, cujo objeto é aquele por quem são feitos. E essa
continuidade a excomunhão a exclui; pois, pela sentença da excomunhão, a Igreja exclui os
excomungados do grêmio dos fiéis, pelos quais os sufrágios se fazem. Por isso, os sufrágios da Igreja,
feitos pela Igreja universal, não lhes aproveitam; e nenhum membro da Igreja, agindo em nome desta,
pode orar por eles, embora um particular possa fazer algum sufrágio com a intenção de lhes obrar a
conversão.

RESPOSTA À TERCEIRA. — O fruto espiritual da Igreja não só resulta dos sufrágios, mas também do
recebimento dos sacramentos e da comunicação dos fiéis.

RESPOSTA À QUARTA. — A excomunhão menor não realiza perfeitamente a essência da excomunhão;
mas algo dela participa. Por onde, não é necessário lhe convenha totalmente com a definição da
excomunhão, mas bastando que o seja apenas parcialmente.

## Art. 2 — Se a Igreja deve excomungar alguém.
O segundo discute-se assim. — Parece que a Igreja não deve excomungar ninguém.

1. — Pois, a excomunhão é uma maldição. Ora, segundo o Apóstolo, somos proibidos de maldizer. Logo,
a Igreja não deve excomungar.

2. Demais. — A Igreja militante deve imitar a triunfante. Ora, na Epístola de S. Judas se lê: Quando o
arcanjo Miguel, disputando com o diabo, altercava sobre o corpo de Moisés, não se atreveu a fulminar-
lhe sentença de blasfemo, mas disse — mande-te o Senhor. Logo, também a Igreja militante não deve
proferir contra ninguém um juízo de maldição e excomunhão.

3. Demais. — Ninguém deve ser entregue às mãos de seu inimigo, salvo quem estiver de todo
desesperado. Ora, pela excomunhão o ex-comungado comungado é entregue às mãos de Satanás, como
o diz o Apóstolo. Logo, como de ninguém devemos desesperar nesta vida, a Igreja não deve excomungar
a ninguém.
Mas, em contrário, O Apóstolo manda que um certo seja excomungado.

2. Demais. — No Evangelho se diz daquele que despreza ouvir as palavras da Igreja: Tem-no por um
gentio ou um publicano. Ora, os gentios estão fora da Igreja. Logo, os que desprezam ouvir as palavras
da Igreja, devem ser excluídos pela excomunhão.

SOLUÇÃO. — O juízo da Igreja deve ser conforme ao juízo de Deus. Ora, Deus pune de muitos modos os
pecadores, para trazê-las ao bem: ou castigando-os com flagelos; ou abandonando-os a si próprios de
maneira que, subtraindo-lhes os seus auxílios, que os livram de cair no mal, reconheçam suas fraquezas
e voltem humildes ao Deus de que se afastaram na sua soberba. Ora, de ambos esses modos a Igreja, na
sentença de excomunhão, imita o juízo divino. Assim, quando exclui alguém da comunhão dos fiéis, para
que disso se envergonhe, imita o juízo divino, que castiga com os seus flagelos. E quando exclui dos
sufrágios e dos outros bens espirituais, imita o juízo divino pelo qual o homem é abandonado a si
próprio, a fim de que conhecendo-se a si mesmo com humildade, volte para Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — De dois modos pode se dar a maldição. — Primeiro,
tendo como intenção o mal mesmo que irrogamos ou dizemos, e tal maldição é absolutamente
proibida. — Ou com a intenção de que redunde em bem de outrem o mal que lhe desejamos com a
nossa maldição. E assim, a maldição é às vezes lícita e salutar, do mesmo modo que um médico pratica
sobre um doente o mal da incisão, para livrá-lo da doença.

RESPOSTA À SEGUNDA. — O diabo é incorrigível. Por isso não é susceptível de nenhum bem, pela pena
de excomunhão.

RESPOSTA À TERCEIRA. — O fato mesmo de ser um privado dos sufrágios da Igreja causa-lhe tríplice
dano, oposto ao tríplice bem que recebemos dos sufrágios da Igreja. — Pois, esses sufrágios valem para
o aumento da graça nos que já a tem, ou para merecê-la nos que não a tem. Por isso, o Mestre das
Sentenças diz: Da graça de Deus ficamos privados pela excomunhão. — Também valem para guarda da
virtude. Por isso diz que ficamos privados da proteção; não que o excomungado seja absolutamente
excluído da providência divina, senão só daquela proteção com que Deus guarda de modo mais especial
os filhos da Igreja. — Servem também para nos defender do inimigo. Por isso diz, que ao diabo é dado
maior poder, espiritual e corporal, de agir sobre o excomungado. Por isso, na Igreja primitiva quando era
necessário trazer os homens à fé por meio de sinais, assim como os dons do Espírito Santo se
manifestavam visivelmente, assim também a excomunhão era conhecida pelas vexações corporais
causadas do diabo. Nem há mal em entregar ao inimigo quem não desesperou; pois, não lhe é entregue
como danando, mas como corrigindo, porque a Igreja tem o poder de lh'o arrancar das mãos quando
quiser.

## Art. 3 — Se alguém deva ser excomungado, por causa de um dano material.
O terceiro discute-se assim. — Parece que ninguém deve ser excomungado por causa de um dano
material.

1. — Pois, não deve a pena exceder à culpa. Ora, a pena de excomunhão é a privação de um bem
espiritual, que tem preeminência sobre todos os bens temporais. Logo, por causa de um bem temporal
ninguém deve ser excomungado.

2. Demais. — A ninguém devemos pagar o mal com o mal, segundo o preceito do Apóstolo. Ora, seria
pagar o mal com o mal o excomungar alguém por um mal temporal. Logo, de nenhum modo isso deve
fazer-se.
Mas, em contrário, Pedro condenou à morte Ananias e Safira pela defraudação do preço de um campo.
Logo, também à Igreja é lícito ex-comungar por causa de danos temporais.

SOLUÇÃO. — Pela excomunhão o juiz eclesiástico exclui de certo modo, do Reino, os excomungados.
Ora, não deve excluir do Reino senão os indignos, como resulta da definição do poder das chaves. E
ninguém se torna indigno senão pelo pecado mortal, que priva da caridade, que é o caminho
conducente ao Reino. Por onde, ninguém pode ser excomungado senão por causa de pecado mortal.
Mas, quem prejudica a outrem no seu ou nos seus bens temporais, de certo modo peca mortalmente e
age contra a caridade. Portanto, contra quem causou um dano material, pode a Igreja proferir a
excomunhão. Ora, como a excomunhão é a gravíssima das penas, as penas são remédios, segundo o
Filósofo, por isso, assim como um médico sábio começa pelos remédios mais brandos e menos
perigosos, assim também não deve a excomunhão ser infligida, mesmo por um pecado mortal, senão ao
pecador contumaz, ou porque não se apresentou ao juiz, ou por ter abandonado o juízo sem licença e
antes de ele terminado, ou por não lhe obedecer à determinação. Pois então, se depois de advertido
não obedecer e desprezar, será reputado contumaz; e deve ser excomungado pelo juiz, que já nada
mais tem a fazer contra ele.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A gravidade da culpa não se mede pelo dano causado
pelo seu autor, mas pela vontade que teve de agir contra a caridade. Por onde, embora a pena de
excomunhão exceda o dano, não excede contudo a gravidade da culpa.

RESPOSTA À SEGUNDA. — Ao que a pena corrige não se lhe faz um mal mas um bem; porque as penas
são remédios, como se disse.

## Art. 4 — Se uma excomunhão injustamente proferida não produz nenhum efeito.
O quarto discute-se assim. — Parece que uma excomunhão injustamente proferida não produz
nenhum efeito.

1. — Pois, a excomunhão priva da proteção e da graça de Deus, da qual ninguém pode ser privado sem
injustiça. Logo, a excomunhão proferida injustamente não produz nenhum efeito.

2. Demais. — Jerônimo diz que seria orgulho farisaico considerar como ligado ou absolvido, quem foi
ligado ou absolvido injustamente. Ora, o orgulho farisaico se inspira na soberba e no erro. Logo a
excomunhão injusta não produz nenhum efeito.
Mas, em contrário. — Segundo Gregório, ordens de um pastor, quer justas, quer injustas, devem ser
temidas. Ora, não o seriam se não produzissem nenhum dano, mesmo quando injusto. Logo, etc.

SOLUÇÃO. — Uma excomunhão pode ser considerada injusta de dois modos. — Primeiro por parte do
seu autor, como quando o faz por ódio ou ira. E então a excomunhão nem por isso deixa de produzir o
seu efeito, embora quem excomunga peque; pois, o excomungado sofre justamente, embora o autor da
excomunhão tenha procedido injustamente. — De outro modo, por parte da excomunhão mesma: ou
por não ser justa sua causa; ou por ter sido proferida a sentença, em desobediência à exigência do
direito. E então, sendo a sentença de modo errada a se tornar nula, não tem nenhum efeito, por não ser
excomunhão. Se porém o erro não anular a sentença, esta produz o seu efeito. O excomungado deve
então obedecer-lhe humildemente, o que lhe redundará em mérito. Ou pode recorrer a um juiz superior
ou pedir ser absolvido da excomunhão. Se porém a desprezar por isso mesmo pecará mortalmente. —
Acontece porém algumas vezes, que a causa seja justa por parte de quem excomunga, sem o ser da
parte do excomungado; como quando alguém é excomungado por um falso crime, provado em juízo. E
então, se humildemente o suportar, o mérito da humildade recompensará o dano da excomunhão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Embora não possamos perder injustamente a graça de
Deus, podemos porém perder injustamente as condições que da nossa parte disporiam a essa graça;
assim, se alguém fosse privado do poder de ensinar, que justamente tem. E neste sentido dizemos que a
excomunhão priva da graça de Deus, como do sobre dito de colhe.

RESPOSTA À SEGUNDA. — Jerônimo se refere à culpa e não as penas, que podem também ser
injustamente infligidas pelos reitores das Igrejas.