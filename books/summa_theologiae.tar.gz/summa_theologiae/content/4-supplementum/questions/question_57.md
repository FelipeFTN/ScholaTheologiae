# Questão 57: Do parentesco legal oriundo da adoção.
Em seguida devemos tratar do parentesco legal, oriundo da adoção. E nesta questão discutem-se três
artigos:

## Art. 1 — Se a adoção foi bem definida: o ato de assumir legitimamente um estranho como filho ou neto, e assim por diante.
O primeiro discute-se assim. ─ Parece má a seguinte definição da adoção: A adoção é o ato de assumir
legitimamente um estranho como filho, ou neto, e assim por diante.

1. Pois, o filho deve estar sujeito ao pai. Ora, às vezes o adaptado não fica sob o poder do pai adotante.
Logo, nem sempre pela adoção se assume um, como filho.

2. Demais. ─ Os pais devem entesourar para os filhos, no dizer do Apóstolo. Ora, não é sempre preciso
que o pai adotante entesoure para o adotado; pois, às vezes este não sucede nos bens daquele. Logo, a
adoção não consiste em tomar alguém como filho.

3. Demais. ─ A adoção, pela qual um estranho é assumido como filho, é assimilada à geração natural,
que engendra naturalmente o filho Logo, a quem cabe a geração natural do filho, também cabe a
adoção. Ora, isto é falso, porque quem não é livre, o menor de vinte e cinco anos, e a mulher não
podem adotar, apesar de poderem engendrar filhos. Logo, não se pode definir com propriedade a
adoção como o fato de assumir alguém como filho.

4. Demais. ─ O fato de assumir um estranho como filho parece necessário, para suprir a falta de filhos
naturais. Ora, quem não pode gerar, como o mutilado e o impotente, é que sobretudo padece a falta de
filhos naturais. Logo, esse é que sobretudo poderia tomar alguém como filho. Ora, tal não lhe é
permitido. Logo, adotar não é assumir ninguém como filho.

5. Demais. ─ No parentesco espiritual, pelo qual assumimos um estranho como filho, a quem não
engendramos carnalmente, pode indeferentemente um de idade tornar-se pai de um menor, e ao
inverso; porque um moço pode batizar a um velho e inversamente. Se, portanto, pela adoção tomamos
a um estranho como filho, sem geração carnal, do mesmo modo poderia indiferentemente um mais
velho adotar o mais moço; ou o mais moço o mais velho. O que não é verdade. Donde, se conclui o
mesmo que antes.

6. Demais. ─ O adotado não difere em nenhum grau do adotante. Logo, todo adotado o é como filho. E
assim, não é exato falar-se em adoção como neto.

7. Demais. ─ A adoção procede do amor; por isso, se diz que Deus, levado da caridade nos adotou como
filhos. Ora, devemos ter maior caridade para com os parentes que para com os estranhos. Logo, não
devemos adotar nenhum estranho, mas um parente.

SOLUÇÃO. - A arte imita a natureza e supre a falta da natureza quando ela falha. Ora, assim como
podemos engendrar filhos, pela geração natural assim também pelo direito positivo, que é a arte do
bom e do equitativo, podemos assumir alguém como filho, por semelhança com o filho natural, para
suprir a falta dos filhos perdidos, razão precípua pela qual foi introduzida a adoção. Mas como o ato de
assumir implica um ponto de origem, pois, quem assume não é o assumido, necessariamente quem é
assumido como filho há de ser uma pessoa estranha. Por onde, assim como a geração natural tem um
termo final, a forma, que é o fim da geração; e um termo de origem ─ a forma contrária, assim também
a geração legal tem um termo vital ─ o filho ou o neto; e um ponto de origem ─ a pessoa estranha. Por
onde, é claro que a referida definição compreende o gênero da adoção. que é chamada ─ o ato de
assumir legitimamente; o ponto de origem, porque se diz ─ um estranho; e o termo final, quando diz ─
como filho ou neto.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A filiação adotiva é uma imitação de filiação natural.
Donde duas espécies de adoção. Uma, que imita perfeitamente a filiação natural. Essa se chama
adrogação e faz passar o adotado para o poder do adotante. Assim, o adotado sucede ex intestato ao
pai adotante, nem pode o pai privá-la, sem culpa dele, da quarta parte da herança. E então não pode ser
adotado senão uma pessoa livre, isto é., sem pai, ou, se o tiver, que for emancipada. Essa adoção não
tem lugar senão por autoridade do príncipe. ─ Outra espécie de adoção é a que imita imperfeitamente a
filiação natural; é chamada simplesmente adoção, pela qual o adotado não cai sob o poder do adotante.
Por isso, é antes uma disposição para a adoção perfeita, do que a adoção perfeita mesmo. E essa adoção
pode recair mesmo sobre quem não é livre; e sem a autoridade do príncipe, bastando a do magistrado.
Então o adotado não sucede nos bens do adotante; nem está obrigado este a lhe deixar nenhum de seus
bens por testamento, se não querendo.
Donde se deduz clara a resposta à segunda objeção.

RESPOSTA À TERCEIRA. ─ A geração natural se ordena à reprodução da espécie; por isso todos podem
gerar naturalmente, que possuem completas as qualidades da espécie. Ora, a adoção se ordena à
sucessão hereditária; por isso dela são capazes apenas os que tem o poder de dispor da sua herança.
Portanto, quem não dispõe de si, ou quem é menor de vinte e cinco anos, ou a mulher, não pode adotar
ninguém, senão por concessão especial do príncipe.

RESPOSTA À QUARTA. ─ Por aquele que tem impedimento perpétuo de gerar não pode a herança
passar para descendentes. Por isso, seus bens devem reverter aos que lhe devem suceder por direito de
parentesco. Por onde, não pode adotar, por isso mesmo que não pode gerar naturalmente. Além disso,
maior dor sofremos com a perda de filhos, que por filhos nunca tivemos. Por onde, quem está impedido
de gerar, não precisa da consolação por não ter filhos, como precisam os que os tiveram e perderam; ou
ainda, que os podiam ter e não o tem por algum obstáculo acidental.

RESPOSTA À QUINTA. - O parentesco espiritual se contrai pelo sacramento, pelo qual os fiéis renascem
em Cristo, em quem não difere o homem da mulher, nem o escravo do livre, nem o moço do velho. Por
isso, pode indiferentemente tornar-se um pai espiritual do outro. Ao passo que, a adoção tem por
escopo a sucessão na herança e uma certa sujeição do adotado ao adotante. Ora, não convém que um
mais velho dependa do mais moço, na administração dos bens da família. Por isso, o mais moço não
pode adotar o mais velho; mas é necessário, segundo as leis, que o adotado seja mais moço que o
adotante, de modo que lhe pudesse ser filho natural.

RESPOSTA À SEXTA. ─ Assim como se podem perder os filhos, assim também os netos. Por onde, como
a adoção foi introduzida para consolar da perda dos filhos, tanto pode um ser subrogado em lugar do
filho, como do neto e assim por diante.

RESPOSTA À SÉTIMA. ─ O parente deve suceder conforme o direito do parentesco. Por isso, tal direito
não cabe a quem recebe a sucessão em virtude da adoção. E o parente adotado, a quem não couber a
sucessão hereditária; não é adotado como parente, se não como estranho, relativamente à herança do
adotante.

## Art. 2 — Se pela adoção se contrai algum vínculo impediente do matrimônio.
O segundo discute-se assim. ─ Parece que pela adoção não se contrai nenhum vínculo impediente do
matrimônio.

1. Pois a cura das almas é mais nobre que a do corpo. Ora, o fato de estar alguém sujeito
espiritualmente aos cuidados de outrem não gera nenhum vínculo de parentesco entre ambos; do
contrário todos os habitantes de uma paróquia seriam parentes do cura, e não poderiam casar com o
filho do mesmo. Logo, nem pode produzir esse efeito a adoção, que sujeita o adotado à direção do
adotante.

2. Demais. ─ O fato de fazer um beneficio a outro não estabelece entre eles nenhum parentesco. Ora, a
adoção outra coisa não é mais que a colação de um benefício. Logo, a adoção não gera nenhum vínculo
de parentesco.

3. Demais. ─ O pai natural provê ao filho sobretudo em três coisas, como diz o Filósofo: dá-lhe a vida, a
nutrição e a educação. Ora, a sucessão hereditária é posterior a elas. Mas, o fato de alguém dar a
outrem nutrição e educação não faz contrair com ele nenhum vínculo de parentesco. Do contrário as
amas, os pedagogos e os mestres seriam parentes daqueles de quem cuidam; o que é falso. Logo, nem
pela adoção, pela qual um sucede na herança de outro, se contrai qualquer parentesco.

4. Demais. ─ Os sacramentos da Igreja não estão sujeitos às leis humanas. Ora, o matrimônio é um
sacramento da Igreja. Logo, como a adoção foi introduzida pela lei humana, parece que não pode
impedir o matrimônio qualquer vínculo contraído pela adoção.
Mas, em contrário. ─ O parentesco impede o matrimônio. Ora, a adoção dá origem a um determinado
parentesco, o legal, como resulta da sua definição; pois, é um certo parentesco proveniente da adoção.
Logo, a adoção causa um vínculo impediente do matrimônio.

2. Demais. ─ O mesmo se conclui das autoridades citadas pelo Mestre.

SOLUÇÃO. ─ A lei divina excluiu do matrimônio sobretudo aquelas pessoas, que a necessidade leva a
viverem sob o mesmo teto. A fim de que, como diz Rabhi Moisés, se pudessem praticar a conjunção
carnal, não se abrisse fácil caminho à concupiscência, para reprimir a qual é ordenado o matrimônio. E o
filho adotado vivendo na casa do pai adotante como o filho natural, por isso, as leis humanas proibiram
a tais filhos contraírem matrimônio. Tal proibição foi aprovada pela Igreja. Donde vem, que o
parentesco legal impede o matrimônio. Donde se deduz a resposta às três primeiras objeções, porque
todos os casos visados não implicam nenhuma convivência capaz de fomentar a concupiscência. Por isso
não causam nenhum parentesco impediente ao matrimônio.

RESPOSTA À QUARTA. ─ A proibição da lei humana não bastaria para impedir o matrimônio, se não
interviesse a autoridade da Igreja, que também o proíbe.

## Art. 3 — Se o parentesco legal não se contrai senão entre o pai adotante e o filho adotado.
O terceiro discute-se assim. ─ Parece que o parentesco legal não se contrai senão entre o pai adotante
e o filho adotado.

1. Pois, parece que esse parentesco devia sobretudo ligar o pai adotante e a mãe natural do adotado,
como se dá com o parentesco espiritual. Ora, entre esses não há nenhum parentesco. Logo, nem entre
outras pessoas, além do adotante e do adotado.

2. Demais. ─ O parentesco impediente do matrimônio é um impedimento perpétuo. Ora, entre o filho
adotado e a filha natural do adotante não há nenhum impedimento perpétuo; pois, dissolvida a adoção
pela morte do adotante ou pela emancipação do adotado, podem eles contrair casamento. Logo, não
tinha o filho com ela nenhum parentesco impediente do matrimônio.

3. Demais. ─ O parentesco espiritual não passa a nenhuma pessoa incapaz de apresentar outra a receber
um sacramento ou de o receber ela própria: por isso não se transmite a um não-batizado. Ora, a mulher
não pode adotar, como do sobredito se colhe. Logo, o parentesco legal não se transmite do marido para
a mulher.

4. Demais. ─ O parentesco espiritual é mais forte que o legal. Ora, o espiritual não atinge o neto. Logo,
nem o legal.
Mas, em contrário. ─ Mais concorda o parentesco legal com a conjunção carnal ou a geração da carne,
que o espiritual. Ora, o parentesco espiritual se transmite a terceira pessoa. Logo, também o legal.

2. Demais. ─ Esta mesma conclusão é apoiada pelas autoridades citadas pelo Mestre.

SOLUÇÃO. ─ Há três espécies de parentesco legal. A primeira, a existente entre os descendentes, e é
contraída entre o pai adotante e o filho adotado e o filho do filho adotivo e o neto e assim por diante. A
segunda, entre o filho adotivo e o filho carnal. A terceira, a modo de afinidade, entre o pai adotante e a
mulher do filho adotivo; ou ao contrário, entre o filho adotado e a esposa do pai adotante. Ora, a
primeira espécie e a terceira impedem perpetuamente o matrimônio. A segunda, porém, não; salvo
enquanto o adotado permanece dependente do adotante; por onde, morto o pai, ou emancipado o
filho, pode contrair matrimônio com a filha natural do adotante.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Pela geração espiritual não sai o filho do poder do pai, ao
contrário do que se dá pela adoção. E assim um filho espiritual permanece filho do pai natural e
simultaneamente, filho espiritual do seu padrinho. O que não se dá com o filho adotivo. Por isso, não
contrai nenhum parentesco o filho adotado com o pai adotante, nem com a mãe e com o pai naturais,
como se dava com o parentesco espiritual.

RESPOSTA À SEGUNDA. ─ O parentesco legal impede o matrimônio por causa da coabitação. Por isso,
desaparecida a necessidade desta, nenhum mal há na disparição desse impedimento; por exemplo,
quando o adotado não esta mais dependente do pai adotivo. Mas, o pai adotante e a sua mulher
conservam sempre uma certa autoridade sobre o filho adotado e sua esposa. Por isso, subsiste um
vínculo entre eles.

RESPOSTA À TERCEIRA. ─ Também a mulher, por concessão do príncipe, pode adotar; por isso, também
sobre ela pode recair o parentesco legal. Além disso, a causa, por que o parentesco legal não possa ter
como sujeito um não-batizado, não vem de não poder ele apresentar uma pessoa a um sacramento;
mas de não poder receber nenhuma realidade espiritual.

RESPOSTA À QUARTA. ─ Pelo parentesco espiritual o filho não fica em dependência da direção e dos
cuidados do pai espiritual, ao contrário do que se dá com o parentesco legal. Pois, tudo o dependente
do filho adotado há de passar para o poder do pai adotante. Por onde, adotado um pai, adotados lhe
ficarão filhos e netos sob o seu poder.