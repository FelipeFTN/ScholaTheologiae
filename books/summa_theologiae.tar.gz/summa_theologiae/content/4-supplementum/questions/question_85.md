# Questão 85: Da claridade dos corpos bem-aventurados.
Em seguida devemos tratar da claridade dos corpos ressurrectos bem-aventurados.
E nesta questão discutem-se três artigos:

## Art. 1 — Se a claridade é propriedade dos corpos gloriosos.
O primeiro discute-se assim. ─ Parece que a claridade não é propriedade dos corpos gloriosos.

1. ─ Pois, como diz Avicena, todo corpo luminoso é constituído de partes pérvias. Ora, as partes do
corpo glorioso não são pérvias, pois, nuns predomina a terra e noutro as carnes e os ossos. Logo, os
corpos gloriosos não serão lúcidos.

2. Demais. ─ Todo corpo lúcido oculta o que lhe está por trás; por isso uma luz eclipsa outros; e uma
chama impede ver a que lhe está atrás. Ora, os corpos gloriosos não ocultarão o seu interior; pois, como
diz Gregório aquilo de Job ─ Não se lhe igualará o ouro nem o cristal ─ lá, na pátria celeste, a corpulência
dos membros não ocultará os pensamentos de um aos olhos dos outros; e também a própria harmonia
do corpo será patente aos olhos corpóreos. Logo, os corpos gloriosos não serão lúcidos.

3. Demais. ─ A luz e a cor exigem no seu sujeito disposições contrárias; pois, como o ensina Aristóteles, a
luz é a superfície visível de um corpo sem contornos determinados, ao passo que a cor supõe um corpo
de limites fixos. Ora, os corpos gloriosos terão cor; porque, como diz Agostinho, a beleza de um corpo
consiste na proporção das partes acompanhada de uma certa suavidade de colorido. E da beleza não
podem ficar privados os corpos gloriosos. Logo, os corpos gloriosos não serão lúcidos.

4. Demais. ─ Se os corpos gloriosos fossem dotados de claridade, desta deveriam participar igualmente
todas as suas partes, assim como todas terão a mesma impassibilidade, subtileza e agilidade. Ora, isto
não é possível, porque uma parte terá maior disposição à claridade, que outras, como os olhos, que as
mãos, o espírito que os ossos, e os humores que as carnes ou os nervos. Logo, parece que esses corpos
não hão de ser lúcidos.
Mas, em contrário, o Evangelho: Refulgirão os justos como o sol, no reino de seu Pai. E noutro lugar da
Escritura: Refulgirão os justos e como faíscas por um canavial discorrerão.

2. Demais. ─ Diz o Apóstolo: Semeia-se em vileza, ressuscitará em glória. O que se refere à claridade,
como o demonstra: o que está dito antes, quando compara a glória dos ressurrectos à claridade das
estrelas. Logo, os corpos dos santos ressurgirão luminosos.

SOLUÇÃO. ─ Que os corpos dos santos hão de ser luminosos depois da ressurreição, devemos admiti-lo
baseados na autoridade da Escritura, que assim o promete. A causa porém dessa claridade uns a
buscam na quinta essência, que então será predominante na constituição do corpo humano. Mas, como
isto é absurdo, consoante dissemos muitas vezes, é melhor dizermos que essa claridade será causada
pela redundância da glória da alma no corpo. Pois, uma cousa é recebida ao modo de ser do sujeito e
não ao do agente. Por isso, a claridade da alma espiritual será recebida corporalmente pelo corpo. Por
onde, conforme a maior claridade da alma, por causa do seu maior mérito, assim diferirá essa claridade
da do corpo, como diz o Apóstolo. E assim, pelo corpo glorioso se conhecerá a glória da alma, assim
como através de um vaso de vidro vemos a cor do corpo nele contido, como diz Gregório, comentando
aquilo de Job. ─ Não lhe igualará o ouro nem o cristal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Avicena se refere aqueles corpos cuja claridade resulta da
natureza dos seus elementos componentes. Ora, não será essa a do corpo glorioso, luminoso, antes,
pelo mérito da virtude.

RESPOSTA À SEGUNDA. ─ Gregório compara os corpos luminosos com o ouro por causa da claridade
deles; e ao cristal, porque serão translúcidos. Donde devemos concluir que serão ao mesmo tempo
translúcidos e luminosos. E o fato de um corpo luminoso não ser translúcido lhe provém de ser a
claridade causada por partes lúcidas densas; ora, a densidade repugna à transparência. Mas a claridade
dos corpos gloriosos terá outra causa, como se disse; e a sua densidade não lhes impede serem
transparentes, como a densidade do vidro também não o priva de ser translúcido. ─ Mas outros dizem
que os corpos gloriosos são comparáveis ao vidro, não por serem transparentes, mas por semelhança.
Pois,assim como podemos ver através de um vaso de vidro o seu conteúdo, assim a glória da alma
poderá ser vista através do corpo glorioso a que estiver unida. Mas a primeira opinião é mais aceitável,
porque explica melhor a dignidade do corpo e é mais consoante às palavras de Gregório.

RESPOSTA À TERCEIRA. ─ A glória do corpo não destrói, mas aperfeiçoa a natureza. Por isso o corpo
conservará a cor que lhe é própria, em virtude da natureza das suas partes. Mas será acrescida pela
glória da alma, assim como também vemos os corpos coloridos por natureza rebrilharem ao esplendor
do sol ou por outra causa extrínseca ou intrínseca.

RESPOSTA À QUARTA. ─ Assim como a claridade da glória redunda da alma no corpo ao modo deste, e
nele está de modo diferente por que o está na alma, assim redundará ela em cada uma das partes do
corpo ao modo destas. Por onde, não há inconveniente em terem essas diversas partes claridades
diversas, enquanto as suas naturezas as tornam diversamente dispostas a recebê-la. Nem há
semelhança com os outros dotes do corpo, que não encontram nas diversas partes do corpo disposições
diversas.

## Art. 2 — Se a claridade de um corpo glorioso pode ser vista por olhos não gloriosos.
O segundo discute-se assim. ─ Parece que a claridade de um corpo glorioso pode ser vista por olhos
não-gloriosos.

1. ─ Pois, deve haver proporção entre o objeto visível e a vista. Ora, olhos não glorificados não são
proporcionados a contemplar a claridade da glória, por ser de gênero diverso da luminosidade da
natureza. Logo, a claridade de um corpo glorioso não poderá ser vista por olhos não-gloriosos.

2. Demais. ─ A claridade do corpo glorioso será maior que presentemente a do sol; pois, no século
futuro, também a do sol será mais intensa do que agora, como diz a Escritura. Mas muito maior será a
do corpo glorioso, por causa do qual o sol e todo o mundo brilharão com maior brilho. Ora, os olhos
não-gloriosos não podem fixar o disco solar por causa da intensidade da sua luz. Logo e com maior
razão, não poderá ver a claridade de um corpo glorioso.

3. Demais. ─ Um objeto, visível colocado em frente aos nossos olhos necessariamente o veremos se não
tivermos maus olhos. Ora, a claridade do corpo glorioso colocado em face de olhos não gloriosos não é
necessariamente vista por eles; assim se deu com os discípulos, que viram o corpo do Senhor depois da
ressurreição, sem lhe contemplarem a claridade. Logo, essa claridade não será visível por olhos não-
gloriosos.
Mas, em contrário, àquilo do Apóstolo ─ Conforme ao seu corpo glorioso, diz a Glosa: Será comparável à
claridade que teve na transfiguração. Ora, essa claridade foi vista pelos olhos não-glorificados dos
discípulos. Logo, também a claridade do corpo glorificado não será visível por olhos não-gloriosos.

2. Demais. ─ No dia do juízo os ímpios serão glorificados quando virem a glória dos justos, como o
concluímos de um lugar da Escritura. Ora, não lhes veriam plenamente a glória se não lhes vissem
também a claridade dos corpos. Logo, etc.

SOLUÇÃO. ─ Certos opinaram que a claridade de um corpo glorioso não pode ser vista por olhos não-
gloriosos senão por milagre. Mas isto não pode ser senão tomando a claridade em sentido equívoco.
Porque a natureza da luz, como tal, é mover-nos a vista; e à vista, como tal, é natural perceber a luz,
assim como a verdade tem relação natural com o intelecto e o bem, com o afeto. Por isso, uma vista que
de nenhum modo pudesse perceber qualquer luz, seria tomada em sentido equívoco ou aquela ou esta.
O que não podemos dizer no caso vertente; porque, do contrário, nada daríamos a conhecer afirmando
que os corpos gloriosos hão de ser luminosos, assim como quem diz que lá no céu um cão nada significa
a quem como cão só conhece o animal desse nome. Donde devemos concluir que a claridade de um
corpo glorioso não poderá vista por olhos não gloriosos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A claridade da glória será de gênero diverso da claridade
da natureza, quanto à sua causa, mas não quanto à espécie. Por onde, assim como a claridade, em razão
da sua natureza específica é proporcionada à vista, o mesmo se dará com a claridade gloriosa.

RESPOSTA À SEGUNDA. ─ Assim como a natureza de um corpo glorioso não pode sofrer nenhuma
paixão senão mediante a alma, assim, pela sua propriedade gloriosa não age senão mediante a alma.
Ora, uma claridade intensa não ofende a vista quando atua por meio da alma, pois, então, cama prazer
mais vivo, mas à ofende agindo por ação natural, aquecendo e dilatando o órgão da vista Ou
desagregando os espíritos vitais. Por onde, a claridade de um corpo glorioso, embora exceda à do sol,
contudo, longe de por sua natureza ofender a vista, causa-lhe prazer. Pois, essa claridade a Escritura a
compara à do jaspe.

RESPOSTA À TERCEIRA. ─ A claridade do corpo glorioso resulta do mérito da vontade. Por isso depende
do império da vontade deixar-se ver ou não; e no poder do corpo glorioso esta manifestar ou ocultar a
sua claridade. Tal era a opinião de Prepositivo.

## Art. 3 — Se um corpo glorioso é necessariamente visto por um corpo não glorioso.
O terceiro discute-se assim. ─ Parece que um corpo glorioso será necessariamente visto por um corpo
não-glorioso.

1. ─ Pois, os corpos gloriosos serão lúcidos. Ora, um corpo lúcido ao mesmo tempo que se manifesta
também manifesta os outros corpos. Logo, os corpos gloriosos serão necessariamente vistos.

2. Demais. ─ Todo corpo, que oculta os corpos colocados por trás de si, é necessariamente visto, por isso
mesmo que oculta os referidos corpos colocados por detrás. Ora, os corpos gloriosos ocultarão à vista
tudo o que lhes estiver colocado por trás; pois, serão corpos dotados de cor. Logo, serão
necessariamente vistos.

3. Demais. ─ Como a quantidade é inerente ao corpo, assim a qualidade, que o torna visível. Ora, a
quantidade não dependerá da vontade, a ponto de um corpo glorioso poder tê-la maior ou menor, a seu
talante. Logo, nem a qualidade, que o torna visível, pode, a seu bel prazer, ser invisível.
Mas, em contrário. ─ Nosso corpo será glorificado à semelhança do de Cristo, depois da ressurreição.
Ora, o corpo de Cristo ressurrecto não era necessariamente visto; ao contrário, em Emaús desapareceu
à vista dos discípulos, como o refere o Evangelho. Logo, também um corpo glorificado não será
necessariamente visto.

2. Demais. ─ Os ressurgidos terão o corpo plenamente obediente à alma. Logo, um corpo glorioso
poderá deixar-se ver ou não, conformo lhe aprouver.

SOLUÇÃO. ─ A visibilidade de um objeto depende da sua ação sobre a vista. Mas o fato mesmo de um
objeto agir ou não sobre outro, que lhe é estranho, não lhe acarreta nenhuma alteração. Por onde, sem
mudar nenhuma propriedade pertencente à perfeição de um corpo glorificado, pode ele deixar-se ver
ou não. Por isso, no poder da alma glorificada estará deixar ver ou não o seu corpo, assim como a alma
pode exercer sobre o corpo qualquer ação que quiser; do contrário, o corpo glorioso não seria um
instrumento totalmente obediente ao agente principal.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A claridade em questão dependerá do corpo glorioso de
modo que ele possa manifestá-la ou ocultá-la.

RESPOSTA À SEGUNDA. ─ A cor de um corpo não lhe impede a transparência senão modificando a vista;
porque a vista não pode ser modificada ao mesmo tempo por duas cores de modo a percebê-las ambas
perfeitamente. Ora, a cor de um corpo glorioso dependerá perfeitamente da alma, que poderá, por
meio da cor, modificar ou não a vista, como lh'o aprouver. Por onde, no poder do corpo glorioso estará
ocultar ou não outro corpo que lhe esteja atrás.

RESPOSTA À TERCEIRA. ─ A quantidade é um atributo inerente ao corpo glorioso; nem poderia ela
alterar-se por vontade da alma, sem alterar-se intrinsecamente o corpo glorioso, o que lhe repugnaria à
impassibilidade. Não há, pois, símil entre a quantidade e a visibilidade, porque também a qualidade que
o torna visível não lh'o pode a alma subtrair conforme lhe aprouver; só a sua ação é que pode ser
suspensa, podendo então ocultar-se o corpo, conforme o quiser a alma.