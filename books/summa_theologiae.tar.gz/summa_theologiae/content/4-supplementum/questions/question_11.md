# Questão 11: Do sigilo da confissão.
Em seguida devemos tratar do sigilo da confissão.
E nesta questão discutem-se cinco artigos:

## Art. 1 — Se em qualquer caso o sacerdote está obrigado a ocultar os pecados que ouviu sob o sigilo da confissão.
O primeiro discute-se assim. ─ Parece que nem em todos os casos está o sacerdote obrigado a ocultar
os pecados que ouviu sob o sigilo da confissão.

1. ─ Pois, como diz Bernardo, o que foi instituído por caridade não deve redundar contra a caridade. Ora,
em certos casos, ocultar o ouvido na confissão encontraria a caridade; assim, se um sacerdote tivesse
conhecimento, na confissão, de um herético, que não pudesse induzir a não corromper o povo; e
semelhantemente, do que soubesse, na confissão, da afinidade entre os que querem casar-se. Logo,
nesses casos deve o sacerdote revelar a confissão.

2. Demais. ─ O ao que estamos obrigados só por preceito da Igreja não é necessário observar-se se a
Igreja legislou em contrário. Ora, o segredo da confissão foi instituído por mandamento da Igreja
somente. Logo, se a Igreja ordenar, que quem souber algo em matéria de tal pecado o diga, quem o
souber por confissão deve dizê-lo.

3. Demais. ─ Devemos salvar de preferência a nossa consciência que a fama de outrem, porque a
caridade é ordenada. Ora, às vezes em ocultando um pecado ouvido em confissão o sacerdote pode
causar dano à própria consciência; assim, se for chamado como testemunha desse pecado e jurar dizer a
verdade, ou como quando o abade sabe por confissão o pecado do prior que lhe está sujeito, e cuja
ocasião o induz à ruína, se o deixar continuar no priorado; e por isso, por causa do seu dever da cura
pastoral, está obrigado a tirar-lhe o priorado; ora, assim procedendo, publica a confissão. Logo, parece
que em certos casos é lícito publicar a confissão.

4. Demais. ─ Pela confissão ouvida, pode o sacerdote ter consciência de que o confitente é indigno de
uma prelatura. Ora, todo aquele que puder está obrigado a impedir a promoção dos indignos. Logo,
como se opuser a essa promoção dará suspeitas de que conhece o pecado e assim, de certo modo,
revelará a confissão, conclui-se que em certos casos é permitido revelar a confissão. Mas, em contrário,
uma decretal: Tome cuidado o sacerdote. Não vá por palavras, por sinais ou por outro qualquer modo,
revelar a confissão do pecador.

2. Demais. ─ O sacerdote deve imitar a Deus, de quem é ministro. Ora, Deus os pecados revelados na
confissão não os revela, mas os oculta. Logo, também o sacerdote não nos deve revelar.

SOLUÇÃO. ─ Nos sacramentos, as práticas externas são os sinais da realidade interna. Por onde, a
confissão, pela qual nos sujeitamos do sacerdote, é o sinal da sujeição interior, pela qual nos sujeitamos
a Deus. Ora, Deus oculta o pecado daquele que se lhe submete pela penitência. Portanto, o mesmo
deve dignificar o sacramento da penitência. E assim, o sacramento necessariamente exige que o
confessor oculte os pecados; e como violador do sacramento peca quem o revela. Além disso, esse
ocultamento tem outras utilidades: atrai maior número de pessoas ao sacramento e os pecados são
também mais sinceramente confessados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Certos dizem que o sacerdote não está obrigado a
conservar sob o sigilo da confissão senão os pecados de que o penitente prometeu emendar-se; do
contrário poderá revelá-los a quem puder ser útil ao confitente, mas não a quem lhe venha ser
obstáculo à emenda. Esta opinião porém é errônea, porque vai contra a verdade do sacramento. Pois,
assim como o batismo é um sacramento, nem sofre nenhuma alteração na sua essência sacramental
pelo fato de alguém o receber dissimuladamente, assim também a confissão não deixa de ser
sacramental, embora o confitente não se proponha emendar-se. Nem por isso, portanto, deverá deixar
de ser guardado o seu segredo. ─ Nem o sigilo da confissão encontra a caridade, que não exige se dê
remédio ao pecado, que se ignora. Ora, o que o sacerdote sabe pela confissão é como se o ignorasse;
pois não o sabe como homem, mas como Deus. Contudo deve dar algum remédio, nos casos figurados,
o quanto puder sem revelar a confissão; assim, advertindo os confitentes; e, aos outros empregando
estudo a fim de se não deixarem corromper pela heresia. Pode também dizer ao prelado que vigie mais
atentamente o seu rebanho, contanto que não diga nada que, por palavras ou sinais, possa trair o
penitente.

RESPOSTA À SEGUNDA. ─ O preceito de guardar o sigilo da confissão resulta do próprio sacramento.
Portanto, assim como o preceito de fazer a confissão sacramental é de direito divino e não pode o
homem ser desligado dele por nenhuma dispensa ou ordem humana, assim nenhum pode ser obrigado
a por qualquer poder humano, a revelar a confissão ou ser liberado desse dever. Portanto, se lhe
ordenassem, sob pena de sentença passada de excomunhão, a dizer se sabe alguma coisa de um
determinado pecado, o confessor não deve dizer; pois, deve interpretar a intenção de quem isso lhe
manda como significando-se sabe como homem. E mesmo interrogado se o que diz o sabe por
confissão, não o deverá dizer. Nem incorreria em ex-comunhão, pois, não está sujeito ao seu superior
senão como homem; ora, o que soube em confissão não foi como homem, mas como Deus.

RESPOSTA À TERCEIRA. ─ Um sacerdote não pode ser tomado como testemunha senão como homem.
Portanto, sem detrimento da sua consciência pode jurar que ignora o que só como Deus o soube. ─
Semelhantemente, pode um prelado sem detrimento da sua consciência, deixar impune ou sem
nenhum remédio, o pecado, que como Deus o soube. Pois, não está obrigado a dar remédio senão ao
modo por que as coisas lhes são confiadas. Portanto, ao que lhe foi confiado no foro da penitência deve
dar remédio no mesmo foro, tanto quanto possível. Assim o abade, no caso referido, deve advertir o
prior a resignar o priorado; ou, se este não o quiser, pode em outra ocasião qualquer, eximi-lo às
obrigações do priorado, contanto que evite toda suspeita de revelação da confissão.

RESPOSTA À QUARTA. ─ Por muitas outras causas, que não o pecado, pode um ser indigno do ofício de
prelado; assim, por falta de ciência da idade ou por uma razão semelhante. Entretanto, quem obstar
esse indigno de receber a prelatura, nem faz suspeitar do crime nem revela a confissão.

## Art. 2 — Se o sigilo da confissão abrange também o que não se ouviu nela.
O segundo discute-se assim. ─ Parece que o sigilo da confissão abrange também o que não se ouviu
nela.

1. ─ Pois são os pecados o objeto da confissão. Ora, às vezes, junto com os pecados, contamos muitas
outras coisas não pertencentes à confissão. Logo, dizendo tais coisas ao sacerdote como a Deus, parece
que o sigilo da confissão também as abrange.

2. Demais. ─ Às vezes dizemos a outrem uma coisa e esse a guarda sob sigilo de confissão. Logo, o sigilo
da confissão abrange também o que nela não foi ouvido.
Mas, em contrário. ─ O sigilo da confissão é anexo à confissão sacramental. Ora, o que está anexo a um
sacramento não vai além desse sacramento. Logo, o sigilo da confissão não abrange senão o que é
matéria desse sacramento.

SOLUÇÃO. ─ O sigilo da confissão diretamente não abrange senão o que constitui matéria desse
sacramento. Mas indiretamente, também o que não constitui matéria da confissão sacramental pode
ser abrangido pelo sigilo que lhe é próprio; assim, o que pudesse fazer trair o pecador ou o pecado. Por
isso, tais coisas não devem menos ser guardadas secretas, com o maior cuidado; quer por evitar
escândalo, quer pelas indiscrições que poderiam resultar do hábito contrário.
Donde se deduz clara a resposta à primeira objeção.

RESPOSTA À SEGUNDA. ─ Ninguém deve prometer facilmente a guardar nada como segredo. Mas quem
o fizer fica obrigado pela promessa a guardar o sigilo, como se em confissão o tivesse ouvido, embora
não o seja sob o sigilo da confissão.

## Art. 3 — Se só o sacerdote está obrigado ao sigilo da confissão.
O terceiro discute-se assim. ─ Parece que nem só o sacerdote está obrigado ao sigilo da confissão.

1. ─ Pois, às vezes, urgindo a necessidade, pode alguém confessar ao sacerdote por um intérprete. Ora,
o intérprete está obrigado, segundo parece, a guardar o sigilo da confissão. Logo, parece que também
quem não é sacerdote está obrigado ao sigilo da confissão.

2. Demais. ─ Em caso de necessidade podemos confessar a um leigo. Ora, este fica obrigado a ocultar os
pecados, pois como a Deus lhe foram ditos. Logo, nem só o sacerdote está obrigado ao sigilo da
confissão.

3. Demais. ─ Pode alguém fingir-se de sacerdote a fim de, por essa fraude, ficar conhecendo a
consciência alheia. Ora, também esse, segundo parece, peca revelando a confissão. Logo, nem só o
sacerdote está obrigado ao sigilo da confissão.
Mas, em contrário, só o sacerdote é o ministro deste sacramento. Ora, o sigilo confessional lhe está
anexo. Logo, só o sacerdote está obrigado ao sigilo da confissão.

2. Demais. ─ O confessor está obrigado a ocultar o ouvido na confissão, porque o soube como Deus e
não como homem: Ora, só o sacerdote é ministro de Deus. Logo, só ele está obrigado a guardar o
segredo.

SOLUÇÃO. ─ O sigilo da confissão é dever do sacerdote enquanto ministro deste sacramento, que outra
coisa não é senão é o dever de guardar secreta a confissão, assim como o poder das chaves é o poder de
absolver. Contudo, como quem não é sacerdote em certas circunstâncias participa do poder das chaves,
ouvindo a confissão em caso de necessidade, assim também participa do ato do sigilo confessional e
está obrigado ao segredo, embora propriamente falando não haja o sigilo da confissão.
Donde se deduzem as RESPOSTAS AS OBJEÇÕES.

## Art. 4 — Se com licença do confitente pode o sacerdote revelar a outrem o pecado ouvido sob o sigilo da confissão.
O quarto discute-se assim. ─ Parece que com licença do confitente não pode o sacerdote revelar a
outrem o ouvido sob o sigilo da confissão.

1. ─ Pois, o que não pode o superior não pede o inferior. Ora, o Papa a ninguém poderá dar licença de
revelar a outrem o pecado ouvido em confissão. Logo, nem o confitente poderia dar essa licença.

2. Demais. ─ O instituído em vista do bem comum não pode ser mudado por arbítrio de um particular.
Ora, o sigilo da confissão foi instituído para o bem de toda a Igreja,a fim de que os homens se acerquem
da confissão com mais confiança. Logo, o confitente não pode dar ao sacerdote licença para revelar a
sua confissão.

3. Demais. Se ao sacerdote pudesse ser dada essa licença, seria dada aos maus sacerdotes para encobrir
a malícia, pois poderiam alegar que licença lhes foi dada, para assim pecarem impunemente. O que é
inadmissível. E portanto, parece que não podem ter tal licença do confitente.

4. Demais. ─ Quem recebesse a revelação dessa confissão não estaria obrigado ao segredo. E assim
poderia tornar público um pecado já perdoado. O que é inadmissível. Logo, não pode o sacerdote
receber essa licença.
Mas, em contrário. O superior pode mandar um pecador ao seu inferior, levando-lhe carta que
manifeste a sua vontade. Logo, por vontade do confitente pode o pecado ser revelado a outrem.

2. Demais. ─ Quem pode agir por si também o pode por outrem. Ora, o confitente pode revelar o seu
pecado, que por si cometeu, a outrem. Logo, também o pode fazer pelo sacerdote.

SOLUÇÃO. ─ Duas são as razões por que está o sacerdote obrigado ao sigilo: primeiro e principalmente,
porque essa ocultação é da essência do sacramento, pois, o sacerdote conhece os pecados como Deus,
cujas vezes faz na confissão; segundo, para evitar escândalo. Mas, o confitente pode fazer o sacerdote
conhecer também como homem o que só como Deus o sabia; e isso, dando-lhe licença de revelar a
confissão. Contudo, o sacerdote deve, ao revelar, evitar o escândalo de ser tido como infrator do sigilo
da confissão.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O Papa não pode dar ao sacerdote licença de revelar a
confissão, porque não pode fazê-lo conhecedor dela como homem. Mas isso o pode o confitente.

RESPOSTA À SEGUNDA. ─ No caso não fica eliminado o instituído para o bem comum, pois não há
quebra do sigilo da confissão quando se diz o que de outro modo foi sabido.

RESPOSTA À TERCEIRA. ─ Por aí não se confere impunidade aos maus sacerdotes, pois lhes incumbe
provar, se acusados, que revelaram por licença do confitente.

RESPOSTA À QUARTA. ─ Quem chega ao conhecimento do pecado, mediante o sacerdote e por vontade
do confitente, participa de algum modo do ato do sacerdote. Por isso se dá com ele o mesmo que com o
intérprete; salvo se o pecador quiser que absoluta e livremente saiba da confissão.

## Art. 5 — Se o que sabemos por confissão, e também de qualquer outro modo, podemos revelar.
O quinto discute-se assim. ─ Parece que o que sabemos por confissão, e também de qualquer outro
modo, de maneira nenhuma o podemos revelar.

1. ─ Pois, não é quebrado o sigilo da confissão, senão revelando-se o pecado nela conhecido. Logo,
quem revela o pecado ouvido em confissão, seja como for que o soube, parece quebrar o sigilo da
confissão.

2. Demais. ─ Quem ouve a confissão de outrem fica obrigado não lhe revelar os pecados. Ora, quem
prometesse a outrem guardar secreto o que lhe ouvisse ficaria obrigado a esse segredo, mesmo que por
outras fontes viesse a sabê-lo. Logo, o que se ouviu em confissão, embora viesse a ser sabido de outro
modo, deveria ser conservado como sigilo.

3. Demais. ─ Duas forças, a mais poderosa domina a outra. Ora, a ciência pela qual recebemos o pecado,
como Deus, é mais elevada e digna que a pela qual como homem o sabemos. Logo, aquela domina esta.
E portanto não a podemos revelar, como o exige a ciência, pela qual sabemos como Deus.

4. Demais. ─ O segredo da confissão foi instituído por evitar o escândalo, a fim de os homens não se
afastarem dela. Ora, se alguém pudesse revelar o ouvido em confissão, mesmo se por outra via o
soubesse, nem por isso deixaria de haver escândalo. Logo, de nenhum modo podemos revelar.
Mas, em contrário. ─ Ninguém pode obrigar a outrem o a que não estava obrigado, salvo se for o
prelado, que obriga sob preceito. Ora, quem conheceu um pecado pelo ter visto, não está obrigado a
ocultá-lo. Logo, quem lh'o confessa, desde que não lhe seja prelado, não pode obrigá-lo ao sigilo, pelo
fato de lh'o confessar.

2. Demais. ─ Desse modo poderia ficar impedida a justiça da Igreja, se alguém, para fugir à sentença de
excomunhão, que lhe ia ser lavrada, por um pecado de que foi convencido, fizesse deste a confissão a
quem devesse lhe lavrar a sentença. Ora, executar a justiça é preceito. Logo, não estamos obrigados a
ocultar o pecado ouvido em confissão, se por outra via o sabemos.

SOLUÇÃO. ─ Nesta matéria três são as opiniões. ─ Assim, certos dizem que o ouvido em confissão não
podemos de nenhum modo revelá-lo, se por outra via o soubemos, quer antes, quer depois. ─ Outros
porém dizem, que a confissão nos tira a faculdade de revelar a outrem o que já antes dela o sabíamos;
mas não a de poder revelar o que depois dela viemos a saber.
Ora, ambas essas opiniões, exagerando o dever do sigilo da confissão, causam prejuízo à verdade e à
conservação da justiça. Pois, poderia torná-la mais inclinado ao pecado o não temer o pecador ser
acusado pelo confessor, se na presença deste reiterasse o pecado. Semelhantemente, muito da justiça
pereceria se não pudessemos testemunhar o que vimos, depois de a confissão nos ter sido feita. ─ Nem
obsta a opinião de certos, que devíamos protestar que o sabido não o obtivemos com o dever do sigilo.
Pois, isso não o poderíamos senão depois de o pecado nos ter sido confessado. E então qualquer
sacerdote poderia, quando quisesse, revelar o pecado, fazendo essa protestação, se essa o deixasse livre
de o revelar.
Por onde, mais verdadeira é a outra opinião, que o sabido por outra via, quer antes, quer depois da
confissão, não estamos obrigados a ocultá-lo, se como homem, o soubemos; pois, podemos dizer ─ sei-o
porque o vi. Estamos porém obrigados ao segredo do que soubemos como Deus; pois não podemos
dizer ─ ouvi-o em confissão. ─ Contudo, por evitar escândalo, devemos nos abster de falar nisso, salvo se
urgir a necessidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Quem diz ter visto o que ouviu na confissão não revela,
senão por acidente, o que nela ouviu. Como quem sabe de uma coisa pela ter ouvido e visto não revela
o que viu, absolutamente falando, se disse que ouviu, senão por acidente; pois, conta como ouvido o
que lhe sucedeu ver. Por onde, esse tal não quebra o sigilo da confissão.

RESPOSTA À SEGUNDA. ─ Quem ouve uma confissão não fica obrigado a não revelar o pecado,
absolutamente falando, mas só enquanto ouvido em confissão. Pois, em nenhum caso deve dizer que
nela o ouviu.

RESPOSTA À TERCEIRA. ─ Isto se entende de duas força opostas. Ora, a ciência pela qual sabemos como
Deus, e a pela qual como homem sabemos, não são opostas. Logo, a objeção não procede.

RESPOSTA À QUARTA. ─ Não devemos evitar escândalos, por um lado, de modo tal, que venha por
outro a perder a justiça. Pois, não devemos deixar de dizer a verdade, por evitar escândalo. Por onde,
quando a verdade e a justiça correm perigo iminente, não devemos deixar de revelar ouvido em
confissão, se por outra via também o soubemos, por evitar escândalo; embora devamos nos esforçar
para evitá-lo, em si mesmo.