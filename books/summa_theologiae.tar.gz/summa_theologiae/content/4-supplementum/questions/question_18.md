# Questão 18: Do efeito das chaves.
Em seguida devemos tratar do efeito das chaves.
E nesta questão discutem-se quatro artigos:

## Art. 1 — Se o poder das chaves se estende ao perdão da culpa.
O primeiro discute-se assim. — Parece que o poder das chaves se estende ao perdão da culpa.

1. — Pois, diz o Evangelho: Aos que vos perdoardes os pecados ser-lhes-ão perdoados. Ora, isto não
significa apenas que os pecados se declarem perdoados, como o explica a letra do Mestre; porque então
o sacerdote do Testamento Novo não teria maior poder que o do Velho. Logo, exerce o poder para o
perdão da culpa.

2. Demais. — Com o poder é dada a graça de perdoar os pecados. Ora, o dispensador deste sacramento
é o sacerdote, em virtude do poder das chaves. Logo, como a graça não se opõe ao pecado, no
concernente à pena, mas no concernente à culpa, parece que o sacerdote perdoa a culpa em virtude do
poder das chaves.

3. Demais. — Maior poder recebe o sacerdote pela sua consagração, que a água do batismo pela sua
santificação. Ora, a água do batismo recebe a virtude de tocar o corpo e purificar o coração, segundo
Agostinho. Logo e com muito maior razão o sacerdote, na sua consagração, recebe um poder que lhe
permite purificar o coração da mácula da culpa.
Mas, em contrário. — Antes, o Mestre tinha dito que Deus não conferiu esse poder ao ministro, para
que cooperasse com êle na purificação interior. Ora, se perdoasse a culpa do pecado, cooperaria com
ele na purificação interior. Logo, o poder das chaves não se estende ao perdão da culpa

2. Demais. — O pecado não é perdoado senão pelo Espírito Santo. Ora, comunicar o Espírito Santo não
pertence a qualquer homem, como disse o Mestre no Livro Primeiro. Logo, nem perdoar a culpa do
pecado.

SOLUÇÃO. — Os Sacramentos, segundo Hugo, pela satisfação, contêm a graça invisível. Ora, às vezes a
santificação é necessária, assim à matéria como ao ministro do sacramento, como é o caso da
confirmação; e então a virtude sacramental existe conjuntamente numa e noutra. Outras vezes, não é
necessária senão a santificação da matéria do sacramento, como se dá com o batismo, porque não exige
necessariamente um ministro determinado; e então a virtude sacramental está toda na matéria. Outras
vezes ainda, o sacramento exige necessariamente a consagração ou a santificação do ministro, sem
nenhuma santificação da matéria; e então toda a virtude sacramental está no ministro, como é o caso
da penitência. Por onde, o poder das chaves, que tem o sacerdote, está para o efeito do sacramento da
penitência, como a virtude da água do batismo está para o efeito do batismo. Ora, o batismo e o
sacramento da penitência convêm de certo modo no seu efeito, porque ambos se ordenam diretamente
contra a culpa — o que não se dá com os outros sacramentos. Mas diferem em que o sacramento da
penitência, tendo como sua matéria os atos de quem os recebe, não por ser conferido senão aos
adultos, que devem ter a preparação para colherem o efeito dos sacramentos. Ao passo que o batismo
umas vezes é ministrado aos adultos, outras às crianças e aos desprovidos do uso da razão; por isso o
batismo confere a graça e a remissão dos pecados às crianças sem deverem elas ter nenhuma
preparação precedente; mas não aos adultos, que devem ter uma preparação eliminante da
dissimulação. E essa preparação às vezes tem precedência no tempo, suficiente para a recepção da
graça, antes de ser o batismo recebido atualmente; mas não antes do desejo do batismo, na vigência da
revelação da verdade cristã. Outras vezes porém, não precede essa preparação no tempo, mas é dada
simultaneamente com a recepção do batismo; e então com o recebimento do batismo é conferida a
graça da remissão da culpa. Mas pelo sacramento da penitência nunca é dada a graça sem preparação
presente ou precedente. Por onde, o poder das chaves opera a remissão da culpa, quer quando apenas
existe um desejo, quer quando se exerce em ato, como a água do batismo.
Mas, como o batismo não opera na qualidade de agente principal, mas na de instrumento, não
contribuindo porém para causar a recepção da graça, mesmo instrumentalmente, mas apenas dispondo
para ela, pela qual se opera a remissão da culpa, o mesmo se dá com o poder das chaves. Por onde, só
Deus tem o poder de perdoar a culpa; e por virtude dele o batismo opera instrumentalmente, como
instrumento inanimado; e o sacerdote como instrumento animado, chamado servo, segundo o Filósofo.
Por onde, o sacerdote obra como ministro.
Portanto é claro que o poder das chaves se ordena de certo modo à remissão da culpa, não pela causar
mas pela dispor. E assim, quem antes da absolvição não estivesse perfeitamente disposto a receber a
graça, consegui-la-ia na confissão mesma e com a absolvição sacramental, não opondo nenhum
obstáculo. Se, pois, o poder das chaves de nenhum modo se ordenasse à remissão da culpa, senão só ao
perdão da pena — como certos dizem, não seria necessário o desejo de receber o efeito das chaves,
para a remissão da culpa, assim como não é necessário o desejo de receber os outros sacramentos, não
ordenados à remissão da culpa, mas à da pena. Mas isto faz ver que não se ordenam ao perdão da
culpa, porque sempre o uso das chaves, para produzir o seu efeito, exige a preparação da parte de
quem deve receber o sacramento. E o mesmo se daria com o batismo se fosse ministrado só aos
adultos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Como diz à letra o Mestre, aos sacerdotes foi cometido o
poder de remitir os pecados, não por virtude própria, o que só pertence a Deus, mas para manifestarem
como ministros, a obra de Deus, que perdoa. O que se dá de três modos. — Primeiro, para que a
manifestem, não como presente, mas como futura, sem em nada contribuírem para ela. E assim, os
sacramentos da Lei Velha significavam a ação de Deus. Por isso o sacerdote dessa lei apenas mostrava a
graça prometida e nada fazia. Segundo, para a significarem como presente, e que em nada para ela
contribuem. Por isso certos dizem que os sacramentos da Lei Nova significam a colação da graça, que
Deus dá no ato mesmo de os conferir, sem haver neles nenhuma outra virtude que contribua para ela. E
segundo esta opinião mesmo o poder das chaves serviria só para mostrar a ação divina na remissão da
culpa, feita no momento da colação sacramental. — Em
terceiro lugar, para significarem a ação divina presente na remissão da culpa, e contribuírem para ela
dispositiva e instrumentalmente. E assim, segundo outra opinião mais comumente sustentada, os
sacramentos da Lei Nova manifestam a purificação feita por Deus. E deste modo também o sacerdote
do Novo Testamento mostra aos absolvidos da culpa que o foram, porque devemos considerar os
sacramentos proporcionalmente aos ministros deles. — Nem obsta que as chaves da Igreja não
disponham para a remissão da culpa, por já ter ela sido perdoada; assim como não importa que o
batismo o disponha, pelo que em si mesmo é, por já ter sido santificado.

RESPOSTA À SEGUNDA. — Nem o sacramento da penitência nem o do batismo contribuem diretamente
para a graça, nem para a remissão da culpa, senão dispositivamente.
Donde também se deduz a RESPOSTA À TERCEIRA.
As outras objeções mostram, que para a remissão da culpa diretamente não contribui o poder das
chaves. O que devemos conceder.

## Art. 2 — Se o sacerdote pode perdoar a pena do pecado.
O segundo discute-se assim. — Parece que o sacerdote não pode perdoar a pena do pecado.

1. — Pois, o pecado merece uma pena eterna e outra temporal. Ora, mesmo depois da absolvição do
sacerdote fica o penitente obrigado a cumprir a pena temporal neste mundo ou no purgatório. Logo,
não perdoa de nenhum modo a pena.

2. Demais. — O sacerdote não pode prejudicar à justiça divina. Ora, pela justiça divina está determinada
aos penitentes a pena que devem sofrer. Logo, o sacerdote nada pode perdoar dela.

3. Demais. — Quem comete um pequeno pecado não deixa de receber menos os efeitos das chaves,
que quem cometeu um pecado maior. Ora, se o sacerdote pode perdoar algo da pena do pecado maior,
é possível haver um pecado de tal modo pequeno, que não lhe é devida maior pena que a perdoada, do
pecado maior. Logo poderá perdoar totalmente a pena desse pecado menor. O que é falso.

4. Demais. — Toda a pena temporal devida ao pecado tem o mesmo fundamento. Se, pois por uma
primeira absolvição for perdoada uma parte da pena, também pela segunda pode sei perdoada outra,
do mesmo pecado. E assim poderão multiplicar-se as absolvições a ponto de pelo poder das chaves,
toda a pena ser perdoada pois, a segunda absolvição não tem menor eficácia que a primeira. Por onde;
o pecado ficará de todo impune. E isso, é inadmissível.
Mas, em contrário. — O poder das chaves é o de ligar e de absolver. Ora, o sacerdote pode impor urna
pena temporal. Logo, pode também absolver da pena.

2. Demais. — O sacerdote não pode perdoar a culpa do pecado, corno diz à letra o Mestre das
Sentenças; nem a pena eterna, pela mesma razão. Se, pois, não pode perdoar a pena temporal do
pecado, de nenhum modo pode perdoá-lo. O que vai em absoluto contra as palavras do Evangelho.

SOLUÇÃO. — Devemos dizer, do efeito, que o poder das chaves atualmente exercido, produz em quem
teve antes a contrição, o mesmo que dizemos do efeito do batismo, dado a quem já estava em graça.
Assim, pela fé e contrição precedentes ao batismo alcançamos a graça de perdão dos pecados, quanto à
culpa; e quando depois recebemos atualmente o batismo, a graça se nos aumenta e ficamos de todo
absolvidos do de reato da pena, por nos tornarmos participantes da paixão de Cristo. Semelhantemente,
quem pela contrição alcançou a remissão dos pecados quanto à culpa, e por consequência quanto ao
reato da pena eterna, perdoada simultaneamente com a culpa, em virtude do poder das chaves, que tira
a sua eficácia da paixão de Cristo, a esse se lhe aumenta a graça e perdoa a pena temporal, cujo reato
ainda permanecia depois da remissão da culpa. Não porém totalmente, corno no batismo, mas só
parcialmente. Porque o regenerado pelo batismo se configura com a paixão de Cristo, recebendo em si
totalmente a eficácia de sua paixão, suficiente para apagar toda pena, de modo que nada resta da pena
do pecado atual anterior; pois, a ninguém devemos imputar a pena, senão o que realmente fez. No
batismo porém, o batizado recebe uma nova vida e se torna, pela graça batismal, um novo homem; por
isso não permanece nele nenhum reato da pena, pelo pecado precedente. Mas pela penitência não
recebemos nenhuma vida nova, pois não é urna regeneração, mas uma cura. Por isso, em virtude do
poder das chaves, que obra no sacramento da penitência, não é perdoada totalmente a pena, mas uma
parte da pena temporal, cujo reato podia permanecer depois da absolvição da pena eterna. Nem só
daquela pena que o penitente deve cumprir, imposta pelo confessor, como certos dizem; porque então
a confissão e a absolvição sacramental não seriam senão ônus, o que não é próprio aos sacramentos da
Lei Nova. Mas também da pena a ser expiada no purgatório algo é perdoado, de modo que quem
morrer absolvido, mas antes de ter satisfeito, será punido no purgatório menos do que o seria se
morresse antes da absolvição.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — O sacerdote não perdoa toda a pena temporal, mas só
parte. Por isso o confitente ainda permanece obrigado à pena satisfatória.

RESPOSTA À SEGUNDA. — A paixão de Cristo satisfez suficientemente pelos pecados de todo o mundo.
Por onde, sem prejuízo para a justiça divina, pode o sacerdote perdoar algo da pena devida pelo
penitente, segundo colheu este, pelos sacramentos da Igreja, os efeitos da paixão de Cristo.

RESPOSTA À TERCEIRA. — A todo pecado é necessário se lhe aplique uma pena satisfatória, pela qual se
lhe de remédio. Por onde, embora por virtude da absolvição seja perdoada uma parte da pena devida
por algum grande pecado não implica isso que de qualquer pecado lhe seja perdoada totalmente a
pena; pois, se assim fosse, algum pecado haveria de ficar totalmente impune; mas em virtude do poder
das chaves, a cada pecado se lhe perdoam proporcionalmente as penas.

RESPOSTA À QUARTA. — Certos dizem, que a primeira absolvição perdoa, pelo poder das chaves, tanto
quanto pode ser perdoado; contudo vale a confissão reiterada, quer pela instrução que ministra, quer
pela maior certeza de sermos perdoados, quer pela intercessão do confessor, quer pelo mérito de
vencer a vergonha de confessar os pecados.- Mas isto não é verdade. Porque, se fosse essa a razão de se
reiterar a confissão, não seria porém a razão de se reiterar a absolvição, sobretudo para quem não tem
nenhuma dúvida sobre a absolvição precedente; pois, do contrário, podia duvidar da segunda
absolvição como duvida da primeira. Assim, vemos que o sacramento da extrema unção não se reitera
na mesma doença, porque pela única vez que foi ministrado, já o sacramento produziu tudo o que podia
produzir. Além disso, na segunda confissão não seria necessário tivesse o poder rias chaves aquele a
quem se ela fizesse, pois que esse poder não deveria aí agir em nada. — Por isso outros dizem, que
mesmo na segunda absolvição é conferido aumento de graça; e quanto maior for a graça recebida,
tanto menos restará da impureza do pecado precedente; e por consequência será devida uma menor
pena purificadora. Por onde, pela primeira absolvição se perdoa mais ou menos a pena ao confitente,
pelo poder das chaves, segundo estiver mais ou menos disposto para a graça. E pode a disposição ser
tal, que mesmo por virtude da contrição seja apagada totalmente a pena, como dissemos. Por isso,
também não é inconveniente se a confissão freqüente apagar totalmente a pena, de modo que o
pecado fique de todo impune, pelo qual a pena que sofreu Cristo satisfez.

## Art. 3 — Se o sacerdote, pelo poder das chaves, pode ligar.
O terceiro discute-se assim. — Parece que o sacerdote, pelo poder das chaves, não pode ligar.

1. Pois, a virtude sacramental se ordena contra o pecado, como remédio. Ora, ligar, longe de ser
remédio do pecado, agrava essa doença, segundo parece. Logo, o sacerdote, pelo poder das chaves, que
é uma virtude sacramental, não pode ligar.

2. Demais. — Assim como absolver ou abrir é remover um obstáculo, assim ligar é por obstáculo. Ora, o
obstáculo para o Reino é o pecado, obstáculo que ninguém nos pode criar, pois, só por vontade
pecamos. Logo, o sacerdote não pode ligar.

3. Demais. — As chaves tiram a sua eficácia da paixão de Cristo. Ora, ligar não é efeito da paixão. Logo,
pelo poder das chaves, o sacerdote não pode ligar.
Mas, em contrário, o Evangelho: Tudo o que ligares sobre a terra será ligado também no céu.

2. Demais. — As potências racionais são susceptíveis de tender para termos opostos. Ora, o poder das
chaves, sendo acompanhado do discernimento, é uma potência racional. Logo, pode tender para termos
opostos. Portanto, se pode absolver também pode ligar.

SOLUÇÃO. — A obra do sacerdote, no uso das chaves, é conforme à obra de Deus, de quem é o ministra.
Ora, Deus pode obrar tanto sobre a pena como sobre a culpa. Sobre a culpa, diretamente, para absolver
dela; indiretamente, para ligar, no sentido em que dizemos que torna o pecado obdurado, por não lhe
dar a graça. Mas sobre a pena obra diretamente, tanto de um como de outro modo; pois, perdoa a pena
e a minora. Semelhantemente, também o sacerdote, embora ao absolver, pelo poder das chaves, exerça
de certo modo um ato ordenado ao perdão da culpa, da maneira referida, contudo, quando liga,
nenhum ato exerce relativamente à culpa, salvo se por ligar se entende o não absolver o pecador, mas
fazer-lhe saber que esta ligado. Mas sobre a pena tem o poder de ligar e de absolver. Pois, absolve da
pena quem perdoa; mas liga quanto a pena que mantém, quanto a esta, porém, dizemos que liga de
dois modos. De um, considerando a gravidade mesma dela em geral; e assim, não liga senão porque não
absolve, e manifesta o pecado como ligado. De outro modo, considerando tal pena e tal outra
determinadamente; e assim liga, quanto à pena, pela impor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Esse resíduo de pena que o pecador deve expiar é um
remédio que purifica da impureza do pecado.

RESPOSTA À SEGUNDA. — Obstáculo ao Reino não é só o pecado, mas também a pena; e já dissemos
como o sacerdote a impõe.

RESPOSTA À TERCEIRA. Mesmo a paixão de Cristo nos obriga a uma certa pena, pela qual com essa
paixão nos conformamos.

## Art. 4 — Se o sacerdote pode ligar e absolver por arbítrio próprio.
O quarto discute-se assim. — Parece que o sacerdote pode ligar e absolver por arbítrio próprio.

1. — Pois, Jerônimo diz: Os cânones não prefixam claramente o tempo durante o qual se deve fazer
penitência, por cada crime, de modo que determine como deve ser a emenda de cada um; mas antes o
deixam confiado ao arbítrio da compreensão do sacerdote. Logo, parece que este pode por seu arbítrio
ligar e absolver.

2. Demais. — O Senhor louvou o feitor iníquo, por haver obrado como homem de juízo, porque perdoou
aos devedores do seu amo, largamente. Ora, o Senhor é mais pronto a ter misericórdia, que qualquer
senhor temporal. Logo, parece tanto mais louvável o sacerdote quanto mais perdoar a pena.

3. Demais. — Toda ação de Cristo serve para nossa instrução. Ora, Cristo a certos pecadores não impôs
nenhuma pena, mas só a emenda da vida, como se deu com a adúltera. Logo, parece que também o
sacerdote pode, segundo o seu arbítrio, ele como Vigário de Cristo, perdoar total ou parcialmente a
pena.
Mas, em contrário. — Gregório diz: Falsa penitência consideramos a não imposta, conforme a qualidade
do crime, pela autoridade dos santos Padres. Logo, parece que de nenhum modo é do sacerdote impor
a pena.

2. Demais. — O exercício do poder das chaves supõe o discernimento. Ora, se dependesse
exclusivamente do arbítrio do sacerdote impor a pena que quisesse, não teria ele necessidade da
discrição, porque nunca poderia ser indiscreto. Logo, não está absolutamente no arbítrio do sacerdote.

SOLUÇÃO. — O sacerdote obra, no uso das chaves, como instrumento e ministro de Deus. Ora, nenhum
instrumento tem ato eficaz, senão enquanto movido pelo agente principal. Por isso diz Dionísio, que os
sacerdotes devem exercer suas sagradas funções, quando Deus os mover. Em sinal do que, antes do
poder das chaves conferido a Pedro, faz o Evangelho menção da revelação da Divindade, que lhe foi
feita; e noutro lugar se diz, que o dom do Espírito Santo, pelo qual se tornaram filhos de Deus, foi dado
aos Apóstolos, antes do poder de perdoarem os pecados. Portanto, quem quisesse exercer o seu poder
independentemente dessa moção divina, não conseguiria o efeito visado, como diz Dionísio. Além disso
se desviaria da ordem divina e, assim incorreria em culpa. — Além disso, as penas satisfatórias são
infligidas como remédios. Ora, os remédios prescritos pela arte médica não servem para todos
indistintamente, mas devem variar segundo o arbítrio do médico, não seguindo este à sua vontade
própria, mas obedecendo à ciência médica. Assim também as penas satisfatórias determinadas pelos
cânones não se aplicam a todos, mas devem variar segundo o arbítrio do sacerdote, regulado por uma
inspiração divina. Assim, pois, como o médico prudente às vezes não prescreve remédio de tal modo
eficaz que baste à cura da doença, a fim de não causar maior dado a fraqueza do doente, assim também
o sacerdote, levado por inspiração divina nem sempre impõe toda a pena devida a um pecado, não vá o
enfermo desesperar com a grandeza da pena e afastar-se totalmente da penitência.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Esse arbítrio deve ser regulado por inspiração divina.

RESPOSTA À SEGUNDA. — Também por isso foi elogiado o feitor, por ter agido prudentemente. Por
isso, a remissão da pena devida deve ser feita com discernimento.

RESPOSTA À TERCEIRA. — Cristo tinha o poder de excelência, nos sacramentos. Por isso, tinha a
autoridade de perdoar a pena, total ou parcialmente, como quisesse. Nem há símile com o que fazem os
que não agem senão como ministros.