# Questão 6: Da confissão quanto a sua necessidade.
Em seguida devemos tratar da confissão. A respeito da qual seis questões temos a considerar. Primeiro,
da necessidade da confissão Segundo, da sua quididade. Terceiro, do seu ministro. Quarto, da sua
qualidade. Quinto, do seu efeito. Sexto, do seu sigilo.
Na primeira questão discutem-se seis artigos:

## Art. 1 — Se a confissão é necessária à salvação.
O primeiro discute-se assim. ─ Parece que a confissão não é necessária à salvação.

1. ─ Pois, o sacramento da penitência foi ordenado à remissão da culpa. Ora, a culpa é suficientemente
perdoada pela infusão da graça. Logo, para fazer penitência do pecado não é necessária a confissão.

2. Demais. ─ O pecado que contraímos e tem em outro a sua causalidade deve receber desse outro o
seu remédio. Logo, o pecado atual, que de movimento próprio cometemos, é necessário receba só de
nós mesmos o seu remédio. Ora, a sanar esse pecado é que se ordena a penitência. Logo, a confissão
não é necessária para a penitência.

3. Demais. ─ A certos lhes foi o pecado perdoado sem que deles leiamos que tivessem confessado; tal o
caso de Pedro, de Madalena e também de Paulo. Ora, a graça de remitir os pecados não tem agora
menor eficácia do que tinha então. Logo, nem é agora de necessidade para a salvação, que
confessemos.

4. Demais. ─ A confissão é exigida, no juízo, para ser infligida a pena, segundo a quantidade da culpa.
Ora, podemos nos infligir a nós mesmos uma pena maior que a que nos fosse infligida por outro. Logo,
parece que a confissão não é necessária à salvação.
Mas, em contrário. ─ Boécio diz: Se queres ser curado pelo médico é necessário que lhe descubras o teu
mal. Ora, necessário à salvação é que recebamos um remédio aos nossos pecados. Logo, também é de
necessidade à salvação que descubramos a nossa doença pela confissão.

2. Demais. ─ No juízo secular não é o juiz o mesmo que o réu. Ora, o juízo espiritual é mais ordenado.
Logo, o pecador, que é o réu, não deve ser juiz de si mesmo, mas deve ser julgado por outro. Portanto, é
necessário que lhe confesse.

SOLUÇÃO. ─ A paixão de Cristo, sem cuja virtude não pode ser perdoado o pecado original nem o atual,
em nós opera pela recepção dos sacramentos, que dela tiram a sua eficácia. Por onde, para a remissão
da culpa, tanto atual como original, é necessário o sacramento da Igreja ─ ou atualmente recebido; ou
pelo menos em desejo, se o que exclui o sacramento for, não o desprezo, mas a injunção da
necessidade. E por consequência, os sacramentos ordenados contra a culpa, com a qual não pode haver
salvação, são de necessidade para a salvação. E portanto, assim como o batismo, pelo qual é apagado o
pecado original, é de necessidade para a salvação, assim também o é o sacramento da penitência. E
assim como quem pede o batismo se submete aos ministros da Igreja, a quem pertence dispensar o
sacramento, assim também, confessando o seu pecado, sujeita-se ao ministro da Igreja afim de alcançar
o perdão, mediante o sacramento da penitência por êle dispensado. E o ministro não pode aplicar o
remédio conveniente se não conhecer o pecado ─ o que se dá pela confissão do pecador. Por onde, a
confissão é de necessidade para a salvação daquele que caiu em pecado mortal atual.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A infusão da graça basta para a remissão da culpa; mas,
depois da culpa perdoada, o pecador ainda é devedor da pena temporal. Mas, para se conseguir a
infusão da graça foram ordenados os sacramentos da graça, e antes de os recebermos, atual ou
intencionalmente,não alcançamos a graça, como se dá no batismo, O mesmo passa com a confissão. E
além disso: pelo pejo da confissão; pelo poder das chaves, a que se o confitente sujeita; pela satisfação
que vai junta e que o sacerdote modera segundo a qualidade dos pecados de que tomou conhecimento
na confissão ─ fica expiada a pena temporal. ─ Mas do facto de a confissão obrar para o perdão da pena
não se deduz que seja de necessidade para a salvação; porque é temporal a pena a que permanecemos
ligados depois do perdão da culpa; portanto, mesmo sem a expiação feita nesta vida, haveria caminho
para a salvação. Mas é de necessidade para a salvação por operar a remissão da culpa ao modo referido.

RESPOSTA À SEGUNDA. ─ O pecado contraído por obra de outrem, isto é, o original, pode
absolutamente ter um remédio externo, como se dá com as crianças. Mas o pecado atual, que por si
mesmo o pecador cometeu, não pode ser expiado se não houver alguma cooperação do pecador.
Contudo não basta por si mesmo para expiar o pecado, assim como por si mesmo foi suficiente para
cometê-lo. Porque o pecado, por parte da conversão, é finito, e foi por essa conversão que o pecador
abraçou o pecado; mas é infinito por parte da aversão, sendo por aí que há de começar a remissão do
pecado, pois, o último na geração é o primeiro na resolução, como diz Aristóteles. Por onde e
necessariamente há de o pecado atual receber de outrem o seu remédio.

RESPOSTA À TERCEIRA. ─ Embora não tenhamos notícia da confissão dessas personagens citadas,
contudo ela bem pode ter-se realizado; pois, muitas coisas se fizeram, que não estão escritas. ─ E além
disso, Cristo tem o poder de excelência nos sacramentos. Por onde, sem o pertinente ao sacramento,
podia conferir a realidade dele.

RESPOSTA À QUARTA. ─ A satisfação não bastaria para expiar a pena do pecado, pela quantidade da
pena que se impõe como satisfação; mas basta enquanto parte do sacramento, a virtude sacramental.
Por onde, é necessário sejam os sacramentos ministrados por dispensadores. E portanto a confissão é
necessária.

## Art. 2 — Se a confissão é de direito natural.
O segundo discute-se assim. ─ Parece que a confissão é de direito natural.

1. ─ Pois, Adão e Caim não estavam obrigados senão aos preceitos da lei natural. Ora, foram censurados
por não terem confessado os seus pecados. Logo, a confissão dos pecados é de direito natural.

2. Demais. ─ Os preceitos existentes tanto na Lei Velha Como na Nova são de direito natural. Ora, a
confissão existia na Lei Velha, como diz Isaías: Faze o teu arrazoado, se algum fundamento tens para te
justificar. Logo, é de direito natural.

3. Demais. ─ Job não estava sujeito senão à lei natural. Ora, ele confessava os pecados, como o refere a
Escritura: Se encobri como homem o meu pecado. Logo, é de direito natural.
Mas, em contrário. ─ Isidoro diz, que o direito natural é o mesmo para todos. Ora, a confissão não na
fazem todos do mesmo modo. Logo, não é de direito natural.

2. Demais ─ A confissão se faz a quem tem o poder das chaves. Ora, poder das chaves da Igreja não foi
instituído por direito natural. Logo, nem a confissão.

SOLUÇÃO. ─ Os sacramentos são umas como proclamações da fé; por isso hão-se de lhe proporcionar a
elas. Ora, a fé é superior ao conhecimento da razão natural. Por isso os sacramentos também são
superiores ao ditame da razão natural. E como o direito natural não no gerou a opinião, mas uma certa
virtude inata infundiu em nós, como diz Túlio, por isso os sacramentos não são de direito natural, mas
de direito divino, superior à natureza. Mas às vezes também se chama natural aquilo que o Criador
impôs a uma determinada coisa. Contudo, propriamente se chama natural o causado pelos princípios da
natureza. E sobrenaturais são as obras que Deus se reserva à sua ação, sem o ministério da natureza;
quer nas obras milagrosas, quer nas revelações dos mistérios, quer na instituição dos sacramentos. E
assim a confissão, que tem necessidade sacramental, não é de direito natural, mas divino.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Adão foi censurado por não ter reconhecido o seu pecado
na presença de Deus; pois, a confissão feita a Deus pelo reconhecimento do pecado é de direito natural.
Ora, presentemente tratamos da confissão feita ao homem. ─ Ou devemos responder que confessar o
pecado, num caso, é de direito natural, isto é, quando alguém constituído em juízo é interrogado pelo
juiz. Pois então o pecador não deve mentir excusando ou negando o seu pecado; e disso foram
repreendidos Adão e Caim. Mas a confissão que fazemos espontaneamente a um homem para
conseguir a remissão dos pecados, de Deus, é de direito natural.

RESPOSTA À SEGUNDA. ─ Os preceitos da lei natural permanecem do mesmo modo na lei de Moisés e
na Lei Nova. Mas a confissão, embora de certo modo já existisse na lei de Moisés, não existia porém do
mesmo modo que na Lei Nova nem na lei da natureza. Pois, na lei da natureza bastava o
reconhecimento do pecado interior, perante Deus. Mas na lei de Moisés era preciso manifestar o
pecado por algum sinal exterior, como pela oblação da vítima pelo pecado, por onde também podia o
pecador revelar-se aos outros como tal. Mas não era preciso o pecador manifestar em especial o pecado
cometido ou as circunstancias do pecado, como o era na Lei Nova.

RESPOSTA À TERCEIRA. ─ Job se refere àquela dissimulação do pecado feita pelo acusado, negando o
pecado ou excusando-o, como se pode concluir da Glosa ao mesmo lugar.

## Art. 3 — Se todos estão obrigados à confissão.
O terceiro discute-se assim. ─ Parece que nem todos estão obrigados à confissão.

1. ─ Pois, como diz Jerônimo, a penitência é a segunda tábua depois do naufrágio. Ora, muitos, depois
do batismo, não sofreram nenhum naufrágio. Logo, nem lhes é preciso fazer penitência. E assim, nem a
confissão, que é parte da penitência.

2. Demais. ─ A confissão deve ser feita ao juiz, em qualquer foro. Ora, há certos que não têm nenhum
juiz come superior. Logo, também não estão obrigados à confissão.

3. Demais. ─ Há certos que só têm pecado veniais. Ora, não estamos obrigados a confessá-los, Logo,
nem iodos estão obrigados à confissão.
Mas, em contrário; a confissão se divide, por contrariedade, da satisfação e da contrição. Ora, todos
estão obrigados à contrição e à satisfação. Logo, também todos estão obrigados à confissão.

2. Demais. ─ Está claro por uma decretal, que todos, de ambos os sexos, chegados aos anos de discrição,
estão obrigados a confessar os pecados.

SOLUÇÃO. ─ De dois modos estamos obrigados à confissão. Primeiro, por direito divino, por isso mesmo
que ela é um remédio. E então, nem todos estão obrigados à confissão, mas só aqueles que caíram rio
pecado mortal, depois do batismo. ─ De outro modo, por preceito de direito positivo. E então, estão
obrigados todos, por instituição da Igreja, feita no Concílio Geral, sob Inocêncio III. Quer para que cada
um se reconheça como pecador, pois, todos pecaram e precisam da graça de Deus. Quer para nos
achegarmos à Eucaristia com muito maior reverência. Quer para os reitores das igrejas reconhecerem os
seus súditos, a fim de se não esconder o lobo dentro do rebanho.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Embora nesta vida mortal depois do batismo, possamos
evitar o naufrágio, que é o pecado mortal, não podemos contudo evitar os pecados veniais, que nos
dispõem ao naufrágio, contra o que também é ordenada a penitência. Por isso há também lugar para a
penitência nos que não pecam mortalmente; e por consequência, para a confissão.

RESPOSTA À SEGUNDA. ─ Ninguém há que não tenha a Cristo como juiz, a quem, mediante o seu
vigário, devemos confessar. O qual vigário, embora possa nos ser inferior, em razão de uma prelatura de
que nos achemos investidos, contudo nos é superior, enquanto somos pecador e êle, ministro de Cristo.

RESPOSTA À TERCEIRA. ─ Por força do sacramento não está ninguém obrigado a confessar os pecados
veniais; mas por força da instituição da Igreja, quando não temos outros pecados a confessar. ─ Ou
podemos responder, segundo certos, que pela decretal referida, não estão obrigados senão os que têm
pecados mortais; o que se deduz das expressões que dizem que devem confessar todos os pecados; e
isso não se pode entender dos veniais, pois ninguém está obrigado a os confessar todos. E, neste
sentido, quem não tem pecados mortais não está obrigado à confissão dos veniais; mas basta, para
cumprir o preceito da Igreja, apresentar-se a um sacerdote e dizer que não tem consciência de nenhum
pecado mortal; e isto se lhe reputa a confissão.

## Art. 4 — Se podemos licitamente confessar um pecado que não cometemos.
O quarto discute-se assim. ─ Parece que podemos licitamente confessar um pecado que não
cometemos.

1. ─ Pois, como diz Gregório, é próprio das boas almas reconhecer culpa onde ela não existe. Logo, é
próprio das boas almas acusarem-se de culpas que não cometeram.

2. Demais. ─ Quem se considera por humildade inferior a um pecador manifesto merece por isso
louvores. Ora, o que pensamos em nosso coração é lícito confessarmos oralmente. Logo, pode
licitamente confessar que cometeu um pecado mais grave que o que realmente tem.

3. Demais. ─ Às vezes duvidamos se um pecado é mortal ou venial. E então, segundo parece, devemos
confessá-lo como mortal. Logo, devemos às vezes confessar o pecado que não temos.

4. Demais. ─ A satisfação é regulada pela confissão. Ora, podemos satisfazer por um pecado que não
cometemos. Logo, também confessar um pecado que não fizemos.
Mas, em contrário. ─ Quem diz ter feito o que não fez, mente. Ora, ninguém deve mentir na confissão,
porque toda mentira é pecado. Logo, ninguém deve confessar o pecado que não fez.

2. Demais. ─ No juízo externo nenhum crime pode ser imputado a ninguém, que não possa ser provado
por testemunhas idôneas. Ora, a testemunha, no foro da penitência, é a consciência. Logo, ninguém
deve acusar-se de pecado que não tenha na consciência.

SOLUÇÃO. ─ Pela confissão deve o penitente manifestar-se ao seu confessor. Ora, quem revela ao
sacerdote coisa diversa da que na consciência tem, quer boa quer má, não se lhe manifesta, mas antes
se lhe oculta. Logo, a confissão não é idônea; pois, para o ser, há de a boca estar de acordo com o
coração, de modo que a boca só acuse o que há no coração.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ De dois modos podemos reconhecer uma culpa onde ela
não existe. ─ Primeiro, entendendo-se que esse reconhecimento se refere à substância do ato. E então
não é verdadeiro o lugar citado. Pois, não tem boa mente, mas mente errada, quem confesse ter
cometido o que não cometeu. ─ De outro modo, quanto à condição do ato. E então é verdadeiro o dito
de Gregório, que o justo teme não haja, da sua parte, algum defeito num ato em si mesmo bom. E nesse
sentido diz a Escritura: Eu me temia de todas as minhas obras. Por isso é próprio da alma boa que esse
temor existente no coração também o acuse a boca.
Donde também se deduz a resposta à segunda objeção, ─ Porque o justo e verdadeiramente humilde
não se reputa pior por ter praticado um ato que fosse genericamente pior; mas porque teme delinquir
mais gravemente, pela soberba, nas boas obras que pratica.

RESPOSTA À TERCEIRA. ─ Quando duvidamos se um pecado é mortal estamos obrigados a confessá-lo,
enquanto subsiste a dúvida. Porque quem comete ou omite um ato, do qual duvida se é pecado mortal,
peca mortalmente, expondo-se ao perigo. E do mesmo modo a perigo se expõe quem deixa de
confessar o de que duvida se é pecado morta1. Não deve porém afirmar que é mortal, mas expô-lo
como duvidoso e pedir o juízo do sacerdote, a quem incumbe discernir entre lepra e lepra.

RESPOSTA À QUARTA. ─ Quem satisfaz pelo pecado que não cometeu não incorre em mentira, como
incorre quem confessou o pecado que não crê haver cometido. Se porém acusar o pecado que não fez,
mas que crê ter feito, não mente. E portanto não peca, se falar de acordo com o que lhe vai no coração.

## Art. 5 — Se estamos obrigados a confessar sem demora.
O quinto discute-se assim. ─ Parece que estamos obrigados a confessar sem demora.

1. ─ Pois, diz Hugo Vitorino: Não podendo alegar necessidade, não ficamos excusados do desprezo. Ora,
todos estamos obrigados a evitar o desprezo. Logo, estamos obrigados a confessar sem demora, desde
que pudermos.

2. Demais. ─ Todos estamos obrigados a nos esforçar mais por evitar a doença espiritual que a doença
do corpo. Ora, quando temos o corpo doente, se tardamos a chamar o médico, será em detrimento da
nossa saúde. Logo, parece que não podemos, sem detrimento da nossa salvação, deixar de confessar os
nossos pecados, sem demora, a um sacerdote, se deles tivermos cópia.

3. Demais. ─ O que devemos sem termo, devemos sem dilação. Ora, sem termo devemos a confissão a
Deus. Logo, devemos fazê-la sem demora.
Mas, em contrário. ─ Na Decretal se determina simultaneamente o tempo da confissão e o de receber a
Eucaristia. Ora, ninguém peca não recebendo a Eucaristia antes do tempo determinado pelo direito.
Logo, também não peca se não confessa antes desse tempo.

2. Demais. ─ Quem omite ao que está obrigado por preceito peca mortalmente. Quem portanto não
confessasse sem dilação, quando tem cópia de sacerdotes se tivesse obrigação de confessar sem
demora, pecaria mortalmente: e pela mesma razão em tempo diverso, e assim por diante. E assim
incorreríamos em muitos pecados mortais, só por uma demora na confissão. O que não é razoável.

SOLUÇÃO. ─ Sendo o propósito de confessar conexo com a contrição, então estamos obrigados a esse
propósito quando o estamos à contrição. Isto é, quando os pecados se nos ocorrem à memória,
sobretudo se estamos em perigo de morte, ou em situação tal em que incorrêssemos em pecado, não
obtendo a remissão deles. Tal o caso do sacerdote obrigado a celebrar, não havendo cópia de
sacerdotes, e que pelo menos está obrigado à contrição e ao propósito de confessar.
Quanto à confissão atual, de dois modos estamos obrigados a ela.
Primeiro, acidentalmente, quando estamos obrigados ao que não podemos fazer, sem termos
confessado. Então estamos obrigados a fazê-lo: como quando devemos receber a Eucaristia a que
ninguém, em estado de pecado mortal, pode achegar-se, senão depois de ter confessado, se tem cópia
de sacerdotes e a necessidade não urge. E dai a obrigação imposta pela Igreja a todos, de se
confessarem uma vez por ano, porque instituiu que uma vez no ano, a saber, na Páscoa, todos recebem
a sagrada comunhão; e portanto antes desse tempo todos estão obrigados a confessar.
De outro modo, estamos obrigados a confissão, em si mesma considerada. E então a mesma razão há de
diferir a confissão e o batismo, pois ambos são sacramentos necessários à salvação. Ora, a receber o
batismo ninguém está obrigado, que teve o propósito de o receber, de modo que pecasse mortalmente
não o recebendo sem dilação. Nem há tempo nenhum determinado além do qual, diferindo o batismo,
pecará mortalmente. Mas pode acontecer que haja ou não pecado mortal em diferir o batismo. E isso
devemos ponderá-lo levando em conta a causa da dilação; pois, como diz o Filósofo, a vontade não
retarda em fazer o que quer senão por alguma causa racional. Por onde, se a causa da dilação do
batismo implicar pecado mortal, como se o fosse por desprezo ou motivo semelhante, a dilação será
pecado mortal; do contrário, não. E assim o mesmo passa com a confissão, que não é de maior
necessidade que o batismo. E como o necessário à salvação estamos obrigados a cumpri-lo nesta vida,
por isso, havendo perigo iminente de morte, ainda essencialmente falando estamos então obrigados a
fazer a confissão ou a receber o batismo. E por isso também Tiago estabeleceu simultaneamente o
preceito de fazer a confissão e de receber a extrema unção.
Por isso é considerada provável a opinião dos que dizem não estarmos obrigados a confessar sem
demora, não obstante ser perigoso diferi-lo. Outros porém dizem que o contrito está obrigado a
confessar sem demora, oferecendo-se oportunidade, segundo a razão desta. Nem importa que a
decretal prefixe o termo de confessarmos uma vez no ano; porque a Igreja não tem a intenção de
tolerar a demora, mas de proibir a negligência de uma dilação maior. Por onde, essa Decretal não
excusa da culpa da dilação quanto ao foro da consciência; mas excusa da pena, no foro da Igreja, de
privação de sepultura devida, no caso de morte sobreveniente antes do referido tempo. Mas esta
opinião parece demasiado severa. Pois, os preceitos afirmativos não obrigam imediatamente, mas só
em tempo determinado. Não porque então possam ser facilmente cumpridos, pecando assim
mortalmente quem não desse esmola, do supérfluo, sempre que um pobre se lhe oferecesse ─ o que é
falso; mas porque o tempo impõe urgente necessidade. E portanto, não implica em pecarmos
mortalmente o não confessarmos logo, oferecendo-se oportunidade, mesmo se não esperamos melhor
oportunidade; mas quando a circunstancia da necessidade do tempo nô-lo impuser. Nem é por
tolerância da Igreja, que não estejamos obrigados à confissão imediata, mas pela natureza do preceito
afirmativo. E por isso o dever era menor, antes de estatuído pela Igreja.
Outros porém dizem que os seculares não estão obrigados a confessar antes do tempo da quaresma,
que lhes é o tempo da penitência; ao passo que os religiosos estão obrigados a fazê-lo sem dilação,
porque todo tempo é para eles tempo de penitência. ─ Mas nada disto é. Pois, os religiosos não estão
obrigados a mais que os outros homens, senão ao que por voto se obrigaram.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Hugo se refere aos que morrem sem sacramento.

RESPOSTA À SEGUNDA. ─ Não é de necessidade para a saúde do corpo que médico seja chamado
imediatamente, salvo quando a urgência da cura o exige. E o mesmo se dá com a doença espiritual.

RESPOSTA À TERCEIRA. ─ A retenção da coisa alheia contra a vontade do dono contraria a um preceito
negativo, que obriga sempre e para sempre. E por isso há sempre a obrigação de restituir sem demora.
Diferente porém é o que passa com o cumprimento de um preceito afirmativo, que obriga sempre mas
não para sempre. Por isso ninguém está obrigado a cumpri-lo sem dilação.

## Art. 6 — Se pode alguém ser dispensado de confessar a um homem.
O sexto discute-se assim. ─ Parece que se pode ser dispensado de confessar a um homem

1. ─ Pois, os preceitos de direito positivo podem ser dispensados pelos prelados da Igreja. Ora, tal é a
confissão. Logo, pode alguém ser dispensado de confessar.

2. Demais. ─ O que por alguém foi instituído pode pelo mesmo ser dispensado. Ora, lemos que a
confissão não foi instituída por Deus, mas pelo homem: Confessai os vossos pecados uns aosoutros. Ora,
o Papa tem o poder de dispensar no que foi instituído pelos Apóstolos, tal o caso dos bígamos. Logo,
também pode dispensar da confissão.
Mas, em contrário. ─A penitência, da qual faz parte a confissão, é sacramento necessário à salvação,
como o batismo. Ora, como ninguém pode dispensar do batismo, também ninguém pode dispensar da
confissão.

SOLUÇÃO. ─ Os ministros da Igreja foram instituídos na Igreja divinamente fundada. Por isso a
instituição da Igreja é pressuposta às obras dos ministros; assim como a obra da criação o foi à da
natureza. E estando a Igreja fundada na fé e nos sacramentos, por isso não pertence aos ministros da
Igreja instituir sacramentos novos ou suprimir os já instituídos; o que só pertence ao poder de
excelência privativo de Cristo, fundamento da Igreja. Por onde, assim como o Papa não pode dispensar
ninguém de receber o batismo para salvar-se, assim também não pode dispensar, de modo que se
salvasse sem a confissão, enquanto esta obriga pela força mesmo do sacramento. Mas pode dispensar
da confissão, enquanto obriga por preceito da Igreja, de modo que se possa diferir mais a confissão, do
que o permita a legislação da Igreja.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Os preceitos de direito divino não obrigam menos que os
de direito natural. Por onde, assim como não pode haver dispensa em matéria de direito natural, assim
também não em matéria de direito divino positivo.

RESPOSTA À SEGUNDA. ─O preceito da confissão não foi primitivamente instituído pelo homem,
embora fosse promulgado por Tiago; mas recebeu de Deus a sua instituição, embora não nos diga a
Escritura expressamente que o tivesse ele instituído. Contudo encontramos nela uma prefiguração dele,
quando confessavam os seus pecados a João os que, pelo batismo deste, se preparavam à graça de
Cristo, e quando o Senhor remeteu os leprosos aos sacerdotes que, embora não fossem sacerdotes do
Novo Testamento, contudo neles estava significado o sacerdócio do Novo Testamento.