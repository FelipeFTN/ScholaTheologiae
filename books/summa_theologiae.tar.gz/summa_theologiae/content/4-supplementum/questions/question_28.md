# Questão 28: Da solenidade da penitência.
Em seguida devemos tratar da solenidade da penitência.
E nesta questão discutem-se três artigos:

## Art. 1 — Se uma penitência deve ser pública ou solenemente imposta.
O primeiro discute-se assim. ─ Parece que nenhuma penitência deve ser pública ou solenemente
imposta.

1. ─ Pois, não é lícito a um sacerdote, mesmo por medo, revelar o pecado ouvido em confissão, por mais
público que seja. Ora, pela penitência solene torna-se público o pecado. Logo, não deve nenhuma
penitência ser solenemente imposta.

2. Demais. ─ O juízo deve ser conforme à condição do foro. Ora, a penitência é um juízo que se
pronuncia num foro secreto. Logo, não deve ser tornada pública ou solene.

3. Demais. ─ A penitência reduz à perfeição todas as imperfeições morais, como diz Ambrósio. Ora, uma
solenização faz o contrário, porque enreda o penitente em muitos defeitos. Assim, um leigo não pode,
depois de uma penitência solene, ser promovido ao clericato, nem um clérigo às ordens superiores.
Logo, a penitência não pode ser imposta com solenidade.
Mas, em contrário. ─ A penitência é um sacramento. Ora, todo sacramento há de ser conferido com uma
certa solenidade. Logo, também a penitência pode ser imposta com solenidade.

2. Demais. ─ O remédio deve convir à doença. Ora, o pecado às vezes é público, o que serve de exemplo
para aliciar muitos ao pecado. Logo, também a penitência, que é o seu remédio, deve ser pública e
solene, pela qual muitos se edifiquem.

SOLUÇÃO. ─ Certas penitências devem ser públicas e solenes por quatro razões, ─ Primeiro, para dar um
remédio público ao pecado público. ─ Segundo, porque quem cometeu um crime gravíssimo é digno da
máxima confusão, mesmo neste mundo. ─ Terceiro, para servirem de terror aos outros. ─Quarto, para
servirem de exemplo de penitência, a fim de não desesperarem os réus de pecados graves.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O sacerdote não revela a confissão quando impõe tal
penitência, embora gere ela a suspeição que o penitente cometeu algum enorme pecado. Pois, não
podemos conhecer ao certo a culpa pela pena, por que pode se dar faça um penitência por outro; assim,
as Vidas dos Padres narram que um deles, para excitar o companheiro à penitência, a fazia com ele, se o
pecado porém for público, o próprio penitente, cumprindo a penitência, manifesta a confissão que fez.

RESPOSTA À SEGUNDA. ─ A penitência solene, quanto à sua imposição, não ultrapassa o foro secreto;
pois, a quem às ocultas pecou secretamente se lhe impõe uma penitência. A exceção dela porém
ultrapassa o foro oculto. E nisso não há nenhum mal.

RESPOSTA À TERCEIRA. ─ A penitência, embora reduza todos os defeitos, restituindo o penitente à
graça primitiva, não restitui sempre porém a dignidade primitiva. Por isso também as mulheres depois
de cumprida a penitência, pelo pecado de fornicação, não recebem o véu, porque não recuperam a
dignidade virginal. Semelhantemente, depois da penitência pública, o pecador não recupera a dignidade
de poder ser aceito para o clericato; e o bispo que o mandasse deveria ser privado do poder de ordenar,
salvo se o exigisse a necessidade da Igreja ou um costume. Pois então terá a dispensa de ser recebido
para as ordens menores, mas não para as ordens sacras. Primeiro, por causa da dignidade dessas
ordens. Segundo, pelo temor da recidiva. Terceiro, para evitar escândalo que poderia nascer no povo
pela lembrança dos pecados precedentes. Quarto, porque, tendo sido o seu pecado público, não teria
autoridade para corrigir os outros.

## Art. 2 — Se uma penitência solene pode ser reiterada.
O segundo discute-se assim. ─ Parece que uma penitência solene pode ser reiterada.

1. ─ Pois, os sacramentos que não imprimem caráter são reiterados com a sua solenidade; assim, a
Eucaristia, a extrema unção e outros. Ora, a penitência não imprime caráter. Logo, deve ser reiterada
com solenidade.

2. Demais. ─ A penitência quando é imposta solenemente é por causa da gravidade e da manifestação
do pecado. Ora, depois de feita a penitência pode-se recair nos mesmos pecados ou em outros ainda
mais graves. Logo, uma penitência solene deve ser reiterada.
Mas, em contrário. ─ A penitência solene significa a expulsão do primeiro homem, do paraíso. Ora, esta
se realizou só uma vez. Logo, uma penitência solene deve ser feita só uma vez.

SOLUÇÃO. ─ Uma penitência solene não pode ser reiterada, por três razões. ─ Primeiro, para não se
tornar vil, pela reiteração. ─ Segundo, pela sua significação. ─ Terceiro, porque a solenização é uma
como uma profissão de conservá-la durante toda a vida; por isso a reiteração se opõe à solenidade.
Se porém o penitente tornar a pecar, não fica impedido de fazer penitência; mas não se deve lhe tornar
a impor uma penitência solene.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Nos sacramentos em que se reitera a solenidade, esta
não repugna à reiteração, como se dá no caso proposto. Por onde, não há símile.

RESPOSTA À SEGUNDA. ─ Embora, em razão do crime, lhe fosse devida a mesma penitência, contudo a
reiteração da solenidade não tem lugar, pelas causas referidas.

## Art. 3 — Se a penitência solene deve ser imposta às mulheres.
O terceiro discute-se assim. ─ Parece que a penitência solene não deve ser imposta às mulheres.

1. ─ Pois, o homem a quem uma penitência solene é imposta deve cortar os cabelos. Ora, isto não
convém à mulher, como lemos no Apóstolo. Logo, a mulher não deve fazer penitência solene.

2. Demais. ─ Parece que tal penitência deve ser imposta aos clérigos. Pois, é imposta pela gravidade do
delito. Ora, um mesmo pecado é mais grave num clérigo que num leigo. Logo, deve ser imposta antes a
um clérigo que a um leigo.

3. Demais. ─ Parece que pode ser imposta por qualquer sacerdote. Porque absolver no foro da
penitência é poder de quem tem as chaves. Ora, o simples sacerdote tem o poder das chaves. Logo,
pode ser ministro dessa penitência.

SOLUÇÃO. ─ A penitência solene é pública, mas não inversamente. Ora, essa penitência se faz do modo
seguinte. ─ No começo da quaresma, os referidos penitentes se apresentam com os seus presbíteros ao
bispo da cidade, ante as portas da igreja, vestidos de saco, os pés nus, a figura inclinada para o chão, os
cabelos cortados. Conduzidos à igreja, o bispo com todo o clero reza os sete salmos penitenciais,
impondo-lhes depois a mão aspergindo-os com água benta e põe-lhes cinza na cabeça, cobre-lhes de
cilícios o pescoço e lhes anuncia chorosamente, que assim como Adão foi expulso do paraíso, assim o
são eles da igreja. Manda aos ministros expulsá-los da igreja, acompanhando-os o clero com este
reponso ─ Com o suor do teu rosto, etc. Pela Ceia do Senhor, em cada ano, são pelos seus presbíteros
reconduzidos à igreja, onde ficarão até a oitava da Páscoa, não podendo comungar nem receber a paz. E
assim se fará todos os anos, enquanto a entrada da igreja lhes for interdita. A última reconciliação é
reservada ao bispo, que é só quem pode impor a penitência solene. ─ Pode porém ser imposta aos
varões, às mulheres, mas não aos clérigos, por evitar escândalo. Mas uma tal penitência não deve ser
imposta senão pelo pecado que tiverem escandalizado todo um país. ─ Quanto à penitência pública,
mas não solene, é a feita à face da Igreja, mas não com a solenidade referida; assim a peregrinação pelo
mundo com um bastão de peregrino. E essa pode reiterar-se e ser imposta por um simples sacerdote;
podendo também sê-la a um clérigo. ─ Contudo às vezes uma penitência solene é tomada como pública.
E é nesse sentido que várias autoridades se referem à penitência solene.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. A mulher traz os cabelos compridos em sinal de sujeição,
mas não o homem. Por isso não é preciso que na penitência a mulher os corte, como deve fazer o
homem.

RESPOSTA À SEGUNDA. ─ Embora num mesmo gênero de pecado, mais peque o clérigo que o leigo,
contudo não se lhe impõe penitência solene, a fim de não cair a ordem em desprezo. Assim, essa
consideração é para com a ordem e não para com a pessoa.

RESPOSTA À TERCEIRA. ─ Os grandes pecados exigem grande cautela para serem curados. Por isso a
imposição de uma penitência solene, imposta unicamente por pecados gravíssimos, é reservada só ao
bispo.
O Sacramento da extrema unção