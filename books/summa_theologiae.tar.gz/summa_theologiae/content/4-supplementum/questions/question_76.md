# Questão 76: Da causa da ressurreição.
Em seguida devemos tratar da causa da nossa ressurreição.
E nesta questão discutem-se três artigos:

## Art. 1 — Se a ressurreição de Cristo é a causa da nossa ressurreição.
O primeiro discute-se assim. ─ Parece que a ressurreição ele Cristo não é a causa da nossa
ressurreição.

1. ─ Pois, posta a causa, segue-se o efeito. Ora, a ressurreição de Cristo não se seguiu imediatamente a
dos outros mortos. Logo, a sua ressurreição não é a causa da nossa.

2. Demais. ─ Todo efeito é necessariamente seguido da causa. Ora, os outros mortos ressurgiriam,
mesmo que Cristo não tivesse ressurgido, porque podia libertar o homem de outro modo. Logo, a
ressurreição de Cristo não é a causa da nossa.

4. Demais. ─ O efeito conserva alguma semelhança da causa. Ora, a ressurreição, pelo menos a dos
maus, em nada se assemelha à de Cristo. Logo, a ressurreição de Cristo não será a causa da ressurreição
deles.
Mas, em contrário. ─ O que é primeiro em um gênero é causa do que vem depois, como diz Aristóteles.
Ora, Cristo, por causa da ressurreição do seu corpo, a Escritura lhe chama as primícias dos que dormem
e o primogênito dos mortos. Logo, a sua ressurreição é a causa da dos outros.

2. Demais. ─ A ressurreição de Cristo mais convém com a do nosso corpo que com a da nossa alma,
operada por meio da justificação. Ora, a ressurreição de Cristo é a causa da nossa justificação, conforme
ao Apóstolo, quando diz, que ressuscitou para nossa justificação. Logo, a ressurreição de Cristo é a causa
da do nosso corpo.

SOLUÇÃO. ─ Cristo, em razão da natureza humana, o Apóstolo lhe chama mediador entre Deus e os
homens. Por isso os dons divinos promanam de Deus para os homens, mediante a humanidade de
Cristo. Ora, assim como não podemos ser libertos da morte espiritual senão pelo dom da graça divina,
assim também só a ressurreição operada pelo poder divino é que nos poderá libertar da morte do
corpo. Por onde, assim como Cristo recebeu pela sua natureza humana as primícias da graça divina, e a
sua graça é a causa da nossa ─ pois, todos nós participamos da sua plenitude, e graça por graça ─ assim a
ressurreição começou com Cristo e a sua é a causa da nossa. De modo que Cristo, enquanto Deus, é
como a causa equívoca da nossa ressurreição; mas, enquanto Deus e homem ressurrecto é da nossa
ressurreição a como causa próxima e unívoca.
Ora, a causa unívoca, quando obra, produz um efeito semelhante à sua forma. Por onde, não somente é
causa eficiente, mas também exemplar desse efeito. O que de dois modos pode se dar. ─ Às vezes pode
a forma, onde se funda a semelhança entre o agente e o seu efeito, ser o princípio direto da ação que
produz esse efeito; tal o calor do fogo no corpo aquecido. ─ Outras vezes porém, o princípio primário é
essencial da ação produtora do efeito não é a forma em si mesma, fundamento da semelhança, mas sim
os princípios dessa forma. Assim, se um homem branco gerasse outro homem branco, a brancura do
gerador não seria em si mesma o princípio ativo da geração; e contudo dizemos que essa brancura é a
causa do ser gerado, porque os princípios da brancura no gerador são os princípios geradores, que
causam a brancura no ser gerado.
E deste modo a ressurreição de Cristo é a causa da nossa ressurreição. Porque a mesma virtude da
divindade de Cristo, que lhe é comum com o Pai, e que é a causa da ressurreição de Cristo, contribui
também para a nossa ressurreição, da qual é a causa eficiente unívoca. Donde o dito do Apóstolo:
Aquele que ressuscitou dos mortos a Jesus Cristo também dará vida aos vossos corpos mortais. Ora, a
ressurreição mesma de Cristo, causada pelo poder divino inerente a Cristo, é a quase causa instrumental
da nossa ressurreição. Pois, Cristo enquanto Deus obrava mediante o seu corpo como instrumento,
conforme o ensina Damasceno, fundado no exemplo do contato corpóreo com que m unificou o
leproso.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Uma causa suficiente a produzir o seu efeito, ao qual é
imediatamente ordenado, imediatamente o produz. Não porém o efeito ao qual se ordena mediante
outro, por mais suficiente que seja para produzi-lo. Assim o calor, por intenso que seja, não causa o
calor imediata e instantaneamente, mas a sua primeira ação é mover para calor, porque o calor produz
o calor mediante movimento. Ora, a ressurreição de Cristo é chamada causa da nossa, não que por si
mesma a produza, mas só mediante o seu principio ─ a virtude divina, que será a causa da nossa
ressurreição, à semelhança da de Cristo. Ora, a virtude divina tudo obra mediante a vontade, muito mais
próxima do efeito. Por onde, não é necessário que à ressurreição de Cristo imediatamente suceda a
nossa; mas basta que tal se de quando a vontade de Deus o ordenar.

RESPOSTA À SEGUNDA. ─ A virtude divina não depende de nenhumas causas segundas, que não possa
produzir imediatamente, ou mediante outras causas segundas, os efeitos delas. Assim, poderia causar a
geração dos corpos inferiores, mesmo que não existisse o movimento do céu. Contudo, pela ordem
universal, que estabeleceu o movimento do céu, é a causa da geração dos seres terrestres.
Semelhantemente, de acordo com a ordem que a providência prefixou às cousas humanas, a
ressurreição de Cristo é a causa da nossa. Mas podia ter estabelecido outra ordem. E então a causa da
nossa ressurreição seria outra, que Deus ordenasse.

RESPOSTA À TERCEIRA. ─ A objeção procede quando todos os seres de uma mesma espécie tem a
mesma relação com a causa primeira do efeito, que deve ser produzido na totalidade dessa espécie.
Ora, tal não se dá no caso vertente. Porque a humanidade de Cristo está mais chegada à divindade, cujo
poder é a causa primeira da ressurreição, do que a humanidade dos outros homens. Por isso a
ressurreição de Cristo é causada pela divindade imediatamente; ao passo que a ressurreição dos outros
homens, mediante a ressurreição de Cristo homem.

RESPOSTA À QUARTA. ─ A ressurreição de todos os homens terá algo de semelhante à de Cristo, porque
todos se assemelham com ele pela vida natural. Por isso todos com ele ressurgirão para uma vida
imortal. Mas os santos, semelhantes a Cristo pela graça, terão também a sua ressurreição semelhante à
de Cristo, no concernente a glória.

## Art. 2 — Se o som da trombeta será a causa da nossa ressurreição.
O segundo discute-se assim. ─ Parece que o som da trombeta não será a causa da nossa ressurreição.

1. ─ Pois, como diz Damasceno: Crê que a ressurreição há de realizar-se pela vontade, pelo poder e
arbítrio de Deus. Logo, sendo estas as causas ela nossa ressurreição, não é necessário supor-lhe como o
som da trombeta.

2. Demais. ─ É inútil emitir um som a quem não no pode ouvir. Ora, os mortos não terão o sentido do
ouvido. Logo, não há necessidade de ouvirem nenhum som para ressurgirem.

3. Demais. ─ Se algum som for a causa da ressurreição, não o será senão por uma virtude recebida do
alto. Por isso aquilo da Escritura ─ Dará a sua voz de virtude ─ diz a Glosa: de ressuscitar os corpos: Ora,
desde que uma virtude é dada a alguém, embora milagrosamente, o ato dela resultante é natural; como
no caso do cego de nascença que, recobrando miraculosamente a vista, depois via naturalmente. Logo,
se um som fosse a causa da ressurreição, esta serra natural. O que é falso.
Mas, em contrário, o Apóstolo: O mesmo Senhor com a trombeta de Deus descerá do céu, e os que
morreram em Cristo ressurgirão primeiro.

2. Demais. ─ A Escritura diz ─ que os mortos ouvirão a voz do Filho de Deus, e os que a ouvirem viverão.
Ora, é a essa voz que se chama trombeta, segundo o Mestre. Logo, etc.

SOLUÇÃO. ─ A causa há de certo modo conjugar-se com o efeito; porque o motor e o movido, a obra e o
operário, devem existir simultaneamente, como o ensina Aristóteles. Ora, Cristo ressurrecto é a causa
unívoca da nossa ressurreição. Por onde depois de ter ressurgido, Cristo fará sentir a sua ação na
ressurreição dos corpos, por algum sinal material. E esse, na opinião de certos, será literalmente a voz
de Cristo ordenando a ressurreição, como quando pôs preceitos ao mar e aos ventos e logo se seguiu
uma grande bonança. Mas outros são de opinião, que esse sinal não será outro senão a aparição mesma
e manifesta do Filho de Deus ao mundo, da qual diz o Evangelho: Do modo que um relâmpago sai do
oriente e se mostra até o ocidente, assim há de ser também a vinda do Filho do homem. E se apelam
nas seguintes palavras de Gregório: O som da tuba não é mais do que a manifestação do Filho como juiz
do universo. E neste sentido a aparição mesma do Filho se chama voz de Deus; porque toda a natureza
se apressará em lhe obedecer à manifestação, como a uma ordem, concorrendo para a restauração dos
corpos humanos. Por isso, o Apóstolo diz que virá com mandato. Daí o nome de voz dada à sua aparição,
por ter o poder de uma ordem. E essa voz, qualquer que ela seja, noutros lugares da Escritura é
chamada clamor, como que do pregoeiro, que convoca ao juízo. Ou ainda som da tuba, quer por ser
ouvido de todos, como explica o Mestre; ou pela semelhança com o uso que se fazia da trombeta no
Antigo Testamento. Pois, convocavam para as assembléias, tocavam a reunir nos combates e
convidavam para as festas, ao som da trompa. Ora, os ressurrectos serão convocados para a grande
assembléia do juízo e para o combate, no qual todo o universo pelejará contra os insensatos; e também
a festa da eterna solenidade.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Damasceno, com as palavras citadas, tocou em três
pontos da causa material da ressurreição: a vontade divina, que ordena; o poder, que executa; e a
facilidade na execução, quando acrescentou ─ o sinal ─ à semelhança do que passa conosco. Pois, é nos
muito fácil fazer o que se realiza imediatamente, à simples manifestação da nossa vontade. Mas muito
maior será essa facilidade, se já antes de pronunciarmos qualquer palavra, ao primeiro sinal da nossa
vontade, chamado em latim nutus, os ministros a executam. E esse nosso sinal é de certo modo uma
causa dessa execução, pois induz ele a que outros ponham em prática o nosso querer. Ora, o sinal
(nutus) divino operativo da ressurreição, não é senão um sinal dado por Deus, a que toda a natureza
obedecerá para fazer ressurgirem os mortos. E esse sinal é o mesmo que o som da trombeta, como do
sobredito resulta.

RESPOSTA À SEGUNDA. ─ As formas dos sacramentos tem a virtude de santificar, não quando são
ouvidas, mas quando proferidas. Assim também o referido som, qualquer que ele seja, terá uma eficácia
instrumental para ressuscitar, não por ser ouvido, mas por ser desferido; do mesmo modo por que uma
voz, fazendo vibrar o ar, desperta um adormecido, por lhe desatar a faculdade sensitiva, e não por ser
conhecida; porque o julgarmos da voz, que nos fere os ouvidos, é consequente ao despertar, e não o
causa.

RESPOSTA À TERCEIRA. ─ A objeção colheria, se a virtude dada ao sem produtivo da ressurreição fosse
um ser de natureza perfeita; porque então o efeito dela procedente teria como princípio uma virtude
feita natural. Ora, a virtude em questão não é tal; mas como a que dissemos terem as formas dos
sacramentos.

3. Demais. ─ A mesma causa produz o mesmo efeito na mesma ordem de cousas. Ora, a ressurreição
será comum a todos os homens. Logo, a ressurreição de Cristo, não sendo a causa de si mesma, não o é
também da dos outros.

## Art. 3 — Se de algum modo os anjos contribuirão para a ressurreição.
O terceiro discute-se assim. ─ Parece que de nenhum modo os anjos contribuirão para a ressurreição.

1. ─ Pois, a ostensiva ressurreição dos mortos supõe um maior poder que a geração humana. Ora, na
geração humana, a alma não é infundida no corpo mediante o ministério dos anjos. Logo, nem pelo
ministério dos anjos se fará a ressurreição, por onde de novo se unirá a alma ao corpo.

2. Demais. ─ Se houver anjos incumbidos desse ministério, hão de ser de preferência as Virtudes, a
quem é próprio fazer milagres. Ora, não são esses os incumbidos, mas os Arcanjos como diz o Mestre.
Logo, a ressurreição não se fará pelo ministério dos anjos.
Mas, em contrário, o Apóstolo, quando diz: O Senhor, com voz de Arcanjo, descerá do céu e os que
morreram ressurgirão. Logo, a ressurreição dos mortos se cumprirá pelo ministério angélico.

SOLUÇÃO. ─ Conforme diz Agostinho, assim como os corpos mais grosseiros e inferiores são governados
numa certa ordem pelos mais subtis e potentes, assim todos os corpos são governados por Deus
mediante os seres vivos dotados de razão. Com o que também está de acordo Gregório. Por isso em
todas as suas obras materiais Deus se serve do ministério dos anjos. Ora, a ressurreição, implica duas
causas ─ a reunião das cinzas, no concernente à transformação dos corpos; e a preparação que as deve
tornar próprias à reconstituição do corpo humano. Por onde, na ressurreição Deus se servirá do
ministério dos anjos para a consecução desses fins. A alma, porém, como criada imediatamente por
Deus, também será de novo imediatamente unida por Deus ao corpo, sem nenhuma intervenção dos
anjos. Semelhantemente, Deus dará ao corpo a glória sem o ministério angélico, assim como também
glorifica imediatamente a alma. Ora, é esse ministério angélico o chamado voz, segundo uma versão
referida pelo Mestre.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Deduz-se clara do que foi dito.

RESPOSTA À SEGUNDA. ─ O ministério angélico será exercido principalmente por Miguel, um dos
Arcanjos, príncipe da Igreja, como foi o da Sinagoga, conforme à Escritura. Ele porém o exercerá sob a
influência das Virtudes e das outras ordens superiores. E assim o que fizer também de certo modo o
farão as ordens superiores. Semelhantemente, os anjos inferiores cooperarão com ele no tocante à
ressurreição de cada um de aqueles a quem foram dados como guardas. De modo que a referida voz
pode ser simultaneamente considerada como de um e de vários anjos.