# Questão 74: Do fogo da última conflagração.
Em seguida devemos tratar do fogo da última conflagração do mundo.
E nesta questão discutem-se nove artigos:

## Art. 1 — Se o mundo será purificado.
O primeiro discute-se assim. ─ Parece que o mundo não sofrerá nenhuma purificação.

1. ─ Pois, só precisa de ser purificado o que é impuro. Ora, as criaturas de Deus não são impuras; donde
o dizer a Escritura ─ Ao que Deus purificou não chames tu comum, i. é, impuro. Logo, as criaturas do
mundo de nenhuma purificação precisam.

2. Demais. ─ A purificação, segundo a justiça divina, se ordena a delir a impureza da culpa; tal o efeito da
purificação depois da morte. Ora, os elementos deste mundo nenhuma contaminação da culpa podem
ter. Logo, parece não precisarem de purificação.

3. Demais. ─ Dizemos que um ser é purificado, quando dele se separa o que lhe é estranho e o degrada;
pois, tirar-lhe o que lhe aumenta a nobreza não é purificá-lo, mas diminuí-lo. Ora, é para sua perfeição e
nobreza, que os elementos estão mesclados com seres de natureza estranha; pois, a forma de um corpo
misto é mais nobre que a de um simples. Logo, parece que de nenhum modo é possível os elementos
deste mundo passarem por qualquer purificação.
Mas, em contrário. ─ Toda renovação supõe uma purificação. Ora, os elementos serão renovados,
conforme aquilo da Escritura: Vi um céu novo e uma terra nova; porque o primeiro céu e a primeira
terra se foram. Logo, os elementos serão purificados.

2. Demais. ─ Áquilo do Apóstolo: É passageiros figura deste mundo, diz a Glosa: A beleza deste mundo
passará pela conflagração dos fogos terrestres.

SOLUÇÃO. ─ O mundo foi, de certo modo, feito para o homem. Portanto, glorificado o corpo humano,
os outros corpos do mundo hão de necessariamente passar para um estado melhor, ficando em lugar
mais conveniente e com aspecto mais deleitável. Ora, para o homem ser glorificado no seu corpo, é
mister, primeiro, purificar-se do que se lhe opõe à glória, a saber: a corrupção e a mácula da culpa. Por
isso, diz o Apóstolo: A corrupção não possuirá a incorruptibilidade; e da cidade da glória estarão fora
todos os impuros. Semelhantemente, os elementos do mundo terão que ser purificados das disposições
contrárias antes de introduzidos no seu novo estado glorioso, na mesma proporção em que isso se der
com o homem. Pois, embora os seres materiais não possam propriamente ser contaminados pela culpa,
contudo esta lhes imprime uma certa inaptidão a servirem para fins espirituais. Assim, vemos que os
lugares, onde se cometeram crimes, não se consideram apropriados a nenhum ofício sagrado senão
depois de purificados. Por isso, a parte do mundo onde habitamos contraiu, pelos nossos pecados, uma
certa incapacidade para receber a glória. Daí o precisar de ser purificada. Do mesmo modo, os
elementos são susceptíveis, pelo contato, na região média do ar, e de muitas gerações, corrupções e
alterações, que se lhes opõem à pureza. Donde a necessidade de serem purificados, para
convenientemente passarem ao novo estado da glória.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Quando dizemos que toda criatura de Deus é pura,
significa isso que não tem na sua substância mescla de malícia nenhuma. Ao contrário da doutrina dos
Maniqueus, que ensinavam serem o bem e o mal duas substâncias de certo modo distintas e, de certo
outro, mescladas. Mas o dizermos que uma criatura é pura não lhe exclui a mescla de natureza estranha
que, embora boa em si mesma, repugna à perfeição da referida criatura. Também não impede possa
uma criatura sofrer a contaminação de um mal, embora este não esteja mesclado com ela, como se lhe
fizesse parte da substância.

RESPOSTA À SEGUNDA. ─ Embora os elementos corpóreos não possam ser contaminados pela culpa,
contudo, pela culpa cometida contra eles, contraem uma certa incapacidade para receberem a
perfeição da glória.

RESPOSTA À TERCEIRA. ─ A forma do misto e a do elemento pode ser considerada a dupla luz. Na sua
perfeição específica, e então um corpo misto é mais nobre. Ou na perpetuidade da sua duração; e então
mais nobre é o corpo simples, por não ser em si mesmo susceptível de nenhuma corrupção, salvo se
esta lhe advier de uma causa externa. Ao contrário, um corpo misto traz em si mesmo a causa da sua
corrupção, que é a composição de elementos contrários. Por onde, o corpo simples, embora
parcialmente corruptível, é incorruptível no seu todo ─ o que do misto não se pode dizer. E como a
glória, na sua perfeição, é incorruptível, por isso a perfeição de um corpo simples convém mais à
perfeição da glória do que a de um corpo misto; salvo se este trouxer em si um princípio de incorrupção,
como o corpo humano, cuja forma é incorruptível. Contudo, embora o corpo misto seja em si mesmo
mais nobre que o simples, todavia este, quando existe por si mesmo e separadamente, tem o ser mais
nobre que quando existe no misto. Porque no misto os corpos simples existem de certo modo em
potência; ao passo que, existindo como tais e separadamente, existem em toda a sua perfeição.

## Art. 2 — Se a purificação do mundo será pelo fogo.
O segundo discute-se assim. ─ Parece que a purificação do mundo não será pelo fogo.

1. ─ Pois, o fogo, sendo parte do mundo, precisa, como todas as outras partes, de purificação. Ora, não
pode um mesmo ser o purificante e o purificado. Logo, parece que o fogo não será purificado.

2. Demais. ─ Assim como o fogo, a água também tem virtude purificadora. Ora, nem tudo será
purificado pelo fogo, e portanto certos seres, como já a lei antiga o distinguia, hão de necessariamente
ser purificados pela água. Logo, parece que não será o fogo o purificador, ao menos em geral.

3. Demais. ─ O fim da purificação é, segundo parece, tornar mais puras as partes do mundo, segregadas
umas das outras. Ora, a segregação das partes do mundo umas das outras só no princípio se fez, por
poder divino. E, nisso constituiu a obra da distinção delas. Daí o dizer Anaxágoras, que o ato dessa
separação é um ato próprio do intelecto motor de todas as cousas. Portanto, parece que no fim do
mundo a purificação se fará imediatamente por Deus e não pelo fogo.
Mas, em contrário, a Escritura: Fogo se incenderá na sua presença e em roda dele tempestade forte. E
em seguida, a propósito do juízo: Chamará de cima ao céu e a terra para julgar o seu povo. Logo, parece
que a última purificação do mundo se dará pelo fogo.

2. Demais. ─ A Escritura diz: os céus ardendo se desfarão e os elementos com o ardor do fogo se
fundirão. Logo, pelo fogo se fará essa purificação.

SOLUÇÃO. ─ A purificação do mundo dele removerá a contaminação contraída pela culpa e a impureza
da mescla, dispondo-o para a perfeição da glória. Ora, esses três efeitos o fogo muito convenientemente
os produzirá. ─ Primeiro porque, sendo o nobilíssimo dos elementos, tem propriedades naturais mais
semelhantes às da glória, como a luz muito bem o mostra. ─ Segundo, porque o fogo não é susceptível
de mistura com corpos estranhos ─ ao contrário do que se dá com os outros elementos ─ por causa da
eficácia da sua virtude ativa. ─ Terceiro, porque a esfera do fogo está longe da nossa habitação; nem o
uso do fogo nos é tão comum como o da água e do ar. Por isso, não sofrem, como estes, a
contaminação. ─ Além disso, tem, no mais alto grau, o poder de purificar e de dividir os corpos, pela
rarefação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O fogo não se destina ao nosso uso, na sua matéria
própria, pois, como tal está afastado de nós; mas só enquanto existente em matéria diferente. Por isso,
mesclado com um elemento estranho, pode ser purificado pelo fogo existente na sua pureza.

RESPOSTA À SEGUNDA. ─ A purificação primeira do mundo pelo dilúvio só visava a infecção do pecado.
Porque o pecado então reinante era o da concupiscência. Daí o ter-se feito a purificação conveniente
pela água, elemento contrário. Mas a segunda purificação também visará a contaminação da culpa e a
impureza da mescla. E tanto para uma como outra cousa, mais convém a purificação fazer-se pelo fogo
que pela água. Porque a água tem, antes, a virtude de agregar que a de desagregar. Por isso, não
poderia ela, como o pode o fogo, purificar os elementos das suas impurezas. ─ Além disso, no fim do
mundo, reinará o vício da tibieza, como já na velhice dele; pois, conforme diz o Evangelho, então a
caridade de muitos esfriará. Daí a conveniência de a purificação fazer-se pelo fogo. ─ Nem há nada que o
fogo não possa de algum modo purificar. Ao passo que certos corpos, como o pano e os vasos de
madeira, não podem ser purificados senão quando destruídos pelo fogo. Esses objetos a Lei mandava
que se purificassem pela água. O que tudo será finalmente consumido pelo fogo.

RESPOSTA À TERCEIRA. ─ Pela obra da distinção foram conferidas aos seres formas diversas, pelas quais
umas das outras se diversificam. O que portanto não podia ser feito senão pelo Autor da natureza. Mas
a purificação final as reduzirá à pureza em que foram criadas. E essa obra poderá ser realizada mediante
o ministério prestado ao Criador pelos seres criados. Por isso tal ministério lhes foi confiado, por
concorrer para o enobrecimento delas.

## Art. 3 — Se fogo do juízo final será da mesma espécie que o elementar.
O terceiro discute-se assim. ─ Parece que o fogo do juízo final não será da mesma espécie que o
elementar.

1. ─ Pois, nada pode consumir-se a si mesmo. Ora, esse fogo consumirá os quatro elementos, como diz a
Glosa. Logo, não será da mesma espécie que o fogo elementar.

2. Demais. ─ Assim como uma virtude se manifesta pela sua operação, assim a natureza pela sua virtude.
Ora, esse fogo, que purificará o universo, terá outra virtude que não a do fogo elementar, incapaz de
produzir tal efeito. Logo, não terá a mesma natureza do fogo elementar.

3. Demais. ─ Seres corpóreos naturais da mesma espécie tem o mesmo movimento. Ora, esse fogo terá
um movimento diferente do elementar, porque se moverá em todas as direções para poder tudo
purificar. Logo, não é da mesma espécie.
Mas, em contrário, diz Agostinho, e está na Glosa: A figura deste mundo passará, abrasado ele pelo fogo
natural. Logo, esse fogo será da mesma natureza do fogo deste mundo.

2. Demais. ─ Assim como a purificação futura será pelo fogo, assim a precedente foi pela água; e uma é
comparável à outra. Ora, a água da primeira purificação foi da mesma espécie da água elementar. Logo,
e por semelhança, também o fogo da segunda será da mesma espécie que o fogo elementar.

SOLUÇÃO. - Nesta matéria há três opiniões.
Uns ensinam que o fogo elementar, que está na sua esfera, descerá para a purificação do mundo. E
dizem que o modo desse descenso será por multiplicação. Pois, o fogo aumenta tanto mais quanto mais
se lhe fornece matéria combustível. E isso então se dará sobretudo quando o exercer ele a sua virtude
sobre todos os demais elementos. ─ Mas contra essa opinião vai a doutrina dos Santos Padres,
consoante à qual esse fogo não só descerá, mas também subirá, conforme uma Glosa a um lugar da
Escritura, que reza que o fogo do juízo subirá tanto quanto subiu a água do dilúvio. Por onde se vê que
esse fogo exercerá a sua ação na região média deste mundo, onde são gerados os seres.
Por isso outros ensinam, que tal fogo será gerado nessa região média, pela convergência dos raios dos
corpos celestes, como os vemos convergirem num espelho comburente. Mas então, as nuvens côncavas
exercerão a função de espelho, para as quais se fará a reverberação dos raios. ─ Mas também isto não é
admissível. Porque os efeitos dos corpos celestes resultam do lugar e do aspecto determinado deles. Por
onde, se tal fogo fosse gerado pela virtude dos corpos celestes, poderíamos saber o tempo dessa
purificação observando os movimento dos astros. O que repugna à autoridade da Escritura.
Por isso outros, de acordo com Agostinho, dizem que assim como a inundação das águas do mundo
causou o dilúvio, assim este mundo desaparecerá pela conflagração do fogo natural. Ora, essa
conflagração outra cousa não é senão a congregação de todas as causas inferiores e superiores que têm
a virtude natural de queimar. Congregação essa que se fará, não pelo curso natural das cousas, mas por
virtude divina. E de todas essas causas assim congregadas será gerado o fogo, que fará arder a face
deste mundo.
Ora, consideradas atentamente essas opiniões, elas se diversificam pela explicação que apresentam da
causa da geração do fogo purificador, e não pela explicação da sua espécie. Pois, o fogo gerado pelo sol,
ou por um agente calefaciente terrestre, é da mesma espécie que o que está na sua esfera, salvo que
supõe, para exercer a sua ação, matéria estranha. O que então se dará; porque o fogo nada pode
purificar, senão tendo de certo modo matéria heterogênea.
Por onde, absolutamente falando, é forçoso conceder que o fogo do juízo final será da mesma espécie
que o fogo elementar.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O fogo purificador, embora da mesma espécie que o de
que usamos, não é contudo numericamente o mesmo. Assim, vemos que dois fogos da mesma espécie,
um ─ o maior, destrói o outro ─ o menor, consumindo-lhe a matéria. Semelhantemente, também tal
fogo poderá consumir o existente neste mundo.

RESPOSTA À SEGUNDA. ─ Assim como a operação resultante da virtude de um ser é indicio da existência
desta, assim essa mesma virtude manifesta a essência ou a natureza procedentes dos princípios
essenciais do ser A operação, porém, não resultante da virtude de um agente ativo, não lhe denuncia a
virtude, como no caso do agente instrumental. Pois, a ação de um instrumento manifesta, antes, a
virtude do motor que a instrumental. Porque manifesta a virtude do agente principal, como o princípio
primeiro da operação; mas a do instrumento não na manifesta, senão enquanto susceptível da
influência do agente principal, que o move. Semelhantemente, a virtude, não procedente dos princípios
essenciais de um ser, não lhe manifesta senão a natureza receptiva. Assim, a virtude pela qual a água
quente pode aquecer, não lhe manifesta a natureza senão quanto à sua capacidade de aquecer. Por
onde, nada impede uma água, dotada dessa virtude, ser da mesma espécie que outra que não a tem. Do
mesmo modo, nenhum inconveniente há em o fogo em questão, dotado da virtude de purificar a face
do mundo, ser da mesma espécie que o de que nos servimos; pois, a virtude calefativa não lhe resulta
dos princípios essenciais, mas do poder ou da ação divina. Quer concebamos essa virtude como uma
qualidade absoluta ─ tal o caso do calor da água quente; quer como uma intenção, como no caso da
virtude instrumental, conforme dissemos. E isto é mais provável, porque o fogo do juízo não atuará
senão como instrumento do poder divino.

RESPOSTA À TERCEIRA. ─ O fogo, pela sua natureza própria tende para cima. Mas quando unido à
matéria, necessária à sua existência fora da sua esfera própria, então se localiza no lugar onde está a
matéria combustível. E deste modo não há inconveniente em que se mova em círculo ou para baixo; e
sobretudo se atua como instrumento do poder divino.

## Art. 4 — Se esse fogo purificará também os céus superiores.
O quarto discute-se assim. ─ Parece que o fogo do juízo final purificará também os céus superiores.

1. ─ Pois, a Escritura diz: Os céus são obras das tuas mãos; eles perecerão, mas tu permaneces. Ora,
também os céus superiores são obras das mãos de Deus. Logo, perecerão na conflagração final do
mundo.

2. Demais. ─ A Escritura diz: Os céus ardentes se desfarão e os elementos com o ardor do fogo se
fundirão. Ora, os céus distintos dos elementos são os céus superiores, onde estão fixas as estrelas. Logo,
parece que também eles serão purificados pelo fogo do juízo.

3. Demais. ─ A ação desse fogo consistirá em remover dos corpos a indisposição para a glória. Ora, no
céu superior há uma indisposição causada tanto pela culpa ─ pois aí pecou o diabo ─ como por uma
deficiência natural. Assim, aquilo do Apóstolo ─ Sabemos que todas as criaturas gemem e estão com
dores de parto até agora ─ diz a Glosa: Todos os elementos exercem laboriosamente as suas funções;
assim como o sol e a lua não é sem custo que ocupam os espaços que lhes foram demarcados. Logo,
também os céus superiores serão purificados pelo fogo do juízo.
Mas, em contrário, os corpos celestes não são susceptíveis de nenhuma impressão estranha.

2. Demais. ─ Aquilo do Apóstolo ─ Em chama de fogo para tomar vingança ─ diz a Glosa: O fogo
precursor da vinda do Supremo Juiz abrasará o mundo e ocupará o mesmo espaço aéreo ocupado pelas
águas do dilúvio. Ora, as águas do dilúvio não subiram até os céus superiores, mas só quinze côvados
acima do cume dos montes, como lemos na Escritura. Logo, os céus superiores não serão purificados
pelo fogo do juízo final.

SOLUÇÃO. ─ A purificação do mundo terá por fim remover dos corpos a imperfeição contrária à
perfeição da glória, que será a perfeição última deles. E essa disposição todos os corpos a tem, mas cada
um a seu modo. Assim, certos tem uma disposição de alguma maneira inerente à sua substância; tal os
corpos terrestres que, misturando-se uns com os outros, perdem a pureza própria. Outros corpos porém
tem uma disposição em nada inerente à substância deles; tais os corpos celestes, que nada tem de
repugnante à perfeição última do universo, senão o movimento, que é uma via para a perfeição. Nem é
o movimento deles qualquer, mas só o movimento local, que não lhes introduz nenhuma alteração
intrínseca, como a da substância, da quantidade ou da qualidade; mas só a mudança local, que é
extrínseca. Por onde, a substância do céu superior não precisa ser privada de nada, bastando apenas
cessar-lhe o movimento. Ora, a cessação do movimento local não se faz por ação de nenhum agente
contrário, mas só por cessar o movimento do motor. Portanto, os corpos celestes não serão purificados
nem pelo fogo nem pela ação de nenhuma criatura; mas, em lugar de purificação, apenas cessarão de
mover-se por assim o determinar a vontade divina.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Como expõe Agostinho, as palavras do salmo citado
devem entender-se dos céus aéreos, a serem purificados pelo fogo da última conflagração. ─ Ou
devemos responder que, aplicadas aos céus superiores, significam que perecem, quanto ao movimento
que atualmente executam.

RESPOSTA À SEGUNDA. ─ Pedro explica a que céu se refere. Pois, antes tinha dito: Os céus e a terra,
agora existentes, purificados antes pela água, serão de novo, por decreto do mesmo Verbo divino,
purgados pelo fogo no dia de juízo. Logo, aqueles céus serão purificados pelo fogo, que antes o foram
pelas águas do dilúvio; e esses são os céus aéreos.

RESPOSTA À TERCEIRA. ─ Essa pena e essa servidão da criatura, atribuídas por Ambrósio aos corpos
celestes, não são mais que as vicissitudes dos movimentos, que os tornam sujeitos ao tempo, e a
privação da perfeição última, que finalmente hão de ter. Demais, o céu empíreo em nada ficou
contaminado com a culpa dos demônios, pois daí foram expulsos logo depois do pecado.

## Art. 5 — Se o fogo do juízo consumirá os outros elementos.
O quinto discute-se assim. ─ Parece que o fogo do juízo consumirá os outros elementos.

1. ─ Pois, diz a Glosa de Beda: O fogo do juízo, o mais enérgico de todos, consumirá os quatro elementos
de que consta o mundo. Mas não os consumirá a todos totalmente, senão só dois; os outros dois os fará
passar a um estado mais perfeito. Logo, parece que pelo menos dois elementos serão totalmente
destruídos por esse fogo.

2. Demais. ─ A Escritura diz: O primeiro céu e a primeira terra se foram e o mar já não é. Ora, pelo céu
entende-se o ar, como Agostinho o explica; e o mar é a reunião das águas. Logo, parece que os três
elementos referidos serão totalmente destruídos.

3. Demais. ─ O fogo não purifica senão porque a sua ação se exerce sobre outras matérias. Ora, para
poder purificar os outros elementos é necessário sejam estes matéria sobre que possa ele exercer-se.
Portanto, terão que se transformar em substância ígnea. Logo, a sua natureza será destruída.

4. Demais. ─ A forma do fogo é a nobilíssima das formas que possa adquirir a matéria elementar. Ora, a
referida purificação levará todas as cousas ao seu estado mais nobre. Logo, os outros elementos se
converterão totalmente em fogo.
Mas, em contrário, aquilo do Apóstolo ─ A figura deste mundo passa ─ diz a Glosa: Passará a beleza, mas
não a substância deste mundo. Ora, é a substância mesma dos elementos a constitutiva da perfeição do
mundo. Logo, não será consumida a substância deles.

2. Demais. ─ Essa purificação final pelo fogo corresponderá à primeira, pela água. Ora, esta não destruiu
a substância dos elementos. Logo, nem do fogo a destruíra.

SOLUÇÃO. ─ Há muitas opiniões sobre esta questão. Uns dizem, que a matéria de todos os elementos
subsistirá, mas sofrerá mudança a imperfeição deles. Assim, dois deles, o ar e a terra, conservarão a sua
forma substancial própria; os outros dois, o fogo e a água, não conservarão a sua forma substancial, mas
tomarão a forma do céu. De modo que o céu será constituído dos três elementos seguintes ─ o ar, o
fogo e a água; embora o ar conserve a mesma forma substancial que agora tem e pela qual recebe
atualmente o nome de céu. Por isso também a Escritura não menciona senão o céu e a terra, quando
diz: Vi um céu novo e uma terra nova. ─ Mas esta opinião é totalmente absurda. Pois, repugna à
filosofia, que nos impede admitir que os corpos celestes sejam susceptíveis da forma do céu, por não
terem matéria comum nem serem contrários uns aos outros. Repugna também à teologia, pois tal
opinião não poderia salvar a perfeição do universo, na integridade das suas partes, desde que o privou
de dois dos seus elementos. Por onde, pela palavra céu se entende um quinto corpo; entendendo-se por
terra todos os mais elementos, como quando a Escritura diz ─ Louvai ao Senhor, os que sois da terra; e
ainda: O fogo, o granizo, a neve, a geada, etc.
Por isso outros ensinam, que todos os elementos subsistirão na sua substância mas privados das suas
qualidades ativas e passivas. Assim como também ensinam que nos corpos mistos os elementos
subsistem nas suas formas substanciais, sem conservarem as suas qualidades próprias; ficam assim num
estado médio, e o meio não é nenhum dos extremos. E este parece também o sentir de Agostinho,
quando escreve: A conflagração última do mundo destruirá totalmente, no seu ardor devorante, as
qualidades dos elementos corruptíveis constitutivos dos nossos corpos corruptíveis; mas, por uma
transformação maravilhosa, a substancia deles receberá as qualidades apropriadas a corpos imortais. ─
Esta opinião porém não parece provável. Porque, as qualidades próprias dos elementos, sendo efeitos
das formas substanciais, enquanto estas subsistirem, não poderão as referidas qualidades transformar-
se, senão por uma ação violenta temporária. Assim vemos a água aquecida recuperar, pela sua virtude
específica própria, a frigidez que por ação do fogo perdeu, contanto que subsista a espécie da água.
Além disso, essas qualidades elementares são, como paixões próprias dos elementos, as constitutivas da
perfeição secundária deles. Nem é provável que nessa final perfeição dos seres percam os elementos
nenhuma das suas perfeições naturais.
Por onde, devemos responder, que os elementos subsistirão na sua substância e qualidades próprias,
purificados porém da contaminação contraída pelos pecados dos homens, e da impureza neles
resultantes da sua ação e paixão mútuas. Pois, cessado o movimento do primeiro móvel, já não mais
terão os elementos terrestres ação nem paixão mútua. E a isso chama Agostinho as qualidades dos
elementos corruptíveis, i. é, disposições naturais que os colocam nos limites da corrupção.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Dizemos que o fogo do juízo final consumirá os quatro
elementos pelos de certo modo purificar. A expressão seguinte ─ dois serão totalmente consumidos ─
não significa que esses dois serão destruídos na sua substância; mas que serão os mais privados das
propriedades que agora tem. Esses, dizem uns serem o fogo e a água, cuias qualidades ativas ─ o calor e
o frio ─ são as mais enérgicas e os princípios que mais contribuem para a corrupção dos outros corpos. E
como na época da conflagração final o fogo e água, elementos ativos por excelência, não mais atuarão,
consideram-se como havendo, mais que todos os outros, sofrido mudança na virtude que agora tem.
Outros autores porém pensam, que esses dois elementos serão o ar e a água, por causa dos vários
movimentos deles, resultantes do movimento dos corpos celestes. E como esses movimentos não serão
da natureza, do fluxo e do refluxo do mar, do curso dos ventos e semelhantes, por isso tais elementos
serão os que maiores mudanças sofrerão nas suas propriedades atuais.

RESPOSTA À SEGUNDA. ─ Como o interpreta Agostinho, na expressão ─ o mar já não é ─ por mar pode
entender-se o século presente, de que antes no mesmo lugar se diz: E o mar deu os mortos que estavam
nele. ─ Tomada porém a palavra mar literalmente, devemos então dizer, que duas causas por ele se
entendem ─ a substância das águas e as suas propriedades salinas, com a agitação das suas ondas. E
neste segundo sentido o mar não subsistirá; subsistirá porém no primeiro.

RESPOSTA À TERCEIRA. ─ O fogo da conflagração final, não exercerá a sua ação senão como
instrumento da providência e do poder divinos. Assim, não na exercerá sobre os outros elementos para
os consumir totalmente, mas só para os purificar. Nem importa que a matéria sobre a qual se exercer
esse fogo fique totalmente privada da sua espécie própria; como se dá com o ferro rubro que, tirado do
fogo, volta ao estado próprio e primitivo, por virtude da espécie que não perdeu. Assim também será
com os elementos purificados pelo fogo.

RESPOSTA À QUARTA. ─ Nas partes dos elementos não devemos considerar só o que a cada uma
convém tomada de per si, mas também o que lhes cabe relativamente ao todo. Ora, digo que, embora a
água fosse mais nobre se tivesse a forma do fogo, como também a terra e o ar, contudo o universo seria
mais imperfeito e a matéria total dos elementos recebesse a forma ígnea.

## Art. 6 — Se todos os elementos serão purificados pelo fogo da conflagração final.
O sexto discute-se assim. ─ Parece que nem todos os elementos serão purificados pelo fogo da
conflagração final.

1. ─ Pois, esse fogo, como já disse, não subirá senão quanto subiu a água do dilúvio. Ora, a água do
dilúvio não subiu até a esfera do fogo. Logo, na purificação última, não será purificado o elemento do
fogo.

2. Demais. ─ Àquilo da Escritura ─ Vi um céu novo, etc. ─ diz a Glosa: Não há dúvida que as
transformações do ar e da terra se farão pelo fogo. Mas há dúvidas quanto à água, porque, segundo se
crê, ela por si mesma se purificará. Logo, pelo menos não é certo que todos os elementos serão
purificados.

3. Demais. ─ O lugar de perpétua impureza nunca será purificado. Ora, o inferno será sempre o lugar da
impureza. Logo, como está colocado entre os elementos, parece que não serão totalmente purificados.

4. Demais. ─ O paraíso terrestre está colocado na terra. Ora, não será purificado pelo fogo, porque nem
mesmo as águas do dilúvio subiram até lá, como diz Beda e o Mestre das Sentenças. Logo, parece que
nem todos os elementos serão totalmente purificados.
Mas, em contrário, a Glosa supra-citada: Os quatro elementos o fogo os consumirá.

SOLUÇÃO. ─ Certos ensinam, que o fogo da última conflagração subirá até o mais alto do espaço, que
contém os quatro elementos. De modo que estes serão totalmente purificados, tanto da contaminação
do pecado, que atingiu também as partes superiores deles ─ como o demonstra o fumo dos sacrifícios
idolátricos, que atingiu essas partes superiores ─, como também da corrupção, porque os elementos são
corruptíveis em todas as suas partes. ─ Mas esta opinião repugna à autoridade da Escritura. Porque,
segundo a Escritura, aqueles céus serão de novo purificados pelo fogo, que já o foram pela água. E
Agostinho diz, que o mundo afogado pelo dilúvio será de novo purificado pelo fogo. Ora, sabemos que a
água do dilúvio não subiu até o espaço supremo dos elementos, mas só até quinze côvados acima do
cume dos montes. Além disso, é sabido que os vapores evaporados da terra, ou quaisquer fumos não
podem ultrapassar a esfera do fogo, até chegar ao ponto extremo dela. E ainda, a contaminação do
pecado não atingiu esse espaço referido. Demais, os elementos não podem ser purificados da sua
corruptibilidade perdendo alguma parte, capaz de ser consumida pelo fogo; mas este poderá consumir-
lhes as impurezas, resultante da mistura de uns com os outros. Ora, essas impurezas se encontram
sobretudo na terra, até a região média do ar. Por onde, o fogo da última conflagração purificará os
elementos até esse espaço. Pois, a tal altura ascenderam as águas do dilúvio; o que podemos avaliar
com probabilidade, considerando a altura dos montes, a que acima dos seus cumes galgaram as águas.
Por isso, concedemos a primeira objeção.

RESPOSTA À SEGUNDA. ─ A razão da dúvida a Glosa a refere quando diz ─ porque, segundo se crê, a
água tem em si mesmo a virtude de se purificar. Mas essa virtude não é tal que lhe possa dar à água a
perfeição que deve ter no futuro estado de cousas, como do sobredito resulta.

RESPOSTA À TERCEIRA. ─ O fim principal dessa purificação será remover da habitação dos santos toda
imperfeição. Por isso, depois dela, tudo o que for impuro será atirado para o receptáculo dos
condenados. E assim, longe de ser purificado, o inferno será o depositário de todas as impurezas do
universo.

RESPOSTA À QUARTA. ─ Embora o pecado do primeiro homem tivesse sido cometido no paraíso o
terrestre, contudo esse lugar não foi o do homem pecador, como o céu empíreo não foi o dos maus
anjos. Pois, de ambos esses lugares tanto o homem como o diabo foram expulsos imediatamente depois
do pecado. Por isso não precisam tais lugares de ser purificados.

## Art. 7 — Se o fogo da última conflagração deve seguir-se ao juízo.
O sétimo discute-se assim. ─ Parece que o fogo da última conflagração deve seguir-se ao juízo.

1. ─ Pois, Agostinho, enumerando as causas que se passarão no juízo, diz: No juízo final se darão os
seguintes acontecimentos ─ a vinda de Elias Tesbita, a conversão dos Judeus, a perseguição pelo
anticristo, o juízo de Cristo, a ressurreição dos mortos, a separação entre os bons e os maus, a
conflagração do mundo e a sua renovação. Logo, a conflagração sucederá ao juízo.

2. Demais. ─ Agostinho diz no mesmo livro: Julgados os ímpios e precipitados no fogo eterno, a figura
neste mundo passará pelo abrasamento geral do fogo que encerra. Logo, a mesma conclusão anterior.

3. Demais. ─ O Senhor quando vier julgar encontrará muitos vivos, como se conclui do seguinte, que
deles diz o Apóstolo: Depois, nós outros, que vivemos, que temos ficado aqui para a vinda do Senhor,
etc. Ora, isto não se daria, se a conflagração do mundo precedesse, porque então esses tais seriam
consumidos pelo fogo. Logo, o fogo será posterior ao juízo.

4. Demais. ─ A Escritura diz, que o Senhor virá julgar o mundo pelo fogo. Portanto, parece que a
conflagração final será a execução da sentença ou do juízo divino. Ora, a execução é posterior ao juízo.
Logo, o fogo sucederá ao juízo.
Mas, em contrário, a Escritura: Fogo irá diante dele.

2. Demais. ─ A ressurreição precederá ao juízo; aliás nem todos os olhos assistiriam ao juízo de Cristo.
Ora, a conflagração do mundo precederá à ressurreição. Além disso, os santos ressurrectos terão corpos
espirituais e impassíveis; e assim não poderão ser purificados pelo fogo, embora o Mestre diga, fundado
em Agostinho, que pelo fogo do juízo final será purificado o que ainda possam ter de impuro. Logo, esse
fogo precederá ao juízo.

SOLUÇÃO. ─ A conflagração final, no seu inicio, realmente precederá ao juízo. O que manifestamente
pode concluir-se do fato de o preceder a ressurreição dos mortos, conforme ao lugar do Apóstolo: Os
que ficamos aqui seremos arrebatados nas nuvens juntamente com Cristo, vindo para julgar. Ao mesmo
tempo haverá a ressurreição geral e a glorificação dos corpos dos santos. Pois, os santos ressurrectos
retomarão seus corpos gloriosos, como se conclui das palavras do Apóstolo: Semeia-se em vileza,
ressuscitará em glória. E simultaneamente com a glorificação dos corpos dos santos, todas as criaturas
serão renovadas, cada uma a seu modo. Assim o diz o Apóstolo: A mesma criatura será livre da sujeição
à corrupção, para participar da liberdade da glória dos filhos de Deus. Ora, a conflagração do mundo,
dispondo para a renovação referida, conforme do sobredito se colhe, podemos manifestamente concluir
que a conflagração final, quanto à purificação do mundo, precederá ao juízo. Mas, quanto ao efeito de
envolver os maus, seguir-se-lhe-á.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Agostinho não se exprime de maneira afirmativa, mas
opinativa. O que resulta das palavras seguintes: Todas essas causas devemos acreditar que hão de
acontecer; mas de que modo e em que ordem se darão, mais então no-lo ensinará a experiência das
causas, do que podemos ter atualmente uma inteligência completa. Julgo porém, que tais
acontecimentos terão lugar na ordem em que os enumerei. Por onde é claro que fala em sentido
opinativo.
E o mesmo podemos responder à segunda objeção.

RESPOSTA À TERCEIRA. ─ Todos os homens morrerão e ressurgirão. O Apóstolo chama vivos os que
conservarem a vida do corpo até a conflagração universal.

RESPOSTA À QUARTA. ─ O fogo da conflagração final não executará a sentença do Supremo Juiz senão
quanto ao ato de envolver os maus. A esta luz, sucederá ao juízo.

## Art. 8 — Se o fogo da conflagração final terá sobre os homens o efeito que se lhe atribui.
O oitavo discute-se assim. ─ Parece que o fogo da conflagração final não terá sobre os homens o efeito
que se lhe atribui.

1. ─ Pois, dizemos que se consome o que é reduzido ao nada. Ora, os corpos dos ímpios não serão
reduzidos ao nada, mas subsistirão eternamente para sofrerem uma pena eterna. Logo, esse fogo não
consumirá os maus, como diz o Mestre.

2. Demais. ─ A quem disser que esse fogo consumirá os corpos dos maus, reduzindo-os a cinza,
responde-se em contrário o seguinte. Tanto os corpos dos maus como o dos bons se resolverão em
cinza. E só Cristo teve o privilégio de o seu corpo não haver sofrido a corrupção. Logo, também os bons,
que viverem no momento da conflagração geral, serão consumidos pelo fogo.

3. Demais. ─ Foram mais contaminados pelo pecado os elementos, que entram na composição do corpo
humano, onde se radicou a concupiscência, mesmo nos bons, que os elementos estranhos a esse corpo.
Ora, estes últimos terão de ser purificados da contaminação do pecado. Logo e com maior razão,
precisam de ser purificados pelo fogo os elementos, que entram na composição do corpo humano,
tanto dos bons como dos maus. Portanto, todos hão de ser reduzidos ao nada.

4. Demais. ─ Enquanto dura esta vida, os elementos atuam do mesmo modo, tanto no corpo dos bons
como no dos maus. Ora, ainda haverá vivos no momento da conflagração universal, porque depois desta
vida já não haverá morte natural, que contudo será provocada por essa conflagração. Logo, o fogo
atuará igualmente sobre os bons e os maus. Donde, pois, parece que não haverá nenhuma diferença
entre eles, quanto a sofrerem o efeito do fogo, ao contrário do que diz o Mestre.

5. Demais. ─ A conflagração final será quase momentânea. Ora, virá apanhar muitos ainda vivos e que
devem ser purificados. Logo, essa conflagração não bastará para purificá-los.

SOLUÇÃO. ─ O fogo da conflagração final, como precursor do juízo, atuará como instrumento da justiça
divina e pela virtude natural do fogo. Pela sua virtude natural atuará tanto sobre os maus como sobre os
bons, que nessa ocasião estiverem vivos, reduzindo-lhes os corpos a cinzas. Mas como instrumento da
justiça divina, fará com que uns e outros lhe sofram diferentemente a pena. Os maus serão cruciados.
Ao contrário, os bons, não precisando de ser purificados, nada sofrerão, como não sofreram os meninos
na fornalha, conforme o refere a Escritura. Embora, como os destes, os seus corpos não hajam de
conservar a sua integridade. Pois, o poder divino, fará esses corpos, sem serem cruciados pela dor, se
reduzirem a cinza. Os bons, porém, que ainda deverem ser purificados, sentirão as dores causadas pelo
fogo, mais ou menos, conforme o merecerem. Mas, depois do juízo, a sua ação se exercerá apenas
sobre os maus, porque os corpos dos bons serão impassíveis.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A consumpção, no lugar citado, se toma no sentido de
redução a cinzas, e não no de aniquilamento.

RESPOSTA À SEGUNDA. ─ Os corpos dos bons, embora reduzidos a cinzas pelo fogo, nem por isso
sentirão qualquer dor, como nenhuma sofreram os meninos na fornalha da Babilônia. Por ai haverá,
pois, diferença entre bons e maus.

RESPOSTA À TERCEIRA. ─ Os elementos do corpo humano serão purificados pelo fogo, mesmo os do
corpo dos bons; mas o poder divino fará com que tal se dê sem os tormentos da dor.

RESPOSTA À QUARTA. ─ O fogo em questão não atuará só pela virtude do elemento natural, mas
também como instrumento da justiça divina.

RESPOSTA À QUINTA. ─ Três são as causas por que poderão ser instantaneamente purificados os que
estiverem vivos por ocasião da conflagração universal. ─ A primeira é que pouco precisarão de ser
purificados; depois de já o terem sido pelos terrores e perseguições precedentes. ─ A segunda é que, em
vida sofreram a sua pena voluntariamente. Ora, uma pena sofrida de livre vontade nesta vida purifica
muito mais que a infligida depois da morte. E o comprova o exemplo dos mártires, em que a foice do
sofrimento lhes eliminará o que porventura ainda mereça purificação, como o diz Agostinho. Contudo, a
pena do martírio é breve em comparação com as penas do purgatório. ─ A terceira é que o calor desse
fogo ganhará em intensidade o que perder pela abreviação do tempo.

## Art. 9 — Se o fogo da conflagração final há de envolver os réprobos.
O nono discute-se assim. ─ Parece que o fogo da conflagração final não há de envolver os réprobos.

1. - Pois, àquilo da Escritura ─ Purificará os filhos de Levi ─ diz a Glosa: Conforme lemos na Escritura,
haverá duas espécies de fogo ─ o purificador dos eleitos, que precederá ao juízo; e o que cruciará os
réprobos. Ora, este último é o fogo do inferno, que envolverá os maus; e o primeiro é o da conflagração
final. Logo, o fogo da conflagração final não será o que há de envolver os réprobos.

2. Demais. ─ O fogo do juízo final servirá a Deus, purificando o mundo. Logo, merecerá, como todos os
outros elementos, uma recompensa: tanto mais quanto é o nobilíssimo deles. Portanto, parece que não
se lhe deveria atribuir a função de ser no inferno a pena dos condenados.

3. Demais. ─ O fogo, que envolverá os maus, será o do inferno. Ora, foi ele preparado para os
condenados, desde o princípio do mundo. Por isso diz o Evangelho: Ide, malditos, para o fogo eterno,
que esta aparelhado para o diabo. E noutro lugar da Escritura: Aparelhado está o lugar de Tophet desde
ontem, aparelhado pelo rei. Comenta a Glosa: Desde ontem, i. é, desde o princípio; Tophet, i. é, o Vale
da Geena. Ora, o fogo da conflagração final não foi preparado desde o principio, mas será gerado com
concurso do fogo natural. Logo, não será ele fogo do inferno, que envolverá os réprobos.
Mas, em contrário, desse fogo diz a Escritura: O fogo abrasará em derredor os seus inimigos.

2. Demais. ─ A Escritura diz: De diante dele saia um rio de fogo e arrebatado. E a Glosa: Para arrastar os
pecadores à geena. Ora, a autoridade citada se refere ao fogo da conflagração universal, como o
demonstra uma glosa do lugar aludido: para punir os maus e purificar os bons. Logo, o fogo da
conflagração universal será precipitado no inferno com os réprobos.

SOLUÇÃO. ─ A purificação e a renovação do mundo totalmente se ordenará à purificação e à renovação
do homem. Portanto, a purificação e a renovação do mundo há de necessariamente corresponder à
purificação e à renovação do gênero humano. Ora, esta última terá lugar quando forem os maus
separados dos bons. Donde o dizer o Evangelho: cujo pá está na sua mão; e ele alimpará a sua eira e
recolherá o trigo no seu celeiro; i. é, os eleitos; e queimará as palhas, i. é, os réprobos, em um fogo que
nunca se apaga. Por onde, nessa purificação universal, tudo o torpe e contaminado será precipitado
com os réprobos no inferno; do contrário, tudo o que for belo e nobre será reservado à glória dos
eleitos no céu. Assim, o mesmo se dará com o fogo da conflagração final, como diz Basílio aquilo da
Escritura: Voz do Senhor que divide a chama do fogo. Pois, tudo o que o fogo tiver de ardência e de
comburente e de grosseiro descerá aos infernos como pena dos réprobos; o que porém for nele súbtil e
lúcido ficará no céu para glória dos eleitos.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O fogo purificador dos eleitos, antes do juízo, será
idêntico ao da conflagração do mundo, embora muitos digam o contrário. Pois, a conveniência exige
que, sendo parte do mundo, o homem seja purificado pelo mesmo fogo que ao mundo purificará. E
quando se distinguem dois fogos ─ o purificador dos bons e o atormentador dos maus ─ distintos tanto
pela sua função como, de certo modo, pela substância, isso é porque o fogo purificador não será
precipitado no inferno, na totalidade da sua substância, como se disse.

RESPOSTA À SEGUNDA. ─ A recompensa do referido fogo estará em que perderá a sua parte grosseira,
que será precipitada no inferno.

RESPOSTA À TERCEIRA. ─ Assim como a glória dos eleitos, depois do juízo, será maior que antes, assim
também a pena dos réprobos. Por onde, assim como a luminosidade será acrescentada à parte superior
para aumentar a glória dos eleitos, assim também tudo quanto as criaturas tiverem de impuro será
precipitado no inferno para aumentar a miséria dos condenados. Por onde, nenhum inconveniente há
em ao fogo dos condenados no inferno, preparado desde o início, se lhes acrescentar outro fogo.