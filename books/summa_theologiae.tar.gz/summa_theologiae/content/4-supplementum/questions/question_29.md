# Questão 29: Do sacramento da extrema unção.
Em seguida devemos tratar do sacramento da extrema unção. Sobre o qual temos cinco questões a
discutir. Primeiro, do que lhe é essencial e da sua instituição. Segundo, dos seus efeitos. Terceiro, do seu
ministro. Quarto, daquele a quem deve ser conferido e em que parte. Quinto, da sua reiteração.
Na primeira questão discutem-se nove artigos:

## Art. 1 — Se a extrema unção é sacramento.
O primeiro discute-se assim. ─ Parece que a extrema unção não é sacramento.

1. ─ Pois, assim como o óleo é aplicado aos enfermos, assim também aos catecúmenos. Ora, a unção
feita com óleo nos catecúmenos não é sacramento. Logo, nem a extrema unção feita nos enfermos.

2. Demais. ─ Os sacramentos da Lei Velha foram sinais dos da Lei Nova. Ora, a extrema unção não teve
nenhuma figura na Lei Velha. Logo, não é sacramento da Lei Nova.

3. Demais. ─ Segundo Dionísio, todo sacramento serve para purificar, para iluminar ou para aperfeiçoar.
Ora, o fim da extrema unção não é nem iluminar, pois isto só o faz o batismo; nem aperfeiçoar, fim
próprio do crisma, segundo o próprio Dionísio, e da Eucaristia. Logo, a extrema unção não é sacramento.
Mas, em contrário. ─ Os sacramentos da Igreja são suficientes para socorrer as nossas misérias, em
qualquer estado. Ora, aos moribundos nenhum outro socorro há senão o da extrema unção. Logo, é
sacramento.

2. Demais. ─ Os sacramentos não são mais que uns remédios espirituais. Ora, a extrema unção é um
remédio espiritual, pois serve para a remissão dos pecados, como lemos na Escritura. Logo, é
sacramento.

SOLUÇÃO. ─ Dentre as operações visíveis com que a Igreja presta o seu ministério, umas são
sacramentos, como o batismo; outras, sacramentais, como o exorcismo. A diferença entre umas e
outras esta, que sacramento se chama a operação pela qual a Igreja alcança o efeito principalmente
visado na administração dos sacramentos; e sacramental se chama aquela operação, que embora não
vise esse efeito principal, contudo se lhe ordena de certo modo. Ora, o efeito visado na administração
dos sacramentos é curar a doença do pecado, conforme aquilo da Escritura: Todo este fruto se reduz a
que seja tirado o seu pecado. Logo, como a extrema unção produz esse fruto, conforme resulta das
palavras de Tiago, nem se ordena a outro sacramento, como se lhe fosse anexo, resulta que a extrema
unção não é sacramental, mas sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O óleo com que são ungidos os catecúmenos, não produz
só pelo fato de ungir o perdão do pecado, efeito próprio do batismo; mas de certo modo dispõe para
este, como dissemos. Logo, essa unção não é sacramento, como o é a extrema unção.

RESPOSTA À SEGUNDA. ─ Este sacramento dispõe-nos imediatamente para a glória, ministrado quando
nos separamos do corpo. Ora, na Lei Velha não era ainda o tempo de se alcançar a glória, porque a lei
nenhuma causa levou à perfeição. Por onde, este sacramento não devia ser nela prefigurado por
nenhum outro que lhe correspondesse, como se fosse uma figura do mesmo gênero. Embora por figuras
remotas fosse de certo modo figurado, em todas as curas que na vigência da Lei Velha se realizaram.

RESPOSTA À TERCEIRA. ─ Dionísio nenhuma menção faz da extrema unção, como não o faz da
penitência nem do matrimônio, porque visava tratar dos sacramentos, enquanto o conhecimento deles
podia servir a fazer conhecer a ordem observada na hierarquia eclesiástica, tanto em relação aos
ministros e aos seus atos, como aos que os recebem. Contudo, como a extrema unção confere a graça e
a remissão dos pecados, não há dúvida que tem poder de iluminar e purificar, como o batismo, embora
não tão plenamente.

## Art. 2 — Se a extrema unção é um só sacramento.
O segundo discute-se assim. ─ Parece que a extrema unção não é um só sacramento.

1. ─ Pois, a unidade de um ser lhe advém da forma, porque pelo mesmo princípio tem ele o ser e a
unidade. Ora, a forma deste sacramento se reitera requentemente, ainda no decurso de um mesmo ato;
e também a matéria, que é aplicada em diversas partes do corpo do ungido. Logo, não é um sacramento
único.

2. Demais. ─ A unção mesma é que é um sacramento, pois, seria ridículo dizer que o óleo é um
sacramento. Ora, são várias as funções. Logo, são vários os sacramentos.

3. Demais. ─ Um sacramento deve ser conferido por um ministro. Ora, em certos casos a extrema unção
não pode ser conferida por um ministro; assim, se depois de feita a primeira unção, o sacerdote morrer,
pois então outro sacerdote é quem deverá continuar. Logo, a extrema unção não é um só sacramento.
Mas, em contrário. ─ A imersão está para o batismo, como a unção para este sacramento. Ora, várias
imersões constituem um só sacramento do batismo. Logo, as várias unções da extrema unção são um só
sacramento.

2. Demais. ─ Se não fosse um só sacramento, então, feita a primeira unção, não seria necessário à
perfeição do sacramento fazer a segunda; porque todo sacramento por si só existe perfeitamente. Ora,
isto é falso. Logo, é um só sacramento.

SOLUÇÃO. ─ A ser uno numericamente, em si mesma considerado, é susceptível de tríplice aspecto. Ou
é indivisível, como o ponto e a unidade, por não ter pluridade nem atual nem potencial; ou é contínuo,
como a linha, dotada de unidade atual e de pluralidade potencial, ou, terceiro, é um ser perfeito
constituído de partes várias; assim, uma casa, multipla de certo modo, mesmo atualmente, mas cuja
multiplicidade se reduz a uma certa unidade. E neste sentido qualquer sacramento é considerado uno,
enquanto a multiplicidade nele existente se aduna, para significar ou causar uma mesma coisa, pois, o
sacramento, significando causa. Por onde, quando uma ação basta a ter uma significação perfeita, a
unidade do sacramento consiste nessa ação única, como se dá com a confirmação. Quando porém a
significação do sacramento pode estar em uma só ou em múltiplas ações, então o sacramento pode
consumar-se por uma só ou por várias ações; assim, o batismo, por uma só imersão e por três, pois, a
ablução, significada por ele, pode se fazer por uma só imersão ou por muitas. Quando porém a
Significação perfeita não pode ser senão mediante várias ações, então estas são necessárias à perfeição
do sacramento; tal o que se dá com a Eucaristia, pois, a nutrição corporal, que significa a espiritual, não
pode ser senão mediante a comida e a bebida. O mesmo se dá com este sacramento; pois, a cura das
chagas internas não pode ser perfeitamente significa da senão pela aplicação do remédio às diversas
regiões doentes. Por onde, a perfeição deste sacramento implica várias ações.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A unidade de um todo perfeito não fica eliminada pela
diversidade de matéria ou da forma existente nas partes do todo. Assim, a carne e os ossos,
constitutivos de um homem, não são a mesma coisa, nem tem a mesma forma. Semelhantemente, no
sacramento da Eucaristia e neste sacramento, a pluridade da matéria e da forma não lhes elimina a
unidade.

RESPOSTA À SEGUNDA. ─ Embora essas ações sejam várias, absolutamente falando, contudo são unidas
numa ação perfeita, que é a unção de todos os sentidos externos, por onde haurimos doença exterior.

RESPOSTA À TERCEIRA. ─ Na Eucaristia, se depois da consagração do pão morrer o sacerdote, outro
sacerdote pode passar à consagração do vinho, começando onde o primeiro parou, ou então recomeçar
o sacrifício com outra matéria. Mas na extrema unção não pode recomeçar desde o princípio, devendo
sempre continuar, porque uma unção feita numa mesma parte tanto vale como se fosse duas vezes
consagrada a mesma hóstia ─o que de nenhum modo se deve fazer. Nem contudo a pluralidade de
ministros tira a unidade a este sacramento, pois operam só como instrumentos; assim, a mudança dos
martelos não priva da sua unidade a operação fabril.

## Art. 3 — Se este sacramento foi instituído por Cristo.
O terceiro discute-se assim. ─Parece que este sacramento não foi instituído por Cristo.

1. ─ Pois, o Evangelho menciona os sacramentos instituídos por Cristo, como a Eucaristia e o batismo.
Ora, não faz menção nenhuma da extrema unção. Logo, não foi instituída por Cristo.

2. Demais. ─ O Mestre das Sentenças diz expressamente, que foi instituído pelos Apóstolos. Logo, não
foi Cristo mesmo quem o instituiu.

3. Demais. ─ Os sacramentos, que Cristo instituiu ele próprio os ministrou na sua própria pessoa. Ora, a
ninguém ministrou este sacramento. Logo, não foi quem o instituiu.
Mas, em contrário. ─ Os sacramentos da Lei Nova são mais dignos que os da Velha. Ora, todos os
sacramentos da Lei Velha foram instituídos por Deus. Logo, e com maior razão, todos os sacramentos da
Lei Nova foram instituídos pelo próprio Cristo.

2. Demais. ─ Quem institui também pode revogar o estatuído. Ora, a Igreja que nos sucessores dos
Apóstolos tem a mesma autoridade que tiveram eles, não poderia eliminar o sacramento da extrema
unção. Logo, quem o instituiu foi Cristo mesmo e não os Apóstolos.

SOLUÇÃO. ─ Nesta matéria há duas opiniões. Uns dizem que este sacramento e o da confirmação não os
instituiu Cristo, por si mesmo, mas deixou a instituição deles aos Apóstolos. Porque esses dois, por causa
da plenitude da graça por eles conferida, não podiam os Apóstolos instituí-los, antes de terem a
recepção pleníssima do Espírito Santo. Por isso são sacramentos da Lei Nova não prefigurados na Lei
Velha. ─Mas essa razão não é muito congente; porque assim como Cristo, antes da sua paixão,
prometeu aos apóstolos a pleníssima missão do Espírito Santo, assim também podia instituir esses
sacramentos.
Por isso outros dizem, que todos os sacramentos foi Cristo mesmo quem os instituiu; mas uns, mais
difíceis de serem cridos, por si mesmo os instituiu, outros, como a extrema unção e a confirmação,
deixou aos Apóstolos promulgarem-nos. Esta opinião parece tanto mais provável, que os sacramentos
constituem o fundamento da lei; por isso devia instituí-los o próprio Legislador. Além disso, porque
tiram a sua eficácia da instituição, que não vem senão de Deus.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Muitas coisas o Senhor disse e fez, que não estão
contidas no Evangelho. Pois, os Evangelistas cuidaram principalmente de transmitir o consernente ao
modo necessário à salvação e à disposição da Igreja. Por isso, referiram a instituição do batismo, da
penitência da Eucaristia e da ordem, feita por Cristo, de preferência à da estrema unção ou da
confirmação, que nem são de necessidade para a salvação nem concernem à disposição da organização
da Igreja. Contudo, a unção com o óleo é referida no Evangelho, quando diz que os Apóstolos ungiam
com óleo os enfermos.

RESPOSTA À SEGUNDA. ─ O Mestre das Sentenças diz, que a extrema unção foi instituída pelos
Apóstolos, porque pelos ensinamentos deles nos foi promulgada a instituição desse sacramento.

RESPOSTA À TERCEIRA. ─ Cristo não ministrou por si próprio senão os sacramentos que deu o exemplo
de receber. Não podia porém receber os sacramentos da penitência e da extrema unção, porque não
tinha pecado. Por isso não os ministrou por si próprio.

## Art. 4 — Se o óleo de oliveira é a matéria conveniente a este sacramento.
O quarto discute-se assim. ─ Parece que o óleo de oliveira não é a matéria conveniente a este
sacramento.

1. ─ Pois, este sacramento é um remédio imediato para a incorrupção. Ora, a incorruptibilidade é
significada pelo bálsamo, aplicado no crisma. Logo, o crisma é que seria a matéria mais conveniente a
este sacramento.

2. Demais. ─ Este sacramento é um remédio espiritual. Ora, a medicação espiritual é significa da pela
aplicação do vinho, como vemos na parábola do homem maltratado pelos ladrões, do Evangelho. Logo,
também o vinho seria a matéria mais conveniente a este sacramento.

3. Demais. ─ Onde é maior o perigo mais comum deve ser o remédio. Ora, o óleo de oliveira, não se
encontrando em todos os lugares da terra, não é um remédio comum. Logo, como este sacramento é
ministrado aos moribundos, que estão em perigo máximo, parece não ser o óleo de oliveira a matéria
conveniente.
Mas, em contrário, a Escritura determina o óleo como a matéria deste sacramento. Ora, óleo
propriamente não se chama senão o óleo de oliveira. Logo, esta é a matéria deste sacramento.

2. Demais. ─ A cura espiritual é significada pela unção do óleo, como está claro na Escritura: A chaga
entumecida não se lhe aplicou remédio para a sua cura, nem com óleo foi suavizada. Logo, a matéria
conveniente deste sacramento é o óleo.

SOLUÇÃO. ─ A cura espiritual ministrada no fim da vida deve ser perfeita, pois, depois dela não há
nenhuma outra; e branda, para não quebrar, mas favorecer a esperança, maximamente necessária aos
que estão no momento da morte. Ora, o óleo é um lenitivo que penetra até o íntimo, e de natureza
difusiva. Por onde, quanto às duas condições referidas, é a matéria conveniente deste sacramento. E
como óleo principalmente se chama o líquido extraído da oliveira, sendo os outros assim também
chamados só por semelhança com ele, por isso o óleo de oliveira deve ser o tomado como a matéria
deste sacramento.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A incorrupção da glória não é a realidade contida neste
sacramento, nem é necessário que a tal causa corresponda a significação da matéria. Por onde, não é
necessário tomar o bálsamo como a matéria deste sacramento: pois, o bálsamo pelo seu odor significa a
boa fama, de que aliás os que estão a ponto de partir deste mundo não precisam; eles precisam só da
pureza da consciência, significada pelo óleo.

RESPOSTA À SEGUNDA. ─ O vinho cura por ser picante, o óleo porém como lenitivo. Por isso a cura da
penitência é que, de preferência à deste sacramento, se aplica o vinho.

RESPOSTA À TERCEIRA. ─ O óleo de oliveira, embora esta não cresça em todos os países, contudo pode
qualquer o ter facilmente. ─ Além disso este sacramento não é de tanta necessidade que os mortos sem
ele não possam salvar-se.

## Art. 5 — Se é necessário ser o óleo consagrado.
O quinto discute-se assim. ─ Parece não é necessário seja o óleo consagrado.

1. ─ Pois, este sacramento só pela forma das palavras já produz a santificação. Logo, será supérflua outra
santificação, feita pela matéria dele.

2. Demais. ─ Os sacramentos trazem a eficácia e a significação próprias na sua própria matéria. Ora, a
significação do efeito deste sacramento cabe ao óleo pela sua propriedade natural; a eficácia porém lhe
resulta da instituição divina. Logo, não é necessária outra santificação, proveniente da matéria.

3. Demais. ─ O batismo é um sacramento mais perfeito que a extrema unção. Ora, o batismo não
pressupõe a santificação da matéria, como necessária para o sacramento. Logo, nem a extrema unção.
Mas, em contrário, todas as outras unções pressupõem matéria consagrada antes. Logo, sendo este
sacramento uma unção, exige matéria consagrada.

SOLUÇÃO. ─ Certos dizem que o óleo puro é a matéria deste sacramento; e na santificação mesma do
óleo, feita pelo bispo, se consuma o sacramento. ─Mas isto é claramente falso em virtude do que
dissemos sobre a Eucaristia, onde mostramos que só esse sacramento consiste na consagração da
matéria.
Por onde, devemos concluir, que este sacramento consiste na unção mesma, como o batismo na
ablução; e a matéria deste é o óleo santificado. Podemos porém dar três razões por que é necessária a
santificação da matéria neste sacramento e em certos outros. ─ A primeira é que a eficácia de todos os
sacramentos provém de Cristo. Por onde, os sacramentos de que ele próprio usou, desse uso tiram a sua
eficácia; assim, o contacto do seu corpo deu às águas a virtude de regenerar. Mas nem deste
sacramento nem de nenhuma unção corporal usou Cristo. Por isso, em todas as unções é necessária a
santificação da matéria. ─ A segunda causa se funda na plenitude da graça, conferida não só para apagar
a culpa, mas também curar resíduos do pecado e a enfermidade do corpo. ─ A terceira é que o seu
efeito corporal, isto é, a cura do corpo, não é produzida por nenhuma propriedade natural da matéria.
Por onde, essa eficácia há-lhe de ser dada pela santificação.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A primeira santificação é a da matéria em si mesma
considerada; a segunda mais lhe concerne ao uso, enquanto ato que lhe confere o seu efeito. Por onde,
nenhuma delas é inútil, pois, também os instrumentos tiram a sua eficácia do artífice, tanto quando são
fabricados como quando atualmente aplicados.

RESPOSTA À SEGUNDA. ─ Essa eficácia, proveniente da instituição mesma do sacramento, a esta
matéria se lhe aplica pela santificação.

RESPOSTA À TERCEIRA. ─ A resposta é clara pelo que foi dito.

## Art. 6 — Se é necessária a matéria deste sacramento ser consagrada pelo bispo.
O sexto discute-se assim. ─Não é necessário que a matéria deste sacramento seja consagrada pelo
bispo.

1. ─ Pois, é mais digna a consagração da matéria no sacramento da Eucaristia que neste sacramento.
Ora, na Eucaristia o sacerdote pode lhe consagrar a matéria. Logo, também neste sacramento.

2. Demais. ─ Nas obras corporais uma arte mais digna nunca prepara matéria inferior; pois, mais digna é
a arte que usa do que aquela que prepara como diz Aristóteles. Ora, o bispo é superior ao sacerdote.
Logo, não há de preparar a matéria para o sacramento de que o sacerdote é o ministro. Mas, quem
dispensa êste sacramento é o sacerdote, como se dirá. Logo, a consagração da matéria não pertence ao
bispo.
Mas, em contrário, mesmo a matéria para as outras unções é consagrada pelo bispo. Logo, também
deve se dar o mesmo no caso vertente.

SOLUÇÃO. ─ O ministro do sacramento não produz, por virtude própria, o efeito do sacramento, como
agente principal; mas, pela eficácia do sacramento, que dispensa. E essa eficácia vem primeiramente de
Cristo, dimanando dele para os outros, ordenadamente, isto é, ao povo, mediante os ministros,
dispensadores dos sacramentos; e para os ministros inferiores, mediante os superiores, que santificam a
matéria. Por onde, todos os sacramentos que precisam de matéria santificada, a primeira santificação
que esta recebe lhe é dada pelo bispo; e o uso, às vezes, pelo sacerdote, para mostrar que o poder deste
deriva do bispo, segundo aquilo da Escritura: É como o perfume derramando na cabeça, que primeiro
desceu sobre a barba, depois até a orla do vestido.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ O sacramento da Eucaristia consiste na santificação
mesma da matéria; mas não no uso. Por onde, propriamente falando, a matéria do sacramento não é
algo de consagrado. Por isso, não é necessária nenhuma santificação da matéria feita de antemão pelo
bispo; mas é necessária a santificação do altar e coisas semelhantes, e ainda a do próprio sacerdote, que
não pode ser feita senão pelo bispo. E assim, nesse mesmo sacramento também se mostra o poder
sacerdotal derivado do bispo, como diz Dionísio. Por onde, o sacerdote pode fazer aquela consagração
da matéria, que é em si mesma sacramento, e não aquela que, como um sacramental, se ordena ao
sacramento, que consiste no uso dos fiéis. Pois, quanto ao que é verdadeiramente corpo de Cristo, não
há nenhuma ordem superior à dos sacerdotes; mas quanto ao corpo místico de Cristo, a ordem
episcopal é superior à sacerdotal, como adiante diremos.

RESPOSTA À SEGUNDA. ─ A matéria do sacramento não é tal matéria determinada, como a de que faz
alguma coisa quem dela usa, conforme se dá com as artes mecânicas; mas aquela em virtude da qual
alguma causa de faz. E assim participa de certo modo da natureza da causa agente, enquanto
instrumento da operação divina. Por onde e necessariamente, a virtude de tal matéria há de ser
adquirida por uma arte ou poder superior. Porque, na ordem das causas eficientes, quanto mais um
agente for eminente tanto mais prioridade terá; ao passo que na ordem das causas puramente
materiais, a que mais prioridade tiver, tanto mais imperfeita será.

## Art. 7 — Se este sacramento tem uma forma.
O sétimo discute-se assim. ─ Parece que este sacramento não tem nenhuma forma.

1. ─ Pois, como a eficácia dos sacramentos vem da instituição, assim também da forma; e por isso é
necessário que a forma seja determinada por aquele mesmo que instituiu o sacramento. Ora, a forma
deste sacramento não foi ensinada nem por Cristo nem pelos Apóstolos. Logo, este sacramento não tem
nenhuma forma.

2. Demais. ─ O necessário à validade do sacramento todos do mesmo modo o observam. Ora, nada é
mais necessário a um sacramento, que tem forma, do que a forma mesma. Logo, como não há nenhuma
forma comumente observada por todos neste sacramento, pois diversas são as palavras usadas, resulta
que este sacramento não tem nenhuma forma.

3. Demais. ─ No batismo a forma é necessária só para a santificação do batismo, que é a água santificada
pelo verbo de vida para apagar os crimes. Ora, este sacramento tem matéria já santificada antes. Logo,
não precisa de nenhuma forma verbal.
Mas, em contrário, o Mestre das Sentenças diz, que todo sacramento da Lei Nova consiste em
realidades e palavras. Ora, as palavras são a forma do sacramento. Logo, sendo este o sacramento da Lei
Nova, parece que tem uma forma.

2. Demais. ─ É rito da Igreja universal usar de certas palavras na colação deste sacramento.

SOLUÇÃO. ─ Certos disseram que este sacramento não tem nenhuma forma necessária. ─ Mas isto
encontra o efeito do mesmo. Pois, todo sacramento produz efeito pela sua significação. Ora, a
significação da matéria não está presa a um efeito determinado ─ pois, pode ter muitas significações
─senão pela forma das palavras. Por isso, em todos os sacramentos da Lei Nova, que produzem o efeito
que figuram, é necessário haja uma realidade e palavras. Além disso Tiago constitui toda a força deste
sacramento na oração, forma dele, como depois se dirá. Por onde, a referida opinião é temerária e
errônea. Por isso, é melhor seguir a opinião comum, que este sacramento tem, como os outros
sacramentos, uma forma determinada.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A Sagrada Escritura é proposta comumente a todos. Por
isso, a forma do batismo, que pode ser conferido por todos, devia ser expressa na Sagrada Escritura.
Semelhantemente, a da Eucaristia, que exprime a fé que devemos ter, de necessidade à salvação. Mas,
as formas dos outros sacramentos não foram transmitidas pela Escritura; a Igreja as recebeu da tradição
dos Apóstolos, que a receberam do Senhor, como diz o Apóstolo: Eu recebi do Senhor o que também
vos ensinei a vós.

RESPOSTA À SEGUNDA. ─ As palavras que são da essência da forma, a saber, a oração deprecativa, são
pronunciadas por todos; mas as que se acrescentam como complemento, nem todos as levam em
conta.

RESPOSTA À TERCEIRA. ─ A matéria do batismo tem uma significação própria que lhes deu o contato
mesmo com a carne do Salvador; da forma das palavras porém recebe a santificação atualmente
santificante. Semelhantemente, depois da santificação da matéria deste sacramento, em si mesma, é
necessário receba a santificação do uso, pela qual atualmente santifica.

## Art. 8 — Se a forma deste sacramento deve ser proferida mediante uma oração indicativa e não deprecativa.
O oitavo discute-se assim. ─ Parece que a forma deste sacramento deve ser proferida por uma oração
indicativa e não deprecativa.

1. ─ Pois, todos os sacramentos da Lei Nova produzem um determinado efeito. Ora, a certeza do efeito
não se exprime, nas formas dos sacramentos, senão por uma oração indicativa, quando se diz: Isto é o
meu corpo, ou, Eu te batizo, etc. Logo, a forma deste sacramento deve ser uma oração indicativa.

2. Demais. ─ Nas formas dos sacramentos deve estar expressa a intenção do ministro, necessária para a
validade deles. Ora, a intenção de conferir o sacramento não se exprime senão por uma oração
indicativa. Logo, etc.

3. Demais. ─ Em certas Igrejas se pronunciam estas palavras, na colação deste sacramento: Eu vos unjo
os olhos com o óleo santificado em nome do Padre, etc.; e isto está conforme às formas dos outros
sacramentos. Logo, parece que nisto consiste a forma deste sacramento.
Mas, em contrário. ─ A forma de um sacramento deve ser observada por todos. Ora, as palavras
referidas não são as pronunciadas, segundo o costume de todas as Igrejas, senão só as palavras
deprecativas seguintes: Por esta santíssima unção e pela sua puríssima misericórdia o Senhor te perdoe
todos os pecados que cometeste com a vista, etc. Logo, a forma deste sacramento é a oração
deprecativa.

2. Demais. ─ O mesmo se conclui das palavras de Tiago, que atribui a eficácia deste sacramento à
oração: A oração da fé, diz, salvará o enfermo. Logo, como a eficácia do sacramento vem da forma,
parece que a forma deste sacramento é a oração referida.

SOLUÇÃO. ─ A forma deste sacramento é a oração deprecativa, como o demonstram as palavras de
Tiago e o uso da Igreja Romana, que só de palavras deprecativas usa na colação do mesmo. E disso
podemos dar muitas razões. ─ A primeira é que, quem recebe este sacramento está falto de forças
próprias. Por isso precisa ser socorrido pela oração. ─ A segunda, é que é dada aos que se partem desta
vida, já não pertencentes ao foro da Igreja, e só nas mãos de Deus repousam. Por isso, a Deus são
entregues pela oração. ─ A terceira é que este sacramento não produz nenhum efeito que esteja
necessariamente ligado a ação do ministro, mesmo que este fizesse exatamente tudo o requerido pela
essência do mesmo. Assim, o efeito do caráter, no batismo e na confirmação; o da transubstanciação, na
Eucaristia; o da remissão do pecado, na penitência acompanhada da contrição, cuja remissão é da
essência do sacramento da penitência; mas não da essência do da extrema unção. Por isso, neste último
sacramento, a forma não pode estar no modo indicativo, como o pode nos outros.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Este sacramento, bem como os outros, tem, por si
mesmo, um efeito certo; mas pode se lhe opor o obstáculo da dissimulação de quem o recebe mesmo
se este tiver a intenção de o receber ─ de modo que nenhum efeito colherá. Por isso, não há
semelhança entre este sacramento e os outros, que sempre produzem algum efeito.

RESPOSTA À SEGUNDA. ─ O ato mesmo que a forma inclui ─ Por esta santa unção ─ exprime
suficientemente a intenção.

RESPOSTA À TERCEIRA. ─ Essas palavras no modo indicativo, que segundo o costume de certas dioceses
precedem à oração, não são a forma deste sacramento; mas uma certa disposição para a forma,
enquanto a intenção do ministro se determina a esse ato, pelas referidas palavras.

## Art. 9 — Se a referida oração é a forma própria deste sacramento.
O nono discute-se assim. ─ Parece que a referida oração não é a forma própria deste sacramento.

1. ─ Pois, nas formas dos outros sacramentos se faz menção da matéria, como se dá com a confirmação.
Ora, tal não se passa com as referidas palavras. Logo, não são uma boa forma.

2. Demais. ─ Assim como a misericórdia divina é a que produz em nós o efeito deste sacramento, assim
também nos outros sacramentos não se faz menção dessa misericórdia, mas antes, da Trindade e da
paixão. Logo, o mesmo se deveria dar aqui.

3. Demais. ─ Na letra do Mestre se referem dois efeitos deste sacramento. Ora, nas palavras, citadas não
se menciona senão um, a saber, a remissão dos pecados; e nada, da cura do corpo a que Tiago ordena a
oração da fé, quando diz: A oração da fé salvará o enfermo. Logo, a forma referida é imprópria.

SOLUÇÃO. ─ A oração referida é a forma própria deste sacramento. Porque o refere, quando diz: por
esta santa unção; e o que nele obra: a divina misericórdia; e o seu efeito: a remissão dos pecados.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ A matéria deste sacramento pode ser deduzida do ato da
unção; não porém a da confirmação do ato expresso na forma. Logo, não há símile.

RESPOSTA À SEGUNDA. ─ A misericórdia supõe e concerne a miséria. E como este sacramento é
ministrado a quem é miserável, isto é, enfermo por isso, antes aqui que alhures se faz menção da
misericórdia.

RESPOSTA À TERCEIRA. ─ A forma deve exprimir o efeito principal e que sempre o sacramento produz,
se não opuser obstáculos quem o recebe. Ora, efeito tal não é a saúde do corpo, conforme do sobredito
resulta, embora às vezes daí resulte. Em razão do que, Tiago atribui este efeito à oração, que é a forma
deste sacramento.