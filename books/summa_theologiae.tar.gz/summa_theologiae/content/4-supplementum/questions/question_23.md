# Questão 23: Da comunicação com os excomungados.
Em seguida devemos tratar da comunicação com os excomungados.
E nesta questão discutem-se três artigos:

## Art. 1 — Se é lícito comunicar com o excomungado, por necessidades puramente temporais.
O primeiro discute-se assim. — Parece lícito comunicar com o excomungado por necessidades
puramente temporais.

1. — Pois, a excomunhão é um ato do poder das chaves. Ora, o poder das chaves se estende só à ordem
espiritual. Logo, pela excomunhão não fica um proibido de comunicar com outro na ordem corporal.

2. Demais. — O que foi instituído em vista da caridade não pode se lhe opor a ela. Ora, por um preceito
de caridade estamos obrigados a socorrer os nossos inimigos, o que não é possível sem comunicação.
Logo, é lícito comunicar com o excomungado nas suas necessidades corporais.
Mas, em contrário, o Apóstolo: Com esse tal nem comer deveis.

SOLUÇÃO. — Há uma dupla excomunhão. — A menor, que priva só da participação dos sacramentos,
mas não da comunhão dos fiéis. E por isso com um tal excomungado é lícito comunicar, mas não é lícito
conferir-lhe os sacramentos. — Outra é a excomunhão maior; e essa priva o excomungado dos
sacramentos da Igreja e da comunhão dos fiéis. Por onde, com o excomungado por tal excomunhão não
é lícito comunicar. Mas como a Igreja recorre à excomunhão para curar os seus filhos e não para os
perder, por isso excetuam-se dessa regra geral certas coisas, — as relativas à salvação — nas quais é
lícito comunicar com o excomungado. Porque, no tocante a elas, podemos licitamente comunicar com
ele, e mesmo trocar palavras em matéria diversa, de modo que mais facilmente, pela familiaridade,
venha a receber a doutrina da salvação.
Excetuam-se também certas pessoas, às quais incumbe especialmente prover às necessidades do
excomungado a saber: a esposa, o filho, o escravo, o empregado rural e o servo. Mas isto se entende,
dos filhos não emancipados; do contrário, ficariam obrigados a evitar a sociedade do próprio pai. Dos
outros, se entende que é lícito comunicar com o excomungado, se antes da excomunhão lhe estavam
sujeitos, mas não se depois. — Certos porém, entendem de maneira inversa, a, saber, que os superiores
podem licitamente comunicar com os inferiores, mas outros pensam em sentido contrário. Mas pelo
menos devem comunicar com eles em matéria a que estão obrigados; pois, assim como os inferiores
estão obrigados ao serviço dos superiores, assim estes a providenciar sobre as necessidades daqueles.
Há ainda outros casos excetuados: Assim, quando se ignora a excomunhão; e quando se é estrangeiro
ou viajante na terra dos excomungados, podendo-se então licitamente comprar, deles ou receber-lhes
esmola. E do mesmo modo se vimos o excomungado em necessidade; porque então, por um preceito de
caridade estamos obrigados a socorrê-lo. Coisas todas expressas neste versículo:
Utilidade, lei, humildade, causa ignorada, necessidade. A utilidade concerne às palavras de salvação: a
lei, ao matrimônio; a humildade, à sujeição. O resto é claro.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — As coisas corporais se ordenam às espirituais. Por onde,
o poder concernente à ordem espiritual, pode abranger também a ordem temporal; assim a arte que
visa o fim ordena o que concerne os meios.

RESPOSTA À SEGUNDA. — No caso em que por preceito de caridade estamos obrigados a comunicar
com o excomungado, não ficamos proibidos de o fazer, como do sobredito se colhe.

## Art. 2 — Se quem comunica com o excomungado fica excomungado.
O segundo discute-se assim. — Parece que quem comunica com o excomungado não fica
excomungado.
1 — Pois, mais separado da Igreja está o gentio que o excomungado. Ora, quem comunica com o gentio
ou com o judeu não fica excomungado. Logo, nem aquele que comunica com um excomungado cristão.

2. Demais. — Quem comunica com um excomungado fica excomungado; pela mesma razão também o
ficará quem comunica com quem com ele comunica, e assim ao Infinito. O que é absurdo. Logo, não fica
excomungado quem comunica com ele.
Mas, em contrário, o excomungado está posto fora da comunhão. Logo, quem com ele comunica se
afasta da comunhão da Igreja. E assim, considerar-se-á excomungado.

SOLUÇÃO. — A excomunhão pode ser proferida contra alguém de dois modos. — Ou de modo que fique
excomungado juntamente com quem com ele comunicar. E então não há dúvida que quem comunicar
com o excomungado incorrerá na pena de excomunhão maior. — Ou o excomungado o é pura e
simplesmente. E então quem lhe participar do crime, dando-lhe conselho, auxílio ou favor, incorrerá
também na pena de excomunhão maior. E quem comunicar com ele, em outras causas, falando-lhe,
saudando-o ou sentando-se à mesma mesa incorrerá na penalidade de excomunhão menor.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — A Igreja não pretende corrigir os infiéis como o faz aos
seus fiéis, cujo governo lhe incumbe. Por isso não separa da comunhão dos infiéis, como o faz em
relação à comunhão dos fiéis, aqueles que excomunga, s0bre os quais exerce o seu poder.

RESPOSTA À SEGUNDA. — É lícito comunicar com o excomungado por excomunhão menor. Assim, a
excomunhão não atinge terceira pessoa.

## Art. 3 — Se comunicar com o excomungado, nos casos não permitidos, é pecado mortal.
O terceiro discute-se assim. — Parece que comunicar com o excomungado, nos casos não permitidos,
é sempre pecado mortal.

1. — Pois, uma decretal determina, que por medo da morte não deve ninguém comunicar com o
excomungado, porque devemos antes sofrer a morte, que pecar mortalmente. Ora, esta razão seria
nula, se não fosse sempre pecado mortal comunicar com o excomungado. Logo, etc.

2. Demais. — Proceder contra o preceito da Igreja é pecado mortal. Ora, a Igreja ordena que ninguém
comunique com um excomungado. Logo, comunicar com um excomungado é pecado mortal.

3. Demais. — Ninguém é privado de receber a Eucaristia por motivo de pecado venial. Ora, quem
comunica com o excomungado em casos não permitidos fica privado de receber a Eucaristia, porque
incorre na pena de excomunhão menor. Logo, quem comunica com o excomungado em casos não
permitidos peca mortalmente.

4. Demais. — Ninguém deve ser excomungado por excomunhão maior senão por pecado mortal. Ora,
segundo o direito, pode um ser excomungado com excomunhão maior por ter comunicado com o
excomungado. Logo, comunicar com o excomungado é pecado mortal.
Mas, em contrário. — Do pecado mortal ninguém pode absolver, salvo quem tiver jurisdição. Ora,
qualquer sacerdote pode absolver da comunicação com o excomungado. Logo, não é pecado mortal.

2. Demais. — A intensidade da pena é proporcional ao pecado. Ora, por comunicação com o
excomungado, o costume comum não comina a pena devida ao pecado mortal, mas antes, a devida ao
pecado venial. Logo, não é pecado mortal.

SOLUÇÃO. — Certos dizem, que sempre que comunicamos com o excomungado por palavras ou por
qualquer modo, por que não é lícito com ele comunicar, pecamos mortalmente, exceto nos casos
excetuados pelo direito. — Mas, como é demasiado rigoroso que pequemos mortalmente por uma
única ligeira palavra que trocamos com o excomungado; e que os que excomungam enredariam a
muitos nos laços da condenação, o que contra os primeiros redundaria, por isso, outros acham mais
provável que nem sempre pecaremos mortalmente, mas só se participarmos do crime do excomungado,
quer in divinis, quer no desprezo da Igreja.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. — Essa decretal se refere à comunicação in divinis. — Ou
devemos responder que o pecado mortal e o venial tem isto de comum, que nem aquele nem este
podem ser ações boas. Por onde, como devemos antes preferir a morte, que pecar mortalmente, assim
também devemos preferi-la ao pecado venial, do modo pelo qual estamos obrigados a nos abster desse
pecado.

RESPOSTA À SEGUNDA. — O preceito da Igreja visa diretamente os bens espirituais e, por
consequência, todo ato legítimo. Por isso, quem comunica com o excomungado in divinis, vai contra o
preceito; quem com eles comunicar em outras matérias procede contra o preceito e peca venialmente.

RESPOSTA À TERCEIRA. — Pode alguém, mesmo sem nenhuma culpa, ser às vezes privado da Eucaristia,
como se dá com os suspensos ou os interditos; porque essas penas são aplicadas às vezes a um, por
culpa de outro, que fica assim por elas punido.

RESPOSTA À QUARTA. — Embora comunicar com um excomungado seja pecado venial, contudo,
comunicar com ele pertinazmente é pecado mortal. Por isso pode um ser excomungado, segundo o
direito.