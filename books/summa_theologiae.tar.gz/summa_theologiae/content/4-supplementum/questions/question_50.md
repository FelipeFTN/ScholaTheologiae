# Questão 50: Dos impedimentos do matrimônio em geral.
Em seguida devemos tratar dos impedimentos do matrimônio em geral; segundo, em especial.

## Art. 1 — Se os impedimentos ao matrimônio foram bem determinados.
O primeiro discute-se assim. ─ Parece que os impedimentos ao matrimônio não foram bem
determinados.

1. Pois, o matrimônio entra na divisão geral dos sacramentos. Ora, aos outros não se lhes determinam
impedimentos. Logo, também não se devem determinar do matrimônio.

2. Demais. ─ Quanto mais imperfeita é uma coisa, menos numerosos devem ser os obstáculos
oferecidos à sua realização. Ora, o matrimônio é o menos perfeito dos sacramentos. Logo, não se lhe
devem opor nenhuns impedimentos, ou muito poucos.

3. Demais. ─ Onde há uma doença há sempre um remédio a lhe ser aplicado. Ora, à concupiscência para
a qual se permitiu o casamento como remédio, todos estão sujeitos. Logo, não deve haver nenhum
impedimento, que torne uma pessoa completamente incapaz de o contrair.

4. Demais. ─ Ilegítimo se chama ao que é contra a lei. Ora, esses impedimentos, que põem obstáculos ao
matrimônio, não são contra a lei natural, pois não surgem igualmente em cada época da história do
gênero humano. Assim, o impedimento resultante do grau de consangüinidade aparece com um motivo
de proibição mais numas épocas que noutras. Entretanto, a lei humana, segundo parece, não pode
estabelecer impedimentos ao casamento, porque o matrimônio não é de instituição humana, mas
divina, como todos os outros sacramentos. Logo, não se devem estabelecer ao casamento
impedimentos especiais, que tornem certas pessoas ineptas para o contrair.

5. Demais. ─ O ilegítimo e o legítimo diferem entre si como o que é contra a lei do que não o é. Onde
não há lugar para um meio termo, pois são opostos por afirmação e negação. Logo, não pode haver
nenhuns impedimentos ao matrimônio que constituíssem em certas pessoas como médias entre as
capazes de se casar e as incapazes.

6. Demais. ─ A união do homem e da mulher só é permitida no casamento. Ora, toda união ilícita deve
ser dissolvida. Logo, um impedimento à realização do casamento anulará por isso mesmo o já realizado.
E assim não se devem opor obstáculos ao casamento, que o impeçam de ser contraído, sem diminuírem
o matrimônio já realizado.

7. Demais. ─ Nenhum impedimento pode privar uma realidade de um elemento que lhe entra na
definição. Ora, a indissolubilidade entra na definição do matrimônio. Logo, não podem existir nenhuns
impedimentos dirimentes do matrimônio já contraído.
Mas, em contrário. ─ Os impedimentos ao matrimônio devem ser em número infinito, porque o
casamento é um bem. Ora, de modos infinitos pode um bem ser defeituoso, como diz Dionísio. Logo,
infinitos são os impedimentos do casamento.

2. Demais. ─ Os impedimentos do matrimônio se fundam nas condições particulares das pessoas. Ora,
essas condições são em número infinito, Logo, também os impedimentos ao casamento.

SOLUÇÃO. ─ No matrimônio devemos distinguir, como nos demais sacramentos, o que lhe é essencial
do que lhe pertence apenas à solenidade. E como, pondo-se de parte o que lhe pertence à solenidade,
do mesmo modo que nos outros sacramentos, ainda o matrimônio continua sendo verdadeiro
sacramento, por isso os impedimentos contrários à sua solenidade, não fazem com que deixe de ser
verdadeiro matrimônio. E esses impedimentos dizemos que o impedem de ser contraído, mas não
dirimem o casamento já contraído. Tal o que resulta da proibição da Igreja ou do tempo feriado. Donde
os versos:
O proibido pela Igreja e o tempo feriado impedem a celebração, sem anular o celebrado.
Ao contrario, os impedimentos contrários ao que é da essência do matrimônio, fazem com que o
casamento contraído não seja verdadeiro matrimônio. Por isso se diz que esses impedimentos não só
impedem o matrimônio de ser contraído, mas ainda dirimem o já celebrado. O que está incluso nestes
versos:
o erro, a condição, o voto, o parentesco, o crime,
A disparidade de culto, a violência, a ordem,
o lígamem, a honestidade,
Se tens afinidade, se fores impotente,
Tudo isto junto impede, o casamento e anula o já contraído.
E o número destes impedimentos pode justificar-se assim. O matrimônio pode ser impedido por parte
do contrato mesmo dele ou por parte dos contraentes. Do primeiro modo, como o contrato do
matrimônio se faz pelo consentimento voluntário, que fica eliminado pela ignorância e pela violência,
dois serão os impedimentos: a violência, isto é, a coação; e o erro, causado pela ignorância. Por isso o
Mestre enumerou esses dois impedimentos ao tratar da causa do matrimônio. Agora passa a tratar dos
resultantes das pessoas dos contraentes. Esses assim se classificam. Pode alguém estar impedido de
contrair matrimônio, ou absolutamente falando, ou com a uma certa pessoa.
Se em sentido absoluto, só não o poderão contrair com mulher nenhuma por incapacidade de realizar o
ato conjugal. O que de dois modos pode ser: ─ Primeiro, porque não o pode de fato; e isso
absolutamente, e então é o impedimento chamada de impotência; ou não pode livremente e esse é o
impedimento chamado de condição servil. ─ Segundo, pelo não poder licitamente. E isto por estar
obrigado à continência. O que de dois modos pode dar-se. Ora, em virtude de uma função assumida, e
tal é o impedimento da ordem. Ou por ter emitido um voto, e será o impedimento do voto.
Quantos aos impedimentos, não absolutos, mas relativos a uma determinada pessoa são os seguintes. ─
O resultante de uma obrigação já assumida para com outra pessoa; assim, quem já casou com uma não
pode casar com outra; e esse é o impedimento de ligamen, isto é, do matrimônio. ─ Ou resulta da
inadaptação de situações entre duas pessoas. E isto por três razões. ─ Primeiro, por causa da grande
distância de situações; e tal é a disparidade de culto. ─ Segundo, pela mínima proximidade donde três
impedimentos: o parentesco, ou a proximidade entre duas pessoas em si mesmas consideradas; a
afinidade, ou a proximidade entre duas pessoas em razão de uma terceira unida pelo matrimônio; e a
justificação da honestidade pública, quando há proximidade entre duas pessoas em razão ele uma
terceira ligada por esponsais. ─ Terceiro, pela conjunção ilegítima precedente, sendo esse o
impedimento do crime de adultério anteriormente com ela cometido.

DONDE A RESPOSTA À PRIMEIRA OBJEÇÃO. ─ Também pode haver impedimentos à celebração dos
outros sacramentos, se for emitido o que lhes pertence à essência ou à solenidade, como dissemos.
Contudo determinam-se impedimentos mais para o matrimônio, que para os outros sacramentos, por
três razões. ─ Primeiro, porque o matrimônio supõe duas pessoas; e assim pode ficar impedido por mais
modos, que os outros sacramentos, que só se administram a uma pessoa em particular. ─ Segundo,
porque o matrimônio tem em nós a sua causa; e certos dos outros a tem em Deus. Por isso, à
penitência, que de certo modo também em nós tem a sua causa, o Mestre assinou certos
impedimentos, como a hipocrisia, a zombaria e outros tais. ─ Terceiro, porque os outros sacramentos
são objeto de preceito, ou de conselho quando se trata de bens mais perfeitos. Ao passo que o
matrimônio é matéria de indulgência; como sendo um bem menos perfeito. Por isso, a fim de se lhe dar
ocasião de melhor se aperfeiçoar, mais impedimentos se determinaram ao matrimônio que aos outros
sacramentos.

RESPOSTA À SEGUNDA. ─ Bens mais perfeitos podem ficar impedidos de mais modos, por exigirem mais
condições. Mas, um bem imperfeito, que também exige várias condições também terá o obstáculo de
vários impedimentos. ─ Tal o caso do matrimônio.

RESPOSTA À TERCEIRA. ─ A objeção colheria, supondo que não houvesse outros remédios com que se
pudesse com maior eficácia obviar à concupiscência. ─ O que é falso.

RESPOSTA À QUARTA. ─ Consideram-se inábeis para contrair matrimônio os que contrariam a lei
reguladora dele. Ora, enquanto função da natureza, o matrimônio é regulado pela lei natural; enquanto
sacramento, pelo direito divino; e enquanto função social, pela lei civil. Por onde, qualquer dessas leis
pode tornar uma pessoa inábil para o contrair. Nem há limite com os outros sacramentos, que são
apenas sacramentos. Ora, a lei natural recebe determinações diversas segundo as diversas situações da
humanidade. E o direito positivo também varia segundo as diversas condições dos homens nos diversos
tempos. Por isso, conforme a diversidade dos tempos, são as pessoas que o Mestre considera ineptos
para contrair matrimônio.

RESPOSTA À QUINTA. - Uma lei pode proibir em geral, ou só em relação a certos casos. Por onde, entre
estar totalmente de acordo com a lei e totalmente contra ela ─ que são opostos por contrariedade, e
não por afirmação e negação ─ há um meio termo consistente em estar de certo modo de acordo com a
lei e, de certo outro, contra. E por isso certas pessoas se consideram numa situação média entre as
absolutamente capazes e as absolutamente incapazes de contratar matrimônio.

RESPOSTA À SEXTA. ─ Os impedimentos não dirimentes do matrimônio já contraído, são um obstáculo
ao nubente, não de contrair o matrimônio, mas de o poder fazer licitamente. Contudo, uma vez
contraído, é válido, embora peque o contraente. Assim como quem consagrasse, depois de ter comido,
pecaria por agir contra uma determinação da Igreja; contudo celebraria realmente o sacramento,
porque o jejum do consacrante não é necessário para a validade da sua consagração.

RESPOSTA À SÉTIMA. ─ Não se diz que os referidos impedimentos dirimem o matrimônio contraído,
como se rompessem um verdadeiro matrimônio feito de acordo com a lei; mas que dirimem como
contrair de fato e não de direito. Por onde, o impedimento sobreveniente ao matrimônio já realizado,
não pode rompê-lo.

RESPOSTA À OITAVA. ─ Os obstáculos capazes de impedir acidentalmente um bem são infinitos, como o
são todas as causas acidentais. Ao contrário, todas as causas capazes de impedir diretamente um bem,
são, como as causas constituintes, determinadas. Porque as causas eficientes da destruição e da
produção de um ser são opostas,ou as mesmas, mas agindo em sentido contrário.

RESPOSTA À NONA. ─ As condições das pessoas particulares, cada uma de per si, são infinitas; mas, em
geral, podem ser reduzidas a um número certo. Assim o demonstraram a medicina e todas as artes
operativas, que consideram as circunstâncias particulares, das quais depende cada ato.