## Mandamentos da lei de Deus

Os mandamentos da lei de Deus são dez: os três primeiros pertencem à honra de Deus e os outros sete ao proveito do próximo.

<ul>
  <li>1º - Amar a Deus sobre todas as coisas.</li>
  <li>2º - Não tomar seu santo nome em vão.</li>
  <li>3º - Guardar os domingos e festas.</li>
  <li>4º - Honrar pai e mãe.</li>
  <li>5º - Não matar.</li>
  <li>6º - Não pecar contra a castidade.</li>
  <li>7º - Não furtar.</li>
  <li>8º - Não levantar falso testemunho.</li>
  <li>9º - Não desejar a mulher do próximo.</li>
  <li>10º - Não cobiçar as coisas alheias.</li>
</ul>

<aside>Estes dez mandamentos se encerram em dois:</aside>

Amar a Deus sobre todas as coisas e ao próximo como a nós mesmos.