# Apêndice

<aside>Orações e fórmulas atualizadas</aside>