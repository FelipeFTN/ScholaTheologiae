## Mandamentos da Igreja

<aside>Os mandamentos da Igreja são cinco:</aside>

<ul>
  <li>1º - Ouvir Missa inteira nos domingos e festas de guarda.</li>
  <li>2º - Confessar-se ao menos uma vez cada ano.</li>
  <li>3º - Comungar ao menos pela Páscoa da Ressurreição.</li>
  <li>4º - Jejuar e abster-se de carne, quando manda a santa madre Igreja.</li>
  <li>5º - Pagar dízimos, segundo o costume.</li>
</ul>