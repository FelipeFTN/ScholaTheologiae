## Sacramentos

<aside>Os sacramentos instituídos por Jesus Cristo são sete:</aside>

<ul>
  <li>1º - Batismo.</li>
  <li>2º - Confirmação.</li>
  <li>3º - Eucaristia.</li>
  <li>4º - Penitência ou Confissão.</li>
  <li>5º - Extrema Unção.</li>
  <li>6º - Ordem.</li>
  <li>7º - Matrimônio.</li>
</ul>