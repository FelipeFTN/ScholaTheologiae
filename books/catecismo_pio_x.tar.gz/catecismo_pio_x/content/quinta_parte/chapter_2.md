## II - <em>Dos dons do Espírito Santo</em>

##### 913 - Quantos e quais são os dons do Espírito Santo?

Os dons do Espírito Santo são sete:

<ul>
  <li>1º - Sabedoria;</li>
  <li>2º - Entendimento;</li>
  <li>3º - Conselho;</li>
  <li>4º - Fortaleza:</li>
  <li>5º - Ciência;</li>
  <li>6º - Piedade;</li>
  <li>7º - Temor de Deus.</li>
</ul>

##### 914 - Para que servem os dons do Espírito Santo?

Os dons do Espírito Santo servem para nos confirmar na Fé, na Esperança e na Caridade, e para nos tornar solícitospara osatosdas virtudesnecessáriaspara conseguir a perfeição da vida cristã.

##### 915 - Que é a Sabedoria?

A Sabedoria é um dom pelo qual nós, elevando o espírito acima das coisas terrenas e frágeis, contemplamos as eternas, isto é, a Verdade, que é Deus, no qual pomos nossa complacência, amando-O como nosso Sumo bem.

##### 916 - Que é o Entendimento?

O Entendimento é um dom pelo qual nos é facilitada, quanto é possível a um homem mortal, a inteligência das verdades da Fé e dos divinos mistérios, os quais não podemos conhecer com as luzes naturais da nossa razão.

##### 917 - Que é o Conselho?

O Conselho é um dom pelo qual, nas dúvidas e incertezas da vida humana, conhecemos o que mais convém à glória de Deus, à nossa salvação e à do próximo.

##### 918 - Que é a Fortaleza?

A Fortaleza é um dom que nos incute energia e coragem para observar fielmente a santa Lei de Deus e da Igreja, vencendo todos os obstáculos, e os assaltos dos nossos inimigos.

##### 919 - Que é a Ciência?

A Ciência é um dom pelo qual julgamos retamente das coisas criadas, e conhecemos o modo de bem usar delas e de as dirigir ao último fim, que é Deus.

##### 920 - Que é a Piedade?

Á Piedade é um dom pelo qual veneramos e amamos a Deus e aos Santos, e conservamos ânimo bondoso e benévolo para com o próximo, por amor de Deus.

##### 921 - Que é o Temor de Deus?

O Temor de Deus é um dom que nos faz reverenciar a Deus, e ter receio de ofender a sua Divina Majestade, e que nos afasta do mal, incitando-nos ao bem.