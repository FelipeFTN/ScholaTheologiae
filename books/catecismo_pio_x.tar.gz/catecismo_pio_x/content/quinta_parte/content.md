# Quinta Parte

<aside>Das virtudes principais e de outras coisas que o cristão deve saber</aside>