## IV - <em>Das obras de misericórdia</em>

##### 937 - Quais são as boas obras de que se nos pedirá conta particular no dia do Juízo?

As boas obras de que se tios pedirá conta particular no dia do Juízo são as obras de misericórdia.

##### 938 - Que se entende por obra de misericórdia?

Obra de misericórdia é aquela com que se socorre o nosso próximo nas suas necessidades corporais ou espirituais.

##### 939 - Quantas são as obras de misericórdia?

As obras de misericórdia são catorze: sete corporais e sete espirituais, conforme são corporais ou espirituais as necessidades que se socorrem,

##### 940 - Quais são as obras de misericórdia corporais?

As obras de misericórdia corporais são:

<ul>
  <li>1ª - Dar de comer a quem tem fome;</li>
  <li>2ª - Dar de beber a quem tem sede;</li>
  <li>3ª - Vestir os nus;</li>
  <li>4ª - Dar pousada aos peregrinos;</li>
  <li>5ª - Assistir aos enfermos;</li>
  <li>6ª - Visitar os presos;</li>
  <li>7ª - Enterrar os mortos.</li>
</ul>

##### 941 - Quais são as obras de misericórdia espirituais?

As obras de misericórdia espirituais são:

<ul>
  <li>1ª - Dar bom conselho;</li>
  <li>2º - Ensinar os ignorantes;</li>
  <li>3ª - Corrigir os que erram;</li>
  <li>4ª - Consolar os aflitos;</li>
  <li>5ª - Perdoar as injúrias;</li>
  <li>6ª - Sofrer com paciência as fraquezas do nosso próximo;</li>
  <li>7ª - Rogar a Deus por vivos e defuntos.</li>
</ul>