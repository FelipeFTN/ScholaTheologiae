## III - <em>Das Bem-aventuranças evangélicas</em>

##### 922 - Quantas e quais são as Bem-aventuranças evangélicas?

As Bem-aventuranças evangélicas são oito:

<ul>
  <li>
    1º - a Bem-aventurados os pobres de espírito, porque deles é o reino do Céu;
  </li>
  <li>2º - a Bem-aventurados os mansos, porque eles possuirão a terra;</li>
  <li>3º - a Bem-aventurados os que choram, porque serão consolados;</li>
  <li>
    4º - a Bem-aventurados os que têm fome e sede de justiça, porque serão
    saciados;
  </li>
  <li>
    5º - a Bem-aventurados os que usam de misericórdia, porque alcançarão
    misericórdia;
  </li>
  <li>6ª - a Bem-aventurados os puros de coração, porque verão a Deus;</li>
  <li>
    7ª - a Bem-aventurados os pacíficos, porque serão chamados filhos de Deus;
  </li>
  <li>
    8ª - a Bem-aventurados os que sofrem perseguição por amor da justiça, porque
    deles é o reino do Céu.
  </li>
</ul>

##### 923 - Por que Jesus Cristo nos propôs as Bem-aventuranças?

Jesus Cristo propôs-nos as Bem-aventuranças para os fazer detestar as máximas do mundo, e para nos convidar a amar e praticar as máximas do seu Evangelho.

##### 924 - Quem são aqueles que o mundo chama bem-aventurados?

O inundo chama bem-aventurados aqueles que desfrutam abundância de riquezas e de honras, que vi vem ein delícias e que não têm nada que os faça sofrer.

##### 925 - Quem são os pobres de espírito, que Jesus Cristo chama bem-aventurados?

Os pobres de espírito, segundo o Evangelho, são aqueles que têm o coração desapegado das riquezas; fazem bom uso delas, se as possuem; não as procuram com solicitude, se não as têm; e sofrem com resignação a perda delas se lhes são tiradas.

##### 926 - Quem são os mansos?

Os mansos são aqueles que tratam o próximo com brandura, e lhe sofrem com paciência os defeitos e as ofensas que dele recebem, sem alteração, ressentimentos ou vingança.

##### 927 - Quem são os que choram, e todavia são chamados bem-aventurados?

Os que choram, e todavia são chamados bem-aventurados, são aqueles que sofrem com resignação as tribulações, e que se afligem pelos pecados cometidos, pelos males e pelos escândalos que se vêem no mundo, pela ausência do céu, e pelo perigo de o perder.

##### 928 - Quem são os que têm fome e sede de justiça?

Os que têm fome e sede de justiça são aqueles, que desejam ardentemente crescer cada vez mais na graça de Deus e na prática das obras boas e virtuosas.

##### 929 - Quem são os que usam de misericórdia?

Os que usam de misericórdia são aqueles que amam, em Deus e por amor de Deus, o seu próximo, se compadecem das suasmisérias, assim corporais como espirituais, e procuram socorrê-lo conforme as suas forças e o seu estado.

##### 930 - Quem são os puros de coração?

Os puros de coração são aqueles que não têm nenhum afeto ao pecado, sempre se afastam dele, e evitam sobretudo toda a espécie de impureza.

##### 931 - Quem são os pacíficos?

Os pacíficos são aqueles que vivem ein paz com o próximo e consigo mesmos, e procuram estabelecer a paz entre aqueles que estão em discórdia.

##### 932 - Quem são os que sofrem perseguição por amor da justiça?

Os que sofrem perseguição por amor da justiça são aqueles que suportam com paciência os escárnios, as censuras, as perseguições por causa da Fé e da Lei de Jesus Cristo.

##### 933 - Que significam os diversos prêmios prometidos por Jesus Cristo nas Bem- aventuranças?

Os diversos prêmios prometidos por Jesus Cristo nas Bem-aventuranças significam todos, sob diversos nomes, a glória eterna do Céu.

##### 934 - Alcançam-nos as Bem-aventuranças só a glória eterna do Paraíso?

As Bem-aventuranças não nos alcançam só a glória eterna do Paraíso; são também meios de tornar nossa vida feliz, tanto quanto é possivel, neste mundo.

##### 935 - Recebem já alguma recompensa nesta vida os que seguem as Bem-aventuranças?

Sim, certamente, os que seguem as Bem-aventuranças recebem já alguma recompensa nesta vida, porque já gozam de uma paz e de um contentamento íntimos que são princípio, embora imperfeito, da felicidade eterna.

##### 936 - Poderão dizer-se felizes os que seguem as máximas do mundo?

Não. Osque seguem asmáximasdo mundo não são felizes, porque não têm a verdadeira paz da alma e estão em risco de se condenar.