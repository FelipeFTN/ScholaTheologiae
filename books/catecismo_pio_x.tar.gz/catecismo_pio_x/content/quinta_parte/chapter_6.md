## VI - <em>Dos pecados ou vícios capitais e de outros pecados mais graves</em>

##### 956 - Que é o vício?

O vício é uma disposição má da alma que leva-a a fugir do bem e a fazer o mal, causada pela freqüente repetição dos atos maus.

##### 957 - Que diferença há entre pecado e vício?

Entre pecado e vício há esta diferença: que o pecado é um ato que passa, enquanto o vício é o mau hábito contraído de cair em algum pecado.

##### 958 - Quais são os vícios que se chamam capitais?

Os vícios que se chamam capitais são sete:

<ul>
  <li>1º - soberba;</li>
  <li>2º - avareza;</li>
  <li>3º - luxúria;</li>
  <li>4º - ira;</li>
  <li>5º - gula;</li>
  <li>6º - inveja;</li>
  <li>7º - preguiça.</li>
</ul>

##### 959 - Como se vencem os vícios ou pecados capitais?

Os vícios ou pecados capitais vencem-se com a prática das virtudes opostas. Assim, a soberba vence-se com a humildade; a avareza, com a liberalidade; a luxúria, com a castidade; a ira, com a paciência; a gula, com a temperança; a inveja, com a caridade; a preguiça, com a diligência e fervor no serviço de Deus.

##### 960 - Por que se chamam capitais estes vícios?

Chamam-se capitais estes vícios, porque são a fonte e a causa de muitos outros vícios e pecados.

##### 961 - Quantos são os pecados contra o Espírito Santo?

Os pecados contra o Espírito Santo são seis:

<ul>
  <li>1º - desesperar da salvação;</li>
  <li>2º - Presunção de se salvar sem merecimentos;</li>
  <li>3º - combater a verdade conhecida;</li>
  <li>4º - ter inveja das graças que Deus dá a outrem; </li>
  <li>5º - obstinar-se no pecado;</li>
  <li>6º - morrer na impenitência final.</li>
</ul>

##### 962 - Por que se chamam estes pecados particularmente pecados contra o Espírito Santo?

Chamam-se estes pecados particularmente pecados contra o Espírito Santo, porque se cometem por pura malícia, o que é contrário à bondade que se atribui ao Espírito Santo.

##### 963 - Quais são os pecados que bradam ao Céu e pedem vingança a Deus?

Os pecados que bradam ao Céu e pedem vingança a Deus são quatro:

<ul>
  <li>1º - homicídio voluntário;</li>
  <li>2º - pecado impuro contra a natureza;</li>
  <li>3º - opressão dos pobres, principalmente órfãos e viúvas;</li>
  <li>4º - não pagar o salário a quem trabalha.</li>
</ul>

##### 964 - Por que se diz que estes pecados pedem vingança a Deus?

Diz-se que estes pecados pedem vingança a Deus, porque o diz o Espírito Santo, e porque a sua malícia é tão grave e manifesta, que provoca o mesmo Deus a puni-los com os mais severos castigos.