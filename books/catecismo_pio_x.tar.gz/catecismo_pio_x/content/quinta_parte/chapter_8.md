## VIII - <em>Dos exercícios piedosos que se aconselham ao cristão para cada dia</em>

##### 969 - Que deve fazer um bom cristão, pela manhã, apenas acorda?

Um bom cristão, pela manhã, apenas acorda, deve fazer o sinal da Cruz, e oferecer o coração a Deus, dizendo estas ou outras palavras semelhantes: Meu Deus, eu vos dou o meu coração e a minha alma.

##### 970 - Em que deveríamos pensar ao levantar da cama e enquanto nos vestimos?

Ao levantar da cama e enquanto nos vestimos, deveríamos pensar que Deus está presente, que aquele dia pode ser o último da nossa vida; e entretanto levantar-nose vestir-nos com toda a modéstia possível.

##### 971 - Depois de se levantar e de se vestir, que deve fazer um bom cristão?

Um bom cristão, apenas se tenha levantado vestido, convém pôr-se na presença de Deuse ajoelhar, se pode, diante de alguma devota imagem, dizendo com devoção: "Eu Vos adoro, meu Deus, e Vos amo de todo o coração; dou-Vos graças por me terdes criado, feito cristão e conservado nesta noite; ofereço-Vos todas as minhas ações, e peço-Vos que neste dia me preserveis do pecado, e me livreis de todo o mal. Assim seja". Reza depois o Padre-Nosso, a Ave-Maria, o Credo, e os atos de Fé, de Esperança e de Caridade, acompanhando-os com um vivo afeto do coração.

##### 972 - Que práticas de piedade deveria fazer todos os dias o cristão?

O cristão, podendo, deveria todos os dias:

<ul>
  <li>1º - assistir com devoção à santa Missa;</li>
  <li>2º - fazer uma visita, por breve que fosse, ao Santíssimo Sacramento;</li>
  <li>3º - rezar o terço do santo Rosário.</li>
</ul>

##### 973 - Que se deve fazer antes do trabalho?

Antes do trabalho, convém oferecê-lo a Deus, dizendo do coração: "Senhor, eu Vos ofereço este trabalho, dai-me a vossa bênção".

##### 974 - Para que fim se deve trabalhar?

Deve-se trabalhar para glória de Deus e para fazer a sua vontade.

##### 975 - Que convém fazer antes da refeição?

Antesda refeição convém fazer o sinal da Cruz, estando de pé, e depoisdizer com devoção: "Senhor, abençoai-nos a nós e ao alimento que vamos tomar, para nos conservarmos no vosso santo serviço".

##### 976 - Depois da refeição, que convém fazer?

Depois da refeição, convém fazer o sinal da Cruz, e dizer: "Senhor, eu Vos dou graças pelo alimento que me destes; fazei-me digno de participar da mesa celeste".

##### 977 - Quando nos vemos atormentados por alguma tentação, que devemos fazer?

Quando nos vemosatormentadospor alguma tentação, devemos invocar com fé o Santíssimo Nome de Jesus ou de Maria, ou recitar fervorosamente alguma oração jaculatória, como, por exemplo: "Dai-me a graça, Senhor, que eu nunca Vos ofenda"; ou então fazer o sinal da Cruz, evitando porém que asoutraspessoas, pelos sinaisexternos, suspeitem da tentação.

##### 978 - Quando uma pessoa reconhece ou duvida que cometeu algum pecado, que deve

fazer?

Quando uma pessoa reconhece, ou duvida que cometeu algum pecado, convém fazer imediatamente um ato de contrição, e procurar confessar-se quanto antes.

##### 979 - Quando fora da Igreja se ouve o sinal de elevação da hóstia na Missa solene, ou da bênção do Santíssimo Sacramento, que se deve fazer?

É bom fazer, ao menos com o coração, um ato de adoração, dizendo, por exemplo: "Graças e louvores se dêem a todo o momento ao Santíssimo e diviníssimo Sacramento".

##### 980 - Que se deve fazer quando tocam às Ave-Marias, pela manhã, ao meio-dia e à noite?

Ao toque das Ave-Marias, o bom cristão recita o Anjo do Senhor com três Ave- Marias.

##### 981 - A noite, antes de deitar, que devemos fazer?

À noite, antesde deitar, convém pôr-nos, como pela manhã, na presença de Deus, recitar devotamente as mesmas orações, fazer um breve exame de consciência, e pedir perdão a Deus dos pecados cometidos durante o dia.

##### 982 - Que haveis de fazer antes de adormecer?

Antesde adormecer, farei o sinal da Cruz, pensarei que posso morrer naquela noite, e oferecerei o coração a Deus, dizendo: "Meu Senhor e meu Deus, eu Vos dou todo o meu coração. Trindade Santíssima, concedei-me a graça de bem viver e de bem morrer. Jesus, Maria e José eu Vos encomendo a minha alma".

##### 983 - Além das orações da manhã e da noite, por que outra forma se pode recorrer a Deus no decurso do dia?

No decurso do dia pode-se invocar a Deus freqüentemente com outras orações breves, que se chamam jaculatórias.

##### 984 - Dizei algumas jaculatórias.

<ul>
  <li>1º - Senhor, valei-me;</li>
  <li>2º - Senhor, seja feita a vossa santíssima vontade;</li>
  <li>3º - Meu Jesus, eu quero ser todo vosso;</li>
  <li>4º - Meu Jesus, misericórdia;</li>
  <li>
    5º - Doce Coração de Jesus, que tanto nos amais, fazei que eu Vos ame cada
    vez mais;
  </li>
  <li>6º - Doce Coração de Maria sede minha salvação.</li>
</ul>

##### 985 - É útil recitar, durante o dia, muitas jaculatórias?

É muito útil recitar, durante o dia, muitas jaculatórias, e podem recitar-se também com o coração, sem proferir palavras, caminhando, trabalhando, etc.

##### 986 - Além das orações jaculatórias, em que outra coisa deveria exercitar-se com freqüência o cristão?

Além das orações jaculatórias, o cristão deveria exercitar-se na mortificação cristã.

##### 987 - Que quer dizer mortificar-se?

Mortificar-se quer dizer privar-se, por amor de Deus, daquilo que agrada, e aceitar o que desagrada aos sentidos ou ao amor próprio.

##### 988 - Quando é o Santíssimo Sacramento levado a um enfermo, que se deve fazer?

Quando é o Santíssimo Sacramento levado a algum enfermo, devemos, sendo possível, acompanhá-Lo com modéstia e recolhimento; e, se não é possível acompanhá-Lo, fazer um ato de adoração em qualquer lugar que nos encontremos, e dizer: "Consolai, Senhor, este enfermo, e concedei-lhe a graça de se conformar com a vossa santíssima vontade. e de conseguir a sua salvação".

##### 989 - Ouvindo tocar o sino pela agonia de algum moribundo, que haveis de fazer?

Ouvindo tocar o sino pela agonia de algum moribundo, irei, se puder, à igreja orar por ele; e, não podendo, encomendarei a Nosso Senhor a sua alma, pensando que dentro em breve tempo hei de encontrar-me também eu naquele estado.

##### 990 - Ao ouvir sinais pela morte de alguém, que haveis de fazer?

Ao ouvir sinais pela morte de alguém, procurarei rezar um De profundis ou um Réquiem, ou um Padre-Nosso e uma Ave-Maria, pela alma daquele defunto, e renovarei o pensamento da morte.