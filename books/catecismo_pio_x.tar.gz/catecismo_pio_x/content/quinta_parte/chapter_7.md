## VII - <em>Dos Novíssimos e de outros meios principais para evitar o pecado</em>

##### 965 - Que se entende por Novíssimos?

Novíssimos são chamados nos Livros Santos as últimas coisas que hão de acontecer ao homem.

##### 966 - Quantos são os Novíssimos?

Os Novíssimos, ou últimas coisas do homem, são quatro: Morte, Juízo, Inferno e Paraíso.

##### 967 - Por que é que esses Novíssimos se chamam últimas coisas que acontecerão ao homem?

Os Novíssimos chamam-se últimas coisas que acontecerão ao homem, porque a Morte é a última coisa que nos acontece neste mundo; o Juízo de Deus é o último entre os juízos que temos a passar; o Inferno é último mal que hão de sofrer os maus; e o Paraíso é sumo bem que hão de receber os bons.

##### 968 - Quando devemos pensar nos Novíssimos?

É bom pensar nosNovíssimos todososdias, e principalmente ao fazer a oração da manha, apenas acordados, à noite antes do deitar, e todas as vezes que somos tentados a fazer algum mal, porque este pensamento é eficacíssimo para nos fazer evitar o pecado.