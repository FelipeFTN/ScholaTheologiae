## I - <em>Das virtudes principais</em>

#### 1º - Das virtudes teologais

##### 852 - Que é a virtude sobrenatural?

A virtude sobrenatural é uma qualidade que Deus infunde na alma, pela qual se tem propensão, facilidade e prontidão para conhecer e praticar o bem, em ordem da vida eterna.

##### 853 - Quantas são as principais virtudes sobrenaturais?

As principais virtudes sobrenaturais são sete, a saber, três teologais e quatro cardeais.

##### 854 - Quais são as virtudes teologais?

As virtudes teologais são: a Fé, a Esperança e a Caridade.

##### 855 - Por que a Fé, a Esperança e a Caridade se chamam virtudes teologais?

Chamam-se a Fé, a Esperança e a Caridade virtudes teologais, porque têm a Deus por objeto imediato e principal e nos são infundidas por Ele.

##### 856 - De que modo têm as virtudes teologais a Deus por objeto imediato?

As virtudes teologais têm a Deus por objeto imediato, porque pela Fé nós cremos em Deus, e cremos tudo o queEle revelou; pela Esperança esperamospossuir a Deus; pela Caridade amamos a Deus e nEle amamos a nós mesmos e ao próximo.

##### 857 - Quando nos infunde Deus na alma as virtudes, teologais?

Deus, pela sua bondade, infunde-nos no alma a, virtudes teologais, quando nos adorna com a graça santificante; e por isso, quando recebemos o Batismo, fomos enriquecidos com estas virtudes, e juntamente com os dons do Espírito Santo.

##### 858 - Basta, para o cristão se salvar, o Batismo as virtudes teologais?

Para quem tem o uso da razão, não basta o ter recebido no Batismo as virtudes teologais; mas é necessário fazer freqüentemente atos destas virtudes.

##### 859 - Quando somos obrigados a fazer atos de Fé, de Esperança e de Caridade?

Somos obrigados a fazer atos de Fé, de Esperança e de Caridade:

<ul>
  <li>1º - quando chegamos ao uso da razão;</li>
  <li>2º - frequentes vezes no decurso da vida.</li>
  <li>3º - em perigo de morte.</li>
</ul>

#### 2º - Da Fé

##### 860 - Que é a Fé?

A Fé e uma virtude sobrenatural, infundida por Deus em nossa alma, pela qual nós, apoiados na autoridade do mesmo Deus, acreditamos que é verdade tudo o que Ele revelou e por meio da Santa Igreja nos propõe para crer.

##### 861 - Como conhecemos as verdades reveladas por Deus?

Conhecemos as verdades reveladas por Deus, por meio da Santa Igreja que é infalível, isto é, por meio do Papa, sucessor de São Pedro, e por meio dosBisposque, em união com o Papa, são sucessores dos Apóstolos, os quais foram instruídos pelo próprio Jesus Cristo.

##### 862 - Temos nós a certeza de que são verdadeiras as doutrinas que a Santa Igreja nos ensina?

Sim, temos a certeza absoluta de que são verdadeiras as doutrinas que a Santa Igreja nos ensina, porque Jesus Cristo empenhou a sua palavra, que a Igreja nunca se enganaria.

##### 863 - Com que pecado se perde a Fé?

A Fé perde-se negando ou duvidando voluntariamente, ainda que seja de um só artigo que nos é proposto para crer.

##### 864 - Como recuperamos a Fé?

Recuperamos a Fé perdida, arrependendo-nos do pecado cometido e crendo de novo tudo o que crê a Santa Igreja.

#### 3º - Dos mistérios

##### 865 - Podemos compreender todas as verdades da Fé?

Não; não podemos compreender todas as verdades da Fé, porque algumas destas verdades são mistérios.

##### 866 - Que são os mistérios?

Os mistérios são verdades superioresà razão, as quaisdevemos crer, ainda que não as possamos compreender.

##### 867 - Por que devemos crer os mistérios?

Devemos crer os mistérios, porque os revelou Deus, que, sendo Verdade e Bondade infinitas, não pode engarnar-Se, nem enganar-nos.

##### 868 - São porventura os mistérios contrários à razão?

Os mistérios são superiores, porém não contrários à razão; e até a própria razão nos persuade a admiti-los.

##### 869 - Por que os mistérios não podem ser contrários à razão?

Os mistérios não podem ser contrários à razão, porque é o mesmo Deus quem nos deu a luz da razão, e quem revelou OS mistérios, e Ele não pode contradizer-Se a Si mesmo.

#### 4º - Da Sagrada Escritura

##### 870 - Onde se acham as verdades que Deus revelou?

As verdades que Deus revelou acham-se na Sagrada Escritura e na Tradição.

##### 871 - Que é a Sagrada Escritura?

A Sagrada Escritura é a coleção dos livrosescritospelosProjetase pelosHagiógrafos, pelos Apóstolos pelos Evangelistas, por inspiração do Espírito Santo, recebidas pela Igreja como inspirados.

##### 872 - Em quantas partes se divide a Sagrada Escritura?

A Sagrada Escritura se divide em duas partes: Antigo e Novo Testamento.

##### 873 - Que contém o Antigo Testamento?

O Antigo Testamento contém os livros inspiradosescritos antes da vinda de Jesus Cristo.

##### 874 - Que contém o Novo Testamento?

O Novo Testamento contém os livros inspirados escritos depois da vinda de Jesus Cristo.

##### 875 - Que nome se dá comumente à Sagrada Escritura?

À Sagrada Escritura dá-se comumente o nome de Bíblia Sagrada.

##### 876 - Que quer dizer a palavra Bíblia?

A palavra Bíblia quer dizer coleção dos livros santos, o livro por excelência, o livro dos livros, o livro inspirado por Deus.

##### 877 - Por que é a Sagrada Escritura chamada o livro por excelência?

A Sagrada Escritura é chamada o livro por excelência, por causa da excelência da matéria de que trata e do Autor que a inspirou.

##### 878 - Não pode haver erro na Sagrada Escritura?

Na Sagrada Escritura não pode haver erro algum, porque, sendo toda inspirada, o Autor de todas as suas partes é o próprio Deus. Isto não obsta a que nas cópias as e traduções da mesma se tenha dado algum engano ou dos copistas ou dos tradutores. Porém, nas edições revistas e aprovadas pela Igreja Católica não pode haver erro no que respeita à fé ou à moral.

##### 879 É necessária a todos os cristãos a leitura da Bíblia?

A leitura da Bíblia não é necessária a todosos cristãos, sendo, como são, instruídos pela Igreja; mas é contudo útil e recomendada a todos.

##### 880 - Pode-se ler qualquer tradução em língua vulgar da Bíblia?

Podem ler-se as traduções em língua vulgar da Bíblia desde que sejam reconhecidas como fiéis pela Igreja Católica, e venham acompanhadas de explicações ou notas aprovadas pela mesma Igreja.

##### 881 - Por que só se podem ler as traduções da Bíblia que são aprovadas pela Igreja?

Só se podem ler as traduçõesda Bíblia que são aprovadaspela Igreja porque só Ela é legítima depositária e guarda da Bíblia.

##### 882 - Por quem podemos nós conhecer o verdadeiro sem tido das Sagradas Escrituras?

O verdadeiro sentido das Sagradas Escrituras podemos conhecê-lo só por meio o da Igreja, porque só a Igreja é que não pode errar ao interpretá-las.

##### 883 - Que deveria fazer um cristão, se lhe fosse oferecida a Bíblia por um protestante ou por algum emissário dos protestantes?

Um cristão a quem fosse oferecida a Bíblia por um protestante, ou por algum emissário dos protestantes, deveria rejeitá-la com horror, por ser proibida pela Igreja. E, se a tivesse aceitado sem reparar, deveria logo lançá-la ao fogo ou entregá-la ao próprio pároco.

##### 884 - Por que proíbe a Igreja as Bíblias protestantes?

A Igreja proíbe as Bíblias protestantes, porque ou estão alteradas e contêm erros, ou então, faltando-lhes a sua aprovação e as notas explicativas das passagens obscuras, podem causar dano à Fé. Por isso a Igreja proíbe também as traduções da Sagrada Escritura já aprovadas por Ela, mas reimpressas sem as explicações que a mesma Igreja aprovou.

#### 5º - Da Tradição

##### 885 - Dizei-me: o que é a Tradição?

A Tradição é a palavra de Deus não escrita, mas comunicada de viva voz por Jesus Cristo e pelos Apóstolos, e que chegou sem alteração, de século ein século, por meio da Igreja, até nós.

##### 886 - Onde se acham os ensinamentos da Tradição?

Os ensinamentos da Tradição acham-se principalmente nos decretos dos Concílios, nos escritos dos Santos Padres, nos atos da Santa Sé, nas palavras e nus usos da Sagrada Liturgia.

##### 887 - Em que consideração se deve ter a Tradição?

A Tradição deve ter-se na mesma consideração em que se tem a palavra de Deus contida na Sagrada Escritura.

#### 6º - Da Esperança

##### 888 - Que é a Esperança?

A Esperança é uma virtude sobrenatural, infundida por Deus na nossa alma, pela qual desejamos e esperamos a vida eterna que Deus prometeu aos seus servos, e os auxílios necessários para alcançá-la.

##### 889 - Por que motivo devemos esperar de Deus o Paraíso e os auxílios necessários para alcançá-lo?

Devemos esperar de Deus o Paraíso e os auxílios necessários para alcançá-lo, porque Deus misericordiosíssimo, pelos merecimentos de Nosso Senhor Jesus Cristo, o prometeu a quem o serve de todo o coração; e, sendo fidelíssimo e onipotente, cumpre sempre a sua promessa.

##### 890 - Quais são as condições necessárias para alcançar o Paraíso?

As condiçõesnecessáriaspara alcançar o Paraíso são: a graça de Deus, a prática das boas obras e a perseverança no seu santo amor até à morte.

##### 891 - Como se perde a Esperança?

Perde-se a Esperança todas as vezes que se perde a Fé; perde-se também pelo pecado de desespero ou de presunção.

##### 892 - Como recuperamos a Esperança?

Recuperamosa Esperança perdida, arrependendo-nosdo pecado cometido, e excitando-nos de novo à confiança na bondade divina.

#### 7º - Da Caridade

##### 893 - Que é a Caridade?

A Caridade é uma virtude sobrenatural, infundida por Deus em nossa alma, pela qual amamos a Deus por Si mesmo sobre todas as coisas, e amamos o próximo como a nós mesmos, por amor de Deus.

##### 894 - Por que motivos devemos amar a Deus?

Devemos amar a Deus, porque Ele é o sumo Bem, infinitamente bom e perfeito, e além disso por que Ele o manda, e pelos inumeráveis benefícios que dEle recebemos.

##### 895 - Como se deve amar a Deus?

Devemos amar a Deus sobre todas as coisas, com todo o nosso coração, com toda a nossa mente, com toda a nossa alma, e com todas as nossas forças.

##### 896 - Que quer dizer: amar a Deus sobre todas as coisas?

Amar a Deus sobre todas as coisas quer dizer: preferi-Lo a todas as criaturas mais caras e mais perfeitas, e estar disposto a perder tudo antes que ofendê-Lo ou deixar de amá-Lo.

##### 897 - Que quer dizer: amar a Deus com todo o nosso coração?

Amar a Deus com todo o nosso coração quer dizer: consagrar-Lhe todos os nossos afetos.

##### 898 - Que quer dizer: amar a Deus com toda a nossa mente?

Amar a Deus com toda a nossa mente quer dizer: dirigir para Ele todos os nossos pensamentos.

##### 899 - Que quer dizer: amar a Deus com toda a nossa alma?

Amar a Deus com toda a nossa alma quer dizer: consagrar-Lhe o uso de todas as potências da nossa alma.

##### 900 - Que quer dizer: amar a Deus com todas as nossas forças?

Amar a Deus com todas as nossas forças quer dizer: esforçar-se por crescer cada vez maisno amor dEle, e proceder de maneira que todas asnossasações tenham por motivo e por fim o seu amor e o desejo de Lhe agradar.

##### 901 - Por que devemos amar o próximo?

Devemos amar o próximo por amor de Deus porque Ele o manda, e porque todo o homem é imagem de Deus.

##### 902 - Somos obrigados a amar também os inimigos?

Sim, somos obrigados a amar também os inimigos, porque também eles são nossos próximos, e porque Jesus Cristo o mandou expressamente.

##### 903 - Que quer dizer: amar o próximo como a nos mesmos?

Amar o próximo como a nós mesmos quer dizer: desejar-lhe e fazer-lhe, tanto quanto pudermos, todo o bem que devemos desejar para nós mesmos, e não lhe desejar nem fazer mal algum.

##### 904 - Quando amamos a nós mesmos retamente?

Amamos retamente a nós mesmos quando procuramos servi r a Deus e pôr n'Ele toda a nossa felicidade.

##### 905 - Como se perde a Caridade?

Perde-se a Caridade com qualquer pecado rnortal.

##### 906 - Como recuperamos a Caridade?

Recuperamosa Caridade, fazendo atosde amor de Deus, arrependendo-nose confessando-nos bem.

#### 8º - Das virtudes cardeais

##### 907 - Quais são as virtudes cardeais?

As virtudes cardeais são: a Prudência, a Justiça, a Fortaleza e a Temperança.

##### 908 - Por que se chamam virtudes cardeais a Prudência, a Justiça, a Fortaleza e a Temperança?

Chamam-se virtudes cardeais a Prudência, a Justiça, a Fortaleza e a Temperança, porque são a base e o fundamento das virtudes morais.

##### 909 - Que é a Prudência?

A Prudência é a virtude que dirige toda ação ao devido fim, e por isso procura os meios convenientes para que a ação seja em tudo bem feita, e portanto aceita ao Senhor.

##### 910 - Que é a Justiça?

A Justiça é a virtude pela qual damos a cada um o que lhe pertence.

##### 911 - Que é a Fortaleza?

A Fortaleza é a virtude que nos dá coragem parti não temer perigo algum, nem a própria morte, no serviço de Deus.

##### 912 - Que é a Temperança?

A Temperança é a virtude pela qual refreamos os desejos desordenados de prazeres sensuais, e usamos com moderação dos bens temporais.