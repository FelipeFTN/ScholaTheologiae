## V - <em>Dos pecados e das suas espécies principais</em>

##### 942 - Quantas espécies há de pecado?

Há duas espécies de pecado: o pecado original e o pecado atual.

##### 943 - Que é o pecado original?

O pecado original é aquele com o qual todos nascemos, exceto a Santíssima Virgem Maria, e que contraímos pela desobediência do nosso primeiro pai Adão.

##### 944 - Que males nos causa o pecado de Adão?

Osmales causadospelo pecado deAdão são: a privação da graça, a perda do Paraíso, a ignorância, a inclinação para o mal, a morte e todas as demais misérias.

##### 945 - Como se apaga o pecado original?

O pecado original apaga-se com o santo Batismo.

##### 946 - Que é o pecado atual?

O pecado atual é aquele que o homem, chegado ao uso da razão, comete por sua livre vontade.

##### 947 - Quantas espécies há de pecado atual?

Há duas espécies de pecado atual: o mortal e o venial.

##### 948 - Que é o pecado mortal?

O pecado mortal é uma transgressão da lei divina, pela qual se falta gravemente aos deveres para com Deus, para com o próximo, ou para com nós mesmos.

##### 949 - Por que se chama mortal?

Chama-se mortal porque dá a morte à alma, fazendo-a perder a graça santificante, que é a vida da alma como a alma é a vida do corpo.

##### 950 - Que males causa à alma o pecado mortal?

O pecado mortal:

<ul>
  <li>1º - priva a alma da graça e da amizade de Deus;</li>
  <li>2º - fá-la perder o Céu;</li>
  <li>
    3º - priva-a dos merecimentos adquiridos e torna-a incapaz de adquirir
    novos;
  </li>
  <li>4º - torna a alma escrava do demônio;</li>
  <li>5º - fá-la merecer o Inferno e também os castigos desta vida.</li>
</ul>

##### 951 - Além da gravidade da matéria, que mais se requer para haver um pecado mortal?

Além da gravidade da matéria, para haver um pecado mortal requer-se a plena advertência desta gravidade, e a vontade deliberada de cometer o pecado.

##### 952 - Que é o pecado venial?

O pecado venial é uma leve transgressão da lei divina, pela qual se falta levemente a algum dever para com Deus, para com o próximo, ou para com nós mesmos.

##### 953 - Por que se chama venial?

Porque é leve em comparação com o pecado mortal; porque não nos faz perder a graça divina; e porque Deus facilmente o perdoa.

##### 954 - Então não se deve fazer grande caso do pecado venial?

Isto seria um erro enorme, porque o pecado venial contém sempre uma ofensa a Deus, e causa prejuízos não pequenos à alma.

##### 955 - Que prejuízos causa o pecado venial?

O pecado venial:

<ul>
  <li>1º - enfraquece e esfria em nós a caridade;</li>
  <li>2º - dispõe-nos para o pecado mortal;</li>
  <li>
    3º - faz-nos merecedores de grandes penas temporais, neste mundo ou no
    outro.
  </li>
</ul>