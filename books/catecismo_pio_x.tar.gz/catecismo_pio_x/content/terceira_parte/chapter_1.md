## I - <em>Dos Mandamentos da Lei de Deus em geral</em>

<div class="side-by-side not-content">

<p>
  A lei do Senhor, que é imaculada, converte as almas; o testemunho do Senhor é
  fiel, dá sabedoria aos pequeninos.
  <br />
  As justiças do Senhor são retas, alegram os corações; o preceito do Senhor é
  claro, esclarece os olhos. <br />
  O temor do Senhor é santo, permanece pelos séculos dos séculos; os juízos do Senhor
  são verdadeiros, cheios de justiça em si mesmos.
  <br />
  São mais para desejar do que o muito ouro e as muitas pedras preciosas; e são mais
  doces que o mel e o favo.
  <br />
  Por isso o teu servo os guarda, e em os guardar há grande recompensa.
  <br />
  Salmo 18, 8-12
</p>

<p>
  Lex Domini inmaculata convertens animas testimonium Domini fidele sapientiam
  praestans parvulis.
  <br />
  Iustitiae Domini rectae laetificantes corda praeceptum Domini lucidum
  inluminans oculos.
  <br />
  Timor Domini sanctus permanens in saeculum saeculi iudicia Domini vera
  iustificata in semet ipsa.
  <br />
  Desiderabilia super aurum et lapidem pretiosum multum et dulciora super mel et
  favum.
  <br />
  Etenim servus tuus custodit ea in custodiendis illisretributio multa.
  <br />
  Psalmus XVIII, 8-12
</p>

<p>
  Bem-aventurados os que se conservam sem mácula no caminho, os que andam na lei
  do Senhor.
  <br />
  Salmo 118, 1
</p>

<p>
  Beati inmaculati in via Qui ambulant in lege Domini.
  <br />
  Psalmus CXVIII, 1
</p>

<p>
  De todo o meu coração te busquei; não me deixes transviar dos teus
  mandamentos.
  <br />
  Escondi no meu coração as tuas palavras, para não pecar contra ti.
  <br />
  Bendito és, Senhor; ensina-me as tuas justas leis. <br />
  Salmo 118, 10-12
</p>

<p>
  In toto corde meo exquisivi te non repellas me a mandatistuis.
  <br />
  In corde meo abscondi elo quia tua ut non peccem tibi.
  <br />
  Benedictus es Domine doce me iustificationes tuas.
  <br />
  Psalmus CXVIII, 10-12
</p>

<p>
  Deleitei-me no caminho das tuas ordens, tanto como em todas as riquezas.
  <br />
  Nos teus mandamentos me exercitarei, e considerarei os teus caminhos.
  <br />
  Nas tuas ordens meditarei; não me esquecerei das tuas palavras.
  <br />
  Concede esta graça ao teu servo, dá-me vida, e eu guardarei as tuas palavras.
  <br />
  Tira o véu dos meus olhos, e considerarei as maravilhas da tua lei.
  <br />
  Salmo 118, 14-18
</p>

<p>
  In via testimoniorum tuorum delectatus sum sicut in omnibus divitiis
  <br />
  In mandatis tuis exercebor et considerabo vias tuas
  <br />
  In iustificationibus tuis meditabor non obliviscar sermones tuos
  <br />
  Retribue servo tuo vivifica me et custodiam sermones tuos
  <br />
  Revela oculos meos et considerabo mirabilia de legetua
  <br />
  Psalmus CXVIII, 14-18
</p>

<p>
  Minha alma desejou ansiosa em todo o tempo as tuas justas leis.
  <br />
  Salmo 118, 20
</p>

<p>
  Concupivit anima mea desider ar eiustificationes tuas in omni tempore
  <br />
  Psalmus CXVIII, 20
</p>

<p>
  Dá-me inteligência, e estudarei a tua lei, e a guardarei de todo o meu
  coração.
  <br />
  Guia-me pela senda de teus mandamentos, porque essa mesma desejei.
  <br />
  Inclina o meu coração para os teus preceitos, e não para a avareza.
  <br />
  Desvia os meus olhos, para que não vejam a vaidade; faze que eu viva segundo o
  teu caminho.
  <br />
  Salmo 118, 34-37
</p>

<p>
  Da mihi intellectum et scrutabor legem tuam et custodiam illam in toto corde
  meo.
  <br />
  Deduc me in semita mandatorum tuorum quia ipsam volui.
  <br />
  Inclina cor meum in testimonia tua et non in avaritiam
  <br />
  Averte oculosmeos ne videant vanitatem in via tua vivifica me.
  <br />
  Psalmus CXVIII, 34-37
</p>

<p>
  Meditarei nos teus mandamentos, que eu amo.
  <br />
  Levantarei as minhas mãos para os teus mandamentos, que eu amo, e
  exercitar-me-ei nas tuas ordens.
  <br />
  Salmo 118, 47-48
</p>

<p>
  Et meditabar in mandatis tuis quae dilexi.
  <br />
  Et levavi manus meas ad mandata quae dilexi et exercebar in
  iustificationibustuis.
  <br />
  Psalmus CXVIII, 47-48
</p>

</div>

##### 342 - De que trata a terceira parte da Doutrina Cristã?

A terceira parte da Doutrina Cristã traiu dos Mandamentos da Lei de Deus e da Igreja.

##### 343 - Quantos são os Mandamentos da Lei de Deus?

Os Mandamentos da Lei de Deus são dez:

<ul>
  <li>1º - Amar a Deus sobre todas as coisas.</li>
  <li>2º - Não tomar seu Santo Nome em vão.</li>
  <li>3º - Guardar domingos e festas.</li>
  <li>4º - Honrar pai e mãe.</li>
  <li>5º - Não matar.</li>
  <li>6º - Não pecar contra a castidade.</li>
  <li>7º - Não furtar.</li>
  <li>8º - Não levantar falso testemunho.</li>
  <li>9º - Não desejar a mulher do próximo.</li>
  <li>10º - Não cobiçar as coisas alheias.</li>
</ul>

##### 344 - Por que têm esse nome os Mandamentos da Lei de Deus?

Os Mandamentos da Lei de Deus têm esse nome porque foi o próprio Deus que os gravou na alma de todo o homem, os promulgou no monte Sinai, na antiga Lei, esculpidos em duas tábuas de pedra, e Jesus Cristo os confirmou na Lei nova.

##### 345 - Quais são os Mandamentos da primeira tábua?

Os Mandamentos da primeira tábua são os três primeiros, que se referem diretamente a Deus, e aos deveres que temos para com Ele.

##### 346 - Quais são os Mandamentos da segunda tábua?

Os Mandamentos da segunda tábua são os últimos sete, que se referem ao próximo e aos deveres que temos para com ele.

##### 347 - Somos obrigados a observar os Mandamentos?

Sim, todos somos obrigados a observar os Mandamentos, porque todos devemos viver segundo a vontade de Deus que nos criou; e basta transgredir gravemente um só deles para merecermos o Inferno.

##### 348 - Podemos observar os Mandamentos?

Podemos, sem dúvida, observar os Mandamentos da Lei de Deus, porque Deus não nosmanda nenhuma coisa impossível, e dá a graça para os observar a quem ti pede devidamente.

##### 349 - Que se deve considerar em cada Mandamento?

Em cada Mandamento deve-se considerar a parte positiva e a parte negativa; isto é, o que nos é ordenado e o que nos é proibido.