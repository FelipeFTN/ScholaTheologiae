# Terceira Parte

<aside>Dos Mandamentos da Lei de Deus e da Igreja</aside>