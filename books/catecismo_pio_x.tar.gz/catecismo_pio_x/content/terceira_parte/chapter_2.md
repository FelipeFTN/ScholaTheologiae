## II - <em>Dos Mandamentos que se referem a Deus</em>

Uma vez mais vos digo que ninguém me tenha por insensato; ou então tomai-me por insensato, para que também eu possa sentir um pouco de orgulho. O que vou dizer na certeza de poder orgulhar-me, não o digo sob inspiração do Senhor mas como num acesso de delírio. Visto que muitos se orgulham das coisas humanas, também eu vou orgulhar-me. Vós, que sois sensatos, suportais de boa vontade os insensatos. Sim, suportais quem vos escraviza, quem vos devora, quem vos explora, quem vos trata com orgulho, quem vos bate no rosto. Neste ponto, sinto vergonha de dizer, parece que fomos fracos. Quanto às pretensões que qualquer outro possa ter falo como louco também eu as tenho. São hebreus? Também sou. São israelitas? Também sou. São da descendência deAbraão? Também sou. São ministros de Cristo? Falando como louco, eu sou mais ainda. Muito mais pelos trabalhos, muito mais pelas prisões, pelos açoites sem conta. Muitas vezes vi a morte de perto. Cinco vezes recebi dos judeus os quarenta açoites menos um. Três vezes fui flagelado com varas. Uma vez, apedrejado. Três vezes naufraguei, uma noite e um dia passei no alto-mar. Viagens sem conta, exposto a perigos nos rios, perigos de assaltantes, perigos da parte de concidadãos, perigos da parte dos pagãos, perigos na cidade, perigos nos lugares desabitados, perigos no mar, perigos entre falsos irmãos! Trabalhos e fadigas, muitas noites sem dormir, com fome e sede, frequentes jejuns, frio e nudez! Além de outras coisas, o que pesa sobre mim diariamente, a preocupação por todas as igrejas! Quem está fraco, sem que eu sinta com ele? Quem é seduzido ao pecado, sem que eu fique indignado? Se é preciso contar vantagens, contarei vantagens da minha fraqueza. O Deus e Pai de nosso Senhor Jesus Cristo, que é bendito pelos séculos, sabe que não minto. Em Damasco, o governador do rei Aretas pôs guarda na cidade dos damascenos, para me prender, mas através de uma janela, fui descido numa cesta pelo muro, e escapei das suas mãos. II Cor 11, 16-33

#### 1º - Do primeiro Mandamento da Lei de Deus

##### 350 - Por que disse o Senhor antes de ditar os Mandamentos: Eu sou o Senhor teu Deus?

Antes de promulgar os seus Mandamentos, Deus disse: Eu sou o Senhor teu Deus, para que saibamos que Deus, sendo o nosso Criador e Senhor, pode mandar o que quiser, e nós, criaturas suas, somos obrigados a obedecer-Lhe.

##### 351 - Que nos ordena Deus com as palavras do primeiro Mandamento: amar a Deus sobre todas as coisas?

Com as palavras do primeiro Mandamento: amar a Deus sobre todas as coisas, Deus nosordena que o reconheçamos, adoremos, amemos e sirvamos a Ele só, como nosso Soberano Senhor.

##### 352 - Como se cumpre o primeiro Mandamento?

Cumpre-se o primeiro Mandamento com o exercício do culto interno e externo.

##### 353 - Que é o culto interno?

O culto interno é a honra que se presta a Deus só com as faculdades da alma isto é, com a inteligência e com a vontade.

##### 354 - Que é o culto externo?

O culto externo é a homenagem que se presta a Deus por meio de atos exteriores e de objetos sensíveis.

##### 355 - Não basta adorar a Deus interiormente, só com o coração?

Não basta adorar a Deus interiormente, só com o coração, mas é necessário adorá- Lo também exteriormente, com a alma e com o corpo juntamente, porque Ele é Criador e Senhor absoluto de uma e de outro.

##### 356 - Poderá haver culto externo sem o interno?

Não pode de forma alguma haver culto externo sem o interno, porque aquele, desacompanhado deste, fica privado de vida, de merecimento e de eficácia, como corpo sem alma.

##### 357 - Que nos proíbe o primeiro Mandamento?

O primeiro Mandamento proíbe-nos a idolatria, a superstição, o sacrilégio, a heresia, e todo e qualquer outro pecado contra a religião.

##### 358 - Que é a idolatria?

Chama-se idolatria o prestar a alguma criatura, por exemplo a uma estátua, a uma imagem, a um homem, o culto supremo de adoração, devido só a Deus.

##### 359 - Como está expressa na Sagrada Escritura esta proibição?

Na Sagrada Escritura está expressa esta proibição com as palavras: Não farás para ti imagem de escultura, nem figura alguma de tudo o que há em cima, no céu, e do que há embaixo, na terra. E não adorarás tais coisas, nem lhes darás culto.

##### 360 - Proíbem estas palavras toda a espécie de imagens?

Não, por certo. Mas só as das falsas divindades, feitas com intuito de adoração, como faziam os idólatras. E tanto isto é verdade, que o próprio Deus deu ordem a Moisés para fazer algumas, como as duas estátuas de querubins que estavam sobre a arca, e a serpente de bronze no deserto.

##### 361 - Que é a superstição?

Chama-se superstição toda e qualquer devoção contrária à doutrina e ao uso da Igreja, bem como o atribuir a urna ação ou alguma coisa uma virtude sobrenatural que ela não tem.

##### 362 - Que é o sacrilégio?

O sacrilégio é a profanação de um lugar, de uma pessoa ou de uma coisa consagrada a Deus ou destinada ao seu culto.

##### 363 - Que é a heresia?

A heresia é um erro culpável de inteligência, pelo qual se nega com pertinácia alguma verdade de fé.

##### 364 - Que mais coisas proíbe o primeiro Mandamento?

O primeiro Mandamento proíbe também todo o comércio ou trato com o demônio, e o filiar-se às seitas anticristãs.

##### 365 - Quem recorresse ao demônio e o invocasse, cometeria pecado grave?

Quem recorresse ao demônio e o invocasse, cometeria um pecado enorme, porque o demônio é o mais perverso inimigo de Deus e do homem.

##### 366 - É lícito interrogar as mesas chamadas falantes ou escreventes, ou consultar de algum modo as almas dos mortos, por meio de espiritismo?

Todas as práticas do espiritismo são proibidas, porque são supersticiosas, e muitas vezes não estão isentas de intervenção diabólica, e por isso foram justamente interditas pela Igreja.

##### 367 - O primeiro Mandamento proíbe acaso honrar e invocar os Anjos e os Santos?

Não. Não é proibido honrar e invocar os Anjos e os Santos, e até o devemos fazer, porque é coisa boa e útil, e altamente recomendada pela Igreja, já que eles são amigos de Deus e nossos intercessores junto dEle.

##### 368 - Sendo Jesus Cristo o nosso único mediador junto de Deus, por que recorremos também à intercessão da Santíssima Virgem e dos Santos?

Jesus Cristo é o nosso mediador junto de Deus, enquanto, sendo verdadeiro Deus e verdadeiro Homem, só Ele, em virtude dos próprios merecimentos, nos reconciliou com Deus e dEle nos obtém todas as graças. Mas, a Santíssima Virgem e os Santos, em virtude dos merecimentos de Jesus Cristo, e pela caridade que os une a Deus e a nós, auxiliam-nos com a sua intercessão a alcançar as graças que pedimos. E este é um dos grandes bens da comunhão dos Santos.

##### 369 - Podemos honrar também as sagradas imagens de Jesus Cristo e dos Santos?

Sim, porque a honra que se tributa às sagradas imagens de Jesus Cristo e dosSantos, refere-se às suas mesmas pessoas.

##### 370 - E as relíquias dos Santos, podem honrar-se?

Sim, também as relíquias dos Santos podem e devem honrar-se porque os seus corpos foram membros vivos de Jesus Cristo e templos do Espírito Santo, e devem ressurgir gloriosos para a vida eterna.

##### 371 - Que diferença há entre o culto que prestamos a Deus, e o culto que prestamos aos Santos?

Entre o culto que prestamos a Deus e o culto que prestamos aos Santos há esta diferença: que a Deus adoramo-Lo pela sua infinita excelência, ao passo que aos Santos não os adoramos, mas só os honramos e veneramos como amigos de Deus e nossos intercessores junto dEle. O culto que prestamos a Deus chama-se latria, isto é, de adoração, e o culto que prestamos aos Santos chama-se dulia, isto é, de veneração aos servos de Deus; enfim o culto especial que prestamos a Maria Santíssima chama-se hiperdulia, isto é, de essencialíssima veneração, como Mãe de Deus.

#### 2º - Do segundo Mandamento da Lei de Deus

Certo homem, chamado Ananias, decomum acordo com sua mulher Safira, vendeu uma propriedade. Com a cumplicidade da mulher, reteve uma parte do preço e foi depositar o resto aos pés dos apóstolos. Pedro, porém, disse: Ananias, por que Satanás se apoderou de teu coração para enganar o Espírito Santo, retendo uma parte do preço do terreno? Por acaso não podias conservá-lo, sem o vender? E depois de vendido, não podias dispor livremente da quantia? Então, por que resolveste fazer isso? Não foi aos homens que mentiste, mas a Deus. Ao ouvir estas palavras, Ananias caiu morto. Grande medo tomou conta de todos os que souberam disso. Alguns jovens se levantaram, envolveram o corpo num lençol e o retiraram dali para sepultar. Passadas umas três horas, entrou também a mulher, sem saber o que havia acontecido. Pedro perguntou-lhe: Dize-me: foi por tanto que vendesteso terreno? Ela respondeu: Sim, foi por essepreço. Então Pedro disse: Por que combinastes tentar o Espírito do Senhor? Olha, já estão entrando pela porta aqueles que sepultaram o teu marido. Eles vão levar também a ti. Ela imediatamente caiu aos pés de Pedro e morreu. Quando os jovens entraram, encontraram a mulher morta e a levaram para sepultar ao lado do marido. Grande medo se apoderou de toda a Igreja e de todos que ouviram tais coisas. Atos 5, 1-11

##### 372 - Que nos proíbe o segundo Mandamento: não tomar seu Santo Nome em vão?

O segundo Mandamento: não tomar seu Santo Nome em vão, proíbe-nos:

<ul>
  <li>1º - pronunciar o nome de Deus sem respeito;</li>
  <li>
    2º - blasfemar contra Deus, contra a Santíssima Virgem ou contra os Santos;
  </li>
  <li>
    3º - fazer juramentos falsos ou não necessários, ou proibidos desta ou
    daquela maneira.
  </li>
</ul>

##### 373 - Que quer dizer pronunciar o Nome de Deus sem respeito?

Pronunciar o Nome de Deus sem respeito quer dizer: pronunciar este Santo Nome, e tudo o que se refere em modo especial ao próprio Deus como o Nome de Jesus Cristo, de Maria e dos Santos com ira, por escárnio, ou de outro modo pouco reverente.

##### 374 - Que é a blasfêmia?

A blasfêmia é um pecado horrível que consiste em palavras ou atos de desprezo ou maldição contra Deus, contra a Virgem, contra os Santos, ou contra as coisas santas.

##### 375 - Há diferença entre a blasfêmia e a imprecação ou praga?

Há diferença, porque com a blasfêmia se amaldiçoa ou se deseja mal a Deus, a Nossa Senhora, aosSantos; ao passo que, com a imprecação ou praga, se amaldiçoa ou se deseja mal a si mesmo ou ao próximo.

##### 376 - Que é jurar?

Jurar é tomar a Deus em testemunho da verdade do que se afirma ou se promete.

##### 377 - É sempre proibido jurar?

Não é sempre proibido o juramento, mas é lícito e até honroso para Deus, quando há necessidade, e se jura com verdade, discernimento e justiça.

##### 378 - Quando não se jura com verdade?

Quando se afirma com juramento o que se sabe ou se julga ser falso, e quando com juramento se promete o que não se tem a intenção de cumprir.

##### 379 - Quando não se jura com discernimento?

Quando se jura sem prudência e sem madura ponderação, ou por coisas de pequena importância.

##### 380 - Quando não se jura com justiça?

Quando se jura fazer uma coisa que não é justa ou permitida, como jurar vingar-se, roubar e outras coisas parecidas.

##### 381 - Somos obrigados a cumprir o juramento de fazer coisas injustas ou proibidas?

Não só não somos obrigados, mas pecaríamos fazendo-as, porque são proibidas pela lei de Deus ou da Igreja.

##### 382 - Quem jura falso, que pecado comete?

Quem jura falso comete pecado mortal, porque desonra gravemente a Deus, verdade infinita, chamando-O em testemunho do que é falso.

##### 383 - Que nos ordena o segundo Mandamento?

O segundo Mandamento ordena-nos que honremos o Santo Nome de Deus, e que cumpramos, além dos juramentos, também os votos.

##### 384 - Que é um voto?

Um voto é uma promessa feita a Deus de uma coisa boa, para nós possível, e melhor que a coisa contrária, a que nós nos obrigamos, como se nos fosse preceituada.

##### 385 - Se a observância do voto se nos tornasse no todo ou em parte muito difícil, que haveria a fazer?

Podia-se pedir a comutação ou a dispensa ao Bispo próprio, ou ao Sumo Pontífice, conforme a qualidade do voto.

##### 386 - É pecado transgredir os votos?

O transgredir os votos é pecado, e por isso não devemos fazer votos sem madura reflexão, e ordinariamente sem o conselho do confessor, ou de outra pessoa prudente, para não nos expormos ao perigo de pecar.

##### 387 - Podem fazer-se votos a Nossa Senhora e aos Santos?

Os votos fazem-se só a Deus; pode-se, porém, prometer a Deus fazer alguma coisa em honra de Nossa Senhora ou dos Santos.

#### 3º - Do terceiro Mandamento da Lei de Deus

No primeiro dia da semana, de manhã muito cedo, as mulheres vieram ao túmulo trazer os perfumes que tinham preparado. Encontraram a pedra do túmulo removida e, entrando, não acharam o corpo do Senhor Jesus. Ficaram sem saber o que fazer. Nisso, dois homens vestidos de roupas brilhantes apareceram diante delas. Como ficassem aterrorizadas e baixassem os olhos para o chão, eles disseram: Por que procurais entre os mortos quem está vivo? Ele não está aqui mas ressuscitou! Lembrai-vos do que vos falou, quando estava ainda na Galiléia: O Filho do homem deveria ser entregue ao poder de pecadores e ser crucificado mas ressuscitaria ao terceiro dia. Então elas se lembraram das palavras de Jesus. Luc 24, 1-8 No primeiro dia da semana, estávamos reunidos para partir o pão. Paulo, que ia viajar no dia seguinte, conversava com os discípulos e prolongou a conversa até meia-noite. Havia muitas lâmpadas na sala onde estávamos reunidos. Um jovem, chamado Êutico, que estava sentado no parapeito de uma janela, adormeceu profundamente enquanto Paulo continuava a falar. Vencido pelo sono, caiu do terceiro andar, e o levantaram morto. Paulo desceu, debruçou-se sobre ele e, abraçando-o, disse: Não vos perturbeis. Ele está vivo. Depois subiu, partiu o pão, comeu e prosseguiu a pregação até ao amanhecer. Então partiu. Quanto ao rapaz, levaram-no vivo, com grandeconsolo detodos. Atos 20, 7-12

##### 388 - Que nos ordena o terceiro Mandamento: guardar domingos e festas?

O terceiro Mandamento: guardar domingos e festas, ordena-nos que honremos a Deus com obras de culto nos dias de festa.

##### 389 - Quais são os dias de festa?

Na Antiga Lei, eram os sábados e outros dias particularmente solenes para o povo judeu; na Lei Nova, são os domingos e outras festividades estabelecidas pela Igreja.

##### 390 - Por que na Lei Nova se guarda o domingo e não o sábado?

O domingo, que significa dia do Senhor, substituiu o sábado, porque foi em dia de domingo que Nosso Senhor Jesus Cristo ressuscitou.

##### 391 - Que obra de culto nos é preceituada nos dias de festa?

É-nos preceituado assistir devotamente ao Santo Sacrifício da Missa.

##### 392 - Com que outras obras costuma um bom cristão santificar as festas?

Um bom cristão santifica as festas:

<ul>
  <li>
    1º - assistindo à doutrina cristã, às pregações e aos ofícios divinos;
  </li>
  <li>
    2º - recebendo com freqüência, com as devidas disposições, os Sacramentos da
    Penitência e da Eucaristia;
  </li>
  <li>
    3º - dando-se à oração e às obras de caridade cristã para com o próximo.
  </li>
</ul>

##### 393 - Que nos proíbe o terceiro Mandamento?

O terceiro Mandamento proíbe-nos os trabalhos servis, e qualquer obra que nos impeça o culto de Deus.

##### 394 - Quais são os trabalhos servis proibidos nos dias santos?

Os trabalhos servis proibidos nos dias santos são os trabalhos chamados manuais, isto é, aqueles trabalhos materiais em que tem parte mais o corpo do que o espírito, como os que ordinariamente são próprios dos servidores, dos operários e dos artífices.

##### 395 - Que pecado se comete trabalhando em dia santo?

Trabalhando em dia santo, comete-se pecado mortal; não obstante não há culpa grave se o trabalho dura pouco tempo.

##### 396 - Não há nenhum trabalho servil que seja permitido nos dias santos?

Nos dias santos são permitidos aqueles trabalhos que são necessários à vida, ou ao serviço de Deus, e os que se fazem por uma causa grave, pedindo licença, se for possível, ao próprio pároco.

##### 397 - Por que nos dias santos são proibidos os trabalhos servis?

São proibidos nos dias santos os trabalhos servis, a fim de que possamos melhor dedicar-nos ao culto divino e à salvação da nossa alma, e para repousar das nossas fadigas. Por isso não é proibido entregar-se a divertimentos honestos.

##### 398 - Que mais devemos evitar de modo especial nos dias santos?

Nos dias santos devemos evitar principalmente o pecado e tudo o que possa induzir-nos a ele, como são os bailes e outras diversões e reuniões perigosas.