## IV - <em>Dos preceitos da Igreja</em>

Se teu irmão pecar, vai e censura-o pessoalmente. Se ele te ouvir, terás ganho teu irmão. Se não te ouvir, leva contigo uma ou duas pessoas a fim de que toda a questão se resolva pela decisão de duas ou três testemunhas. Se não as ouvir, vai dizê-lo à igreja. E, se não escutar a igreja, seja para ti como um pagão e pecador público. Eu vos garanto: Tudo que ligardes na terra, será ligado no céu; e tudo que desligardes na terra, será desligado no céu. Digo-vos ainda: Se doisde vósse unirem na terra para pedir qualquer coisa, hão de conseguilo do meu Pai que está nos céusl Porque onde dois ou três estiverem reunidos em meu nome, eu estarei ali no meio deles. Mt 18, 15-20 Então os apóstolos e presbíteros, de acordo com toda a Igreja, resolveram escolher alguns homens e enviá-los a Antioquia com Paulo e Barnabé; escolheram Judas, chamado Barsabás, eSilas, homens influentes entre os irmãos. Por seu intermédio enviaram a seguinte carta: Os irmãos, os apóstolos e presbíteros saúdam os irmãos de Antioquia, Síria e Cilícia, convertidos dentre os pagãos. Chegou ao nosso conhecimento que alguns dos nossos vos têm perturbado com palavras, confundindo vossas mentes, sem nenhuma autorização de nossa parte. Por isso resolvemos, de comum acordo, enviar-vos alguns homens escolhidos, em companhia de nossos amadosBarnabé ePaulo, que expuseram suas vidas pelo nome de Nosso Senhor Jesus Cristo. Estamos enviando Judas e Silas para vos comunicar de viva voz as mesmas coisas. Pareceu bem ao Espírito Santo e a nós não vos impor nenhuma outra exigência além das necessárias: que vos abstenhais das carnes imoladas aos ídolos, do sangue, das carnes sufocadas e da prostituição. Procedereis bem evitando estas coisas. Passai bem. Atos 15, 22-29

#### 1º - Dos preceitos da Igreja em geral

##### 469 - Além dos Mandamentos da Lei de Deus, que mais coisas somos nós obrigados a observar?

Além dos Mandamentos da Lei de Deus, somos obrigados a observar os mandamentos ou preceitos da Igreja.

##### 47O Somos obrigados a obedecer à Igreja?

Sem dúvida, somos obrigados a obedecer à Igreja, porque o próprio Jesus Cristo no-lo ordena, e porque os preceitos da Igreja facilitam a observância dos Mandamentos de Deus.

##### 471 - Quando começa a obrigação de observar os preceitos da Igreja?

A obrigação de observar os preceitos da Igreja começa geralmente com o uso da razão.

##### 472 - É pecado transgredir um preceito da Igreja?

Transgredir com advertência um preceito da Igreja em matéria grave é pecado grave.

##### 473 - Quem pode dispensar de um preceito da Igreja?

De um preceito da Igreja só pode dispensar o Papa ou quem dele receber as competentes faculdades.

##### 474 - Quantos e quais são os preceitos da Igreja?

Os preceitos da Igreja são cinco:

<ul>
  <li>1º - Ouvir Missa inteira nos domingos e festas de guarda.</li>
  <li>2º - Confessar-se ao menos uma vez cada ano.</li>
  <li>3º - Comungar ao menos pela Páscoa da Ressurreição.</li>
  <li>4º - Jejuar e abster-se de carne quando manda a Santa Madre Igreja.</li>
  <li>5º - Pagar dízimos segando o costume.</li>
</ul>

#### 2º - Do primeiro preceito da Igreja

##### 475 - Que nos manda o primeiro preceito ou manda mento da Igreja: ouvir Missa inteira nos domingos e festas de guarda?

O primeiro preceito da Igreja: ouvir Missa inteira nos domingos e festas de guarda, manda-nos assistir com devoção à Santa Missa nos domingos e nas outras festas de preceito.

##### 476 - Qual é a Missa à qual a Igreja deseja que se assista nos domingos e nas outras festas de preceito?

A Missa à qual a Igreja deseja que, sendo possível, se assista nos domingos e nas outras festas de guarda, é a Missa paroquial.

##### 477 - Por que recomenda a Igreja aos fiéis que assistam à Missa paroquial?

A Igreja recomenda aos fiéis que assistam à Missa paroquial:

<ul>
  <li>
    1º - a fim de que aqueles que pertencem à mesma paróquia se unam a orar,
    juntamente com o pároco, que é seu chefe espiritual;
  </li>
  <li>
    2º - a fim de que os paroquianos participem mais do Santo Sacrifício, que é
    aplicado principalmente por eles;
  </li>
  <li>
    3º - a fim de que ouçam as verdades do Evangelho que os párocos têm
    obrigação de expor à Santa Missa;
  </li>
  <li>
    4º - a fim de que conheçam as prescrições e avisos que se dão à estação da
    referida Missa.
  </li>
</ul>

##### 478 - Que quer dizer domingo?

Domingo quer dizer dia do Senhor, isto é, dia especialmente consagrado ao serviço de Deus.

##### 479 - Por que no primeiro mandamento da Igreja se faz menção especial do domingo?

No primeiro mandamento da Igreja faz-se menção especial do domingo, porque é ele o principal dia de festa entre os cristãos, como entre os judeus o principal dia de festa era o sábado, por instituição do próprio Deus.

##### 48O Que outras festas instituiu a Igreja?

A Igreja instituiu também as festas de Nosso Senhor, da Santíssima Virgem, dos Anjos e dos Santos.

##### 481 - Por que instituiu a Igreja outras festas de Nosso Senhor?

A Igreja instituiu outras festas de Nosso Senhor memória dos seus divinos mistérios.

##### 482 - Por que foram instituídas as festas da Santíssima Virgem, dos Anjos e dos Santos?

As festas da Santíssima Virgem, dos Anjos e dos Santos foram instituídas:

<ul>
  <li>
    1º - em memória das graças que Deus lhes fez e para as agradecer à bondade
    divina;
  </li>
  <li>
    2º - a fim de que os honremos, imitemos os seus exemplos e alcancemos o
    auxílio de suas orações.
  </li>
</ul>

#### 3º - Do segundo preceito da Igreja

##### 483 - Que nos manda a Igreja com as palavras do segundo preceito: confessar-se ao menos uma vez cada ano?

Com as palavras do segundo preceito: confessar-se ao menos uma vez cada ano, a Igreja obriga todos os cristãos que chegaram ao uso da razão, a receber, uma vez ao menos em cada ano, o Sacramento da Penitência.

##### 484 - Qual é o tempo mais próprio para cumprir o preceito da confissão anual?

O tempo mais próprio para cumprir o preceito da confissão anual é a Quaresma, segundo o uso introduzido e aprovado ein toda a Igreja.

##### 485 - Por que diz a Igreja que nos confessemos ao menos uma vez cada ano?

A Igreja diz ao menos, para dar a conhecer o seu desejo de que nos aproximemos deste Sacramento com mais freqüência.

##### 486 - É pois útil confessar-nos com freqüência?

É muito útil confessar-nos com freqüência, sobretudo porque é difícil que se confesse bem e se conserve isento de pecado mortal, quem se confessa raras vezes.

##### 487 - Satisfaz-se a este segundo preceito com uma confissão sacrílega?

Quem fizer uma confissão sacrílega, não satisfaz ao segundo preceito da Igreja, porque a intenção da Igreja é que se receba este Sacramento para nossa santificação.

#### 4º - Do terceiro preceito da Igreja

##### 488 - Que nos manda a Igreja com as palavras do terceiro preceito: comungar ao menos pela Páscoa da Ressurreição?

Com as palavras do terceiro preceito: comungar ao menos pela Páscoa da Ressurreição, a Igreja obriga todos os cristãos que chegarem à idade da discrição a receber todos os anos a Santíssima Eucaristia, durante o tempo pascal; e é bom que seja na própria paróquia.

##### 489 - Qual o tempo útil para satisfazer, no Brasil, o preceito da Comunhão Pascal?

No Brasil, o tempo útil para satisfazer o preceito da Comunhão Pascal vai do dia 2 de fevereiro, festa da Purificação de Nossa Senhora e da Apresentação do Menino Jesus no Templo, até o dia 16 de julho, comemoração de Nossa Senhora do Carmo.

##### 49O Somos obrigados a comungar em alguma outra ocasião, fora do tempo pascal?

Sim, somos obrigados também a comungar em perigo de morte.

##### 491 - Por que se diz que devemos comungar ao menos pela Páscoa?

Porque a Igreja deseja vivamente que não somente na Páscoa, mas com muita freqüência, nos aproximemos da Sagrada Comunhão, que é o alimento divino das nossas almas.

##### 492 - Satisfaz-se a este preceito com uma Comunhão sacrílega?

Quem fizer uma Comunhão sacrílega não satisfaz ao terceiro preceito da Igreja; porque a intenção da Igreja é que se receba esteSacramento para o fim para que foi instituído, isto é, para nossa santificação.

#### 5º - Do quarto preceito da Igreja

##### 493 - Que nos manda o quarto preceito da Igreja com as palavras jejuar e abster-se de carne quando manda a Santa Madre Igreja?

O quarto preceito da Igreja: jejuar e abster-se de carne quando manda a Santa Madre Igreja, manda-nos que jejuemos e nos abstenhamos de carne na Quarta-Feira de Cinzas e na Sexta-Feira Santa; e que nos abstenhamos de carne em todas as sextas-feiras do ano. Esta abstinência pode ser comutada por outra obra pia, a juízo do Bispo Diocesano.

##### 494 - Em que consiste o jejum?

O jejum consiste em tomar uma só refeição, durante o dia, e em não comer coisas proibidas.

##### 495 - Nos dias de jejum, além da única refeição, é proibido tomar qualquer outro alimento?

Nos diasde jejum, a Igreja permite uma pequena parva pela manhã, e uma ligeira refeição à noite, ou, então, cerca do meio-dia, quando se deixa para a tarde a refeição maior.

##### 496 - Para que serve o jejum?

O jejum serve para nos dispor melhor para a oração, para fazer penitência dos pecados cometidos, e para nos preservar de cometer outros novos.

##### 497 - Quem é obrigado a jejuar?

São obrigados a jejuar todos os cristãos, desde os vinte e um anos completos até aos sessenta começados, se não estão dispensados ou escusados por legitimo impedimento. A abstinência começa a obrigar aos catorze anos.

##### 498 - Estão também dispensados de toda a mortificação os que não estão obrigados a jejuar?

Os que não estão obrigados a jejuar, nem por isso estão dispensados de toda a mortificação, porque todos temos obrigação de fazer penitência.

##### 499 - Para que fim foi instituída a Quaresma?

A Quaresma foi instituída a fim de imitarmos, de algum modo, o rigoroso jejum de quarenta dias que Jesus Cristo observou no deserto, e a fim de nos prepararmos, por meio da penitência, para celebrar santamente a festa da Páscoa.

##### 500 - Qual o fim do jejum do Advento?

O jejum do Advento foi instituído para nos dispor a celebrar santamente a festa do Natal

##### 501 - Para que foi instituído o jejum das Quatro Têmporas?

O jejum das Quatro Têmporas foi instituído para consagrar cada uma das quatro estações do ano com a penitência de alguns dias; para pedir a Deus a conservação dos frutos da terra; para Lhe dar graças pelos frutos já concedidos, e para Lhe pedir que dê à sua Igreja santos ministros, que são ordenados nos sábados das Quatro Têmporas.

##### 502 - Para que foi instituído o jejum das vigílias?

O jejum das vigílias foi instituído a fim de nos prepararmos para celebrar santamente as festas principais.

##### 503 - Que nos proíbe a Santa Igreja nos dias de jejum e abstinência?

Quando a pessoa não está legitimamente dispensada, deve no dia de jejum e abstinência tornar uma só refeição plena, podendo fazer duas outras pequenas, uma pela manhã e outra à tarde, que evite grave dano, como, por exemplo, uma forte dor de cabeça. Nos dias de abstinência, proíbe o uso da carne e do caldo de carne.

##### 504 - Por que a Igreja quer que nos abstenhamos de comer carne a sexta-feira?

A fim de que façamos penitência todas as semanas, e sobretudo à sexta-feira, em honra da Paixão de Jesus Cristo.

#### 6º - Do quinto preceito da Igreja

##### 505 - Como se observa o quinto preceito da Igreja: pagar dízimos segundo o costume?

Observa-se o quinto preceito: pagar dízimos segundo o costume, pagando aquelas ofertas ou contribuições, que foram estabelecidas, para reconhecer o supremo domínio que Deus tem sobre todas as coisas, e para sustentar os ministros do altar.