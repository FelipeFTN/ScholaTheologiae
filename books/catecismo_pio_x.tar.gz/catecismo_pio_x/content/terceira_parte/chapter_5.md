## V - <em> Dos deveres particulares do próprio estado e dos conselhos evangélicos </em>

#### 1º - Dos deveres do próprio estado

##### 506 - Que vêm a ser os deveres do próprio estado?

Por deveres do próprio estado entendem-se aquelas obrigações particulares que cada um tem por causa do seu estado, da sua condição e da situação em que se acha.

##### 507 - Quem impôs aos diversos estados os seus deveres particulares?

Foi o mesmo Deus que impôs aos diversos estados os deveres particulares, porque estes derivam dos seus divinos Mandamentos.

##### 508 - Explicai-me com algum exemplo como os deveres particulares derivam dos Dez

Mandamentos No quarto Mandamento, sob o nome de pai e mãe, entendem-se também todos osnossos superiores; assim deste Mandamento derivam todos os deveres de obediência, de amor e de respeito dos inferiores para com os seus superiores e todososdeveresde vigilância que têm os superiores sobre os seus inferiores.

##### 509 - De que Mandamentos derivam os deveres dos operários, dos comerciantes, dos administradores de bens alheios e outros semelhantes?

Os deveres de fidelidade, de sinceridade, de justiça, de eqüidade, que eles têm, derivam do sétimo, do oitavo e do décimo Mandamento, que proíbem toda a fraude, injustiça, negligência e duplicidade.

##### 510 - De que Mandamento derivam os deveres das pessoas consagradas a Deus?

Os deveres das pessoas consagradas a Deus derivam do segundo Mandamento, que manda cumprir os votos e as promessas feitas a Deus; visto como essas pessoas se obrigaram por esta forma à observância de todos ou de alguns conselhos evangélicos.

#### 2º - Dos conselhos evangélicos

##### 511 - Que são os conselhos evangélicos?

Os conselhos evangélicos são alguns meios sugeridos por Jesus Cristo no santo Evangelho, para chegar à perfeição cristã.

##### 512 - Quais são os conselhos evangélicos?

Os conselhos evangélicos são: pobreza voluntária, castidade perpétua e obediência inteira, ein tudo o que não seja pecado.

##### 513 - Para que servem os conselhos evangélicos?

Os conselhos evangélicos servem para facilitar a observância dos Mandamentos e para assegurar melhor a salvação eterna.

##### 514 - Por que os conselhos evangélicos facilitam a observância dos Mandamentos?

Os conselhos evangélicos facilitam a observância dos Mandamentos, porque nos ajudam a desapegar o coração do amor dos bens terrenos, dos prazeres e das honras, e assim nos afastam do pecado.