## III - <em>Dos Mandamentos que se referem ao próximo</em>

#### 1º - Do quarto Mandamento da Lei de Deus

Honra teu pai e tua mãe, como o Senhor teu Deus te mandou, para que vivas longos anos e sejas feliz na terra que o Senhor teu Deus te dá. Deut 5, 16 Meu filho, escuta a advertência de teu pai, e não rejeites o ensino de tua mãe, pois serão diadema para tua cabeça e um colar para teu pescoço. Prov 1, 8-9 Pois o Senhor glorifica o pai em seus filhos e consolida a autoridade da mãe sobre a prole. Quem honra o pai, expia os pecados; quem glorifica a mãe, é como se acumulasse tesouros. Quem honra o pai será alegrado pelos filhos e, no dia em que orar, será atendido. Quem glorifica o pai terá vida longa, e quem obedece ao Senhor proporcionará repouso à sua mãe. Quem teme o Senhor honrará seu pai e, como a senhores, servirá seus genitores. Com obras e palavras honra teu pai, para que venha sobre ti a sua bênção. A bênção do pai consolida a casa dos filhos; a maldição da mãe lhes destrói os alicerces. Não te glories da desonra de teu pai, pois a desonra do pai não é uma glória para ti. A glória do homem vem da honra de seu pai, e é uma desonra para os filhos a mãe desprezada. Filho, ampara teu pai na velhice, e não lhe causes desgosto enquanto vive. Ainda que perca a razão, sê tolerante e não o desprezes, tu, que estás em teu pleno vigor. Não será esquecida a compaixão para com teu pai e, em lugar dos pecados, terás os méritos aumentados. No dia da aflição, o Senhor lembrar-se-á de ti; e teus pecados desaparecerão, como o gelo ao calor do dia. Quem abandona o pai é como blasfemador; e é maldito do Senhor quem irrita sua mãe. Eclo 3, 2-13. Quem amaldiçoa o pai e a mãe verá sua lâmpada apagar-se nas trevas. Prov 20, 20 Maldito, quem desprezar o pai ou a mãe! E todo o povo dirá: Amém! Deut 27, 16 Quando o viram, ficaram admirados e sua mãe lhe disse: Filho, por que agiste assim conosco? Olha, teu pai e eu, aflitos, te procurávamos. Ele respondeu-lhes : Por que me procuráveis? Não sabíeis que eu devia estar na casa do meu Pai? Eles não entenderam o que lhes dizia. Depois desceu com eles e foi para Nazaré, e lhes era submisso. Sua mãe conservava a lembrança de tudo isso no coração. Jesus crescia em sabedoria, idadeegraça diantedeDeusedaspessoas. Luc 2, 48-52

##### 399 - Que nos ordena o quarto Mandamento: honrar pai e mãe?

O quarto Mandamento: honrar pai e mãe, ordena-nos respeitar o pai e a mãe, obedecer-lhes em tudo o que não é pecado, e auxiliá-los em suas necessidades espirituais e temporais.

##### 400 - Que nos proíbe o quarto Mandamento?

O quarto Mandamento proíbe-nos ofender os nossos pais com palavras, obras, ou de qualquer outra maneira.

##### 401 - Debaixo do nome de pai e de mãe, que mais pessoas compreende este Mandamento?

Debaixo do nome de pai e de mãe, este Mandamento também compreende todos os legítimos superiores tanto eclesiásticos como seculares, aos quais portanto devemos obedecer e respeitar.

##### 402 - De onde vem aos pais a autoridade de mandar nos filhos, e aos filhos a obrigação de lhes obedecer?

A autoridade que os pais têm de mandar nos filhos, e a obrigação que têm os filhos de obedecer, vêm-lhes de Deus que constituiu e ordenou a família, a fim de que nela o homem encontre os primeiros meios necessários para o seu aperfeiçoamento material e espiritual.

##### 403 - Têm os pais deveres para com os filhos?

Os pais têm o dever de amar, cuidar e alimentar seus filhos, de prover à sua educação religiosa e civil, de dar-lhes o bom exemplo, de afastá-los das ocasiões de pecado, de corrigi-los nas suas faltas, e de auxiliá-los a abraçar o estado para o qual são chamados por Deus.

##### 404 - Deu-nos Deus o modelo da família perfeita?

Deus nosdeu o modelo da família perfeita na Sagrada Família, na qual JesusCristo viveu sujeito a Maria Santíssima e a São José até aos trinta anos, isto é, até quando começou a desempenhar a missão que o Padre Eterno Lhe confiara, de pregar o Evangelho.

##### 405 - Poderiam as famílias, se vivessem isoladamente uma das outras, prover a todas as suas necessidades materiais e morais?

Se as famílias vivessem isoladamente umas das outras, não poderiam prover às suas necessidades, e é necessário o que elas se unam em sociedade civil, a fim de se auxiliarem mutuamente, para o seu aperfeiçoamento e para sua felicidade comum.

##### 406 - Que é a sociedade civil?

A sociedade civil é a reunião de muitas famílias, dependentesda autoridade de um chefe, para se auxiliarem reciprocamente a conseguir o mútuo aperfeiçoamento e a felicidade temporal

##### 407 - De onde vem à sociedade civil a autoridade que a governa?

A autoridade que governa a sociedade civil vem de Deus, que a quer constituída para o bem comum.

##### 408 - Há obrigação de respeitar a autoridade que governa a sociedade civil e de lhe prestar obediência?

Sim, todos os que pertencem à sociedade civil, têm obrigação de respeitar a autoridade e de lhe obedecer, porque esta autoridade vem de Deus, e porque assim o exige o bem comum.

##### 409 - Devem respeitar-se todas as leis que são impostas pela autoridade civil?

Devem respeitar-se todas as leisque a autoridade civil impõe, desde que não sejam contrárias à Lei de Deus, pois esta é a ordem e o exemplo de Nosso Senhor Jesus Cristo.

##### 410 - Além do respeito e da obediência às leis impostas pela autoridade, os que formam parte da sociedade civil têm mais alguns deveres?

Os que formam parte da sociedade civil, além da obrigação de respeitar e obedecer às leis, têm o dever de viver em harmonia e de procurar, segundo suaspossibilidades, que a sociedade seja virtuosa, pacífica, ordenada e próspera para o proveito comum, com vistas à salvação eterna dos indivíduos.

#### 2º - Do quinto Mandamento da Lei de Deus

Aconteceu, tempos depois, que Caim apresentou ao Senhor frutosda terra como oferta. Abel, por sua vez, ofereceu osprimeiros cordeirinhos e a gordura das ovelhas. E o Senhor olhou para Abel e sua oferta, mas não deu atenção a Caim e sua oferta. Caim se enfureceu e ficou com o rosto abatido. O Senhor disse a Caim: Por que estásenfurecido e andas com o rosto abatido? Não é verdade que, se fizereso bem, andarásde cabeça erguida? Mas se não o fizeres, o pecado não estará à porta, espreitando-te, como um assaltante? Tu, porém, terás de dominá-lo. Caim disse a Abel, o irmão: Vamos para o campo! Mas, quando estavam no campo, Caim agrediu o irmão Abel e o matou. O Senhor perguntou a Caim: Onde está teu irmão Abel? E ele respondeu: Não sei. Acaso sou o guarda de meu irmão? O que fizeste? perguntou ele Ouço da terra a voz do sangue de teu irmão, clamando por vingança! Agora serás amaldiçoado pela própria terra que engoliu o sangue de teu irmão, derramado por ti. Quando cultivares o solo, negar-te-á o sustento e virás a ser um fugitivo, errante sobre a terra. Caim disse ao Senhor : O castigo é grande demaispara suportá-lo. Eis que hoje me expulsasda face deste solo fértil e devo ocultar-me diante de teu rosto. Quando estiver fugindo e vagueando pela terra, quem me encontrar, matar-me-á. Mas o Senhor lhe disse: Pois bem. Se alguém matar Caim, será vingado sete vezes. O Senhor pôs, então, um sinal em Caim para que ninguém, ao encontrá-lo, o matasse. Afastando-se da presença do Senhor, Caim foi habitar na região deNod, ao oriente deÉden. Gênesis 4, 3-16

##### 411 - Que nos proíbe o quinto Mandamento: não matar?

O quinto Mandamento: não matar, proíbe dar a morte ao próximo, nele bater ou feri-lo, ou causar qualquer outro dano no seu corpo, por nós ou por meio de outrem. Proíbe também ofendê-lo com palavras injuriosas e querer-lhe o mal. Neste Mandamento Deus proíbe ainda ao homem dai, a morte a si mesmo, isto é, o suicídio.

##### 412 - Por que é pecado grave matar o próximo?

Porque o que mata usurpa temerariamente o direito que só Deus tem sobre a vida do homem; porque destroi a segurança da sociedade humana, e porque tira ao próximo a vida, que é o maior bem natural que ele tem neste mundo.

##### 413 - Haverá casos em que seja lícito matar o próximo?

É lícito tirar a vida do próximo: durante o combate ein guerra justa; quando se executa por ordem da autoridade suprema a condenação à morte em castigo de algum crime; e finalmente quando se trata de necessária e legítima defesa da vida, no momento de uma injusta agressão.

##### 414 - No quinto Mandamento proíbe também Deus fazer mal à vida espiritual do próximo?

Sim, Deus no quinto Mandamento proíbe também fazer mal à vida espiritual do próximo com o escândalo.

##### 415 - Que é o escândalo?

O escândalo é toda palavra, ação ou omissão, que é ocasião para os outros de cometerem pecados.

##### 416 - É pecado grave o escândalo?

O escândalo é um pecado grave, porque tende a destruir a maior obra de Deus, que é a redenção, com a perda das almas: pois que ele dá ao próximo a morte da alma tirando-lhe a vida da graça, que é mais preciosa que a vida do corpo; e porque é causa de uma multidão de pecados. Por isso, Deus ameaça os escandalosos com os mais severos castigos.

##### 417 - Por que no quinto Mandamento Deus proíbe ao homem dar a morte a si mesmo, isto é, suicidar-se?

No quinto Mandamento Deus proíbe o suicídio, porque o homem não é senhor da sua vida, como o não é da dos outros. A Igreja, por seu lado, castiga o suicida com a privação da sepultura eclesiástica.

##### 418 - É proibido no quinto Mandamento também o duelo?

Sim, o quinto Mandamento proíbe também o duelo, porque o duelo participa da malícia do suicídio e do homicídio, e fica excomungado todo o que voluntariamente nele toma parte, ainda que seja como simples espectador.

##### 419 - É também proibido o duelo, quando é excluído o perigo de morte?

Sim, é também proibido este duelo, porque não só não podemos matar, mas nem sequer ferir voluntariamente a nós mesmos ou a outrem.

##### 420 - Pode a defesa da honra justificar o duelo?

Não. Porque é falso que no duelo se repare a ofensa, e porque não se pode reparar a honra com uma ação injusta, irracional e bárbara, qual é o duelo.

##### 421 - Que nos ordena o quinto Mandamento?

O quinto Mandamento ordena-nos que perdoemos aos nossos inimigos e queiramos bem a todos.

##### 422 - Que deve fazer quem danificou o próximo na vida do corpo, ou na da alma?

Quem danificou o próximo, não basta que se confesse, mas deve também reparar o mal que fez, compensando o próximo dos danos que lhe causou, retratando os erros que lhe ensinou, e dando-lhe bom exemplo.

#### 3º - Do 6º e do 9º

Mandamentos da Lei de Deus

José foi levado para o Egito. Putifar, um egípcio, ministro do Faraó e chefe da guarda do palácio, o comprou dos ismaelitas que o tinham levado para lá. Mas o Senhor estava com José e ele se tornou um homem bem sucedido enquanto esteve na casa de seu senhor egípcio. O patrão notou que o Senhor estava com ele e fazia prosperar todas as suas iniciativas. José conquistou asboasgraçasde seu amo que o pôsa seu serviço, constituindo-o administrador da casa e confiando-lhe todos osbens. E desde o momento em que o fez administrador, o Senhor abençoou em atenção a José a casa do egípcio e derramou sua bênção sobre tudo que possuía em casa e no campo. Ele entregou tudo nas mãosde José e não se preocupava com coisa alguma a não ser com o que comia. Ora, José tinha um belo porte e era formoso de rosto. Aconteceu, depois, que a mulher de seu amo pôs nele os olhos e lhe disse: Dorme comigo. Ele recusou, dizendo à mulher de seu senhor: Em verdade meu senhor não me pede contas do que há na casa, confiando-me todos os bens. Ele próprio não é mais importante do que eu nesta casa. Nada se reservou senão a ti por seres sua mulher. Como poderia eu fazer tamanha maldade pecando contra Deus! E ainda que ela insistisse com José, todos os dias, para dormir com ela ou mesmo estar com ela, ele não atendeu. Um dia José entrou na casa para cumprir as tarefas e nenhum dos empregados estava em casa. A mulher o agarrou pelo manto, dizendo: Dorme comigo. Mas ele largou-lhe nas mãos o manto e fugiu correndo para fora. Vendo que lhe tinha deixado nas mãoso manto e escapado para fora, ela se pôs a gritar e a chamar os empregados, dizendo: Vede! meu marido trouxe este hebreu para abusar de nós. Aproximou-se de mim para dormir comigo, mas pus-me a gritar em voz alta. Quando viu que comecei a gritar por socorro, largou o manto junto a mim e fugiu correndo para fora. A mulher ficou com o manto de José até o marido voltar para casa. Então falou-lhe nos mesmos termos, dizendo: Esse escravo hebreu que nos trouxeste, veio ter comigo e quis abusar de mim. Quando me ouviu gritar por socorro, largou junto de mim o manto e fugiu para fora. Ao ouvir o marido o que dizia a mulher, assim é que me tratou teu escravo, ficou furioso. Mandou prender José e o meteu no cárcere, onde se guardavam os presos do rei. E José ficou no cárcere. Mas o Senhor estava com José e concedeu-lhe seu favor, atraindo-lhe a simpatia do chefe do cárcere. Este confiou a seus cuidados todos os que se achavam presos. Era ele que organizava tudo que lá se fazia. O chefe da prisão não se preocupava com coisa alguma que lhe fora confiada, porque o Senhor estava com José e fazia prosperar tudo o que ele fazia. Gênesis 39, 1-23

##### 423 - Que nos proíbe o sexto Mandamento: não pecar contra a castidade?

O sexto Mandamento: não pecar contra a castidade, proíbe qualquer ação, palavra ou olhar contrários à santa pureza, e a infidelidade no matrimônio.

##### 424 - Que nos proíbe o nono Mandamento?

O nono Mandamento proíbe expressamente todo o desejo contrário à fidelidade que os cônjuges se juraram ao contrair matrimônio; e proíbe também todo o pensamento culpável e todo desejo de ação proibida pelo sexto Mandamento.

##### 425 - É um grande pecado a impureza?

É um pecado gravíssimo e abominável diante de Deus e dos homens; rebaixa o homem à condição dos irracionais, arrasta-o a muitos outros pecados e vícios, e provoca o, mais terríveis castigos de Deus nesta vida e na outra.

##### 426 - São pecados todos os pensamentos que nos vêm ao espírito contra a pureza?

Os pensamentos que nos vêm ao espírito contra ti pureza, por si mesmos não são pecados, mas antes tentações e incentivos ao pecado.

##### 427 - Quando são pecados os maus pensamentos?

Osmauspensamentos, ainda que não sejam seguidosde ação, são pecados, quando culpavelmente lhes damosmotivo, ou neles consentimos, ou nos expomos ao perigo próximo de neles consentir.

##### 428 - Que nos ordenam o sexto e o nono Mandamentos?

O sexto Mandamento ordena-nos que sejamos castos e modestos nas ações, nos olhares, no porte e nas palavras. O nono Mandamento ordena-tios que sejamos castos e puros, ainda mesmo tio nosso íntimo, isto é, tia alma e no coração.

##### 429 - Que devemos fazer para observar o sexto e o nono Mandamentos?

Para bem observarmoso sexto e o nono Mandamentos, devemos invocar freqüenternente e de todo o coração a Deus, ser devotos de Maria Virgem, Mãe da pureza, lembrar-nos de que Deus nos vê, pensar ria morte, nos castigos divinos, tia Paixão de Jesus Cristo, guardar os nossos sentidos, praticar a mortificação cristã, e freqüentar os sacramentos corri as devidas disposiçoes.

##### 43O Que devemos evitar para nos conservarmos castos?

Para nos conservarmos castos, devemos evitar a ociosidade, os maus companheiros, as más leituras, a intemperança, o olhar para figuras indecentes, osespetáculos licenciosos, osbailes, as conversase diversõesperigosas, bem como todas asdemaisocasiões de pecado.

#### 4º - Do sétimo Mandamento da Lei de Deus

Jesus entrou em Jericó e atravessava a cidade. Havia ali um homem rico, chamado Zaqueu, chefe dos cobradores do imposto. Procurava ver Jesus, mas não conseguia por causa da multidão, pois era muito baixo. Correndo na frente, subiu numa figueira brava para vê-lo, pois tinha de passar por ali. Ao chegar ao lugar, Jesus olhou para cima e disselhe: Zaqueu, desce depressa, poishoje devo ficar em tua casa. Ele desceu a toda pressa e o recebeu com alegria. Ao ver isso, todos começaram a resmungar: Ele foi hospedar-se na casa de um pecador. Zaqueu entretanto, de pé, disse ao Senhor: Senhor, vou dar a metade dos meus bens aospobres e, se em alguma coisa prejudiquei alguém, vou restituir quatro vezes mais. Disse-lhe Jesus: Hoje a salvação entrou nesta casa porque também este é um filho deAbraão. Poiso Filho do homem veio procurar e salvar o que estava perdido. Luc 19, 1-9

##### 431 - Que nos proíbe o sétimo Mandamento: não furtar?

O sétimo Mandamento: não furtar, proíbe tirar ou reter injustamente as coisas alheias, e causar dano ao próximo nos seus bens de qualquer outro modo.

##### 432 - Que quer dizer furtar?

Furtar quer dizer: tirar injustamente as coisas alheias contra a vontade do dono, quando ele tem toda a razão e todo o direito de não querer ser privado do que lhe pertence.

##### 433 - Por que se proíbe o furtar?

Porque se peca contra a justiça, e se faz injúria ao próximo, tirando e retendo, contra o seu direito e contra a sua vontade, o que lhe pertence.

##### 434 - Que são as coisas alheias?

São todas as coisas que pertencem ao próximo, das quais tem a propriedade ou o uso, ou simplesmente as tem em depósito.

##### 435 - De quantos modos se tiram injustamente as coisas alheias?

De dois modos: com o furto e com o roubo.

##### 436 - Como se comete o furto?

Comete-se o furto tirando ocultamente as coisas alheias.

##### 437 - Como se comete o roubo?

Comete-se o roubo tirando com violência ou manifestamente as coisas alheias.

##### 438 - Em que casos se podem tirar as coisas alheias, sem cometer pecado?

Quando o dono se não opõe, ou então, quando se opõe injustamente, como aconteceria se alguém estivesse em extrema necessidade, contanto, que tirasse só o que lhe é estritamente necessário para suprir à necessidade urgente e extrema.

##### 439 - È só com o furto e com o roubo que se prejudica o próximo nos seus bens?

Prejudica-se também com a fraude, com a usura e com outra qualquer injustiça contra os seus bens.

##### 44O Como se comete a fraude?

Comete-se a fraude enganando o próximo no comércio com pesos, medidas ou moedas falsas, ou com gêneros deteriorados; falsificando escrituras e documentos; em suma, fazendo falsidades nas compras, nas vendas ou em qualquer outro contrato, e ainda quando se não quer dar o preço justo ou o preço combinado.

##### 441 - De que modo se comete a usura?

Comete-se a usura exigindo sem titulo legítimo um juro ilícito por uma quantia emprestada, abusando da necessidade ou da ignorância do próximo.

##### 442 - Que outras injustiças se cometem contra os bens do próximo?

São injustiças fazê-lo perder injustamente o que tem, danificá-lo nas suas propriedades, não trabalhar como se deve, não pagar, por malícia, asdívidase mercadorias compradas, ferir ou matar osanimaisdo próximo, estragar ou deixar estragar-se o que se tem em depósito, impedir alguém de auferir um lucro justo, auxiliar os ladrões, e receber, esconder ou comprar as coisas roubadas.

##### 443 - É pecado grave roubar?

É um pecado grave contra a justiça quando se trata de matéria grave, porque é de suma importância que seja respeitado o direito que cada um tem sobre os próprios bens, e isto para bem dos indivíduos, das famílias e da sociedade.

##### 444 - Quando é grave a matéria do furto?

É grave quando se tira coisa importante, e ainda quando, tirando-se coisa de pouca monta, o próximo sofre com isso grave dano.

##### 445 - Que nos ordena o sétimo Mandamento?

O sétimo Mandamento ordena-nos que respeitemos as coisas alheias, que paguemos o justo salário aos operários, e que observemos a justiça ein tudo o que se refere à propriedade alheia.

##### 446 - Quem pecou contra o sétimo Mandamento, basta que se confesse disso?

Quem pecou contra o sétimo Mandamento, não basta que se confesse, mas é necessário que faça o que puder para restituir as coisas alheias e reparar os danos causados ao próximo.

##### 447 - Que é a reparação dos danos causados?

A reparação dos danos causados é a compensação que se deve dar ao próximo pelos frutos e lucros perdidos por causa do furto e das outras injustiças cometidas ein seu prejuízo.

##### 448 - A quem se devem restituir as coisas roubadas?

Àquele a quem se roubaram; aos seus herdeiros, se já tiver morrido; e se isso for verdadeiramente impossível. deve-se dar o seu valor aos pobres e a obras pias.

##### 449 - Que se deve fazer, quando se acha alguma coisa de grande valor?

Deve-se empregar grande diligência para achar o dono, e restituir-lhe fielmente.

#### 5º - Do oitavo Mandamento da Lei de Deus

Em Babilônia vivia um homem de nome Joaquim. Estava casado com uma senhora chamada Susana filha de Helcias, que era muito bonita e religiosa. Também seus pais eram pessoas justas e tinham educado a filha de acordo com a Lei de Moisés. Joaquim era muito rico e tinha um parque confinante com sua casa; junto dele afluíam os judeus, por ser o mais respeitado de todos. Ora, naquele ano dois anciãos do povo tinham sido apontados como juízes, a respeito dos quais o Senhor tinha dito: De Babilônia brotou a iniqüidade, da parte de anciãos-juízes que aparentemente governavam o povo. Eles freqüentavam a casa de Joaquim, e todos os que tinham alguma questão se dirigiam a eles. Ora, quando pelo meio-dia o povo se tinha dispersado, Susana ia passear no parque do marido. Os dois anciãos viam-na todos os dias entrar e passear, e acabaram se apaixonando por ela. Fizeram o contrário do que deveriam ter feito, evitando erguer os olhos para o Céu e esquecendo os justos juízos de Deus. Embora ambos se sentissem perdidamente apaixonadospor ela, contudo um não traía ao outro o seu sofrimento, porque ainda sentiam vergonha de manifestar o desejo ardente de a possuir. Todos os dias espreitavam avidamente por vê-la. Certo dia um disse ao outro: Vamos para casa, é hora de almoço! Mas quando saíram e se separaram um do outro, deram um giro, acabando por encontrar-se no mesmo ponto... Forçados portanto a se explicar, finalmente confessaram um ao outro sua paixão; então combinaram espreitar uma eventual ocasião de a encontrar a sós. Ora, enquanto os dois estavam à espreita duma ocasião favorável, certo dia Susana entrou no parque segundo seu costume, acompanhada apenas por duas mocinhas; é que queria tomar banho por causa do calor intenso. Não havia lá ninguém, exceto os dois velhos que estavam escondidos e a espreitavam. Então ela ordenou àsmocinhas: Por favor, ide buscar-me azeite e perfumes e trancai as portas do parque, enquanto tomo banho! Elas obedeceram, trancando as portas do parque e retirando- se por uma porta lateral, para buscar o que a patroa tinha pedido, sem se darem conta que os velhos estavam lá escondidos. Apenas as duas mocinhas tinham saído, os dois velhos se levantaram e correram para Susana, dizendo: Olha, as portas do parque estão trancadas e ninguém nos vê; nós estamos apaixonados por ti: faze-nos a vontade e entrega-te a nós! Caso contrário, nós deporemos contra ti que um moço estava contido e foi por isso que mandaste embora asmeninas. Então Susana deu um suspiro, exclamando: Vejo-me encurralada de todos os lados. Pois se fizer isto, espera-me a morte, mas se não o fizer, não escaparei das vossas mãos. Contudo prefiro cair inocente em vossas mãos a pecar na presença do Senhor. Então ela se pôs a gritar em altas vozes, mas também os dois velhos gritaram contra ela. Um deles correu para as portas do parque e as abriu. Quando a gente da casa ouviu a gritaria no parque, precipitaram-se pela porta dos fundos para ver o que lhe estaria sucedendo. Mas quando os velhos apresentaram a sua versão dos fatos, os empregados ficaram muito constrangidos, porque jamais se tinha ouvido falar de qualquer deslize de Susana. Quando no dia seguinte o povo se reuniu em casa do seu marido Joaquim, os dois anciãos vieram animados pela intenção criminosa de conseguir sua condenação à morte; por isso se dirigiram ao povo reunido: Mandai comparecer a Susana filha de Helcias, mulher de Joaquim! Mandaram-na portanto chamar. Ela compareceu em companhia dos pais e filhos e de todos os parentes. Ora, Susana era mulher de aparência exuberante e de extraordinária beleza. Como ela se apresentasse com o rosto velado, os dois malvados mandaram tirar-lhe o véu, para se embriagarem da sua beleza. Seus familiares e todos os parentes choravam. Os dois velhos se levantaram no meio do povo e puseram as mãos sobre a cabeça de Susana. Mas, entre lágrimas, ela olhou para o céu, pois seu coração tinha confiança no Senhor. Em seguida osanciãos deram este depoimento: Enquanto estávamos passeando a sós no parque, esta mulher entrou com duasmocinhase mandou fechar asportasdo parque, para depois mandá-las embora. Então um moço, que estava escondido, aproximou-se dela e com ela se deitou. Quando nós, do canto do parque onde estávamos, vimos esta infâmia, corremos para eles e os surpreendemos juntos. Não conseguimos, é verdade, agarrar o moço, porque era mais forte que nós, e assim abriu as portas e sumiu. A esta mulher, porém, agarramose lhe perguntamos, quem era aquele moço. Mas ela não o quis revelar. Disto nós damos testemunho. A assembléia lhes deu crédito como a anciãos do povo e juízes que eram, e a condenou à morte. Susana, porém, gritou em alta voz e rezou: Ó Deus eterno que conheces os segredos e sabes tudo antes que aconteça, tu bem sabes que elesproferiram falso testemunho contra mim! Eisque vou morrer, embora não tenha cometido o crime do qual maldosamente me acusam! E o Senhor escutou a sua voz. Enquanto Susana estava sendo conduzida para a execução, o Senhor excitou o santo espírito dum jovem de nome Daniel, e ele gritou em altas vozes: Sou inocente do sangue desta pessoa! Então todo o povo se voltou para ele e perguntou: O que queres dizer com isto? De pé, no meio deles, elerespondeu: Então soistão insensatosassim, israelitas? Sem inquérito sério e sem provas concludentes condenastes uma filha de Israel! Voltai ao tribunal, por que estes malvados deram falso testemunho contra ela! Então todo o povo voltou apressadamente, e os anciãos convidaram a Daniel, dizendo: Tem a bondade de tomar lugar em nosso meio e presta-nos o teu depoimento, pois Deus te concedeu o privilégio da idade. Daniel lhes disse: Separai-os longe um do outro, para os poder submeter a interrogatório! Quando foram separados um do outro, Daniel chamou a um deles e lhe disse: Velho encarquilhado e cheio de crimes! Agora vêm à luz os pecados que cometias antes, proferindo sentenças injustas, condenando os inocentes e absolvendo os culpados, quando o Senhor ordena: Ao inocente e ao justo não os matarás! Poisbem! Se a viste tão bem, dize-me à sombra de qual árvore os viste abraçados? O outro respondeu: À sombra duma aroeira. Daniel respondeu: Mentiste direto contra tua cabeça, pois o anjo de Deus já recebeu dele ordem de te cortar pelo meio! Tendo-o despedido, mandou vir o outro e lhe disse: Raça de Canaã e não de Judá! A beleza te fascinou e a paixão perverteu teu coração. É assim que procedíeis com as mulheres israelitas, e elaspor medo vos faziam a vontade; mas esta mulher judia não suportou vossa iniqüidade. Ora bem! Dize-me debaixo de que árvore os surpreendeste a se entreterem? Ele respondeu: Foi debaixo duma azinheira. Daniel lhe respondeu: Também tu mentiste diretamente contra tua cabeça! Pois o anjo de Deus já está à espera, com a espada na mão, para te cortar ao meio e dar cabo devós. Toda a assistência pôs-se a gritar em voz alta, dando graças a Deus que salva os que nele esperam. Voltaram-se contra os dois velhos, porque Daniel os tinha convencido por suas próprias palavras que eram falsas testemunhas. Segundo a Lei de Moisés, aplicaram-lhes a pena que maldosamente tinham tramado contra o próximo, e os mandaram matar. Desta maneira, naquele dia foi salva uma vida inocente. Helcias e sua mulher louvaram a Deus por causa da sua filha e o mesmo fizeram Joaquim, esposo de Susana, e todos os seus familiares; eles louvaram a Deus, porque nela não foi achada qualquer coisa que merecesse reprovação. Dan 13, 1-62

##### 450 - Que nos proíbe o oitavo Mandamento: não levantar falso testemunho?

O oitavo Mandamento: não levantar falso testemunho, proíbe-nos atestar falsidade em juízo; proíbe também a detração ou murmuração, a calúnia, a adulação, o juízo e a suspeita temerários, e toda espécie de mentiras.

##### 451 - Que é a detração ou murmuração?

A detração ou murmuração é um pecado que consiste em manifestar, sem justo motivo, os pecados ou defeitos alheios.

##### 452 - Que é a calúnia?

A calúnia é um pecado que consiste em atribuir maliciosamente ao próximo culpas e defeitos que não tem.

##### 453 - Que é a adulação?

A adulação é um pecado que consiste em enganar urna pessoa, dizendo-lhe falsamente bem dela mesma ou de outra, com o fim de tirar daí algum proveito.

##### 454 - Que é o juízo ou suspeita temerária?

O juízo ou suspeita temerária é um pecado que consiste em julgar ou suspeitar mal dos outros, sem justo fundamento.

##### 455 - Que é a mentira?

A mentira é um pecado que consiste em afirmar como verdadeiro ou como falso, por meio de palavras ou de ações, o que se julga não ser assim.

##### 456 - De quantas espécies é a mentira?

A mentira é de três espécies: jocosa, oficiosa e nociva.

##### 457 - Que é a mentira jocosa?

Mentira jocosa é aquela pela qual se mente por gracejo e sem prejuízo para ninguém.

##### 458 - Que é a mentira oficiosa?

Mentira oficiosa é a afirmação de urna falsidade para utilidade própria ou alheia, sem prejuízo para ninguém.

##### 459 - Que é a mentira nociva?

Mentira nociva é a afirmação de uma falsidade com prejuízo do próximo.

##### 460 - É lícito alguma vez mentir?

Nunca é lícito mentir nem por gracejo, nem para proveito próprio ou alheio, porque é coisa má por si mesma.

##### 461 - Que pecado é a mentira?

A mentira, quando é jocosa ou oficiosa, é pecado venial; mas, quando é nociva, é pecado mortal, se o prejuízo que causa é grave.

##### 462 - É necessário dizer sempre tudo conforme se pensa?

Não. Nem sempre é necessário, especialmente quando quem pergunta não tem o direito de saber o que pergunta.

##### 463 - Quem pecou contra o oitavo Mandamento, basta que se confesse?

Quem pecou contra o oitavo Mandamento, não basta que confesse o seu pecado, masé também obrigado a retratar tudo o que disse caluniando o próximo, e a reparar, do melhor modo que possa, os danos que lhe causou.

##### 464 - Que nos ordena o oitavo Mandamento?

O oitavo Mandamento ordena-nos que digamos oportunamente a verdade, e que interpretemos em bom sentido, tanto quanto pudermos, as ações do nosso próximo.

#### 6º - Do décimo Mandamento da Lei de Deus

Eis o que se passou depois destes acontecimentos: Nabot de Jezrael possuía uma vinha em Jezrael ao lado do palácio de Acab, rei de Samaria. Acab falou com Nabot: Cede-me a tua vinha para que me sirva de horta, pois ela está bem perto da minha casa, e eu te darei uma vinha melhor, ou se preferires, posso pagar-te o preço em dinheiro. Mas Nabot respondeu a Acab: Deusme livre de entregar-te a herança de meuspais! Acab voltou para casa contrariado e furioso, por causa da resposta que Nabot de Jezrael lhe tinha dado, negando-se a lhe ceder a herança de seus pais. O rei se jogou na cama, virou o rosto e não quis comer. Sua esposa Jezabel entrou no quarto e lhe perguntou: Por que estás tão mal-humorado e não queres comer? Ele lhe respondeu: É que tive uma conversa com Nabot de Jezrael e lhe fiz a proposta de me ceder a sua vinha por dinheiro, ou se o preferisse, eu lhe daria em troca outra vinha. Mas o homem me respondeu que não me cede a vinha. Sua esposa Jezabel lhe disse: Bela figura de rei de Israel estás fazendo! Levanta-te, toma alimento e fica de bom humor! Eu te arranjarei a vinha de Nabot de Jezrael. Em seguida ela escreveu uma carta em nome de Acab, selou-a com o selo do rei e a enviou aos anciãos e nobres da cidade que moravam com Nabot. Na carta ela escrevia como segue: Proclamai um jejum e colocai Nabot na primeira fila. Fazei sentarem-se em frente dele dois cafajestes que dêem este depoimento: Tu amaldiçoastea Deuse ao rei! Depois conduzi-o para fora e apedrejai-o atémorrer. Os homens da cidade, anciãos e nobres, seus concidadãos, procederam conforme a ordem recebida de Jezabel, como estava escrito na carta que lhes tinha enviado. Proclamaram um jejum e deram a Nabot o primeiro lugar na assembléia. Chegaram também os dois cafajestes e se sentaram na frente dele. Os dois cafajestes acusaram a Nabot na presença do povo, nestes termos: Nabot amaldiçoou a Deus e ao rei! Em seguida o conduziram para fora da cidade e o apedrejaram até morrer. Então avisaram a Jezabel: Nabot foi apedrejado emorreu. Ao saber que Nabot tinha sido apedrejado e estava morto, Jezabel disse a Acab: Levanta-te e toma posse da vinha que Nabot de Jezrael não te quis vender, pois Nabot não está mais vivo; ele morreu. Quando Acab soube que Nabot estava morto, levantou-se para descer até a vinha de Nabot de Jezrael e dela tomar posse. As ameaças de Elias. Então a palavra do Senhor foi dirigida ao tesbita Eliasnestestermos: Levanta-te, desce ao encontro de Acab, rei de Israel, que reside em Samaria. Olha, ele está na vinha de Nabot, aonde desceu para dela tomar posse. Fala-lhe neste teor: Assim fala o Senhor: Tu és um assassino e por cima ladrão! E lhe falarás nestes termos: Assim fala o Senhor: No mesmo lugar onde os cães lamberam o sangue de Nabot, lamberão também o teu próprio sangue! Acab respondeu a Elias: Quer dizer que me surpreendeste, meu inimigo? Ele respondeu: Sim, surpreendi! Porque te prestaste para praticar o que desagrada ao Senhor, eisque vou trazer para ti desgraças. Vou varrer-te, exterminando em Israel todas as pessoas do sexo masculino da família de Acab, escravos e livres. Tratarei tua família como as famílias de Jeroboão filho de Nabat, e de Baasa filho de Aías, porque me causaste irritação e seduziste Israel ao pecado. Também a respeito de Jezabel o Senhor falou assim: Os cachorros devorarão a Jezabel na propriedade de Jezrael. Os membros da família de Acab que morrerem na cidade, serão devorados pelos cachorros, e os que morrerem na campanha, serão comidospelasavesdo céu. I Reis 21, 1-23

##### 465 - Que nos proíbe o décimo Mandamento: não cobiçar as coisas alheias?

O décimo Mandamento: não cobiçar as coisas alheias, proíbe o desejo de privar o próximo dos seus bens, e o desejo de adquirir bens por meios injustos.

##### 466 - Por que Deus proíbe o desejo dos bens alheios?

Deus proíbe-nos o desejo dos bens alheios, porque Ele quer que nós, até interiormente, sejamos justos, e nos conservemos cada vez mais afastados das ações injustas.

##### 467 - Que nos ordena o décimo Mandamento?

O décimo Mandamento ordena-nos que nos contentemos com o estado em que Deus nos colocou, e que soframos com paciência a pobreza, quando Deus nos queira neste estado.

##### 468 - Como pode o cristão estar contente na pobreza?

O cristão pode estar contente mesmo na pobreza, considerando que o maior de todos os bens é a consciência pura e tranqüila, que a nossa verdadeira pátria é o céu, e que Jesus Cristo se fez pobre por amor de nós, e prometeu um prêmio especial a todos aqueles que suportam com paciência a pobreza.