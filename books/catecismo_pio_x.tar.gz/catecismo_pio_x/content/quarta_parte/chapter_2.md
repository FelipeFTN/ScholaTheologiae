## II - <em>Do Batismo</em>

#### 1º - Natureza e efeitos do Batismo

##### 549 - Que é o Sacramento do Batismo?

O Batismo é o Sacramento pelo qual renascemos para a graça de Deus, e nos tornamos cristãos.

##### 550 - Quais são os efeitos do Sacramento do Batismo?

O Sacramento do Batismo confere a primeira graça santificante, que apaga o pecado original e também o atual, se o há; perdoa toda a pena por eles devida; imprime o caráter de cristão; faz-nos filhos de Deus, membros da Igreja e herdeiros do Paraíso, e torna-nos capazes de receber os outros Sacramentos.

##### 551 - Qual é a matéria do Batismo?

A matéria do Batismo é a água natural, que se derrama sobre a cabeça do que é batizado, de maneira que escorra.

##### 552 - Qual é a forma do Batismo?

A forma do Batismo é esta: Eu te batizo em nome do Pai e do Filho e do Espírito Santo.

#### 2º - Ministro do Batismo

##### 553 - A quem compete batizar?

Batizar compete por direito aosBispose aospárocos; mas, em caso de necessidade, qualquer pessoa pode batizar, seja homem ou seja mulher, e até um herege ou um infiel, contanto que realize o rito do Batismo e tenha intenção de fazer o que faz a Igreja.

##### 554 - Se houver necessidade de batizar uma pessoa que está em perigo de morte, e estiverem muitas pessoas presentes, quem é que deverá batizar?

Se houver necessidade de batizar alguém em perigo de morte, e estiverem muitas pessoas presentes, deverá batizá-lo o Sacerdote, se lá estiver; na sua falta, um eclesiástico de ordem inferior, e na falta deste, o leigo homem de preferência à mulher, a não ser que a perícia maior da mulher ou a decência exijam o contrário.

##### 555 - Que intenção deve ter quem batiza?

Quem batiza deve ter a intenção de fazer o que faz a Santa Igreja ao batizar.

#### 3º - Rito do Batismo e disposições de quem o recebe já adulto

##### 556 - Como se batiza?

Batiza-se derramando água sobre a cabeça do batizando, ou, não podendo ser sobre a cabeça, sobre qualquer outra parte principal do corpo, e dizendo ao mesmo tempo: Eu te batizo em nome do Pai e do Filho e do Espírito Santo.

##### 557 - Se alguém derramasse a água e outro proferisse as palavras, a pessoa ficaria batizada?

Se alguém derramasse a água, e outro proferisse as palavras, a pessoa não ficaria batizada; é necessário que seja a mesma pessoa que derrame a água e pronuncie as palavras.

##### 558 - Quando se duvida se a pessoa está morta, deve-se deixar de batizá-la?

Quando se duvida se a pessoa está morta, deve-se batizá-la sob condição, dizendo: Se estás vivo, eu te batizo em nome do Pai e do Filho e do Espírito Santo.

##### 559 - Quando se devem levar à Igreja as crianças para serem batizadas?

As crianças devem ser levadas à Igreja para serem batizadas, o mais cedo possível.

##### 560 - Por que se deve ter tanta solicitude em levar as crianças ao Batismo?

Deve-se ter suma solicitude em levar a batizar as crianças, porque elas pela sua tenra idade estão expostas a muitos perigos de morrer, e não podem salvar-se sem o Batismo.

##### 561 - Pecam então os pais e as mães que, pela sua negligência, deixam morrer os filhos sem Batismo ou simplesmente demoram em fazê-lo?

Sim, os pais e as mães, que pela sua negligência deixam morrer os filhos sem Batismo, pecam gravemente, porque os privam da vida eterna; e pecam também gravemente, demorando muito tempo o Batismo, porque os expõem ao perigo de morrer sem o terem recebido.

##### 562 - Quando o que se batiza é adulto, que disposições deve ter?

O adulto que se batiza deve ter, além da fé, a dor, pelo menos imperfeita, dos pecados mortais que tivesse cometido.

##### 563 - Se um adulto se batizasse em pecado mortal, sem esta dor, que receberia?

Se um adulto se batizasse em pecado mortal, sem esta dor, receberia o caráter do Batismo, mas não a remissão dos pecados, nem a graça santificante; e estes efeitos ficariam suspensos, enquanto não fosse removido o impedimento pela dor perfeita dos pecados ou pelo Sacramento da Penitência.

#### 4º - Necessidade do Batismo e deveres dos batizados

##### 564 - É o Batismo necessário para a salvação?

O Batismo é absolutamente necessário para a salvação, porque o Senhor disse expressamente: Quem não renascer na água e no Espírito Santo, não poderá entrar no reino dos céus.

##### 565 - Pode suprir-se de algum modo a falta do Batismo?

A falta do Batismo pode supri-la o martírio, que se chama Batismo de sangue, ou um ato de amor perfeito de Deus, ou de contrição, junto com o desejo, ao menos implícito, do Batismo, e este ato chama-se Batismo de desejo.

##### 566 - A que fica obrigado quem recebe o Batismo?

Quem recebe o Batismo, fica obrigado a professar sempre a fé e a observar a lei de Jesus Cristo e da sua Igreja.

##### 567 - A que se renuncia ao receber o santo Batismo?

Ao receber o santo Batismo renuncia-se para sempre ao demônio, às suas obras e às suas pompas.

##### 568 - Que se entende por obras e pompas do demônio?

Por obras e pompas do demônio, entendem-se os pecados e as máximas do mundo, contrárias às máximas do Santo Evangelho.

#### 5º - Nome e padrinhos

##### 569 - Por que se impõe o nome de um Santo ao que se batiza?

Ao que se batiza, impõe-se o nome de um Santo, para o pôr sob a especial proteção de um padroeiro celeste, e para o animar a imitar-lhe os exemplos.

##### 570 - O que são os padrinhos e as madrinhas do Batismo?

Ospadrinhose asmadrinhasdo Batismo são aquelaspessoasque por disposição da Igreja seguram as crianças junto à pia batismal, respondem por elas, e ficam responsáveis, diante de Deus, pela educação cristã das mesmas, especialmente se vierem a faltar os pais.

##### 571 - Somos nós obrigados a cumprir as promessas e renúncias que por nós fizeram nossos padrinhos?

Sim, somos obrigados, sem dúvida, a cumprir as promessas e renúncias que por nós fizeram os nossos padrinhos, porque Deus, só mediante estas condições, nos recebeu na sua graça.

##### 572 - Que pessoas se devem escolher para padrinhos e madrinhas?

Devem escolher-se para padrinhos e madrinhas pessoas católicas e de bons costumes, e observantes das leis da Igreja.

##### 573 - Quais são as obrigações dos padrinhos e das madrinhas?

Os padrinhos e as madrinhas são obrigados a cuidar que os seus filhos espirituais sejam instruídos nas verdades da fé, e vivam como bons cristãos, edificando-os com o bom exemplo.

##### 574 - Que vínculo contraem os padrinhos do Batismo?

Os padrinhos contraem um parentesco espiritual com o batizado, e este parentesco origina impedimento de matrimônio com o mesmo.