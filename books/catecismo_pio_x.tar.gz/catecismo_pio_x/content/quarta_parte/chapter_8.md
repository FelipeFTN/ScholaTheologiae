## VIII - <em>Da Ordem</em>

##### 811 - Que é o Sacramento da Ordem?

A Ordem é o Sacramento que dá o poder de exercitar os ministérios sagrados que se referem ao culto de Deus e à salvação das almas, e que imprime na alma de quem o recebe o caráter de ministro de Deus.

##### 812 - Por que se chama Ordem?

Chama-se Ordem porque consiste em vários graus, uns subordinados aos outros, dos quais resulta a sagrada Hierarquia.

##### 813 - Quais são estes graus?

Supremo entre eles é o Episcopado, que contém a plenitude do Sacerdócio; em seguida o Presbiterado ou Sacerdócio simples; depois o Diaconado e as Ordens que se chamam menores.

##### 814 - Quando Jesus Cristo instituiu a Ordem Sacerdotal?

Jesus Cristo instituiu a Ordem Sacerdotal na Última Ceia, quando conferiu aos Apóstolos e aos seus sucessores o poder de consagrar a Santíssima Eucaristia. E no dia da sua ressurreição conferiu aos mesmos o poder de perdoar e de reter os pecados, constituindoos assim os primeiros Sacerdotes da Nova Lei em toda a plenitude do seu poder.

##### 815 - Quem é o ministro deste Sacramento?

O ministro deste Sacramento é só o Bispo.

##### 816 - É então grande a dignidade do Sacerdócio cristão?

A dignidade do Sacerdócio cristão é muito grande, pelo duplo poder que lhe conferiu Jesus Cristo sobre o seu Corpo real e sobre o seu Corpo místico, que é a Igreja, e pela divina missão, confiada aos Sacerdotes, de conduzir todos os homens à vida eterna.

##### 817 - É necessário o Sacerdócio católico na Igreja?

O Sacerdócio católico é necessário na Igreja, porque sem ele os fiéis estariam privados do Santo Sacrifício da Missa e da maior parte dos Sacramentos; não teriam quem os instruísse na fé, e ficariam como ovelhas sem pastor à mercê dos lobos; em suma, não existiria a Igreja como Cristo a instituiu.

##### 818 - Então não acabará nunca o Sacerdócio católico sobre a terra?

O Sacerdócio católico, não obstante a guerra que contra ele move o Inferno, há de durar até o fim dos séculos, porque Jesus Cristo prometeu que as potências do Inferno não prevaleceriam jamais contra a sua Igreja.

##### 819 - Será pecado desprezar os Sacerdotes?

É pecado gravíssimo, porque o desprezo e as injúrias que se dirigem contra osSacerdotes recaem sobre o próprio Jesus Cristo, que disse aos seus Apóstolos: Quem a vós despreza, a Mim despreza.

##### 820 - Qual deve ser o fim de quem abraça o estado eclesiástico?

O fim de quem abraça o estado eclesiástico deve ser unicamente a glória de Deus e a salvação das almas.

##### 821 - Que é necessário para entrar no estado eclesiástico?

Para entrar no estado eclesiástico é necessário, antes de tudo, a vocação divina.

##### 822 - Que deve fazer o cristão para conhecer se Deus o chama ao estado eclesiástico?

Para conhecer se Deus o chama ao estado eclesiástico, o cristão deve:

<ul>
  <li>
    1º - pedir fervorosamente a Nosso Senhor que lhe manifeste qual é a sua
    vontade;
  </li>
  <li>
    2º - tomar conselho com o próprio Bispo ou com um diretor sábio e prudente;
  </li>
  <li>
    3º - examinar com diligência se tem a aptidão necessária para os estudos,
    para os ministérios e para as obrigações desse estado.
  </li>
</ul>

##### 823 - Quem entrasse para o estado eclesiástico, sem vocação divina, faria mal?

Quem entrasse para o estado eclesiástico, sem ser chamado por Deus, faria um mal muito grave e colocar-se-ia em risco de se perder.

##### 824 - Fazem mal os pais que, por motivos temporais, induzem os filhos a abraçar o estado eclesiástico sem vocação?

Os pais que, por motivos temporais, induzem os filhos a abraçar o estado eclesiástico sem vocação, cometem também culpa gravíssima, porque com isto usurpam o direito que Deus reservou exclusivamente para Si de escolher os seus ministros, e porque põem os filhos em risco de condenação eterna.

##### 825 - Quais são os deveres dos fiéis para com aqueles que são chamados às ordens sacras?

Os fiéis devem:

<ul>
  <li>
    1º - deixar aos seus filhos e subordinados plena liberdade de seguir a
    vocação divina;
  </li>
  <li>
    2º - pedir a Deus que se digne conceder à sua Igreja bonsPastores e
    ministros zelosos; e até foram instituídos para este fim os jejuns das
    Quatro Têmporas;
  </li>
  <li>
    3º - ter um respeito singular a todos aqueles que, por meio das Ordens, são
    consagrados ao serviço de Deus.
  </li>
</ul>