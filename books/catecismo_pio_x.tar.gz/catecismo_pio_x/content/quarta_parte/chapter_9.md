## IX - <em>Do Matrimônio</em>

#### 1º - Natureza do Sacramento do Matrimônio

##### 826 - Que é o Sacramento do Matrimônio?

O Matrimônio é um Sacramento instituído por Nosso Senhor Jesus Cristo, que estabelece uma união santa e indissolúvel entre o homem e a mulher, e lhes dá a graça de se amarem um ao outro santamente, e de educarem cristãmente seus filhos.

##### 827 - Por quem foi instituído o Matrimônio?

O Matrimônio foi instituído pelo próprio Deus no Paraíso terrestre; e no Novo Testamento foi elevado por Jesus Cristo à dignidade de Sacramento.

##### 828 - Tem o Sacramento do Matrimônio alguma significação especial?

O Sacramento do Matrimônio significa a união indissolúvel de Jesus Cristo com a Santa Igreja, sua esposa e nossa Mãe amantíssima.

##### 829 - Por que se diz que o vínculo do Matrimônio é indissolúvel?

Diz-se que o vínculo do Matrimônio é indissolúvel, isto é, que não se pode quebrar senão pela morte de um dos cônjuges, porque assim o estabeleceu Deus desde o começo, e assim o proclamou solenemente Jesus Cristo, Senhor Nosso.

##### 830 - No Matrimônio cristão, poder-se-ia separar o contrato do Sacramento?

Não. No Matrimônio entre cristãos o contrato não se pode separar do Sacramento, porque para eles o Matrimônio não é outra coisa senão o mesmo contrato natural, elevado por Jesus Cristo à dignidade de Sacramento.

##### 831 - Então, entre os cristãos não pode haver verdadeiro Matrimônio que não seja Sacramento?

Entre os cristãos não pode haver verdadeiro Matrimônio que não seja Sacramento.

##### 832 - Que efeitos produz o Sacramento do Matrimônio?

O Sacramento do Matrimônio:

<ul>
  <li>1º - dá um aumento da graça santificante;</li>
  <li>
    2º - confere a graça especial para se cumprirem fielmente todos os deveres
    matrimoniais.
  </li>
</ul>

#### 2º - Ministros, cerimônias e disposições para o Matrimônio

##### 833 - Quem são os ministros do Sacramento do Matriônio?

Os ministros deste Sacramento são os mesmos esposos, que reciprocamente conferem e recebem o Sacramento.

##### 834 - De que maneira se administra este Sacramento?

Este Sacramento, porque conserva a natureza de contrato, é administrado pelos mesmos contraentes, declarando na presença do próprio pároco, ou de outro Sacerdote devidamente autorizado, e de duas testemunhas, que se unem em matrimônio.

##### 835 - Para que serve então a bênção que o pároco dá aos esposos?

A bênção que o pároco dá aos esposos não é necessária para constituir o Sacramento, mas é dada para sancionar em nome da Igreja a sua união, e para atrair sempre mais sobre eles as bênçãos de Deus.

##### 836 - Que intenção deve ter quem contrai Matrimônio?

Quem contrai Matrimônio deve ter intenção:

<ul>
  <li>1º - de fazer a vontade de Deus, que o chama a tal estado;</li>
  <li>2º - de procurar nele a salvação da própria alma;</li>
  <li>3º - de educar cristãmente os filhos, se Deus lhos der.</li>
</ul>

##### 837 - De que maneira se devem dispor os esposos para receber com fruto o Sacramento do Matrimônio?

Os esposos, para receber com fruto o Sacramento do Matrimônio, devem:

<ul>
  <li>
    1º - encomendar-se de todo o coração a Deus, para conhecer a sua vontade e
    para alcançar d'Ele as graças que são necessárias em tal estado;
  </li>
  <li>
    2º - consultar os própriospais, antesde chegar ao noivado, como o exige a
    obediência e o respeito devido aos mesmos;
  </li>
  <li>
    3º - preparar-se com uma boa confissão, até mesmo geral, se for necessário,
    de toda a vida;
  </li>
  <li>
    4º - evitar toda a familiaridade perigosa de trato e de palavras, ao
    conversarem mutuamente. antes de receberem este Sacramento.
  </li>
</ul>

##### 838 - Quais são as principais obrigações das pessoas unidas em Matrimônio?

As pessoas unidas em Matrimônio devem:

<ul>
  <li>
    1º - guardar inviolada a fidelidade conjugal, e proceder sempre cristãmente
    ein tudo;
  </li>
  <li>
    2º - amar-se mutuamente, suportando-se um ao outro com paciência, e viver em
    paz e harmonia;
  </li>
  <li>
    3º - se têm filhos, cuidar seriamente de prover às suas necessidades,
    dar-lhes educação cristã, e deixar-lhes a liberdade de escolher o estado de
    vida a que Deus os chamar.
  </li>
</ul>

#### 3º - Condições e impedimentos do Matrimônio

##### 839 - Que é necessário para contrair validamente o Matrimônio cristão?

Para contrair validamente o Matrimônio cristão é necessário estar livre de qualquer impedimento matrimonial dirimente, e dar livremente o próprio consentimento ao contrato do Matrimônio na presença do próprio pároco ou de um Sacerdote devidamente autorizado, e de duas testemunhas.

##### 840 - Que é necessário para contrair licitamente o Matrimônio cristão?

Para contrair licitamente o Matrimônio cristão, é necessário estar livre dos impedimentos matrimoniais impedientes, estar instruído nas verdades principais da religião, e estar em estado de graça. Não estando em estado de graça, cometer-se-ia um sacrilégio.

##### 841 - Que são os impedimentos matrimoniais?

Os impedimentos matrimoniais são certas circunstâncias que tornam o matrimônio ou inválido ou ilícito. No primeiro caso chamam-se impedimentos dirimentes, no segundo impedimentos impedientes.

##### 842 - Dai-me alguns exemplos de impedimentos dirimentes.

Impedimentos dirimentes são, por exemplo, a consangüinidade até ao terceiro grau, o parentesco espiritual, o voto solene de castidade, a diversidade de culto entre batizados e não batizados etc.

##### 843 - Dai-me algum exemplo de impedimento impediente.

Impedimento impediente é, por exemplo, o voto simples de castidade etc.

##### 844 - São os fiéis obrigados a manifestar à autoridade eclesiástica os impedimentos matrimoniais que conhecem?

Os fiéis são obrigados a manifestar à autoridade eclesiástica os impedimentos matrimoniaisque conhecem; e é por isso que ospárocos fazem aspublicações, isto é, lêem os pregões dos que se vão casar.

##### 845 - Quem tem o poder de estabelecer impedimentos matrimoniais, de dispensar deles, e de julgar da validade do Matrimônio cristão?

Só a Igreja tem o poder de estabelecer impedimentos e de julgar da validade do Matrimônio entre os cristãos, como só a Igreja pode dispensar daqueles impedimentos que Ela estabeleceu.

##### 846 - Por que só a Igreja tem o poder de estabelecer impedimentos e de julgar da validade do Matrimônio?

Só a Igreja tem o poder de estabelecer impedimentos, de julgar da validade do Matrimônio e de dispensar dos impedimentos que Ela própria estabeleceu, porque não se podendo separar no matrimônio cristão o contrato do Sacramento, também o contrato cai sob alçada da Igreja, porque só a Ela conferiu Jesus Cristo o direito de promulgar leis e decisões acerca das coisas sagradas.

##### 847 - Pode a autoridade civil dissolver, com o divórcio, o vínculo do Matrimônio cristão?

Não. O vínculo do Matrimônio cristão não pode ser dissolvido pela autoridade civil, porque esta não pode ingerir-se em matéria de Sacramentos, nem separar o que Deus uniu.

##### 848 - Que é o matrimônio ou casamento civil?

O casamento civil não é mais que uma formalidade prescrita pela lei para os cidadãos, a fim de dar e de assegurar os efeitos civis aos casados e aos seus filhos.

##### 849 - Pode um cristão celebrar somente o casamento ou contrato civil?

Um cristão não pode celebrar somente o contrato civil, porque este não é Sacramento, e portanto não é um verdadeiro matrimônio.

##### 850 - Em que condições se encontrariam os esposos que convivessem juntos, unidos somente pelo casamento civil?

Os esposos que convivessem juntos, unidos somente pelo casamento civil, estariam em estado habitual de pecado mortal, e a sua união seria sempre ilegítima diante de Deus e da Igreja.

##### 851 - Deve fazer-se também o contrato civil?

Deve fazer-se também o contrato civil, porque, embora não seja ele Sacramento, serve, no entanto, para garantir aos casados e a seus filhos os efeitos civis da sociedade conjugal; eisporque, como regra geral, a autoridade eclesiástica não permite o casamento religioso, quando não se cumprem as formalidades prescritas pela autoridade civil.