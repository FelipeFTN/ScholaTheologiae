## IV - <em>Da Santíssima Eucaristia</em>

#### 1º - Da natureza da Santíssima Eucaristia e da presença real de Jesus Cristo neste Sacramento

##### 594 - Que é o Sacramento da Eucaristia?

A Eucaristia é um Sacramento que, pela admirável conversão de toda a substância do pão no Corpo de JesusCristo, e de toda a substância do vinho no seu precioso Sangue, contém verdadeira, real e substancialmente o Corpo, Sangue, Alma e Divindade do mesmo Jesus Cristo Nosso Senhor, debaixo das espécies de pão e de vinho, para ser nosso alimento, espiritual.

##### 595 - Está na Eucaristia o mesmo Jesus Cristo que está no Céu e que nasceu, na terra, da Santíssima Virgem?

Sim, na Eucaristia está verdadeiramente o mesmo Jesus Cristo que está no Céu e que nasceu, na terra, da Santíssima Virgem Maria.

##### 596 - Por que acreditais que no Sacramento da Eucaristia está verdadeiramente Jesus Cristo?

Eu acredito que no Sacramento da Eucaristia está verdadeiramente presente Jesus Cristo, porque Ele mesmo o disse, e assim no-lo ensina a Santa Igreja.

##### 597 - Qual é a matéria do Sacramento da Eucaristia?

A matéria do Sacramento da Eucaristia é a que foi empregada por Jesus Cristo. a saber: o pão de trigo e o vinho de uva.

##### 598 - Qual é a forma do Sacramento da Eucaristia?

A forma do Sacramento da Eucaristia são as palavras usadas por Jesus Cristo: Isto é o meu Corpo: este é o meu Sangue.

##### 599 - Que é a hóstia antes da consagração?

A hóstia antes da consagração é pão de trigo.

##### 600 - Depois da consagração, que é a hóstia?

Depois da consagração, a hóstia é o verdadeiro Corpo de Nosso Senhor Jesus Cristo, debaixo das espécies de pão.

##### 601 - Que está no cálice antes da consagração?

No cálice, antes da consagração, está vinho com algumas gotas de água.

##### 602 - Depois da consagração, que há no cálice?

Depois da consagração, há no cálice o verdadeiro Sangue de Nosso Senhor Jesus Cristo, debaixo das espécies de vinho.

##### 603 - Quando se faz a mudança do pão no Corpo, e do vinho no Sangue de Jesus Cristo?

A conversão do pão no Corpo, e do vinho no Sangue de JesusCristo, faz-se precisamente no ato em que o sacerdote, na santa Missa, pronuncia as palavras da consagração.

##### 604 - Que é a consagração?

A consagração é a renovação, por meio do sacerdote, do milagre operado por Jesus Cristo na última Ceia, quando mudou o pão e o vinho no seu Corpo e no seu Sangue adorável, por estas palavras: Isto é o meu Corpo; este é o meu Sangue.

##### 605 - Como é chamada pela Igreja a miraculosa conversão do pão e do vinho no Corpo e no Sangue de Jesus Cristo?

A miraculosa conversão, que todos os dias se opera sobre os nossos altares. é chamada pela Igreja transubstanciação.

##### 606 - Quem deu tanta virtude às palavras da consagração?

Foi o mesmo Jesus Cristo Nosso Senhor, Deus onipotente, que deu tanta virtude às palavras da consagração.

##### 607 - Depois da consagração não fica ainda alguma coisa do pão e do vinho?

Depois da consagração ficam só as espécies do pão e do vinho.

##### 608 - Que são as espécies do pão e do vinho?

Dizem-se espécies a quantidade e as qualidades sensíveis do pão e do vinho, como a figura, a cor, o sabor.

##### 609 - De que maneira podem ficar as espécies do pão e do vinho sem a sua substância?

As espécies do pão e do vinho ficam maravilhosamente sem a sua substância por virtude de Deus Onipotente.

##### 610 - Debaixo das espéciesde pão está só o Corpo de JesusCristo, e debaixo dasespécies de vinho está só o seu Sangue?

Tanto debaixo dasespéciesde pão, corno debaixo dasespéciesde vinho, está Jesus Cristo vivo e todo inteiro com seu Corpo, Sangue. Alma e Divindade.

##### 611 - Podereis dizer-me por que tanto na hóstia como no cálice está Jesus Cristo todo inteiro?

Tanto na hóstia como no cálice está Jesus Cristo todo inteiro, porque Ele está na Eucaristia vivo e imortal como no céu; por isso onde está o seu Corpo, está também o seu Sangue, sua Alma e sua Divindade; e onde está seu Sangue está também seu Corpo, sua Alma e sua Divindade, pois tudo isto é inseparável em Jesus Cristo.

##### 612 - Quando Jesus está na hóstia, deixa de estar no Céu?

Quando Jesus está na hóstia, não deixa de estar no Céu, mas encontra-se ao mesmo tempo no Céu e no Santíssimo Sacramento.

##### 613 - Jesus Cristo está presente em todas as hóstias consagradas do mundo?

Sim, Jesus está presente ein todas as hóstias consagradas.

##### 614 - Como é possível que Jesus Cristo esteja em todas as hóstias consagradas?

Jesus Cristo está em todas as hóstias consagradas, por efeito da onipotência de Deus, a quem nada é impossível.

##### 615 - Quando se parte a hóstia, parte-se também o Corpo de Jesus Cristo?

Quando se parte a hóstia, não se parte o Corpo de Jesus Cristo, mas partem-se somente as espécies do pão.

##### 616 - Em que parte da hóstia fica o Corpo de Jesus Cristo?

O Corpo de Jesus Cristo fica inteiro em todas e em cada uma das partes em que a hóstia foi dividida.

##### 617 - Está Jesus Cristo tanto numa hóstia grande como na partícula de uma hóstia?

Tanto numa hóstia grande, como na partícula de uma hóstia, está sempre o mesmo Jesus Cristo.

##### 618 - Por que motivo se conserva nas igrejas a Santíssima Eucaristia?

Conserva-se nas igrejas a Santíssima Eucaristia, a fim de ser adorada pelos fiéis, e levada aos enfermos, quando for necessário.

##### 619 - Deve-se adorar a Eucaristia?

A Eucaristia deve ser adorada por todos, porque Ela contém verdadeira, real e substancialmente o mesmo Jesus Cristo Nosso Senhor.

#### 2º - Da instituição e dos efeitos do Sacramento da Eucaristia

##### 620 - Quando instituiu Jesus Cristo o Sacramento da Eucaristia?

Jesus Cristo instituiu o Sacramento da Eucaristia na última ceia que celebrou com seus discípulos, na noite que precedeu sua Paixão.

##### 621 - Por que instituiu Jesus Cristo a Santíssima Eucaristia? Jesus Cristo instituiu

a Santíssima Eucaristia, por três razões principais:

<ul>
  <li>1º - para ser o sacrifício da nova lei;</li>
  <li>2º - para ser alimento da nossa alma;</li>
  <li>
    3º - para ser um memorial perpétuo da sua Paixão e Morte, e um penhor
    precioso do seu amor para conosco e da vida eterna.
  </li>
</ul>

##### 622 - Por que Jesus Cristo instituiu este Sacramento debaixo das espécies de pão e de vinho?

Jesus Cristo instituiu este Sacramento debaixo das espécies de pão e de vinho, porque a Eucaristia devia ser nosso alimento espiritual, e era por isso conveniente que nos fosse dada em forma de comida e de bebida.

##### 623 - Que efeitos produz em nós a Santíssima Eucaristia?

Os principais efeitos que a Santíssima Eucaristia produz em quem a recebe dignamente são estes:

<ul>
  <li>
    1º - conserva e aumenta a vida da alma, que é a graça, como o alimento
    material sustenta e aumenta a vida do corpo;
  </li>
  <li>
    2º - perdoa os pecados veniais e preserva dos mortais; produz consolação
    espiritual.
  </li>
</ul>

##### 624 - Não produz em nós a Santíssima Eucaristia outros efeitos?

Sim. A Santíssima Eucaristia produz em nós outros três efeitos, a saber:

<ul>
  <li>
    1º - enfraquece as nossas paixões, e em especial amortece em nós o fogo da
    concupiscência;
  </li>
  <li>
    2º - aumenta em nós o fervor e ajuda-nos a proceder em conformidade com os
    desejos de Jesus Cristo;
  </li>
  <li>
    3º - dá-nos um penhor da glória futura e da ressurreição do nosso corpo.
  </li>
</ul>

#### 3º - Das disposições necessárias para bem comungar

##### 625 - Produz o Sacramento da Eucaristia sempre em nós os seus maravilhosos efeitos?

O Sacramento da Eucaristia produz em nós os seus maravilhosos efeitos, quando o recebemos com as devidas disposições.

##### 626 - Quantas coisas são necessárias para fazer uma comunhão bem feita?

Para fazer uma comunhão bem feita, são necessárias três coisas:

<ul>
  <li>1º - estar em estado de graça;</li>
  <li>2º - estar em jejum desde uma hora antes da comunhão;</li>
  <li>
    3º - saber o que se vai receber e aproximar-se da sagrada Comunhão com
    devoção.
  </li>
</ul>

##### 627 - Que quer dizer: estar em estado de graça?

Estar em estado de graça quer dizer: ter a consciência limpa de todo o pecado mortal.

##### 628 - Que deve fazer antes de comungar quem sabe que está em pecado mortal?

Quem sabe que está em pecado mortal, deve fazer uma boa confissão antes de comungar; porque para quem está em pecado mortal, não basta o ato de contrição perfeita, sem a confissão, para fazer uma comunhão bem feita,

##### 629 - Por que não basta o ato de contrição perfeita, a quem sabe que está em pecado mortal, para poder comungar?

Porque a Igreja ordenou, em sinal de respeito a este Sacramento, que quem é culpado de pecado mortal, não ouse receber a Comunhão, sem primeiro se confessar.

##### 630 - Quem comungasse em pecado mortal, receberia a Jesus Cristo?

Quem comungasse em pecado mortal, receberia a JesusCristo, mas não a sua graça; pelo contrário, cometeria sacrilégio e incorreria na sentença de condenação.

##### 631 - Em que consiste o jejum eucarístico?

O jejum eucarístico consiste em abster-se de qualquer espécie de comida ou bebida, exceto a água natural, que, na atual disciplina eucarística, não quebra o jejum.

##### 632 - Pode comungar quem engoliu restos de comida presos aos dentes?

Quem engoliu restos de comida presos aos dentes, pode comungar, porque já não são tomados como alimentos ou perderam tal condição.

##### 633 - Quem não está em jejum, pode comungar alguma vez?

Comungar sem estar em jejum é permitido aos doentes que estão em perigo de morte, e aos que obti prolongada. A comunhão feita pelos doentes em perigo de morte chama-se Viático, porque os sustenta na viagem que eles fazem desta vida à eternidade.

##### 634 - Que querem dizer as palavras: saber o que se vai receber?

Saber o que se vai receber quer dizer: conhecer o que ensina com respeito a este Sacramento a Doutrina Cristã e acreditá-lo firmemente.

##### 635 - Que quer dizer: comungar com devoção?

Comungar com devoção quer dizer: aproximar-se da sagrada Comunhão com humildade e modéstia, tanto na própria pessoa como no vestir, e fazer a preparação antes e a ação de graças depois da Comunhão.

##### 636 - Em que consiste a preparação antes da Comunhão?

A preparação antes da Comunhão consiste em nos entretermos algum tempo a considerar quem é Aquele que vamos receber e quem somosnós; e em fazer atosde fé, de esperança, de caridade, de contrição, de adoração, de humildade e de desejo de receber a Jesus Cristo.

##### 637 - Em que consiste a ação de graças depois da Comunhão?

A ação de graças depois da Comunhão consiste em nos conservarmos recolhidos a honrar a presença do Senhor dentro de nósmesmos, renovando os atosde fé, de esperança, de caridade, de adoração, de agradecimento, de oferecimento e de súplica, pedindo sobretudo aquelas graças que são mais necessárias para nós e para aqueles por quem somos obrigados a orar. sobretudo licença especial em razão de moléstia

##### 638 - Que se deve fazer no dia da Comunhão?

No dia da Comunhão deve-se manter, o mais possível, o recolhimento, ocupar-se em obras de piedade, bem como cumprir com grande esmero os deveres de estado.

##### 639 - Depois da sagrada Comunhão, quanto tempo permanece Jesus Cristo em nós?

Depois da sagrada Comunhão, Jesus Cristo permanece em nós com a sua graça enquanto se não peca mortalmente; e com a sua presença real permanece em nós enquanto se não consomem as espécies sacramentais.

#### 4º - Da maneira de comungar

##### 640 - Como devemos apresentar-nos no ato de receber a sagrada Comunhão?

No ato de receber a sagrada Comunhão devemos estar de joelhos, com a cabeça medianamente levantada, com os olhos modestos e voltados para a sagrada Hóstia, com a boca suficientemente aberta e com a língua um pouco estendida sobre o lábio inferior. Senhoras e meninas devem estar com a cabeça coberta.

##### 641 - Como se deve segurar a toalha ou a patena da Comunhão?

A toalha ou a patena da Comunhão deve-se segurar de maneira que recolha a sagrada Hóstia, caso ela viesse a cair.

##### 642 - Quando se deve engolir a sagrada Hóstia?

Devemos procurar engolir a sagrada Hóstia o mais depressa possível, e convém abster-nos de cuspir algum tempo.

##### 643 - Se a sagrada Hóstia se pegar ao céu da boca, que se deve fazer?

Se a sagrada Hóstia se pegar ao céu da boca, é preciso despegá-la com a língua, nunca porém com os dedos.

#### 5º - Do preceito da comunhão

##### 644 - Quando há obrigação de comungar?

Há obrigação de comungar todos os anos pelei Páscoa, na própria paróquia, e além disso em perigo de morte.

##### 645 - Em que idade começa a obrigar o preceito da Comunhão pascal?

O preceito da Comunhão pascal começa a obrigar na idade em que a criança é capaz de recebê-la com as devidas disposições.

##### 646 - Pecam aqueles que têm idade capaz para serem admitidos à Comunhão e não comungam?

Aqueles que, tendo a idade capaz para serem admitidos à Comunhão, não comungam, ou porque não querem, ou porque não estão instruídos por sua culpa, pecam sem dúvida. Pecam outrossim os seus pais, ou quem lhes faz as vezes, se o adiamento da Comunhão se dá por sua culpa, e hão de dar por isso severas contas a Deus.

##### 647 - É coisa boa e útil comungar freqüentemente?

É coisa ótima comungar freqüentemente e até todos os dias, contanto que se faça com as devidas disposições.

##### 648 - Qual a freqüência com que se deve comungar?

Pode-se comungar tão freqüentemente quanto o permita o conselho de um confessor piedoso e douto.