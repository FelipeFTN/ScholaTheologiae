## I - <em>Dos Sacramentos em geral</em>

#### 1º - Natureza dos Sacramentos

##### 515 - De que trata a quarta parte da Doutrina Cristã?

A quarta parte da Doutrina Cristã trata dos Sacramentos.

##### 516 - Que se entende pela palavra Sacramento?

Pela palavra Sacramento entende-se um sinal sensível e eficaz da graça, instituído por Jesus Cristo, para santificar as nossas almas.

##### 517 - Por que chamais aos Sacramentos sinais sensíveis e eficazes da graça?

Chamo aos Sacramentos sinais sensíveis e eficazes da graça, porque todos os Sacramentos significam, por meio de coisas sensíveis, a graça divina que eles produzem na nossa alma.

##### 518 - Explicai com um exemplo como os Sacramentos são sinais sensíveis e eficazes da graça.

No Batismo, o ato de derramar a água sobre cabeça da pessoa, e aspalavras: Eu te batizo, isto é, eu te lavo, em nome do Padre e do Filho e do Espírito Santo, são um sinal sensível do que o Batismo opera na alma; porque assim como a água lava o corpo, assim a graça, dada pelo Batismo, purifica a alma, do pecado.

##### 519 - Quantos e quais são os Sacramentos?

Os Sacramentos são sete, a saber: Batismo, Confirmação, Eucaristia, Penitência, Extrema-Unção, Ordem e Matrimônio.

##### 520 - Quantas coisas se requerem para fazer um Sacramento?

Para fazer um Sacramento requerem-se a matéria, a forma, e o ministro, que tenha intenção de fazer o que faz a Igreja.

##### 521 - Que é a matéria dos Sacramentos?

A matéria dosSacramentos é a coisa sensível que se emprega para os fazer; como, por exemplo, a água natural no Batismo, o óleo e o bálsamo na Confirmação.

##### 522 - Que é a forma dos Sacramentos?

A forma dos Sacramentos são as palavras que se proferem para os fazer.

##### 523 - Quem é o ministro dos Sacramentos?

O ministro dos Sacramentos é a pessoa que faz ou confere os Sacramentos.

#### 2º - Do efeito principal dos Sacramentos, que é a graça

##### 524 - Que é a graça?

A graça de Deus é um dom interior, sobrenatural, que nos é dado sem merecimento algum da nossa parte, mas pelos merecimentos de Jesus Cristo, ein ordem à vida eterna.

##### 525 - Como se divide a graça?

Divide-se a graça em: graça santificante, que se chama também habitual; e graça atual.

##### 526 - Que é a graça santificante?

A graça santificante é um dom sobrenatural, inerente à nossa alma, que nos faz justos, filhos adotivos de Deus e herdeiros do Paraíso.

##### 527 - Quantas espécies há de graça santificante?

Há duas espécies de graça santificante: graça primeira, e graça segunda.

##### 528 - Que é a graça primeira?

A graça primeira é aquela pela qual o homem passa do estado de pecado rnortal ao estado de justiça, de amizade com Deus.

##### 529 - E que é a graça segunda?

A graça segunda é um aumento da graça primeira.

##### 530 - Que é a graça atual?

A graça atual é um dom sobrenatural que ilumina nossa inteligência, move e fortalece a nossa vontade, a fim de que pratiquemos o bem e evitemos o mal.

##### 531 - Podemos nós resistir à graça de Deus?

Sim, podemos resistir à graça de Deus, porque ela não destroi o nosso livre arbítrio.

##### 532 - Com as nossas forças, podemos nós fazer alguma coisa que nos seja útil para a vida eterna?

Sem o auxílio da graça de Deus, só com as nossas forças, não podemos fazer nada que nos seja útil para a vida eterna.

##### 533 - Como nos comunica Deus a graça?

Deus nos comunica a graça principalmente por meio dos santos Sacramentos.

##### 534 - Além da graça santificante, conferem-nos os Sacramentos mais outra graça?

Os Sacramentos, além da graça santificante, conferem também a graça sacramental.

##### 535 - Que é a graça sacramental?

A graça sacramental consiste no direito que se adquire, recebendo qualquer Sacramento, de ter ein tempo oportuno as graças atuais necessárias, para cumprir as obrigações que derivam do Sacramento recebido. Assim, quando fomos batizados, recebemos o direi to a ter as graças necessárias as para vi vermos cristãmente.

##### 536 - Dão sempre os Sacramentos a graça a quem os recebe?

Os Sacramentos dão sempre a graça, contanto que se recebam com as disposições necessárias.

##### 537 - Quem deu aos Sacramentos a virtude de conferir a graça?

Foi Jesus Cristo que, por sua Paixão e Morte, deu aos Sacramentos a virtude de conferir a graça.

##### 538 - Quais são os Sacramentos que conferem a primeira graça santificante?

Os Sacramentos que conferem a primeira graça santificante, que nos faz amigos de Deus, são dois: Batismo e Penitência.

##### 539 - Como se chamam, por este motivo, estes dois Sacramentos?

Estes doisSacramentos, isto é, o Batismo e a Penitência, chamam-se por este motivo Sacramentos de mortos, porque são instituídos principalmente para restituir a vida da graça às almas mortas pelo pecado.

##### 540 - Quais são os Sacramentos que aumentam a graça em quem a possui?

Os Sacramentos que aumentam a graça em quem a possui, são os outros cinco, isto é, a Confirmação, a Eucaristia, a Extrema-Unção, a Ordem e o Matrimônio, os quais conferem a graça segunda.

##### 541 - Como se chamam, por esse motivo, estes cinco Sacramentos?

Estes cinco Sacramentos, isto é, a Confirmação, a Eucaristia, a Extrema-Unção, a Ordem e o Matrimônio, chamam-se Sacramentos de vivos, porque aqueles que os recebem, devem estar isentos de pecado mortal, quer dizer, já vivos pela graça santificante.

##### 542 - Que pecado comete quem recebe um Sacramento de vivos, sabendo que não está em estado de graça?

Quem recebe um Sacramento de vivos, sabendo que não está em estado de graça, comete um grave sacrilégio.

##### 543 - Quais são os Sacramentos mais necessários para nossa salvação?

Os Sacramentos mais necessários para nossa salvação, são dois: o Batismo e a Penitência; o Batismo é necessário absolutamente para todos, e a Penitência é necessária para todos aqueles que pecaram mortalmente depois do Batismo.

##### 544 - Qual é o maior de todos os Sacramentos?

O maior de todos os Sacramentos é o Sacramento da Eucaristia, porque contém não só a graça, mas também ao mesmo Jesus Cristo, autor da graça e dos Sacramentos.

#### 3º - Do caráter que imprimem alguns Sacramentos

##### 545 - Quais são os Sacramentos que se podem receber uma só vez?

Os Sacramentosque se podem receber uma só vez, são três: Batismo, Confirmação e Ordem.

##### 546 - Por que os trêsSacramentos, Batismo, Confirmação e Ordem só se podem receber uma vez?

Os três Sacramentos, Batismo, Confirmação e Ordem, podem-se receber uma só vez, porque imprimem caráter.

##### 547 - Que é o caráter que cada um destes três Sacramentos imprime na alma?

O caráter impresso na alma em cada um destes três Sacramentos, é um sinal espiritual que nunca se apaga.

##### 548 - Para que serve o caráter que estes três Sacramentos imprimem na alma?

O caráter que estes três Sacramentos imprimem na alma, serve para nos distinguir, no Batismo como membros de Jesus Cristo, na Confirmação como seus soldados, na Ordem como seus ministros.