## VI - <em>Da Penitência</em>

#### 1º - Da Penitência em geral

##### 670 - Que é o Sacramento da Penitência?

A Penitência, chamada também Confissão, é o Sacramento instituído por Jesus Cristo para perdoar os pecados cometidos depois do Batismo.

##### 671 - Por que se dá a este Sacramento o nome de Penitência?

Dá-se a este Sacramento o nome de Penitência, porque, para obter o perdão dos pecados, é necessário detestá-los com arrependimento e porque quem cometeu uma falta deve sujeitar-se à pena que o Sacerdote impõe.

##### 672 - Por que este Sacramento se chama também Confissão?

Chama-se este Sacramento também Confissão, porque, para alcançar o perdão dos pecados, não basta i detestá-los, mas é necessário acusar-se deles ao Sacerdote, isto é, confessá-los.

##### 673 - Quando Jesus Cristo instituiu o Sacramento da Penitência?

Jesus Cristo instituiu o Sacramento da Penitência no dia da sua Ressurreição, quando, depois de entrar no cenáculo, deu solenemente aos seus Apóstolos o poder de perdoar os pecados.

##### 674 - Como deu Jesus Cristo aos seus Apóstolos o poder de perdoar os pecados?

JesusCristo deu aos seusApóstoloso poder de perdoar ospecados, soprando sobre eles, e dizendo: Recebei o Espírito Santo: àqueles a quem perdoardes os pecados, ser-lhes-ão perdoados, e àqueles a quem os retiverdes ser-lhes-ão retidos.

##### 675 - Qual é a matéria do Sacramento da Penitência?

Distingue-se a matéria do Sacramento da Penitência em remota e próxima. A remota é constituída pelos pecados cometidos pelo penitente depois do Batismo, e a matéria próxima são os atos do próprio penitente, isto é, a contrição, a acusação e a satisfação.

##### 676 - Qual é a forma do Sacramento da Penitência?

A forma do Sacramento da Penitência é esta: Eu te absolvo dos teus pecados.

##### 677 - Quem é o ministro do Sacramento da Penitência?

O ministro do Sacramento da Penitência é o Sacerdote aprovado pelo Bispo para ouvir confissões.

##### 678 - Por que o Sacerdote deve ser aprovado pelo Bispo?

O Sacerdote deve ser aprovado pelo Bispo para ouvir confissões, porque, para administrar validamente este Sacramento, não basta o poder da Ordem, mas é necessário também o poder de jurisdição, isto é, a faculdade de julgar, que deve ser dada pelo Bispo.

##### 679 - Quantas são as partes do Sacramento da Penitência?

As partes do Sacramento da Penitência são: a contrição, a confissão e a satisfação da parte do pecador, a absolvição da parte do sacerdote.

##### 680 - Que é a contrição ou a dor dos pecados?

A contrição ou a dor dospecados é um desgosto da alma, pelo qual se detestam os pecados cometidos, e se propõe não os tornar a cometer no futuro.

##### 681 - Que quer dizer esta palavra contrição?

A palavra contrição quer dizer fratura ou despedaçamento, como quando uma pedra é esmagada e reduzida a pó.

##### 682 - Por que se dá o nome de contrição à dor dos pecados?

Dá-se o nome de contrição à dor dos pecados, para significar que o coração duro do pecador em certo modo se despedaça pela dor de ter ofendido a Deus.

##### 683 - Em que consiste a confissão dos pecados?

A confissão consiste na acusação distinta dos nossos pecados ao confessor, para dele recebermos a absolvição e a penitência.

##### 684 - Por que é que a confissão se chama acusação?

Chama-se a confissão acusação, porque não deve ser uma narração indiferente, mas sim uma verdadeira e dolorosa manifestação dos próprios pecados.

##### 685 - Que é a satisfação ou penitência?

A satisfação ou penitência é a oração ou outra boa obra, que o confessor impõe ao pecador em expiação dos seus pecados.

##### 686 - Que é a absolvição?

A absolvição é a sentença que o Sacerdote pronuncia em nome de Jesus Cristo, para perdoar os pecados ao pecador.

##### 687 - Das partes do Sacramento da Penitência, qual é a mais necessária?

Das partes do Sacramento da Penitência, a mais necessária é a contrição, porque sem ela nunca se pode obter o perdão dos pecados, e com ela só, quando é perfeita, pode obter-se o perdão, contanto que esteja unida com o desejo, ao menos implícito, de confessar-se.

#### 2º - Dos efeitos e da necessidade do Sacramento da Penitência e das disposições para bem recebê-lo

##### 688 - Quais são os efeitos do Sacramento da Penitência?

O Sacramento da Penitência confere a graça santificante, com a qual são perdoados os pecados mortais e também os veniais que se confessaram e de que haja arrependimento; comuta a pena eterna em temporal, da qual também é perdoada uma parte maior ou menor, conforme as disposições do penitente; faz reviver o mereci. mento das boas obras feitas antes de se cometer o pecado mortal; dá à alma auxílios oportunos para não recair no pecado e restitui a paz à consciência.

##### 689 - É o Sacramento da Penitência necessário a todos para se salvarem?

O Sacramento da Penitência é necessário, para se salvarem, a todos aqueles que, depois do Batismo, cometeram algum pecado mortal.

##### 690 - É bom confessar-se com freqüência?

Confessar-se com freqüência é coisa ótima, porque o Sacramento da Penitência, além de apagar os pecados, dá as graças necessárias para evitá-los no futuro.

##### 691 - Tem o Sacramento da Penitência virtude de per. doar todos os pecados, por muitos e grandes que sejam?

Sim, o Sacramento da Penitência tem virtude de perdoar todos os pecados, por muitos e grandes que sejam, contanto que se receba com as devidas disposições.

##### 692 - Quantas coisas são necessárias para fazer uma confissão bem feita?

Para fazer uma boa confissão, são necessárias cinco coisas:

<ul>
  <li>1º - exame de consciência;</li>
  <li>2º - dor de ter ofendido a Deus;</li>
  <li>3º - propósito de nunca mais pecar;</li>
  <li>4º - acusação dos próprios pecados;</li>
  <li>5º - satisfação ou penitência.</li>
</ul>

##### 693 - Que devemos fazer, antes de tudo, para bem nos confessarmos?

Para bem nos confessarmos devemos, antes de tudo, pedir de todo o coração ao Senhor que nos dê luz para conhecer todos os nossos pecados e força para os detestar.

#### 3º - Do exame de consciência

##### 694 - Que é o exame de consciência?

O exame de consciência é uma diligente investigação dos pecados que se cometeram, desde a última confissão bem feita.

##### 695 - Como se faz o exame de consciência?

Faz-se o exame de consciência trazendo diligentemente à memória, na presença de Deus, todos os pecados ainda não confessados, cometidos por pensamentos, palavras, obras e omissões contra os Mandamentos de Deus e da Igreja, e contra as obrigações do próprio estado.

##### 696 - Sobre que mais coisas devemos examinar-nos?

Devemos examinar-nos também sobre os maus hábitos e sobre as ocasiões de pecado.

##### 697 - No exame, devemos investigar também o número dos pecados?

No exame devemos investigar também o número dos pecados mortais.

##### 698 - Que é necessário para que um pecado seja mortal?

Para que um pecado seja mortal são necessárias três coisas: matéria grave, plena advertência e consentimento perfeito da vontade.

##### 699 - Quando há matéria grave?

Há matéria grave, quando se trata de uma coisa notavelmente contrária à Lei de Deus e da Igreja.

##### 700 - Quando há plena advertência no pecado?

Há plena advertência no pecado, quando se conhece perfeitamente que se faz um mal grave.

##### 701 - Quando, no pecado, há o consentimento perfeito da vontade?

Ha. no pecado, o consentimento perfeito da vontade, quando se quer fazer deliberadamente uma coisa, embora se reconheça que é culpável.

##### 702 - Que diligência se deve usar no exame de consciência?

No exame de consciência deve usar-se aquela diligência que se usaria em um negócio de grande importância.

##### 703 - Quanto tempo se deve empregar no exame de consciência?

Deve empregar-se no exame de consciência mais ou menos tempo, conforme a necessidade, isto é, conforme o número e a qualidade dos pecados que sobrecarregam a consciência, e conforme o tempo decorrido desde a última confissão bem feita.

##### 704 - Como se pode facilitar o exame para a confissão?

Facilita-se o exame para a confissão, fazendo todasasnoiteso exame de consciência sobre as ações do dia.

#### 4º - Da dor ou arrependimento

##### 705 - Que é a dor dos pecados?

A dor dos pecados consiste num desgosto e numa detestação sincera da ofensa feita a Deus.

##### 706 - De quantas espécies é a dor?

A dor é de duas espécies: perfeita ou de contrição; imperfeita ou de atrição.

##### 707 - Que é a dor perfeita ou de contrição?

A dor perfeita é o desgosto de ter ofendido a Deus, porque Deus é infinitamente bom e digno, por Si mesmo, de ser amado sobre todas as coisas.

##### 708 - Por que se chama perfeita a dor de contrição?

Chama-se perfeita a dor de contrição por duas razões:

<ul>
  <li>
    1º - porque se refere exclusivamente à bondade de Deus, e não ao nosso
    proveito ou prejuízo;
  </li>
  <li>
    2º - porque nos faz alcançar imediatamente o perdão dos pecados, ficando-nos
    porém a obrigação de nos confessarmos.
  </li>
</ul>

##### 709 - Então a dor perfeita alcança-nos o perdão dos pecados independentemente da confissão?

A dor perfeita não nos alcança o perdão dos pecados independentemente da confissão, porque sempre inclui a vontade de se confessar.

##### 710 - Por que a dor perfeita, ou contrição, produz este efeito de nos conceder o estado de graça?

A dor perfeita, ou contrição, produz este efeito, porque procede da caridade, que não pode encontrar-se na alma juntamente com o pecado mortal.

##### 711 - Que é a dor imperfeita ou de atrição?

A dor imperfeita ou de atrição é aquela pela qual nos arrependemosde ter ofendido a Deus como nosso supremo Juiz, isto é, por temor dos castigos que merecemos e nos esperam nesta ou na outra vida, ou pela própria fealdade do pecado.

##### 712 - Que condições deve ter a dor para ser boa?

A dor, para ser boa, deve ter quatro condições: deve ser interna, sobrenatural, suma e universal.

##### 713 - Que quer dizer: a dor deve ser interna?

Quer dizer que deve estar no coração e na vontade, e não só nas palavras.

##### 714 - Por que a dor deve ser interna?

A dor deve ser interna, porque a vontade, que se afastou de Deus com o pecado, deve voltar para Deus, detestando o pecado cometido.

##### 715 - Que quer dizer: a dor deve ser sobrenatural?

Quer dizer que deve ser excitada em nós pela graça do Senhor, e a devemos conceber levados por motivos que procedem da fé.

##### 716 - Por que a dor deve ser sobrenatural?

A dor deve ser sobrenatural, porque é sobrenatural o fim a que se dirige, isto é, o perdão de Deus, a aquisição da graça santificante e o direito à glória eterna.

##### 717 - Explicai melhor a diferença entre a dor sobrenatural e a natural.

Quem se arrepende por ter ofendido a Deus infinitamente bom e digno por Si mesmo de ser amado, por ter perdido o Paraíso e merecido o inferno, ou então pela malícia intrínseca do pecado, tem dor sobrenatural, porque estes são os motivos fornecidos pela fé. Quem, ao contrário, se arrependesse só pela desonra ou castigo que lhe vem dos homens, ou por algum prejuízo puramente temporal, teria dor natural, porque se arrependeria só por motivos humanos.

##### 718 - Por que a dor deve ser suma?

A dor deve ser suma, porque devemos considerar e odiar o pecado como o maior de todos os males, visto ser ofensa de Deus, sumo Bem.

##### 719 - Para ter dor dos pecados, é porventura necessário chorar, como às vezes se chora pelas desgraças desta vida?

Não. Não é necessário que materialmente se chore pela dor dospecados; masbasta que no íntimo do coração se deplore mais o ter ofendido a Deus, do que qualquer outra desgraça.

##### 720 - Que quer dizer que a dor deve ser universal?

Quer dizer que se deve estender a todos os pecados mortais cometidos.

##### 721 - Por que a dor se deve estender a todos os pecados mortais cometidos?

Porque quem se não arrepende, ainda que seja de um só pecado mortal, continua sendo inimigo de Deus.

##### 722 - Que devemos fazer para ter dor dos nossos pecados?

Para ter dor dos nossos pecados, devemos pedi-la de todo o coração a Deus e excitá-la ein tios com a consideração do grande mal que fizemos, pecando.

##### 723 - Como fareis para vos excitardes a detestar os pecados?

Para me excitar a detestar os pecados considerarei:

<ul>
  <li>
    1º - o rigor da infinita justiça de Deus, e a deformidade do pecado que
    enfeiou a minha alma, e me tornou merecedor das penas eternas do inferno;
  </li>
  <li>
    2º - que perdi a graça, a amizade e a qualidade de filho de Deus, e a
    herança do Paraíso;
  </li>
  <li>
    3º - que ofendi o meu Redentor que morreu por mim, e que os meus pecados
    foram a causa da sua morte;
  </li>
  <li>
    4º - que desprezei o meti Criador, o meu Deus; que Lhe voltei as costas, a
    Ele, meu sumo Bem, digno de ser amado sobre todas as coisas, e servido
    fielmente.
  </li>
</ul>

##### 724 - Devemos ter grande empenho, quando nos vamos confessar, em ter verdadeira dor dos nossos pecados?

Sim, quando nos vamos confessar, devemos ter muito empenho em ter verdadeira dor dosnossospecados, porque esta é a coisa mais importante de todas; e, se falta a dor, a confissão não é válida.

##### 725 - Quem se confessa só de pecados veniais, deve ter dor de todos?

Quem se confessa só de pecados veniais, para se confessar validamente, basta que se arrependa de algum deles; mas, para alcançar o perdão de todos, é necessário que se arrependa de todos os que reconhece ter cometido.

##### 726 - Quem se confessa só de pecados veniais, e não está arrependido nem sequer de um só, faz uma boa confissão?

Quem se confessa só de pecados veniais, e não está arrependido nem sequer de um só, faz uma confissão nula; a confissão além disso é sacrílega, se adverte que lhe falta a dor.

##### 727 - Que convém fazer para tornar mais segura a confissão só de pecados veniais?

Para tornar mais segura a confissão só de pecados veniais, é prudente acusar, com verdadeira dor, também algum pecado mais grave da vida passada, ainda que já confessado outras vezes.

##### 728 - É bom fazer com freqüência o ato de contrição?

É coisa boa e muito útil fazer, com freqüência, o ato de contrição, principalmente antes de se deitar, e quando se tem certeza ou se duvida de ter caído em pecado mortal, para recuperar mais depressa a graça de Deus; é útil, sobretudo, para alcançar mais facilmente de Deus a graça de fazer semelhante ato na ocasião de maior necessidade, isto é, em perigo de morte.

#### 5º - Do propósito

##### 729 - Em que consiste o propósito?

O propósito consiste em uma vontade determinada de nunca mais cometer o pecado, e de empregar todos os meios necessários para o evitar.

##### 730 - Que condições deve ter esta resolução, para ser um bom propósito?

Para ser um bom propósito, esta resolução deve ter principalmente três condições: deve ser absoluta, universal e eficaz.

##### 731 - Que quer dizer: o bom propósito deve ser absoluto?

Quer dizer que o propósito deve ser sem condição alguma de tempo, de lugar ou de pessoa.

##### 732 - Que quer dizer: o bom propósito deve ser universal?

O bom propósito deve ser universal, quer dizer que devemos ter a vontade de evitar todos os pecados mortais, tanto os que já tenhamos cometido no passado, como os que poderíamos cometer ainda.

##### 733 - Que quer dizer: o bom propósito deve ser eficaz?

O bom propósito deve ser eficaz, quer dizer que é necessário termos uma vontade decidida de perder todas as coisas antes que cometer um novo pecado, de fugir das ocasiões perigosas de pecar, de destruir os maus hábitos, e de satisfazer a todas as obrigações lícitas contraídas em conseqüência dos nossos pecados.

##### 734 - Que é que se entende por mau hábito?

Por mau hábito entende-se a disposição adquirida para cair com facilidade naqueles pecados aos quais nos acostumamos.

##### 735 - Que devemos fazer para corrigir os maus hábitos?

Para corrigir osmaushábitos, devemos vigiar sobre nós mesmos, fazer muita oração, confessar-nos com freqüência, ter um bom diretor sem mudá-lo, e pôr em prática os conselhos e os remédios que ele nos propõe.

##### 736 - Que se entende por ocasiões perigosas de pecar?

Por ocasiões perigosas de pecar entendem-se todas aquelas circunstâncias de tempo, de lugar, de pessoas ou de coisas, que, pela sua própria natureza, ou pela nossa fragilidade, nos induzem a cometer o pecado.

##### 737 - Somos gravemente obrigados a evitar todas as ocasiões perigosas?

Somos gravemente obrigados a evitar as ocasiões perigosas que de ordinário nos levam a cometer o pecado mortal, e que se chamam ocasiões próximas de pecado.

##### 738 - Que deve fazer quem não pode evitar alguma ocasião de pecado?

Quem não pode evitar alguma ocasião de pecado diga-o ao confessor, e siga os conselhos dele.

##### 739 - Que considerações nos auxiliam a fazer o propósito?

Para fazer o propósito auxiliam-nosasmesmas considerações que servem para excitar a dor, isto é, a consideração dos motivos que temos para temer a justiça de Deus, e para amar a sua infinita bondade.

#### 6º - Da acusação dos pecados ao confessor

##### 740 - Depoisde vos terdesdisposto bem para a confissão com o exame, com a dor e com o propósito, que haveis de fazer?

Depois de me ter disposto bem com o exame, com a dor e com o propósito, irei fazer ao confessor a acusação dos meus pecados, para receber a absolvição.

##### 741 - De que pecados somos obrigados a confessar-nos?

Somos obrigados a confessar-nos de todos os pecados mortais; é bom, porém, confessar também os veniais.

##### 742 - Quais são as qualidades que deve ter a acusação dos pecados, ou confissão?

As qualidades principais que deve ter a acusação dos pecados são cinco: deve ser humilde, íntegra, sincera, prudente e breve.

##### 743 - Que querem dizer as palavras: a acusação deve ser humilde?

A acusação deve ser humilde, quer dizer que o penitente deve acusar-se diante do seu confessor sem altivez de ânimo ou de palavras, mas com sentimentos de um réu que reconhece a sua culpa, e comparece diante do juiz.

##### 744 - Que quer dizer: a acusação deve ser íntegra?

A acusação deve ser íntegra, quer dizer que se devem confessar, com as suas circunstâncias e no seu número, todos os pecados mortais cometidos desde a última confissão bem feita, e dos quais se tem consciência.

##### 745 - Quais são as circunstâncias que se devem dizer para que a acusação seja íntegra?

Para que a acusação seja íntegra, devem acusar-se as circunstâncias que mudam a espécie do pecado.

##### 746 - Quais são as circunstâncias que mudam a espécie do pecado?

As circunstâncias que mudam a espécie do pecado são:

<ul>
  <li>
    1º - aquelas pelas quais uma ação pecaminosa de venial se torna mortal;
  </li>
  <li>
    2º - aquelas pelas quais uma ação pecaminosa contém a malícia de dois ou
    mais pecados mortais.
  </li>
</ul>

##### 747 - Dai-me um exemplo de uma circunstância que faça tornar mortal um pecado venial?

Quem, para se desculpar, dissesse uma mentira da qual resultasse dano grave para o próximo, deveria manifestar esta circunstância, que muda a mentira, de oficiosa em gravemente nociva.

##### 748 - Dai-me agora exemplo de uma circunstância pela qual uma e a mesma ação pecaminosa contém a malícia de dois ou mais pecados?

Quem tivesse roubado uma coisa sagrada, deveria acusar esta circunstância, que acrescenta ao furto a malícia do sacrilégio.

##### 749 - Se uma pessoa não tiver a certeza de ter come tido um pecado, deve confessálo?

Se uma pessoa não tiver a certeza de ter cometido um pecado, não é obrigada a confessá-lo; se porém o quiser acusar, deverá acrescentar que não tem a certeza de o ter cometido.

##### 750 - Quem não se lembra exatamente do número dos seus pecados, que deve fazer?

Quem não se lembra exatamente do número dos seus pecados, deve acusar o número aproximado.

##### 751 - Quem deixou de confessar por esquecimento um pecado mortal, ou uma circunstância necessária, fez uma boa confissão?

Quem deixou de confessar por esquecimento um pecado mortal, ou uma circunstância necessária, fez uma boa confissão, contanto que tenha empregado a devida diligência no exame de consciência.

##### 752 - Se um pecado mortal esquecido na confissão volta depois à lembrança, somos obrigados a acusá-lo noutra confissão?

Se um pecado mortal esquecido na confissão volta depois à lembrança, somos obrigados, sem dúvida, a acusá-lo na primeira vez que de novo nos confessarmos.

##### 753 - Quem por vergonha, ou por outro motivo culpável, cala voluntariamente na confissão algum pecado mortal, que comete?

Quem, por vergonha, ou por qualquer outro motivo culpável, cala voluntariamente algum pecado 'mortal na confissão, profana o Sacramento e por isso torna-se réu de gravíssimo mo sacrilégio.

##### 754 - Quem ocultou voluntariamente algum pecado mortal na confissão, como há de conciliar a própria consciência?

Quem ocultou culpavelmente algum pecado mortal na confissão, deve expor ao confessor o pecado ocultado, dizer em quantas confissões o ocultou, e repetir todas as confissões, desde a última bem feita.

##### 755 - Que deve considerar quem se vir tentado a calar algum pecado na confissão?

Quem se vir tentado a calar um pecado grave na confissão, deve considerar:

<ul>
  <li>1º - que não teve vergonha de pecar na presença de Deus, que vê tudo;</li>
  <li>
    2º - que é melhor manifestar os próprios pecados ao confessor em segredo, do
    que viver inquieto no pecado, ter uma morte infeliz, e ser por isso
    envergonhado no dia do Juízo universal, em face do mundo inteiro;
  </li>
  <li>
    3º - que o confessor é obrigado ao sigilo sacramental, sob pecado
    gravíssimo, e com a ameaça de severíssimas penas temporais e eternas.
  </li>
</ul>

##### 756 - Que significam estas palavras: a acusação deve ser sincera?

A acusação deve ser sincera, significa que é necessário declarar os pecados como eles são, sem os desculpar, sem os diminuir e sem os aumentar.

##### 757 - Que significam estas palavras: a confissão deve ser prudente?

A confissão deve ser prudente, significa que, ao confessar os pecados, devemos servir-nosdos termosmaismodestos, e que devemosguardar-nosde descobrir ospecados alheios.

##### 758 - Que significam estas palavras: a confissão deve ser breve?

A confissão deve ser breve, significa que não. devemos ir falar de coisas inúteis ao confessor.

##### 759 - Mas o dever de confessar a outro homem os próprios pecados, não será muito custoso, sobretudo se são muito vergonhosos?

Ainda que confessar a outro homem os próprios pecados possa ser penoso, é necessário fazê-lo, porque é de preceito divino; e de outro modo não se pode obter o perdão dos pecados cometidos; além disso, a dificuldade de se confessar é compensada por muitas vantagens e grandes consolações.

#### 7º - Do modo de se confessar

##### 760 - Como vos apresentareis ao confessor?

Ponho-me de joelhos aos pés do confessor, e digo: Abençoai-me, Padre, porque pequei.

##### 761 - Que fareis enquanto o confessor vos der a bênção?

Inclino-me humildemente para receber a bênção, e faço o sinal da Cruz.

##### 762 - Depois de feito o sinal da Cruz, que direis?

Depois de feito o sinal da Cruz, direi: Eu me confesso a Deus todo-poderoso, à bem-aventurada sempre Virgem Maria, a todos os Santos, e a vós, Padre, porque pequei.

##### 763 - E depois, que direis?

Depois direi: Confessei-me em tal tempo; por graça de Deus recebi a absolvição, cumpri a penitência, e fui à Comunhão. Em seguida faz-se a acusação dos pecados.

##### 764 - Terminada a acusação dos pecados, que direis?

Direi: Acuso-me ainda de todos os pecados da vida passada, especialmente contra tal ou tal virtude, por exemplo, contra a pureza, contra o quarto Mandamento, etc.

##### 765 - Depois desta acusação, que direis ainda?

Direi: De todos estes pecados e de todos aqueles de que não me lembro, peço perdão a Deus de todo o meu coração; e a vós, Padre, peço a penitência e a absolvição.

##### 766 - Concluída assim a acusação dos pecados, que mais resta a fazer

Concluída a acusação dos pecados, é necessário ouvir com respeito o que disser o confessor; aceitar a penitência com sincera vontade de cumpri-la; e, enquanto ele dá a absolvição, renovar o ato de contrição.

##### 767 - Depois de recebida a absolvição, que há ainda a fazer?

Depois de recebida a absolvição, é preciso agradecer a Nosso Senhor, cumprir quanto antes a penitência, e pôr em prática os avisos do confessor.

#### 8º - Da absolvição

##### 768 - Devem os confessores dar sempre a absolvição àqueles que se confessam?

Os confessores devem dar a absolvição somente àqueles que julgam bem dispostos a recebê-la.

##### 769 - Podem os confessores diferir ou negar alguma vez a absolvição?

Os confessores não só podem, mas devem diferir ou negar a absolvição em certos casos, para não profanar o Sacramento.

##### 770 - Quais são os penitentes que se devem considerar mal dispostos, e aos quais se deve ordinariamente diferir ou negar a absolvição?

Os penitentes que se devem considerar mal dispostos são principalmente:

<ul>
  <li>
    1º - aqueles que não sabem os mistérios principais da fé, ou não se importam
    de aprender os pontos da Doutrina Cristã, que são obrigados a saber,
    conforme o seu estado;
  </li>
  <li>
    2º - aqueles que são gravemente negligentes em fazer o exame de consciência
    ou não dão sinais de dor e arrependimento;
  </li>
  <li>
    3º - aqueles que não querem restituir, podendo, as coisas alheias ou a
    reputação roubada;
  </li>
  <li>4º - aqueles que não perdoam de coração aos seus inimigos;</li>
  <li>
    5º - aqueles que não querem empregar os meios para se corrigir dos seus maus
    hábitos;
  </li>
  <li>6º - aqueles que não querem fugir das ocasiões próximas de pecado.</li>
</ul>

##### 771 - Não há excessivo rigor da parte do confessor em diferir a absolvição ao penitente que ele não julga ainda bem disposto?

Não. Não há excesso de rigor no confessor que difere a absolvição do penitente, porque não o julga ainda bem disposto; há antes caridade, pois procede como um bom médico, que tenta todosos remédios, ainda os desagradáveise penosos, para salvar a vida ao doente.

##### 772 - Deverá desesperar ou afastar-se inteiramente da confissão o pecador a quem se difere ou se nega a absolvição?

O pecador a quem se difere ou se nega a absolvição não deve desesperar ou afastar- se inteiramente da confissão; mas deve humilhar-se, reconhecer o seu estado deplorável, aproveitar osbons conselhos que o confessor lhe dá, e assim pôr-se quanto antes em estado de merecer a absolvição.

##### 773 - Que deve fazer o penitente quanto à escolha do confessor?

O verdadeiro penitente deve encomendar-se muito a Deus para escolher um confessor piedoso, douto e prudente, e deve depois entregar-se às suas mãos, e submeter-se a ele como a seu juiz e médico.

#### 9º - Da satisfação ou penitência

##### 774 - Que é a satisfação?

A satisfação, que também se chama penitência sacramental, é um dos atos do penitente, com o qual ele dá uma certa reparação à justiça divina pelos pecados cometidos pondo em prática aquelas obras que o confessor lhe impõe.

##### 775 - É obrigado o penitente a aceitar a penitência que o confessor lhe impõe?

O penitente é obrigado a aceitar a penitência que o confessor lhe impõe, se a pode cumprir, e, se não a pode cumprir, deve dizê-lo humildemente ao mesmo confessor, e pedir-lhe outra.

##### 776 - Quando se deve cumprir a penitência?

Se o confessor não marcou tempo, a penitência deve cumprir-se quanto antes, e deve fazer-se a diligência por cumpri-la em estado de graça.

##### 777 - Como se deve cumprir a penitência?

A penitência deve cumprir-se na sua integridade e com devoção.

##### 778 - Porque na confissão se impõe uma penitência?

Impõe-se uma penitência porque de ordinário, depois da absolvição sacramental que perdoa a culpa e a pena eterna, resta uma pena temporal a pagar neste mundo ou no Purgatório.

##### 779 - Por que razão quis Nosso Senhor perdoar no Sacramento do Batismo toda a pena devida aos pecados, e não no Sacramento da penitência?

Nosso Senhor quis perdoar no Sacramento do Batismo toda a pena devida aos pecados, e não no Sacramento da Penitência, porque os pecados depois do Batismo são muito mais graves, visto serem cometidos com maior conhecimento e ingratidão aos benefícios de Deus, e também para que a obrigação de satisfazer por eles sirva de freio para não se recair no pecado.

##### 780 - Podemos nós, com as nossas forças, dar satisfação a Deus?

Não; com nossas forças, não podemos dar satisfação a Deus; mas nós o podemos unindo-nos a Jesus Cristo que, com os merecimentos da sua Paixão e morte, dá valor às nossas ações.

##### 781 - É sempre bastante a penitência dada pelo confessor para pagar a pena que ainda resta, devida aos pecados?

A penitência que dá o confessor, de ordinário não é bastante para pagar a pena devida pelos pecados; por isso deve-se fazer a diligência por suprir com outras penitências voluntárias.

##### 782 - Quais são as obras de penitência?

As obras de penitência podem reduzir-se a três espécies: à oração, ao jejum, à esmola.

##### 783 - Que se entende por oração?

Por oração entende-se toda a espécie de exercícios de piedade.

##### 784 - Que se entende por jejum?

Por jejum entende-se toda a espécie de mortificação.

##### 785 - Que se entende por esmola?

Por esmola entende-se toda e qualquer obra de misericórdia espiritual e corporal.

##### 786 - Qual é a penitência mais meritória: a que dá o confessor, ou a que nós fazemos por nossa escolha?

Á penitência que nos dá o confessor é mais meritória, porque, sendo parte do Sacramento, recebe maior virtude dos merecimentos da Paixão de Jesus Cristo.

##### 787 - Vão logo para o Céu os que morrem depois de ter recebido a absolvição, mas antes de terem satisfeito plenamente à justiça de Deus?

Não; eles vão para o Purgatório, para ali satisfazerem à justiça de Deuse se purificarem inteiramente.

##### 788 - Podem as almas que estão no Purgatório ser aliviadas por nós nas suas penas?

Sim, as almas que estão no Purgatório podem ser aliviadas com orações, com esmolas, com todas as demais obras boas e com as indulgências, mas sobretudo com o Santo Sacrifício da Missa.

##### 789 - Além da penitência, que mais deve fazer o penitente depois da confissão?

O penitente, depoisda confissão, além de cumprir a penitência, se danificou injustamente o próximo nos bens ou na honra, ou se lhe deu escândalo, deve, o mais breve e na medida em que for possível, restituir-lhe os bens, reparar-lhe a honra e remediar o escândalo.

##### 790 - Como se pode reparar o escândalo que se causou?

Pode-se reparar o escândalo que se causou fazendo cessar a ocasião dele, e edificando com as palavras e com o bom exemplo aqueles que se tenha escandalizado.

##### 791 - De que maneira devemos satisfazer o próximo quando o tivermos ofendido?

Devemos satisfazer o próximo quando o tivermos ofendido, pedindo-lhe perdão ou dando-lhe alguma outra reparação conveniente.

##### 792 - Que frutos produz em nós uma boa confissão?

Uma boa confissão:

<ul>
  <li>1º - perdoa-nos os pecados cometidos, e dá-nos a graça de Deus;</li>
  <li>2º - restitui-nos a paz e o sossego de consciência;</li>
  <li>
    3º - reabre-nos as portas do Paraíso, e comuta a pena eterna do inferno em
    pena temporal;
  </li>
  <li>
    4º - preserva-nos das recaídas, e torna-nos capazes de ganhar indulgências.
  </li>
</ul>

#### 10º - Das indulgências

##### 793 - Que é a indulgência?

A indulgência é a remissão da pena temporal devida pelos pecados já perdoados quanto à culpa, remissão que a Igreja concede fora do Sacramento da Penitência.

##### 794 - De quem recebeu a Igreja o poder de conceder indulgências?

Foi de Jesus Cristo que a Igreja recebeu o poder de conceder indulgências.

##### 795 - De que maneira nos perdoa a Igreja a pena temporal por meio das indulgências?

A Igreja perdoa a pena temporal por meio das indulgências, aplicando-nos as satisfações superabundantes de Jesus Cristo, da Santíssima Virgem e dos Santos, as quais formam o que se chama o tesouro da Igreja.

##### 796 - Quem tem o poder de conceder indulgências?

O poder de conceder indulgências pertence ao Papa em toda a Igreja, e ao Bispo, na sua diocese, na medida em que lhe é concedido pelo Papa.

##### 797 - Quantas espécies há de indulgências?

Há duas espécies de indulgências: a indulgência plenária e a indulgência parcial.

##### 798 - Que é a indulgência plenária?

A indulgência plenária é a que perdoa toda a pena temporal devida pelos nossos pecados. Por isso, se alguém morresse depois de ter recebido esta indulgência, iria logo para o céu, inteiramente isento das penas do Purgatório.

##### 799 - Que é a indulgência parcial?

A indulgência parcial é a que perdoa só uma parte da pena temporal, devida pelos nossos pecados.

##### 800 - Qual é a intenção da Igreja ao conceder as indulgências?

A intenção da Igreja ao conceder as indulgências é auxiliar a nossa incapacidade de expiar neste mundo toda a pena temporal, fazendo-nos conseguir por meio de obras de piedade e de caridade cristã aquilo que nos primeiros séculosEla obtinha com o rigor dos cânones penitenciais.

##### 801 - Em que apreço devemos ter as indulgências?

Devemos ter as indulgências em muito grande apreço, porque com elas se satisfaz a justiça de Deus e mais depressa e mais facilmente se alcança a posse do céu.

##### 802 - Quais são as condições requeridas para se ganharem as indulgências?

As condições para se ganharem as indulgências são:

<ul>
  <li>
    1º - o estado de graça, pelo menos ao cumprir a última obra, e o desapego
    mesmo das culpas veniais cuja a pena se quer apagar;
  </li>
  <li>
    2º - o cumprimento das obras que a Igreja prescreve para se ganhar a
    indulgência;
  </li>
  <li>3º - a intenção de ganhá-las.</li>
</ul>

##### 803 - Podem as indulgências aplicar-se também às almas do Purgatório?

Sim, as indulgências podem aplicar-se também às almas do Purgatório quando quem as concede declara que se lhes podem aplicar.

##### 804 - Que é o Jubileu?

O Jubileu, que ordinariamente se concede todos os vinte e cinco anos, é uma indulgência plenária, à qual estão anexos muitos privilégios e concessões particulares, como o poder de obter-se a absolvição de alguns pecados reservados e de censuras, e a comutação de alguns votos.