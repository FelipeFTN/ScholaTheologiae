## VII - <em>Da Extrema-Unção</em>

##### 805 - Que é o Sacramento da Extrema-Unção?

A Extrema-Unção é o Sacramento instituído para alívio espiritual e também temporal dos enfermos em perigo de vida.

##### 806 - Que efeitos produz o Sacramento da Extrema-Unção?

O Sacramento da Extrema-Unção produz os seguintes efeitos:

<ul>
  <li>1º - aumenta a graça santificante;</li>
  <li>
    2º - apaga os pecados veniais e também os mortais que o enfermo arrependido
    já não possa confessar;
  </li>
  <li>
    3º - tira a fraqueza e languidez para o bem, que fica, ainda depois de se
    ter alcançado o perdão dos pecados;
  </li>
  <li>
    4º - dá força para suportar pacientemente o mal, para resistir às tentações,
    e para morrer santamente;
  </li>
  <li>
    5º - ajuda a recuperar a saúde do corpo, se isso for útil à salvação da
    alma.
  </li>
</ul>

##### 807 - Em que tempo se deve receber a Extrema-Unção?

A Extrema-Unção deve receber-se quando a doença é grave, e, se puder ser, depois de o enfermo ter recebido osSacramentos da Penitência e da Eucaristia; e deve procurar-se que o enfermo a receba quando está ainda com plena consciência e com alguma esperança de vida.

#####

808 - Por que é bom que o enfermo receba a Extrema-Unção quando está em plena consciência e com alguma esperança de vida?

É bom receber a Extrema-Unção quando o enfermo está ainda com plena consciência e com alguma esperança de vida, porque recebendo-a com melhores disposições poderá obter maior proveito; e além disso, como este Sacramento dá a saúde do corpo, se convém à alma auxiliando as forças da natureza, não se deve estar à espera de que se desespere da cura.

##### 809 - Com que disposições se deve receber a Extrema-Unção?

As principais disposições para receber a Extrema-Unção são: estar em estado de graça, confiar na eficácia do Sacramento e na misericórdia divina e resignar-se à vontade de Deus.

##### 810 - Que sentimento deve experimentar o enfermo à vista do Sacerdote?

À vista do Sacerdote, o enfermo deve experimentar sentimentos de gratidão para com Deus, por lho ter enviado, deve recebê-lo de boa vontade e pedir, se puder, por si mesmo, os confortos da Religião.