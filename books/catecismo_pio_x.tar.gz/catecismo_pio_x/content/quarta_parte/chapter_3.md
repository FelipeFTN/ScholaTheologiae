## III - <em>Da Confirmação ou Crisma</em>

##### 575 - Que é o Sacramento da Confirmação?

A Confirmação, ou Crisma, é um Sacramento que nos dá o Espírito Santo, imprime na nossa alma o caráter de soldados de Cristo, e nos faz perfeitos cristãos.

##### 576 - De que maneira o Sacramento da Confirmação nos faz perfeitos cristãos?

A Confirmação faz-nosperfeitos cristãos, confirmando-nosna fé, e aperfeiçoando em nós as outras virtudes e os dons recebidos no santo Batismo; e é por isso que se chama Confirmação.

##### 577 - Quais são os dons do Espírito Santo que se recebem na Confirmação?

Os dons do Espírito Santo, que se recebem na Confirmação, são sete:

<ul>
  <li>1º - Sabedoria,</li>
  <li>2º - Entendimento;</li>
  <li>3º - Conselho;</li>
  <li>4º - Fortaleza;</li>
  <li>5º - Ciência;</li>
  <li>6º - Piedade;</li>
  <li>7º - Temor de Deus.</li>
</ul>

##### 578 - Qual é a matéria deste Sacramento?

A matéria deste Sacramento, além da imposição das mãos do Bispo, é a unção feita na fronte da pessoa batizada, com o santo Crisma; por isso, este Sacramento se chama também Crisma, que significa Unção.

##### 579 - Que é o santo Crisma?

O santo Crisma é óleo de oliveira misturado com bálsamo, e consagrado pelo Bispo na Quinta-Feira Santa.

##### 580 - Que significam o óleo e o bálsamo neste Sacramento?

Neste Sacramento, o óleo, que se derrama e fortalece, significa a abundância da graça que se difunde na alma do cristão para o confirmar na fé; e o bálsamo, que é aromático e preserva da corrupção, significa que o cristão fortificado por esta graça é capaz de difundir o bom aroma das virtudes cristãs, e de preservar-se da corrupção dos vícios.

##### 581 - Qual é a forma do Sacramento da Confirmação?

A forma atual do Sacramento da Confirmação é esta: Recebe o sinal do dom do Espírito Santo, que substituiu a antiga: Eu te assinalo com o sinal da Cruz, e te confirmo com o Crisma da salvação, em nome do Pai e do Filho e do Espírito Santo. Assim seja.

##### 582 - Quem é o ministro do Sacramento da Confirmação?

O ministro ordinário do Sacramento da Confirmação e só o Bispo.

##### 583 - Com que cerimônias administra o Bispo a Confirmação?

O Bispo, para administrar o Sacramento da Confirmação, primeiro estende as mãos sobre os que estão para se crismar, invocando sobre eleso Espírito Santo; em seguida faz uma unção em forma de cruz com o santo Crisma na fronte de cada um, dizendo aspalavrasda forma; depois, com a mão direita, dá uma leve bofetada na face do crismado, dizendo: A paz seja contigo; e no fim abençoa solenemente todos os crismados.

##### 584 - Por que se faz a unção na fronte?

Faz-se a unção na fronte, onde aparecem os sinais do temor e da vergonha, a fim de que o crismado entenda que não deve envergonhar-se do nome e da profissão de cristão, nem ter medo dos inimigos da fé.

##### 585 - Por que se dá uma leve bofetada na face do crismado?

Dá-se uma leve bofetada na face do crismado para que saiba que deve estar pronto a sofrer todas as afrontas e todas as penas pela fé e amor de Jesus Cristo.

##### 586 - Devem todos procurar receber o Sacramento da Confirmação?

Sim, todos devem procurar receber o Sacramento da Confirmação e fazer que os seus subordinados o recebam.

##### 587 - Em que idade é conveniente receber o Sacramento da Confirmação?

A idade em que é conveniente receber o Sacramento da Confirmação é a de sete anos, pouco mais ou menos, porque então costumam começar as tentações e já se pode conhecer bastante a graça deste Sacramento, e conservar-se a lembrança de tê-lo recebido.

##### 588 - Que disposições se requerem para receber o Sacramento da Confirmação?

Para receber dignamente o Sacramento da Confirmação é necessário estar em estado de graça, saber os mistérios principais da nossa santa Fé, e aproximar-se deste Sacramento com reverência e devoção.

##### 589 - Cometeria pecado quem recebesse a Confirmação segunda vez?

Cometeria um sacrilégio, porque a Confirmação é um daqueles Sacramentos que imprimem caráter na alma e que portanto só se podem receber uma vez.

##### 590 - Que deve fazer o cristão para conservar a graça da Confirmação?

Para conservar a graça da Confirmação, o cristão deve orar freqüentemente, fazer boas obras, e viver segundo a lei de Jesus Cristo, sem respeito humano.

##### 591 - Por que também na Confirmação há padrinhos e madrinhas?

Para que estes, com as palavrase com osexemplos, orientem o crismado no caminho da salvação e o auxiliem nos combates espirituais.

##### 592 - Que condições se requerem no padrinho?

O padrinho deve ser de idade conveniente, católico, crismado, instruído nas coisas mais necessárias da religião e de bons costumes; e deve ser do mesmo sexo que o crismado.

##### 593 - Contrai algum parentesco com o crismado o padrinho de Crisma?

Sim, o padrinho de Crisma contrai parentesco espiritual com o crismado; mas este parentesco não é impedimento para o matrimônio.