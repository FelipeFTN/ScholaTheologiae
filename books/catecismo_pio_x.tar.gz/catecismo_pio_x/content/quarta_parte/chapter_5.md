## V - <em>Do Santo Sacrifício da Missa</em>

### 1º - Da essência, da instituição e dos fins do Santo Sacrifício da Missa

##### 649 - Deve considerar-se a Eucaristia só como Sacramento?

A Eucaristia não é somente um Sacramento; é também o sacrifício permanente da Nova Lei, que Jesus Cristo deixou à Igreja, para ser oferecido a Deus pelas mãos dos seus sacerdotes.

##### 650 - Em que consiste em geral o sacrifício?

O sacrifício, em geral, consiste em oferecer a Deus uma coisa sensível, e destruí-la de alguma maneira, para reconhecer o supremo domínio que Ele tem sobre nós e sobre todas as coisas.

##### 651 - Como se chama este sacrifício da Nova Lei?

Este sacrifício da Nova Lei chama-se a santa Missa.

##### 652 - Que é então a santa Missa?

A santa Missa é o sacrifício do Corpo e do Sangue de Jesus Cristo, oferecido sobre os nossos altares, debaixo das espécies de pão e de vinho, ein memória do sacrifício da Cruz.

##### 653 - É o Sacrifício da Missa o mesmo que o da Cruz?

O Sacrifício da Missa é substancialmente o mesmo que o da Cruz, porque o mesmo Jesus Cristo, que se ofereceu sobre a Cruz, é que se oferece pelas mãos dos sacerdotes seus ministros, sobre os nossos altares, mas quanto ao modo por que é oferecido, o sacrifício da Missa difere do sacrifício da Cruz, conservando todavia a relação mais íntima e essencial com ele.

##### 654 - Que diferença, pois, e que relação há entre o Sacrifício da Missa e o da Cruz?

Entre o Sacrifício da Missa e o sacrifício da Cruz há esta diferença e esta relação: que Jesus Cristo sobre se ofereceu derramando o seu sangue e merecendo para nós; ao passo que sobre os altares Ele se sacrifica sem derramamento de sangue, e nos aplica os frutos da sua Paixão e Morte.

##### 655 - Que outra relação tem o Sacrifício da Missa com o da Cruz?

Outra relação do Sacrifício da Missa com o da Cruz é que o Sacrifício da Missa representa de modo sensível o derramamento do Sangue de Jesus Cristo na Cruz; porque em virtude das palavras da consagração só o Corpo de nosso Salvador se torna presente debaixo das espécies de pão, e debaixo das espécies de vinho, só o seu Sangue; entretanto, pela concomitância natural e pela união hipostática, está presente, debaixo de cada uma das espécies, Jesus Cristo todo inteiro, vivo e verdadeiro.

##### 656 - Não é porventura o Sacrifício da Cruz o único sacrifício da Nova Lei?

O Sacrifício da Cruz é o único sacrifício da Nova Lei, porquanto por ele Nosso Senhor aplacou a Justiça Divina, adquiriu todos os merecimentos necessários para nos salvar, e assim consumou da sua parte a nossa redenção. São estes merecimentos que Ele nos aplica pelos meios que instituiu na sua Igreja, entre os quais está o Santo Sacrifício da Missa.

##### 657 - Para que fins se oferece o Santo Sacrifício da Missa?

Oferece-se a Deus o Santo Sacrifício da Missa para quatro fins:

<ul>
  <li>
    1º - para honrá-Lo como convém, e sob este ponto de vista o sacrifício é
    latrêutico;
  </li>
  <li>
    2º - para Lhe dar graças pelos seus benefícios, e sob este ponto de vista o
    sacrifício é eucarístico;
  </li>
  <li>
    3º - para aplacá-Lo, dar-Lhe a devida satisfação pelos nossos pecados, para
    sufragar as almas do Purgatório, e sob este ponto de vista o sacrifício é
    propiciatório;
  </li>
  <li>
    4º - para alcançar todas as graças que nos são necessárias, e sob este ponto
    de vista o sacrifício é impetratório.
  </li>
</ul>

##### 658 - Quem oferece a Deus o Santo Sacrifício da Missa?

O primeiro e principal oferente do Santo Sacrifício da Missa é Jesus Cristo, e o sacerdote é o ministro que em nome de Jesus Cristo oferece este sacrifício ao Eterno Padre.

##### 659 - Quem instituiu o Santo Sacrifício da Missa?

Foi o próprio Jesus Cristo que instituiu o Santo Sacrifício da Missa, quando instituiu o Sacramento da Eucaristia, e disse que fosse ele feito em memória da sua Paixão.

##### 660 - A quem se oferece o Santo Sacrifício da Missa?

O Santo Sacrifício da Missa oferece-se só a Deus.

##### 661 - Se a santa Missa se oferece só a Deus, por que se celebram tantas Missas em honra da Santíssima Virgem e dos Santos?

A missa celebrada em honra da Santíssima Virgem e dos Santos é sempre um sacrifício oferecido só a Deus; diz-se, porém, celebrada em honra da Santíssima Virgem e dos Santos, para louvar a Deus neles pelos dons que lhes concedeu, e para alcançar, pela intercessão deles, em maior abundância, as graças de que necessitamos.

##### 662 - Quem participa dos frutos da Missa?

Toda a Igreja participa dos frutos da Missa, mas particularmente:

<ul>
  <li>
    1º - o sacerdote e os que assistem à Missa, os quais se consideram unidos ao
    sacerdote;
  </li>
  <li>
    2º - aqueles por quem se aplica a Missa, e podem ser tanto vivos como
    defuntos.
  </li>
</ul>

#### 2º - Do modo de assistir à Missa

##### 663 - Quantas coisas são necessárias para ouvir bem e com fruto a santa Missa?

Para ouvir bem e com fruto a santa Missa são necessárias duas coisas:

<ul>
  <li>1º - modéstia exterior,</li>
  <li>2º - devoção interior.</li>
</ul>

##### 664 - Em que consiste a modéstia exterior?

A modéstia exterior consiste particularmente em estar modestamente vestido, em observar o silêncio e o recolhimento, e em estar, quanto possível, de joelhos, excetuando o tempo dos dois evangelhos, que se ouvem estando de pé.

##### 665 - Ao ouvir a santa Missa qual é o melhor modo de praticar a devoção interior?

O melhor modo de praticar a devoção interior ao ouvir a santa Missa é o seguinte:

<ul>
  <li>
    1º - Unir-se, desde o começo, a própria intenção à do sacerdote, oferecendo
    a Deus o Santo Sacrifício para os fins por que foi instituído;
  </li>
  <li>
    2º - acompanhar o sacerdote em cada uma das orações e ações do Sacrifício;
  </li>
  <li>
    3º - meditar a Paixão e morte de Jesus Cristo e detestar, de todo o coração,
    os pecados que Lhe deram causa;
  </li>
  <li>
    4º - fazer a comunhão sacramental, ou ao menos a espiritual, ao tempo em que
    o sacerdote comunga.
  </li>
</ul>

##### 666 - Que é a Comunhão espiritual?

A Comunhão espiritual é um grande desejo de se unir sacramentalmente a Jesus Cristo, dizendo por exemplo: Meu Senhor JesusCristo, eu desejo de todo o meu coração unir-me a Vós agora e por toda a eternidade ; e fazendo os mesmos atos que se fazem antes e depois da Comunhão sacramental.

##### 667 - Impede ouvir a Missa com fruto a recitação do Rosário ou de outras orações durante o Santo Sacrifício?

A recitação destas orações não impede ouvir com fruto a Missa, desde que haja um esforço possível de seguir as cerimônias do Santo Sacrifício.

##### 668 - É coisa boa também rezar pelos outros, quando se assiste à Santa Missa?

É coisa boa rezar também pelos outros, quando se assiste à santa Missa; e até o tempo da santa Missa é o mais oportuno para rezar pelos vivos e pelos mortos.

##### 669 - Terminada a Missa, que se deve fazer?

Terminada a Missa, devemos dar graças a Deus por nos ter concedido a graça de assistir a este grande sacrifício e pedir-Lhe perdão das faltas cometidas enquanto a assistíamos.