## II - <em>Da oração dominical</em>

Um dia, Jesus estava rezando num certo lugar. Quando terminou, um dos discípulos lhe pediu: Senhor, ensina-nos a rezar como João ensinou a seusdiscípulos. Ele lhes disse: Quando rezardes, dizei: Pai, santificado seja o teu nome, venha o teu Reino. O pão nosso de cada dia nos dá hoje. E perdoa-nos os nossos pecados, pois também nós perdoamos a todo o nosso devedor, e não nos deixescair em tentação. Jesus acrescentou: Se algum de vós tiver um amigo e for procurá-lo à meia-noite e lhe disser: Amigo, empresta-me três pães, pois um amigo meu chegou de viagem e não tenho nada para oferecer, e ele responder lá de dentro: Não me incomodes, a porta já está fechada e eu e meus filhos já estamos deitados; não posso me levantar para te dar os pães. Eu vos digo: Se ele não se levantar e não lhe der os pães por ser seu amigo, ao menos se levantará por causa do incômodo e lhe dará quantos necessitar. Pedir com confiança Digo-vos, pois: Pedi e vos será dado; buscai e achareis; batei e vos abrirão. Pois quem pede, recebe; quem procura, acha; e a quem bate, se abre. Que pai dentre vósdará uma pedra a seu filho que pede um pão? Ou lhe dará uma cobra se ele pedir um peixe? Ou se pedir um ovo lhe dará um escorpião? Se, pois, vós que sois maus, sabeis dar coisas boas aos vossos filhos, quanto mais o Pai do céu saberá dar o Espírito Santo aos que pedirem! Luc 11, 1-13

#### 1º - Da oração dominical em geral

##### 278 - Qual é a oração vocal mais excelente?

A oração vocal mais excelente é aquela que o próprio Jesus Cristo nos ensinou, isto é, o Pai-Nosso.

##### 279 - Por que é o Pai-Nosso a oração mais excelente?

O Pai-Nosso é a oração mais excelente porque foi o próprio Jesus Cristo que a compôs e no-la ensinou; porque contém claramente, em poucas palavras, tudo o que podemos esperar de Deus; e porque é a regra e o modelo de todas as outras orações.

##### 280 - É também o Pai-Nosso a oração mais eficaz?

O Pai-Nosso é também a oração mais eficaz, porque é a mais agradável a Deus, porque é feita com as mesmas palavras que nos ditou o seu Divino Filho.

##### 281 - Por que se chama o Pai-Nosso oração dominical?

Chama-se o Pai-Nosso oração dominical, que quer dizer oração do Senhor, precisamente porque a ensinou Jesus Cristo por sua própria boca.

##### 282 - Quantas petições há no Pai-Nosso?

No Pai-Nosso há sete petições precedidas de um preâmbulo.

##### 283 - Rezai o Pai-Nosso.

Pai-Nosso, que estais no Céu:

<ul>
  <li>1ª - Santificado seja o vosso nome.</li>
  <li>2ª - Venha a nós o vosso reino.</li>
  <li>3ª - Seja feita a vossa vontade, assim na terra como no Céu.</li>
  <li>4ª - O pão nosso de cada dia nos dai hoje.</li>
  <li>
    5ª - Perdoai-nos as nossas dívidas assim como nós perdoamos aos nossos
    devedores.
  </li>
  <li>6ª - E não nos deixeis, cair em tentação.</li>
  <li>7ª - Mas livrai-nos do mal. Amém</li>
</ul>

##### 284 - Por que, invocando a Deus no princípio da oração dominical, O chamamos nosso Pai?

No princípio da oração dominical chamamos a Deus nosso Pai para despertar a nossa confiança na sua infinita bondade, visto sermos seus filhos.

##### 285 - Por que podemos nós dizer que somos filhos de Deus?

Somos filhos de Deus:

<ul>
  <li>
    1º - porque Ele nos criou à sua imagem e nos conserva e governa com a sua
    providência;
  </li>
  <li>
    2º - porque, por especial benevolência, Ele nos adotou no Batismo como
    irmãos de Jesus Cristo e co-herdeiros, juntamente com Ele, da eterna glória.
  </li>
</ul>

##### 286 - Por que chamamos a Deus Pai nosso, e não Pai meu?

Chamamos a Deus Pai nosso e não Pai meu, porque todos somos seus filhos, e portanto devemos considerar-nos e amar-nos todos como irmãos, e orar uns pelos outros.

##### 287 - Estando Deus em toda a parte, por que é que Lhe dizemos: que estais no Céu?

Deus está em toda a parte; mas dizemos: Pai Nosso que estais no Céu, para elevar os nossos corações ao Céu, onde Deus se manifesta na glória aos seus filhos.

#### 2º - Da primeira petição do Pai-Nosso

##### 288 - Que pedimos a Deus na primeira petição: santificado seja o vosso nome?

Na primeira petição: santificado seja o vosso nome, pedimos que Deus seja conhecido, amado, honrado e servido por todos os homens, e por nós em particular.

##### 289 - Que temos em vista, ao pedir que Deus seja conhecido, amado e servido por todos os homens?

Temos em vista pedir que os infiéis cheguem ao conhecimento do verdadeiro Deus, que os hereges reconheçam os seus erros, que os cismáticos voltem à unidade da Igreja, que os pecadores se corrijam e que os justos sejam perseverantes no bem.

##### 290 - Por que em primeiro lugar pedimos que seja santificado o nome de Deus?

Em primeiro lugar pedimos que seja santificado o nome de Deus, porque devemos prezar mais a glória de Deus do que todos os nossos bens e vantagens.

##### 291 - De que maneira podemos nós promover a glória de Deus?

Podemos promover a glória de Deus com a oração, o bom exemplo e dirigindo para Ele todos os nossos pensamentos afetos e ações.

#### 3º - Da segunda petição do Pai-Nosso

##### 292 - Que entendemos por reino de Deus?

Por reino de Deus entendemos uni tríplice reino espiritual, a saber: o reino de Deusem nós, ou o reino da graça; o reino de Deus na terra, isto é, a Santa Igreja Católica; e o reino de Deus nos céus, ou o Paraíso.

##### 293 - Que pedimos com as palavras: venha a nós o vosso reino, com relação à graça?

Com relação à graça, pedimosque Deus reine em nós com a sua graça santificante, pela qual Ele se compraz em residir em nós como um rei em seu palácio, e que nos mantenha unidos a si pelas virtudes da fé, da esperança e da caridade, pelas quais reina sobre ti nossa inteligência, sobre o nosso coração e sobre a nossa vontade.

##### 294 - Que pedimos com as palavras venha a nós o vosso reino, com relação à Igreja?

Com relação à Igreja, pedimos que Ela se dilate cada vez mais, e se propague por todo o mundo para salvação dos homens.

##### 295 - Que pedimos com as palavras venha a nós o vosso reino, com relação à glória?

Com relação à glória, pedimos que possamos um dia ser admitidos no Santo Paraíso, para o qual fomos criados e onde seremos plenamente felizes.

#### 4º - Da terceira petição do Pai-Nosso

##### 296 - Que pedimos na terceira petição: seja feita a vossa vontade, assim na terra como no Céu?

Na terceira petição: seja feita a vossa vontade, assim na terra como no Céu. pedimos a graça de fazer em todas as coisas a vontade de Deus, obedecendo aos seus santos Mandamentos tão prontamente como os Anjos e os Santos Lhe obedecem no Céu. Pedimos, além disso, a graça de corresponder às inspirações divinas e de viver resignados à vontade de Deus, quando Ele nos manda tribulações.

##### 297 - É-nos necessário cumprir a vontade de Deus?

É-nos tão necessário cumprir a vontade de Deus, como nos é necessário conseguir a salvação eterna, porque Jesus Cristo disse que só entrará tio reino dos céus quem tiver feito a vontade de seu Pai.

##### 298 - De que maneira podemos conhecer qual a Vontade de Deus a nosso respeito?

A Vontade de Deus rios é manifestada pelos Mandamentos de sua Lei e pelos preceitos de sua Santa Igreja. Nossos superiores espirituais, postos por Deus para guiar-nos no caminho da Salvação, nos orientam a fim de que conheçamos os desígnios particulares da Providência a nosso respeito, desígnios que se podem manifestar em divinas inspirações ou nas circunstâncias em que o Senhor nos tenha colocado.

##### 299 - Devemos sempre reconhecer a vontade de Deus nas prosperidades ou adversidades da vida?

Tanto nas prosperidades como nas adversidades da vida presente, devemos reconhecer sempre a vontade de Deus, o qual tudo dispõe ou permite para nosso bem.

##### 300 - Quer dizer que Deus nos revela sua Vontade pelos sinais dos tempos?

Não. A revelação Divina encerrou-se com a morte do último Apóstolo, de maneira que não há mais Revelação pública necessária para a salvação. A afirmação de que devemos ver em todas as coisas a Vontade de Deus, diz apenas que todas as coisas estão sujeitas à Santíssima Vontade de Deus, de maneira que mesmo o mal não acontece sem uma permissão de Deus, que sabe tirar o bem do mal, e por isso o permite. E como Deus tem sobre os homens uma amorosa Providência, devemos ver em todos os acontecimentos, bons ou maus, um desígnio de Deus que visa nossa salvação eterna.

#### 5º - Da quarta petição do Pai-Nosso

##### 301 - Que pedimos na quarta petição: o pão nosso de cada dia nos dai hoje?

Na quarta petição: o pão nosso de cada dia nos dai hoje, pedimos a Deus o que nos é necessário cada dia para a alma e para o corpo.

##### 302 - Que pedimos a Deus para a nossa alma?

Para a nossa alma pedimos a Deus o sustento da vida espiritual, isto é, pedimos ao Senhor que nos dê a sua graça, da qual a todo o instante temos necessidade.

##### 303 - Como se sustenta a vida da nossa alma?

A vida da nossa alma sustenta-se especialmente com o alimento da palavra divina, e com o Santíssimo Sacramento do altar.

##### 304 - Que pedimos a Deus para o nosso corpo?

Para o nosso corpo pedimos o que é necessário para o sustento da vida temporal.

##### 305 - Por que dizemos: o pão nosso nos dai hoje, não dizemos antes: dai-nos hoje o pão?

Dizemos: O pão nosso nos dai hoje, e não dizemos: dai-nos hoje o pão, para excluir todo o desejo tio,, bens alheios. Por isso pedimos ao Senhor que nos ajude nos ganhos justos e lícitos, a fim de granjearmos o sustento com o nosso trabalho, sem furtos nem fraudes.

##### 306 - Por que dizemos: o pão nos dai, e não: o pão me dai?

Dizemos: nos dai, e não: me dai, para nos lembrarmos de que, assim como os bens nos vêm de Deus, assim também se Ele no-los dá em abundância, é para que distribuamos o supérfluo pelos pobres.

##### 307 - Por que acrescentamos: de cada dia?

Acrescentamos de cada dia, porque devemos desejar o que nos é necessário para a vida, e não a fartura dos alimentos e dos bens da terra.

##### 308 - Que quer dizer mais a palavra hoje na quarta petição?

A palavra hoje quer dizer que não devemos estar demasiadamente preocupados com o futuro, irias pedir o que rios é necessário rio momento.

#### 6º - Da quinta petição do Pai-Nosso

##### 309 - Que pedimos na quinta petição: Perdoai-nos as nossas dívidas, assim como nós perdoamos aos nossos devedores?

Na quinta petição: perdoai-nos as nossas dívidas, assim como nós perdoamos aos nossos devedores, pedimos a Deus que nos perdoe os nossos pecados, corno nós perdoamos aos que nos ofendem.

##### 310 - Por que nossos pecados são chamados de dívidas?

Nossos pecados são chamados de dívidas porque por causa deles devemos satisfazer a divina justiça, seja nesta vida, seja na outra.

##### 311 - Os que não perdoam ao próximo, podem esperar que Deus lhes perdoe?

Os que não perdoam ao próximo não têm razão alguma para esperar que Deus lhes perdoe, tanto mais que se condenam por si mesmos, dizendo ti Deus que lhes perdoe, como eles perdoam ao próximo.

#### 7º - Da sexta petição do Pai-Nosso

##### 312 - Que pedimos na sexta petição: e não nos deixeis cair em tentação?

Na sexta petição: e não nos deixeis cair em tentação, pedimos a Deus que nos livre das tentações, ou não permitindo que sejamos tentados, ou dando-nos graças para não sermos vencidos.

##### 313 - Que são as tentações?

As tentações são um incitamento ao pecado que nos vem do demônio, ou das pessoas más ou das nossas paixões.

##### 314 - É pecado ter tentações?

Não é pecado ter tentações, mas é pecado consentir nelas, ou expor-se voluntariamente ao perigo de consentir.

##### 315 - Por que permite Deus que sejamos tentados?

Deus permite que sejamos tentados, para provar a nossa fidelidade, para fortalecer as nossas virtudes e para aumentar os nossos merecimentos.

##### 316 - Que devemos fazer para evitar as tentações?

Para evitar as tentações devemos fugir das ocasiões perigosas, guardar os sentidos, receber com freqüência a os santos sacramentos, fazer uso da oração, especialmente da devoção a Maria Santíssima, Senhora Nossa.

#### 8º - Da sétima petição do Pai-Nosso

##### 317 - Que pedimos na sétima petição: mas livrai-nos do mal?

Na sétima petição: mas livrai-nos do mal, pedimos a Deus que nos livre dos males passados, presentes, futuros, e especialmente do sumo mal, que é o pecado, da condenação eterna, que é o seu castigo.

##### 318 - Por que dizemos: livrai-nos do mal, e não: dos males?

Dizemos: livrai-nos do mal, e não: dos males, por que não devemos desejar ser isentos de todos os males desta vida, mas só daqueles que são nocivos à nossa alma, e por isso pedimos a libertação do mal em geral, isto é, de tudo aquilo que Deus vê que para nós é mal.

##### 319 - Não é lícito pedir a Deus que nos livre de algum mal em particular, por exemplo, de uma doença?

Sim. é lícito pedir a libertação de algum mal em particular, mas sempre entregando-nos à vontade de Deus, que pode no entanto, ordenar aquela tribulação para proveito da nossa alma.

##### 320 - Para que nos servem as tribulações que Deus nos manda?

As tribulações que Deus nos envia nos são úteis para fazermos penitência das nossas culpas, para provar nossas virtudes, e sobretudo para levar-nos à imitação de Jesus Cristo, nossa cabeça, ao qual é justo que nos conformemos nos sofrimentos, se quisermos ter parte na sua glória.

##### 321 - Que quer dizer Amém no fim do Pai-Nosso?

Amém quer dizer: assim seja, assim desejo. assim peço ao Senhor e assim espero.

##### 322 - Para se alcançarem as graças pedidas no Pai-Nosso basta rezá-lo de qualquer maneira?

Para se alcançarem as graças pedidas no Pai-Nosso é necessário rezá-lo sem precipitação, com atenção e acompanhá-lo com o coração.

##### 323 - Quando devemos rezar o Pai-Nosso?

Devemos rezar o Pai-Nosso todos os dias, porque todos os dias temos necessidade do auxílio de Deus.