## III - <em>Da Ave-Maria</em>

No sexto mês, o anjo Gabriel foi enviado da parte de Deus para uma cidade da Galiléia, chamada Nazaré, a uma virgem, prometida em casamento a um homem, chamado José, da casa de Davi. O nome da virgem era Maria. Entrando onde ela estava, o anjo lhe disse: Alegra-te, cheia de graça, o Senhor está contigo! Ao ouvir as palavras, ela se perturbou e refletia no que poderia significar a saudação. Mas o anjo lhe falou: Não tenhas medo, Maria, porque encontraste graça diante de Deus. Eis que conceberás e darás à luz um filho e lhe porás o nome de Jesus. Ele será grande e será chamado Filho do Altíssimo. O Senhor Deus lhe dará o trono de Davi, seu pai. Ele reinará na casa de Jacó pelos séculos e seu reino não terá fim. Maria perguntou ao anjo: Como acontecerá isso, pois não conheço homem? Em resposta o anjo lhe disse: O Espírito Santo virá sobre ti e o poder do Altíssimo te cobrirá com sua sombra; é por isso que o menino santo que vai nascer será chamado Filho de Deus. Até Isabel, tua parenta, concebeu um filho em sua velhice, e este é o sexto mês daquela que era considerada estéril, porque para Deus nada é impossível. Disse então Maria: Eis aqui a serva do Senhor. Aconteça comigo segundo tua palavra! E dela seafastou o anjo. Naqueles dias, Maria se pôs a caminho e foi apressadamente às montanhas para uma cidade de Judá. Entrou em casa de Zacarias e saudou Isabel. Aconteceu que, mal Isabel ouviu a saudação de Maria, a criança saltou em seu ventre; e Isabel, cheia do Espírito Santo, exclamou em voz alta: Bendita és tu entre as mulheres e bendito é o fruto do teu ventre! Donde me vem a honra que a mãe do meu Senhor venha a mim? Pois quando soou em meus ouvidos a voz de tua saudação, a criança saltou de alegria em meu ventre. Feliz é aquela que teve fé no cumprimento do que lhe foi dito da partedo Senhor. Luc 1, 26-45

##### 324 - Que oração costumamos rezar depois do Pai-Nosso?

Depois do Pai-Nosso rezamos a saudação angélica, isto é, a Ave-Maria, por meio da qual recorremos à Santíssima Virgem.

##### 325 - Por que é a Ave-Maria chamada saudação angélica?

Chama-se a Ave-Maria saudação angélica, porque principia com a saudação que dirigiu à Virgem Maria o Arcanjo São Gabriel.

##### 326 - De quem são as palavras da Ave-Maria?

Aspalavras da Ave-Maria são, em parte do Arcanjo São Gabriel, em parte de Santa Isabel e em parte da Igreja.

##### 327 - Quais são as palavras do Arcanjo São Gabriel?

As palavras do Arcanjo São Gabriel são: Ave, cheia de graça; o Senhor é convosco, bendita sois vós entre as mulheres.

##### 328 - Quando disse o Anjo a Maria estas palavras?

O Anjo disse a Maria estas palavras quando Lhe foi anunciar da parte de Deus o mistério da Encarnação, que nEla devia operar-se.

##### 329 - Que temos em vista ao saudarmos a Santíssima Virgem com as mesmas palavras do Arcanjo?

Ao saudarmos a Santíssima Virgem com as mesmas palavras do Arcanjo, nós nos congratulamos com Ela, lembrando os dons e singulares privilégios com que Deus a favoreceu de preferência a todas as outras criaturas.

##### 330 - Quais são as palavras de Santa Isabel?

As palavras de Santa Isabel são: Bendita sois vós entre as mulheres, e bendito é o fruto do vosso ventre.

##### 331 - Quando disse Santa Isabel estas palavras?

Santa Isabel disse estas palavras, inspirada por Deus, quando, três meses antes de nascer seu filho João Batista, foi visitada pela Santíssima Virgem, que já trazia no seio o seu Divino Filho Jesus.

##### 332 - Que fazemos ao dizer estas palavras?

Ao dizer estas palavras de Santa Isabel, congratulamo-nos com Maria Santíssima pela sua excelsa dignidade de Mãe de Deus, bendizemos a Deus e darnos-Lhe graças por nos ter dado Jesus Cristo por meio de Maria.

##### 333 - De quem são as demais palavras da Ave-Maria?

Todas as demais palavras da Ave-Maria foram acrescentadas pela Igreja.

##### 334 - Que pedimos com as últimas palavras da Ave-Maria?

Com as ultimas palavras da Ave-Maria pedimos o proteção da Santíssima Virgem no decurso desta vida e especialmente na hora da nossa morte, no qual nos será mais necessária.

##### 335 - Por que depois do Pai-Nosso, dizemos antes a Ave-Maria do que outra qualquer oração?

Porque a Santíssima Virgem é a Advogada mais poderosa junto de Jesus Cristo: por isso, depois de termos rezado a oração que Jesus Cristo nos ensinou, pedimos à Santíssima Virgem que nos alcance as graças que imploramos.

##### 336 - Por que motivo é tão poderosa a Santíssima Virgem?

A Santíssima Virgem é tão poderosa, porque é Mãe de Deus, e é impossível que não seja atendida por Ele.

##### 337 - Que nos ensinam os Santos a respeito da devoção à Virgem Maria?

A respeito da devoção a Maria, os Santos nos ensinam que os seus verdadeiros devotos são por Ela amados e protegidos com amor de Mãe muito terna, e por meio dEla têm a certeza de encontrar a Jesus Cristo, e de alcançar o Paraíso.

##### 338 - Qual é a devoção à Virgem Maria, que a Igreja nos recomenda de modo especial?

A devoção que a Igreja nos recomenda de modo especial em honra da Santíssima Virgem é a reza do santo Rosário.