## I - <em>Da oração em geral</em>

<p>
  Jesus contou também a seguinte parábola para alguns que confiavam em si
  mesmos, tendo-se por justos, e desprezavam os outros: Dois homens subiram ao
  Templo para orar; um era fariseu, o outro, um cobrador de impostos. O fariseu
  rezava, de pé, desta maneira: Ó meu Deus, eu te agradeço por não ser como
  osoutroshomens, que são ladrões, injustos, adúlteros, nem mesmo como este
  cobrador de impostos. Jejuo duas vezes por semana, pago o dízimo de tudo que
  possuo. Mas o cobrador de impostos, parado à distância, nem se atrevia a
  levantar os olhos para o céu. Batia no peito, dizendo: Ó meu Deus, tem piedade
  de mim, pecador! Eu vos digo: Este voltou justificado para casa e não aquele.
  Porque todo aquele que se eleva será humilhado, e quem se humilha será
  elevado. Luc 18, 9-14
  <br /> E quando orardes, não sejais como os hipócritas, que gostam de rezar em
  pé nas sinagogas e nas esquinas das praças para serem vistos pelos outros. Eu vos
  garanto: eles já receberam a recompensa. Mas quando rezares, entra no teu quarto,
  fecha a porta e reza ao teu Pai que está no oculto. E o Pai, que vê no oculto,
  te dará a recompensa. E nas orações não faleis muitas palavras, como os pagãos.
  Eles pensam que serão ouvidos por causa das muitas palavras. Não os imiteis, pois
  o Pai já sabe de vossas necessidades antes mesmo de pedirdes. Mt 6, 2-9
</p>

##### 252 - De que trata a segunda parte da Doutrina Cristã?

A segunda parte da Doutrina Cristã trata da oração em geral, e do Padre-Nosso em particular.

##### 253 - Que é a oração?

A oração é uma elevação da alma a Deus, para adora-Lo, para Lhe dar graças e para Lhe pedir aquilo de que precisamos.

##### 254 - Como se divide a oração?

A oração divide-se em mental e vocal. Oração mental é a que se faz só com a alma; oração vocal a que se faz com as palavras acompanhadas da atenção do espírito e da devoção do coração.

##### 255 - Pode dividir-se de outra maneira a oração?

A oração pode também dividir-se em particular e pública.

##### 256 - Que é a oração particular?

A oração particular é a que faz cada um em particular, por si ou pelos outros.

##### 257 - Que é a oração pública?

A oração pública é a que fazem os ministros sagrados, em nome da Igreja, e pela salvação do povo fiel. Pode-se chamar pública também a oração feita em comum e publicamente pelos fiéis, como nas procissões, nas peregrinações e na Igreja.

##### 258 - Temos nós esperança fundamentada de obter por meio da oração os auxílios e graças de que necessitamos?

A esperança de obter de Deus as graças de que necessitamos, é fundamentada nas promessas de Deus onipotente, muito misericordioso e fidelíssimo, e nos merecimentos de Jesus Cristo.

##### 259 - Em nome de quem devemos pedir a Deus as graças de que necessitamos?

<p>
  Devemos pedir a Deus as graças de que necessitamos, em nome de Jesus Cristo,
  como Ele mesmo nosensinou e como pratica a Igreja, a qual termina sempre as
  suas orações com estas palavras: <i>per Dominum nostrum Jesum Christum</i>,
  que quer dizer: por Nosso Senhor Jesus Cristo.
</p>

##### 260 - Por que devemos pedir a Deus as graças em nome de Jesus Cristo?

Devemos pedir as graças em nome de Jesus Cristo, porque, sendo Ele o nosso mediador, só por meio dEle podemos aproximar-nos do trono de Deus.

##### 261 - Se a oração tem tanta eficácia, como é que tantas vezes não são atendidas as nossas orações?

Muitas vezes as nossas orações não são atendidas, ou porque pedimos coisas que não convêm à nossa eterna salvação, ou porque não pedimos como deveríamos.

##### 262 - Quais são as coisas que principalmente devemos pedir a Deus?

Devemos principalmente pedir a Deus a sua glória, a nossa salvação e os meios para consegui-la.

##### 263 - Não é também lícito pedir bens temporais?

Sim, é também lícito pedir a Deus os bens temporais, sempre com a condição de que sejam conformes à sua santíssima vontade, e não sejam obstáculo à nossa eterna salvação.

##### 264 - Se Deus sabe tudo aquilo de que necessitamos, por que devemos rezar?

Embora Deus saiba tudo aquilo de que necessitamos, quer todavia que nós Lho peçamos, para reconhecermos que é Ele que dá todos os bens, para Lhe testemunharmos a nossa humilde submissão, e para merecermos os seus favores.

##### 265 - Qual é a primeira e a melhor disposição para tornar eficazes as nossas orações?

A primeira e a melhor disposição, para tornar eficazes as nossas orações, é estar em estado de graça, ou, não o estando, ao menos desejar recuperar esse estado.

##### 266 - Que mais disposições se requerem para bem orar?

Para bem orar requerem-se especialmente o recolhimento, a humildade, a confiança, a perseverança e a resignação.

##### 267 - Que quer dizer orar com recolhimento?

Quer dizer: pensar que estamos a falar com Deus; e por isso devemos orar com todo o respeito e a devoção possíveis, evitando, quanto for possível, as distrações, isto é, todo o pensamento estranho à oração.

##### 268 - Diminuem as distrações o merecimento da oração?

Sim, quando nós mesmos as provocamos, ou não as repelimos com diligência. Se porém fizermos quanto podemos para estarmos recolhidos em Deus, então as distrações não diminuem o merecimento da nossa oração, mas até o podem aumentar.

##### 269 - Que se requer para fazermos oração com recolhimento?

Devemos antes da oração afastar todas as ocasiões de distração, e durante a oração devemos pensar que estamos na presença de Deus, que nos vê e nos ouve.

##### 270 - Que quer dizer orar com humildade?

Quer dizer: reconhecer sinceramente a nossa indignidade, incapacidade e miséria, acompanhando a oração com a compostura do corpo.

##### 271 - Que quer dizer orar com confiança?

Quer dizer que devemos ter firme esperança de sermos atendidos, se daí provier a glória de Deus e o nosso verdadeiro bem.

##### 272 - Que quer dizer orar com perseverança?

Quer dizer que não nos devemos cansar de orar, se Deus não nos atender imediatamente, senão que devemos continuar a orar ainda com mais fervor.

##### 273 - Que quer dizer orar com resignação?

Quer dizer que nos devemos conformar com a vontade de Deus, que conhece melhor do que nós quanto nos é necessário para a nossa salvação eterna, ainda mesmo no caso em que as nossas orações não fossem atendidas.

##### 274 - Atende Deus sempre as orações bem feitas?

Sim, Deus atende sempre as orações bem feitas; mas da maneira que Ele sabe ser mais útil para a nossa salvação eterna, e não sempre segundo a nossa vontade.

##### 275 - Que efeitos produz em nós a oração?

A oração faz-nos reconhecer a nossa dependência, em todas as coisas, de Deus, supremo Senhor, faz-nos progredir na virtude, alcança-nos de Deus misericórdia fortalece- nos contra as tentações, conforta-nos nas tribulações, auxilia-nos nas nossas necessidades e alcança-nos a graça da perseverança final.

##### 276 - Quando devemos especialmente orar?

Devemos orar especialmente nos perigos, nas tentações e no momento da morte; além disso, devemos orar freqüenternente, e é bom que o façamos pela manhã e à noite, e no princípio das ações importantes do dia.

##### 277 - Por quem devemos orar?

Devemos orar por todos; isto é, por nós mesmos pelos nossos parentes, superiores, benfeitores, amigos e inimigos; pela conversão dos pobres pecadores, daqueles que estão fora da verdadeira Igreja, e pelas benditas almas do Purgatório.