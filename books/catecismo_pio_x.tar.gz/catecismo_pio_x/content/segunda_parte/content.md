# Segunda Parte

<aside>Da Oração</aside>