## IV - <em>Do terceiro artigo do Credo</em>

No sexto mês, o anjo Gabriel foi enviado da parte de Deus para uma cidade da Galiléia, chamada Nazaré, a uma virgem, prometida em casamento a um homem, chamado José, da casa de Davi. O nome da virgem era Maria. Entrando onde ela estava, o anjo lhe disse: Deus te salve, cheia de graça, o Senhor está contigo! Ao ouvir as palavras, ela se perturbou e refletia no que poderia significar a saudação. Mas o anjo lhe falou: Não tenhas medo, Maria, porque encontraste graça diante de Deus. Eis que conceberás e darás à luz um filho e lhe porás o nome de Jesus. Ele será grande e será chamado Filho do Altíssimo. O Senhor Deus lhe dará o trono de Davi, seu pai. Ele reinará na casa de Jacó pelos séculos e seu reino não terá fim. Maria perguntou ao anjo: Como acontecerá isso, pois não conheço homem? Em resposta o anjo lhe disse: O Espírito Santo virá sobre ti e o poder do Altíssimo te cobrirá com sua sombra; e por isso mesmo Santo que vai nascer de ti será chamado Filho de Deus. Eis que também Isabel, tua parenta, concebeu um filho em sua velhice, e este é o sexto mês daquela que era considerada estéril, porque para Deus nada é impossível. Disse então Maria: Eis aqui a serva do Senhor. Aconteça comigo segundo tua palavra! E o anjo afastou-se dela. Luc 1, 26-33

##### 82 - Que nos ensina o terceiro artigo do Credo: o qual foi concebido pelo poder do Espírito Santo, nasceu de Maria Virgem?

O terceiro artigo do Credo ensinam-nos que o Filho de Deus tomou um corpo e uma alma, como nós temos, no seio puríssimo de Maria Santíssima, pelo poder do Espírito Santo, e que nasceu desta Virgem.

##### 83 - Concorreram o Padre e o Filho também para for mar o corpo e para criar a alma de Jesus Cristo?

Sim, para formar o corpo e para criar a alma de Jesus Cristo, concorreram todas as três Pessoas divinas.

##### 84 - Por que se diz só: foi concebido pelo poder do Espírito Santo?

Diz-se só: foi concebido pelo poder do Espírito Santo, porque a Encarnação do Filho de Deus é obra de bondade e de amor, e as obras de bondade e de amor atribuem-se ao Espírito Santo.

##### 85 - Fazendo-se homem, deixou o Filho de ser Deus?

O Filho de Deus, fazendo-se homem, não deixou de ser Deus.

##### 86 - Então Jesus Cristo é Deus e homem ao mesmo tempo?

Sim, o Filho de Deus encarnado, isto é, Jesus Cristo, é Deus e homem ao mesmo tempo, perfeito Deus e perfeito homem.

##### 87 - Há então em Jesus Cristo duas naturezas?

Sim, em Jesus Cristo, que é Deus e homem, há duas naturezas, a divina e a humana.

##### 88 - E haverá também em Jesus Cristo duas pessoas, a divina e a humana?

No Filho de Deus feito homem há só uma Pessoa, que é a divina.

##### 89 - Quantas vontades há em Jesus Cristo?

Em Jesus Cristo há duas vontades, uma divina, outra humana.

##### 90 - Tinha Jesus Cristo vontade livre?

Sim, Jesus Cristo tinha vontade livre, mas não podia fazer o mal, porque poder fazer o mal é defeito, e não perfeição da liberdade.

##### 91 - Serão uma e a mesma Pessoa o Filho de Deus e o Filho de Maria Santíssima?

O Filho de Deus e o Filho de Maria Santíssima são a mesma Pessoa, isto é, Jesus Cristo, verdadeiro Deus e verdadeiro homem.

##### 92 - E a Virgem Maria, será Mãe de Deus?

Sim, Maria Santíssima é Mãe de Deus, porque é Mãe de Jesus Cristo, que é verdadeiro Deus.

##### 93 - De que maneira veio Maria a ser Mãe de Jesus Cristo?

Maria veio a ser Mãe de Jesus Cristo unicamente por virtude do Espírito Santo.

##### 94 É de fé que Maria foi sempre Virgem?

Sim, é de fé que Maria Santíssima foi sempre Virgem, e é chamada a Virgem por excelência.