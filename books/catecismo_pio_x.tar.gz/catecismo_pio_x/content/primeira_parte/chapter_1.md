## I - <em>Do Credo em geral</em>

##### 15 - Qual é a primeira parte da Doutrina Cristã?

A primeira parte da Doutrina Cristã é o Símbolo dos Apóstolos, chamado vulgarmente Credo.

##### 16 - Por que chamamos ao Credo Símbolo dos Apóstolos?

O Credo chama-se Símbolo dos Apóstolos, porque é um compêndio das verdades da Fé, ensinadas pelos Apóstolos.

##### 17 - Quantos artigos tem o Credo?

O Credo tem doze artigos.

##### 18 - Dizei-os.

<ul>
  <li>1º - Creio em Deus Padre, todo-poderoso, Criador do céu e da terra.</li>
  <li>2º - E em Jesus Cristo, um só seu Filho, Nosso Senhor.</li>
  <li>
    3º - qual foi concebido pelo poder do Espírito Santo, nasceu de Maria
    Virgem.
  </li>
  <li>
    4º - Padeceu sob o poder de Pôncio Pilatos, foi crucificado, morto e
    sepultado.
  </li>
  <li>5º - Desceu aos infernos, ao terceiro dia ressurgiu dos mortos.</li>
  <li>
    6º - Subiu ao Céu, está sentado à direita de Deus Padre todo-poderoso.
  </li>
  <li>7º - De onde há de vir a julgar os vivos e os mortos.</li>
  <li>8º - Creio no Espírito Santo.</li>
  <li>9º - Na Santa Igreja Católica; na comunhão dos Santos.</li>
  <li>10º - Na remissão dos pecados.</li>
  <li>11º - Na ressurreição da carne.</li>
  <li>12º - Na vida eterna. Amém</li>
</ul>

##### 19 - Que quer dizer a palavra Credo, eu creio que dizeis no começo do Símbolo?

A palavra Credo, eu creio quer dizer: eu tenho por absolutamente verdadeiro tudo o que nestes doze artigos se contém; e o creio mais firmemente do que se o visse com os meus olhos, porque Deus, que não pode nem enganar-Se nem enganar-nos, revelou estas verdades à Santa Igreja Católica, e por meio dEla eis revela também a nós.

##### 20 - Que contêm os artigos do Credo?

Os artigos do Credo contêm tudo o que de mais importante devemos crer acerca de Deus, de Jesus Cristo e da Igreja, sua Esposa.

##### 21 - É muito útil rezar freqüentemente o Credo?

É utilíssimo rezar freqüentemente o Credo, para imprimirmos cada vez mais no coração as verdades da Fé.