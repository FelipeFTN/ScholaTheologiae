## XI - <em>Do décimo artigo do Credo</em>

Alguns dias depois, Jesus entrou novamente em Cafarnaum, e souberam que ele estava em casa. Reuniu-se tanta gente que nem mesmo em frente à porta havia lugar para todos. E Jesus lhes anunciava a palavra. Trouxeram-lhe um paralítico, carregado por quatro homens. Como não podiam levá-lo até Jesus, por causa da multidão, descobriram o teto no lugar em que ele se achava, e pela abertura desceram a maca em que estava deitado o paralítico. Ao ver a fé deles, Jesus disse ao paralítico: Filho, os teus pecados estão perdoados. Ora, estavam sentadosali alguns escribas, pensando consigo mesmos: Como estehomem pode falar assim? Ele blasfema! Quem pode perdoar pecados senão só Deus? Mas Jesus percebeu logo em seu espírito os pensamentos deles e disse: Por que estais pensando assim? a O que é mais fácil dizer ao paralítico: teuspecados estão perdoados ou dizer: levanta-te, toma a tua maca e anda? Pois bem, para que saibaisque o Filho do homem * tem na terra poder de perdoar os pecados disse ao paralítico eu te digo: levanta-te, toma a tua maca e vai para casa. Ele se levantou, pegou logo a sua maca e saiu à vista de todos. Todos se espantaram e se puseram a louvar a Deus, dizendo: Nunca vimoscoisa igual! Mar 2, 1-12

##### 234 - Que nos ensina o décimo artigo do Credo: na remissão dos pecados?

O décimo artigo do Credo ensina-nos que Jesus Cristo deixou à sua Igreja o poder de perdoar os pecados.

##### 235 - Pode a Igreja perdoar toda a espécie de pecados?

Sim, a Igreja pode perdoar todos os pecados, por numerosos e graves que sejam, porque Jesus Cristo Lhe concedeu pleno poder de ligar e desligar.

##### 236 - Quem são os que na Igreja exercem este poder de perdoar os pecados?

Os que na Igreja exercem o poder de perdoar os pecados são, em primeiro lugar, o Papa que é o único que possui a plenitude de tal poder; depois os Bispos e, sob a dependência dos Bispos, os Sacerdotes.

##### 237 - Como perdoa a Igreja os pecados?

A Igreja perdoa os pecados pelos merecimentos de Jesus Cristo, administrando os Sacramentos por Ele instituídos para esse fim, especialmente o Batismo e a Penitência.