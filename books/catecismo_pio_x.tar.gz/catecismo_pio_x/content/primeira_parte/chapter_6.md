## VI - <em>Do quinto artigo do Credo</em>

No dia seguinte, isto é, depois da sexta-feira, os sumos sacerdotes e os fariseus foram a Pilatos e disseram: Senhor, lembramo-nos de que aquele impostor disse em vida: Depois de três dias ressuscitarei. Manda, pois, guardar o sepulcro até o terceiro dia para não acontecer que os seus discípulos venham roubar o corpo e digam ao povo: Ele ressuscitou dosmortos. E esta última impostura será pior do que a primeira. Pilatos lhes disse: Vós tendes a guarda. Ide e guardai-o como bem entendeis. Elesforam e puseram guarda ao sepulcro depoisdeselarem a pedra. Passado o sábado, ao amanhecer do primeiro dia da semana, Maria Madalena e a outra Maria foram ver o sepulcro. Subitamente houve um grande terremoto, pois um anjo do Senhor desceu do céu, aproximou-se, rolou a pedra do sepulcro e sentou-se nela. O seu aspecto era como o de um relâmpago e sua veste, branca como a neve. Paralisados de medo, osguardas ficaram como mortos. O anjo, dirigindo-se àsmulheres, disse: Não tenhais medo. Sei que procurais Jesus, o crucificado. Ele não está aqui! Ressuscitou conforme tinha dito. Vinde ver o lugar onde estava. Ide logo dizer a seus discípulos que ele ressuscitou dos mortos e que vai à frentedevóspara a Galiléia. Lá o vereis. Eiso queeu tinha a dizer. Jesus aparece às mulheres. Afastando-se logo do túmulo, cheias de temor e grande alegria, correram para dar a notícia aos discípulos. De repente, Jesus saiu ao encontro delas e disse-lhes: Salve! Elas se aproximaram, abraçaram-lhe os pés e se prostraram diante dele. Disse-lhes então Jesus: Não tenhais medo! Ide dizer a meus irmãos que se dirijam à Galiléia elá meverão. Mt 27, 62-66; 28, 1-10.

##### 114 - Que nos ensina o quinto artigo do Credo: desceu a mansão dos mortos, ressuscitou ao terceiro dia?

O quinto artigo do Credo ensina-nos que a alma de Jesus Cristo, assim que se separou do corpo, foi ao Limbo e que, no terceiro dia, se uniu de novo ao corpo, para nunca mais dele se separar.

##### 115 - Que se entende aqui por mansão dos mortos?

Por mansão dos mortos (ou infernos, em algumas traduções) entende-se aqui o Limbo, isto é, aquele lugar onde estavam as almas dos justos, esperando ti redenção de Jesus Cristo.

##### 116 - Por que as almas dos justos não foram introduzidas no Paraíso antes da morte de Jesus Cristo?

As almas dos justos não foram introduzidas no Paraíso antes da morte de Jesus Cristo, porque pelo pecado de Adão o Paraíso estava fechado; e convinha que Jesus Cristo, cuja morte o reabriu, fosse o primeiro a entrar nele.

##### 117 - Por que Jesus Cristo quis esperar até ao terceiro dia para ressuscitar?

Jesus Cristo quis demorar até ao terceiro dia para ressuscitar, para mostrar de modo insofismável, que verdadeiramente tinha morrido.

##### 118 - Foi a ressurreição de Jesus Cristo semelhante à dos outros homens ressuscitados?

A ressurreição de Jesus Cristo não foi semelhante à dos outros homens ressuscitados, porque Jesus Cristo ressuscitou por virtude própria, e os outros foram ressuscitados por virtude de Deus.