# Primeira Parte

<aside>Do Símbolo dos Apóstolos, chamado vulgarmente o Credo</aside>

A fé é o fundamento do que se espera e a convicção das realidades que não se vêem. Foi a fé que fez a glória dos antigos. Pela fé sabemos que o universo foi criado pela palavra de Deus, de sorte que do invisível teve origem o visível. Pela fé Abel ofereceu a Deus sacrifício melhor do que Caim e por ela foi declarado justo, tendo Deus aprovado as suas oferendas, e é pela fé que depois de morto Abel continua a falar. Epístola aos hebreus 4, 1-4