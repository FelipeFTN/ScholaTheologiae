## III - <em>Do segundo artigo do Credo</em>

Imediatamente Jesus obrigou os seus discípulos a subir para a barca e a passarem antes dele à outra margem do lago, en quanto ele despedia as turbas, Despedidas as turbas, subiu só a um monte para orar. Quando chegou a noite, achava-se ali. Entretanto, a barca achava-se a muitos estádios da terra e era batida pelasondas, porque o vento era contrário. Porém, na quarta vigília da noite, foi Jesus ter com eles, andando sobre o mar. E (os discípulos), quando o viram andar sobre o mar, turbaram-se dizendo : E um fantasma. E, com medo, começaram a gritar. Mas Jesus falou-lhes imediatamente, dizendo: Tende confiança; sou eu, não reinais. Respondendo Pedro, disse: Senhor, se és tu, manda-me ir até onde estás por sobre as águas. Ele disse: Vem. Descendo Pedro da barca, caminhava sobre a água para ir a Jesus. Vendo, porém, que o vento era forte, temeu, e, começando a submergir-se, gritou, dizendo: Senhor, salva-me! Imediata mente Jesus estendendo a mão, o tomou e lhe disse: Homem de pouca fé, porque duvidaste? Depoisque subiram para a barca, o vento cessou. Os que estavam na barca aproximaram-se dele e o adoraram, dizendo: Verdadeiramentetu éso Filho deDeus. Mt 14, 22-33

##### 68 - Que nos ensina o segundo artigo do Credo: e em Jesus Cristo, um só seu Filho, Nosso Senhor?

O segundo artigo do Credo ensina-nos que o Filho de Deus é a segunda Pessoa da Santíssima Trindade; que Ele é Deus eterno, todo-poderoso, Criador e Senhor, como o Pai; que se fez homem para nos salvar; e que o Filho, de Deus feito homem se chama Jesus Cristo.

##### 69 - Por que se chama Filho a segunda Pessoa?

A segunda Pessoa chama-se Filho porque é gerada pelo Pai por via de inteligência, desde toda a eternidade; e por este motivo se chama também Verbo eterno do Pai.

##### 70 - Sendo também nós filhos de Deus, por que Jesus Cristo se chama Filho único de Deus Pai?

Jesus Cristo chama-se Filho único de Deus porque só Ele é por natureza seu Filho, e nós seus filhos por criação e por adoção.

##### 71 - Por que Jesus Cristo se chama Nosso Senhor?

Chama-se Jesus Cristo Nosso Senhor porque, enquanto Deus, juntamente com o Pai e o Espírito Santo, nos criou, como também porque, enquanto Deus e homem, nos remiu com seu Sangue.

##### 72 - Por que o Filho de Deus feito homem se o chama Jesus?

O Filho de Deus feito homem chama-se Jesusque quer dizer Salvador, porque nos salvou da morte eterna que merecíamos por nossos pecados.

##### 73 - Quem deu o nome de Jesus ao Filho de feito homem?

Foi o mesmo Pai Eterno que deu o nome de Jesus ao Filho de Deus feito homem, por meio do Arcanjo São Gabriel, quando este anunciou à Virgem Santíssima o mistério da Encarnação.

##### 74 - Por que o Filho de Deus feito homem se chama também Cristo?

O filho de Deus feito homem chama-se também Cristo, que quer dizer Ungido e consagrado, porque antigamente ungiam-se os reis, os sacerdotes e os profetas e Jesus é Rei dos reis, Sumo Sacerdote e Sumo Profeta.

##### 75 - Foi Jesus Cristo verdadeiramente ungido e consagrado com unção corporal?

A unção de Jesus Cristo não foi corporal, como a dos antigos reis, sacerdotes e profetas, mas toda espiritual e divina, porque a plenitude da divindade habita nEle substancialmente.

##### 76 - Tiveram os homens algum conhecimento de Jesus Cristo antes da sua vinda?

Sim, os homens tiveram conhecimento de Jesus Cristo antes da sua vinda, pela promessa do Messias, que Deus fez aos nossos primeiros paisAdão e Eva, a qual renovou aos santos Patriarcas; e também pelas profecias e muitas figuras que O designavam.

##### 77 - Como sabemos nós que Jesus Cristo é verdadeira mente o Messias e o Redentor prometido?

Sabemos que Jesus Cristo é verdadeiramente o Messias e o Redentor prometido, porque nEle se cumpriu:

<ul>
  <li>1º - tudo o que anunciavam as profecias;</li>
  <li>2º - tudo o que representavam as figuras do Antigo Testamento.</li>
</ul>

##### 78 - Que prediziam as profecias acerca do Redentor?

As profecias prediziam acerca do Redentor: a tribo e a família da qual devia sair; o lugar e o tempo do nascimento; os seus milagrese as mais minuciosas circunstâncias da sua Paixão e morte; a sua ressurreição e ascensão ao Céu; o seu reino espiritual, universal e perpétuo, que é a Santa Igreja Católica.

##### 79 - Quais são as principais figuras do Redentor no Antigo Testamento?

As principais figuras do Redentor no Antigo Testamento são o inocente Abel, o sumo sacerdote Melquisedec, o sacrifício de Isaac, José vendido pelos irmãos, o profeta Jonas, o cordeiro pascal e a serpente de bronze, levantada por Moisés tio deserto.

##### 80 - Como sabemos nós que Jesus Cristo é verdadeiro Deus?

Sabemos que Jesus Cristo é verdadeiro Deus:

<ul>
  <li>
    1º - pelo testemunho do Pai Eterno, quando disse: Este é o meu Filho muito
    amado, no qual tenho posto todas as minhas complacências: ouvi-O ;
  </li>
  <li>
    2º - pela afirmação do próprio Jesus Cristo, confirmada com os mais
    estupendos milagres;
  </li>
  <li>3º - pela doutrina dos Apóstolos;</li>
  <li>4º - pela tradição constante da Igreja Católica.</li>
</ul>

##### 81 - Quais são os principais milagres operados por Jesus Cristo?

Os principais milagres operados por Jesus Cristo são, além da sua ressurreição, a saúde restituída aos enfermos, a vista aos cegos, o ouvido aos surdos, a vida aos mortos.