## VII - <em>Do sexto artigo do Credo</em>

Os que prenderam Jesus levaram-no a Caifás, o Sumo Sacerdote, onde os escribas e anciãos se haviam reunido. Pedro o seguiu de longe até o pátio do Sumo Sacerdote. Entrou ali e sentou-se junto com os guardas para ver como ia terminar. Os sumos sacerdotes e todo o Sinédrio procuravam falsos testemunhoscontra Jesuspara condená-lo à morte. Masnão os encontraram, embora muitas testemunhas falsas se tivessem apresentado. Finalmente apresentaram-se duas testemunhas que disseram: Este homem falou: Posso destruir o Santuário de Deus e em três dias reconstruí-lo. Então o Sumo Sacerdote levantou-se e perguntou: Nada respondes ao que estes depõem contra ti? Jesus, porém, permanecia calado. O Sumo Sacerdote lhe disse: Conjuro-te pelo Deus vivo: dize-nos se tu és o Cristo, o Filho de Deus. Jesus respondeu-lhe: Tu o disseste. Entretanto eu vosdigo: Um dia vereis o Filho do homem sentado à direita do Todo-poderoso, vindo sobre as nuvens do céu. Então o Sumo Sacerdote rasgou asvestesn e disse: Blasfemou! Que necessidade temosde maistestemunhas? Acabaisde ouvir a blasfêmia. O que vosparece? Eles responderam: É réu de morte. Então começaram a cuspir-lhe no rosto e a darlhe bofetadas, e outros a ferir-lhe o rosto ; e diziam: Adivinha, ó Cristo, quem foi quetebateu? Mt 7, 57-68

##### 119 - Que nos ensina o sexto artigo do Credo: subiu ao Céu, está sentado à direita de Deus Padre todo-poderoso?

O sexto artigo do Credo ensina-nos que Jesus quarenta dias depois da sua ressurreição na presença dos seusdiscípulos, subiu por Si mesmo tio Céu e que sendo, enquanto Deus, igual tio Padre Eterno na Glória, enquanto homem, foi elevado acima de todos os Anjos e de todos os Santos, e constituído Senhor de todas as coisas.

##### 120 - Por que Jesus Cristo, depois da sua ressurreição, esteve quarenta dias na terra, antes de subir ao Céu?

Jesus Cristo, depois da sua ressurreição, esteve quarenta dias na terra, antes de subir ao Céu, para provar, com várias aparições, que ressuscitara verdadeiramente, e para instruir melhor os Apóstolos e confirmá-los nas verdades da fé.

##### 121 - Por que Jesus Cristo subiu ao Céu?

Jesus Cristo subiu ao Céu:

<ul>
  <li>1º - para tomar posse do seu reino, que havia merecido com sua morte;</li>
  <li>
    2º - para preparar o nosso lugar na glória, e para ver nosso Mediador
    eAdvogado junto do Padre Eterno;
  </li>
  <li>3º - para enviar o Espírito Santo aos seus Apóstolos.</li>
</ul>

##### 122 - Por que se diz de Jesus Cristo que subiu ao Céu, e de sua Mãe Santíssima se diz que foi levada para o Céu?

Diz-se de Jesus Cristo que subiu, e de sua Mãe Santíssima que foi levada ao Céu, porque Jesus Cristo, sendo Homem-Deus, subiu ao Céu por virtude própria; mas sua Mãe, que era criatura, embora a mais digna de todas, foi levada ao Céu por virtude de Deus.

##### 123 - Explicai as palavras: Está sentado à direita de Deus Padre todo-poderoso.

As palavras está sentado significam ti posse pacífica que Jesus Cristo tem da sua glória, o as palavras à direita de Deus Padre todo-poderoso exprimem que Ele, tem o lugar de honra sobre todas as criaturas.