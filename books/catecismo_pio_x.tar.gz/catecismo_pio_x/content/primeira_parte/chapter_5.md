## V - <em>Do quarto artigo do Credo</em>

Levaram, pois, Jesus da casa de Caifás ao Pretório. Era de manhã. Não entraram no Pretório para se não contaminarem, a fim de comerem a Páscoa. Pilatos, pois, Saiu fora para lhes falar e disse: Que acusação apresentais contra este homem? Responderam e disseram lhe: Se este não fosse um malfeitor, não o entregaríamos nas tuasmãos. Pilatos disse-lhes então: Tomai-o vós e julgai-o segundo a vos. sa lei, Mas os judeus disseram-lhe: A nós não nos é permitido matar ninguém. Para se cumprir a palavra que Jesus dissera, significando de que morte havia de morrer. Tornou, pois, Pilatos a entrar no Pretório, chamou Jesus e disse-lhe: Tu és o rei dos judeus? Respondeu Jesus: Tu dizes isso de ti mesmo, ou foram outrosque to disseram de mim? Respondeu Pilatos: Porventura sou eu judeu? A tua nação e os pontífices são os que te entregaram nas minhas mãos. Que fizeste tu? Respondeu Jesus: O meu reino não é deste mundo; se o meu reino fosse deste inundo, certamente que os meus ministros se haviam de esforçar para que eu não fosse entregue aos judeus; mas o meu reino não é daqui. Disse-lhe então Pilatos: Logo tu és rei? Respondeu Jesus: Tu dizes, sou rei, Nasci, e vim ao mundo para dar testemunho da verdade; todo o que está pela verdade. ouve a minha voz. "Disse lhe Pilatos: O que é a verdade? Dito isto, tornou a sair, para ir ter com os judeus e disse-lhes: Não encontro nele crime algum. Ora é costume que eu pela Páscoa, vos solte um prisioneiro; quereis. pois, que vos solte o rei dos judeus? Então gritaram todos novamente, dizendo: Não este. mas Barrabás. Ora Barrabás era um salteador. Pilatos tomou então Jesus e mandou-o flagelar. Os soldados, tecendo uma coroa de espinhos, puseram-lha sobre a cabeça e revestiram- no com um manto de púrpura. Depois, aproximavam-se dele e diziamlhe: Salve, rei dos judeus! e davam-lhe bofetadas. Saiu Pilatos ainda entra vez fora, e disse-lhes: Eis que vo-lo trago fora, para que conheçais que não encontro nele crime algum. Saiu, pois, Jesus trazendo a coroa de espinhos e o manto de Púrpura. E (Pilatos) Eis aqui o homem. Então os, príncipes dos sacerdotes e os ministros, tendo-o visto, gritaram, dizendo: Crucifica-o, crucifica-o! Disse-lhes Pilatos: Tomai-o vós e crucificai-o, porque eu não en centro nele crime algum Responderam-lhe os judeus: Nós temos uma lei e segundo a lei deve morrer Porque se fez Filho de Deus. Pilatos, tendo ouvido estas palavras temeu ainda mais. Entrou novamente no Pretório e disse a Jesus: Donde és tu? Mas Jesus não lhe deu resposta Então disse-lhe Pilatos: Não me falas? Não ves que tenho poder para te soltar, e também para te crucificar? Respondeu Jesus: Tu não terias poder algum sobre mim, se não fosse dado do alto. Por isso o que me entregou a ti, tem maio pecado. Desde este momento, procurava Pilatos soltá-lo. Porém os judeus gritavam, dizendo: Se soltas este, não é, amigo de César, Porque todo o que se faz rei, declara-se contra César. Pilatos, tendo ouvido estas palavras, conduziu Jesus para fora e sentou se no seu tribunal. no lugar chamado Lithostrotos, em hebraico Gabbatha. Era a Parásceve (ou dia de preparação) da Páscoa, cerca da hora sexta, e disse aos judeus: Eis o vosso rei. Mas eles gritaram: Tira-o, tira-o, crucifica-o! Disse-lhes Pilatos: Pois eu, hei de crucificar o vosso rei? Responderam os pontífices: Não rei temos rei, senão César. Então entregou-lho, Para que fosse crucificado. S. João, 18, 28-40; 19, 1-23

##### 95 - Que nos ensina o quarto artigo do Credo: padeceu sob o poder de Pôncio Pilatos, foi crucificado, morto e sepultado?

O quarto artigo do Credo ensina-nos que JesusCristo, para remir o mundo com o seu precioso Sangue, padeceu sob Pôncio Pilatos, governador da Judéia, e morreu no madeiro da Cruz, da qual foi descido, e no fim sepultado.

##### 96 - Que quer dizer a palavra padeceu?

A palavra padeceu exprime todos os sofrimentos suportados por Jesus Cristo na sua Paixão.

##### 97 - Padeceu Jesus Cristo enquanto Deus ou enquanto homem?

Jesus Cristo padeceu enquanto homem somente, porque enquanto Deus não podia padecer nem morrer.

##### 98 - Que espécie de suplício era o da cruz?

O suplício da cruz era, naqueles tempos, o mais cruel e ignominioso de todos os suplícios.

##### 99 - Quem foi que condenou Jesus Cristo a ser crucificado?

Quem condenou Jesus Cristo a ser crucificado foi Pôncio Pilatos, governador da Judéia, o qual no entanto reconhecera a sua inocência; mas cedeu covardemente às ameaças dos judeus.

##### 100 - Não poderia livrar-Se Jesus Cristo das mãos dos judeus ou de Pilatos?

Sim, Jesus Cristo podia livrar-Se das mãos dos judeus ou de Pilatos; mas, conhecendo que a vontade do seu Eterno Pai era que Ele padecesse e morresse pela nossa salvação, submeteu-Se voluntariamente, e até saiu ao encontro dos seus inimigos, e deixou-Se espontaneamente prender e conduzir à morte.

##### 101 - Onde foi crucificado Jesus Cristo?

Jesus Cristo foi crucificado sobre o monte Calvário.

##### 102 - Que fez Jesus Cristo na Cruz?

Jesus Cristo na Cruz orou pelos seus inimigos, deu por Mãe ao discípulo São João, e na pessoa dele a nós todos, a sua mesma Mãe, Maria Santíssima; ofereceu a sua morte em sacrifício, e satisfez à justiça de Deus pelos pecados dos homens.

##### 103 - Não bastaria que viesse um Anjo satisfazer por nós?

Não bastava que viesse um Anjo satisfazer por nós, porque a ofensa feita a Deus pelo pecado era, sob certo aspecto, infinita; e para satisfazê-la requeria-se unia pessoa que tivesse merecimento infinito

##### 104 - Para satisfazer à justiça divina era necessário que JesusCristo fosse Deuse homem ao mesmo tempo?

Sim, era necessário que Jesus Cristo fosse homem para poder padecer e morrer, e era necessário que fosse Deus, para que os seus sofrimentos fossem de valor infinito.

##### 105 - Por que razão era necessário que os merecimentos de Jesus Cristo fossem de valor infinito?

Era necessário que os merecimentos de Jesus Cristo fossem de valor infinito, porque a majestade de Deus, ofendida pelo pecado, é infinita.

##### 106 - Era necessário que Jesus Cristo padecesse tanto?

Não era absolutamente necessário que Jesus Cristo padecesse tanto, porque o menor dos seus sofrimentos bastaria para a nossa redenção, pois cada um dos seus atos era de valor infinito.

##### 107 - Por que então Jesus quis sofrer tanto?

Jesus quis sofrer tanto, para satisfazer mais abundantemente à justiça divina, para nos mostrar mais claramente o seu amor, e para nos inspirar maior horror ao pecado.

##### 108 - Aconteceram prodígios na morte de Jesus?

Sim, na morte de Jesus obscureceu-se o sol, tremeu a terra, abriram-se algumas sepulturas, e muitos mortos ressuscitaram.

##### 109 - Onde foi sepultado o corpo de Jesus Cristo?

O corpo de Jesus Cristo foi sepultado num túmulo novo, escavado na rocha do monte, pouco distante do lugar onde Ele foi crucificado.

##### 110 - Na morte de Jesus Cristo, separou-se a divindade do corpo e dá alma?

Na morte de Jesus Cristo a divindade não se separou nem do corpo nem da alma; mas só a alma se separou do corpo.

##### 111 - Por quem morreu Jesus Cristo?

Jesus Cristo morreu pela salvação de todos os homens, e satisfez por todos.

##### 112 - Se Jesus Cristo morreu pela salvação de todos, por que nem todos se salvam?

Jesus Cristo morreu por todos, mas nem todos se salvam, porque nem todosO reconhecem, nem todos seguem a sua lei, nem todos se servem dos meios de santificação que nos deixou.

##### 113 - Para nos salvarmos basta que Jesus Cristo tenha morrido por nós?

Para nos salvarmos não basta que Jesus Cristo tenha morrido por nós, mas é necessário que sejam aplicados, a cada um de nós, o fruto e os merecimentos da sua Paixão e morte, aplicação que se faz, sobretudo, por meio dos Sacramentos, instituídos para este fim pelo mesmo Jesus Cristo; e como muitos ou não recebem os Sacramentos, ou não os recebem com as condições devidas, eles tornam inútil para si próprios a morte de Jesus Cristo.