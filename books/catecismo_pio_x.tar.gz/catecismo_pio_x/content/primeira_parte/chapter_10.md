## X - <em>Do nono artigo do Credo</em>

Então os apóstolos e presbíteros, de acordo com toda a Igreja, resolveram escolher alguns homens e enviá-los a Antioquia com Paulo e Barnabé; escolheram Judas, chamado Barsabás, e Silas, homens influentes entre os irmãos. Por seu intermédio enviaram a seguinte carta: Os irmãos, os apóstolos e presbíteros saúdam os irmãos de Antioquia, Síria e Cilícia, convertidos dentre os pagãos. Chegou ao nosso conhecimento que alguns dos nossos vos têm perturbado com palavras, confundindo vossas mentes, sem nenhuma autorização de nossa parte. Por isso resolvemos, de comum acordo, enviar-vos alguns homens escolhidos, em companhia de nossos amados Barnabé e Paulo, que expuseram suas vidas pelo nome de Nosso Senhor Jesus Cristo. Estamos enviando Judas e Silas para vos comunicar de viva voz as mesmas coisas. Pareceu bem ao Espírito Santo e a nós não vos impor nenhuma outra exigência além das necessárias: que vos abstenhais das carnes imoladas aos ídolos, do sangue, das carnes sufocadas e da prostituição. Procedereis bem evitando estas coisas. Passai bem. Atos 15, 22-29

#### 1º - Da Igreja em geral

##### 142 - Que nos ensina o nono artigo do Credo: creio na Santa Igreja Católica; na Comunhão dos Santos?

O nono artigo do Credo ensina-nos que Jesus Cristo fundou sobre a terra uma sociedade visível, a qual se chama Igreja Católica, e que todas as pessoas que fazem parte desta Igreja estão em comunhão entre si.

##### 143 - Por que, depois do artigo que trata do Espírito Santo, fala-se imediatamente da Igreja Católica?

Depois do artigo que trata do Espírito Santo, fala-se imediatamente da Igreja Católica, para indicar que toda a santidade da mesma Igreja procede do Espírito Santo, que é o autor de toda a santidade.

##### 144 - Que quer dizer esta palavra Igreja?

A palavra Igreja quer dizer convocação ou reunião de muitas pessoas.

##### 145 - Quem nos convocou ou chamou para a Igreja de Jesus Cristo?

Nós fomos chamados para a Igreja de Jesus Cristo por uma graça particular de Deus, a fim de que, com a luz da fé e pela observância da lei divina, Lhe prestemoso culto devido, e cheguemos à vida eterna.

##### 146 - Onde se encontram os membros da Igreja?

Os membros da Igreja encontram-se parte no Céu, e formam a Igreja triunfante; parte no Purgatório, e formam a Igreja padecente; parte na terra, e formam a Igreja militante.

##### 147 - Estas diversas partes da Igreja constituem uma só Igreja?

Sim, estas diversas partes da Igreja constituem uma só Igreja e um só corpo, porque têm a mesma cabeça que é Jesus Cristo, o mesmo espírito que as anima e as tine, e o mesmo fim que é a felicidade eterna, que uns já estão gozando e que outros esperam.

##### 148 - A qual das partes da Igreja se refere principalmente este nono artigo?

Este nono artigo do Credo refere-se principalmente à Igreja militante, que é a Igreja na qual estamos atualmente.

#### 2º - Da Igreja em particular

##### 149 - Que é a Igreja Católica?

A Igreja Católica é a sociedade ou reunião de todas as pessoas batizadas que, vivendo na terra, professam a mesma fé e a mesma lei de Cristo, participam dos mesmos Sacramentos, e obedecem aos legítimos Pastores, principalmente ao Romano Pontífice.

##### 150 - Dizei precisamente o que é necessário para alguém ser membro da Igreja.

Para alguém ser membro da Igreja, é necessário estar batizado, crer e professar a doutrina de Jesus Cristo, participar dos mesmos Sacramentos, reconhecer o Papa e os outros legítimos Pastores da Igreja.

##### 151 - Quem são os legítimos Pastores da Igreja?

Os legítimos Pastores da Igreja são o Pontífice Romano, isto é, o Papa, que é o 1º Pastor universal, e os Bispos. Além disso, sob a dependência dos Bispos e do Papa, têm parte no oficio de Pastores os outros Sacerdotes e especialmente os párocos.

##### 152 - Por que dizeis que o Pontífice Romano é o Pastor Universal da Igreja?

Porque Jesus Cristo disse a São Pedro, primeiro Papa: Tu és Pedro, e sobre esta pedra edificarei a minha Igreja, e dar-te-ei as chaves do reino dos Céus, e tudo o que ligares na terra, será ligado no Céu; e tudo o que desligares na terra, será desligado também no Céu. E disse-lhe mais: Apascenta os meus cordeiros, apascenta as minhas ovelhas.

##### 153 - Então não pertencem à Igreja, de Jesus Cristo as sociedades de pessoas batizados que não reconhecem o Romano Pontífice por seu chefe?

Todos os que não reconhecem o Romano Pontífice por seu chefe, não pertencem à Igreja de Jesus Cristo.

##### 154 - Como se pode distinguir a Igreja de Jesus Cristo, de tantas sociedades ou seitas, fundadas pelos homens, e que se dizem cristãos?

Pode-se distinguir a verdadeira Igreja de Jesus Cristo, de tantas sociedades ou seitas fundadas pelos homens e que se dizem cristãs, por quatro notas características. Ela é Una, Santa, Católica e Apostólica.

##### 155 - Por que dizeis que a Igreja é Una?

Digo que a verdadeira Igreja é Una, porque os seus filhos, de qualquer tempo ou lugar, estão unidos entre si na mesma fé, no mesmo culto, na mesma lei e na participação dos mesmos Sacramentos, sob o mesmo chefe visível, o Romano Pontífice.

##### 156 - Não poderia haver mais de uma Igreja?

Não pode haver mais de uma Igreja, porque, assim como há um só Deus, uma só Fé e um só Batismo, assim também não há nem pode ode haver senão uma só Igreja verdadeira.

##### 157 - Mas não se chamam também igrejas o conjunto dos fiéis de uma nação, ou de uma diocese?

Chamam-se igrejas também o conjunto dos fiéis de uma nação ou de uma diocese, mas são sempre porções da Igreja universal, e formam com ela uma só Igreja.

##### 158 - Por que dizeis que a verdadeira Igreja é Santa?

Chamo a verdadeira Igreja de Santa, porque Jesus Cristo, a sua cabeça invisível, é Santo, santos são muitos dos seus membros, santas são a sua Fé e a sua Lei, santos os seus Sacramentos, e fora dEla não há nem pode haver verdadeira santidade.

##### 159 - Por que dizeis que a Igreja é Católica?

Chamo a verdadeira Igreja de Católica, que quer dizer universal, porque abrange os fiéis de todos os tempos, de todos os lugares, de todas as idades e condições, e todos os homens do mundo são chamados a fazer parte dEla.

##### 160 - Por que a Igreja se chama também Apostólica?

A verdadeira Igreja chama-se também Apostólica, porque remonta sem interrupção até aos Apóstolos; porque crê e ensina tudo o que creram e ensinaram osApóstolos; e porque é guiada e governada pelos legítimos sucessores dos Apóstolos.

##### 161 - Por que a verdadeira Igreja se chama também Romana?

A verdadeira Igreja chama-se também Romana, porque os quatro caracteres da unidade, santidade, catolicidade e apostolicidade se encontram só na Igreja que tem por chefe o Bispo de Roma, sucessor de São Pedro.

##### 162 - Como é constituída a Igreja de Jesus Cristo?

A Igreja de Jesus Cristo é constituída como uma sociedade verdadeira e perfeita. E nEla, como numa pessoa moral, podemos distinguir um corpo e uma alma.

##### 163 - Em que consiste a alma da Igreja?

A alma da Igreja consiste no que Ela tem de interior e de espiritual, isto é, a Fé, a Esperança, a Caridade, os dons da graça e do Espírito Santo, e todos os tesouros celestes que lhe provieram dos merecimentos de Cristo Redentor e dos Santos.

##### 164 - E o corpo da Igreja, em que consiste?

O corpo da Igreja consiste no queEla tem de visível e de externo, quer na associação dos seus membros, quer no seu culto e no seu ministério de -ensino, quer no seu governo e ordem externa.

##### 165 - Para nos salvarmos basta sermos de qualquer maneira membros da Igreja Católica?

Não basta para nos salvarmos o sermos de qualquer maneira membros da Igreja Católica, mas é preciso que sejamos seus membros vivos.

##### 166 - Quais são os membros vivos da Igreja?

Os membros vivos da Igreja são todos os justos e só eles, isto é, aqueles que estão atualmente em graça de Deus.

##### 167 - E quais são nEla os membros mortos?

Membros mortos da Igreja são os fiéis que estão em pecado mortal.

##### 168 - Pode alguém salvar-se fora da Igreja Católica, Apostólica, Romana?

Não. Fora da Igreja Católica, Apostólica, Romana, ninguém pode salvar-se, como ninguém pôde salvar-se do dilúvio fora da arca de Noé, que era figura desta Igreja.

##### 169 - Como então se salvaram os antigos Patriarcas, os Profetas, e todos os outros justos do Antigo Testamento?

Todos os justos do Antigo Testamento se salvaram em virtude da fé que tinham em Cristo que havia de vir, por meio da qual eles já pertenciam espiritualmente a esta Igreja.

##### 170 - Mas quem se encontrasse, sem culpa sua, fora da Igreja, poderia salvar-se?

Quem, encontrando-se sem culpa sua - quer dizer, em boa fé - fora da Igreja, tivesse recebido o batismo, ou tivesse desejo, ao menos implícito, de o receber e além disso procurasse sinceramente a verdade, e cumprisse a vontade de Deus o melhor que pudesse, ainda que separado do corpo da Igreja, estaria unido à alma dEla, e portanto no caminho da salvação.

##### 171 - E quem, sendo muito embora membro da Igreja Católica, não pusesse em prática os seus ensinamentos, salvar-se-ia?

Quem, sendo muito embora membro da Igreja Católica, não pusesse em prática os seus ensinamentos, seria membro morto, e portanto não se salvaria, porque para a salvação de um adulto requer-se não só o Batismo e a Fé, mas também as obras conformes à Fé.

##### 172 - Somos obrigados a acreditar todas as verdades que a Igreja ensina?

Sim, somos obrigados a acreditar todasas verdades que a Igreja nos ensina, e Jesus Cristo declarou que quem não crê, já está condenado.

##### 173 - Somos também obrigados a fazer tudo o que a Igreja manda?

Sim, somos obrigados a fazer tudo o que a Igreja manda, porque Jesus Cristo disse aos Pastores da Igreja: Quem vos ouve, a Mim ouve, e quem vos despreza, a Mim despreza.

##### 174 - Pode enganar-Se a Igreja nas coisas que nos propõe para crermos?

Não. Nas coisas que nos propõe para crer, a Igreja não pode enganar-Se, porque, segundo a promessa de Jesus Cristo, é sempre assistida pelo Espírito Santo.

##### 175 - A Igreja Católica é então infalível?

Sim, a Igreja Católica é infalível. Por isso aqueles que rejeitam as suas definições, perdem a fé, e fazem-se hereges.

##### 176 - A Igreja Católica pode ser destruída ou perecer?

Não. A Igreja Católica pode ser perseguida, mas não pode ser destruída nem perecer. Ela há de durar até ao fim do mundo, porque até ao fim do mundo JesusCristo estará com Ela, como prometeu.

##### 177 - Por que é a Igreja Católica tão perseguida?

A Igreja Católica é tão perseguida, porque assim foi também perseguido o seu Divino Fundador, e porque reprova os vícios, combate as paixões e condena todas as injustiças e todos os erros.

##### 178 - Há mais alguns deveres dos católicos para com a Igreja?

Todo o cristão deve ter para com a Igreja um amor ilimitado, considerar-se feliz e infinitamente honrado por pertencer a Ela, e empenhar-se pela glória e aumento dEla por todos os meios ao seu alcance.

#### 3º - Da Igreja docente e da Igreja discente

Um anjo do Senhor falou a Filipe: Vai para o sul pelo caminho que, através do deserto, desce de Jerusalém para Gaza. E Filipe partiu. Ora, um etíope, camareiro e tesoureiro-mor a serviço da rainha Candace da Etiópia, tinha ido prestar culto em Jerusalém. Voltava, sentado no seu carro, lendo o profeta Isaías. O Espírito Santo disse a Filipe: Aproxima-te e acompanha aquele carro. Filipe acelerou o passo. Ouvindo que lia o profeta Isaías, perguntou: Será que estás entendendo o que lês? Ele respondeu: Como é que vou entender se ninguém me orienta? Então convidou Filipe para subir e sentar-se ao seu lado. A passagem da Escritura que ele lia era a seguinte: Como uma ovelha levada ao matadouro, e como um cordeiro diante de quem o tosquia, ele emudeceu e não abre a boca. Com humilhação foi consumado o seu julgamento; de seus descendentes, quem falará? pois a sua vida é tirada da terra. O camareiro perguntou a Filipe: Dize-me, de quem o profeta está falando? De si mesmo ou de outro? Filipe pôs-se a falar e, começando com esta passagem da escritura, anunciou-lhe a boa-nova de Jesus. Seguindo o caminho, encontraram água e o camareiro disse: Aqui existe água, o que impede que eu seja batizado? Mandou parar o carro, e os dois desceram para a água, Filipe e o camareiro, e Filipe o batizou. Quando subiram da água, o Espírito do Senhor arrebatou Filipe n, e o camareiro já não o viu, mas alegre prosseguiu seu caminho. Quanto a Filipe, foi parar em Azoto e, de passagem, anunciava a boa-nova a todas as cidades até chegar a Cesaréia Atos 8, 26-40

##### 179 - Há alguma distinção entre os membros que compõem a Igreja?

Entre os membros que compõem a Igreja há distinção muito importante, porque há uns que mandam, outros que obedecem, uns que ensinam, outros que são ensinados.

##### 180 - Como se chama a parte da Igreja que ensina?

A parte da Igreja que ensina chama-se docente, ou ensinante.

##### 181 - E a parte da Igreja que é ensinada, como se chama?

A parte da Igreja que é ensinada chama-se discente.

##### 182 - Quem estabeleceu esta distinção na Igreja?

Esta distinção na Igreja estabeleceu-a o próprio Jesus Cristo.

##### 183 - A Igreja docente e a Igreja discente são, pois, duas Igrejas distintas?

A Igreja docente e a Igreja discente são duas partes distintas de uma só e mesma Igreja, como no corpo humano a cabeça é distinta dos outros membros, e, não obstante, forma com eles um corpo só.

##### 184 - De que pessoas se compõe a Igreja docente?

A Igreja docente compõe-se de todos os Bispos (quer se encontrem dispersos, quer se encontrem reunidos em Concílio), unidos à sua cabeça, o Romano Pontífice.

##### 185 - E a Igreja discente, de que pessoas é composta?

Á Igreja discente é composta de todos os fiéis.

##### 186 - Quais são as pessoas que têm na Igreja autoridade de ensinar?

Os que têm na Igreja o poder de ensinar são o Papa e osBispos e, sob a dependência destes, os outros ministros sagrados.

##### 187 - Somos obrigados a ouvir a Igreja docente?

Sim, sem dúvida, somos todos obrigados a ouvir a Igreja docente, sob pena de condenação eterna, porque Jesus Cristo disse aos Pastores da Igreja, na pessoa dos Apóstolos: Quem vosouve, a Mim ouve, e quem vosdespreza, a Mim despreza.

##### 188 - Além da autoridade de ensinar, tem a Igreja mais algum poder?

Sim, além da autoridade de ensinar, a Igreja tem especialmente o poder de administrar as coisas santas, de fazer leis e de exigir a sua observância.

##### 189 - Virá do povo o poder que têm os membros da hierarquia eclesiástica?

O poder que têm os membros da hierarquia eclesiástica não vem do Povo, e seria heresia o dizê-lo: vem unicamente de Deus.

##### 190 - A quem compete o exercício destes poderes?

O exercício destes poderes compete unicamente ao corpo hierárquico, isto é, ao Papa e aos Bispos a ele subordinados.

#### 4º - Do Papa e dos Bispos

Chegando à região de Cesaréia de Filipe, Jesus perguntou a seus discípulos: Quem as pessoas dizem que é o Filho do homem? Eles responderam: Alguns dizem que é João Batista; outros, Elias; outros, Jeremias ou um dos profetas. Então ele perguntou-lhes: E vós, quem dizeis que eu sou? Simão Pedro respondeu: Tu és o Cristo, o Filho de Deus vivo. Em resposta, Jesus disse: Feliz és tu, Simão filho de Jonas, porque não foi a carne nem o sangue quem te revelou isso, mas o Pai que está nos céus. E eu te digo: Tu és Pedro e sobre esta pedra construirei a minha Igreja e as portas do inferno nunca levarão vantagem sobre ela. Eu te darei as chaves do reino dos céus, e tudo que ligares na terra será ligado nos céus, e tudo que desligares na terra será desligado nos céus. E deu ordens aos discípulos de não falarem para ninguém que ele era o Cristo. Mt 16, 13-20.

##### 191 - Quem é o Papa?

O Papa, a quem chamamos também Sumo Pontífice ou Romano Pontífice, é o sucessor de São Pedro na Sede de Roma, o Vigário de Jesus Cristo na terra, e o chefe visível da Igreja.

##### 192 - Por que o Romano Pontífice é o sucessor de São Pedro?

O Romano Pontífice é o sucessor de São Pedro. porque São Pedro reuniu na sua pessoa a dignidade de Bispo de Roma e de chefe da Igreja e porque, por disposição divina, estabeleceu em Roma a sua sede, e aí morreu. Por isso quem é eleito Bispo de Roma, é também herdeiro de toda a sua autoridade.

##### 193 - Por que o Romano Pontífice é o Vigário de Jesus Cristo?

O Romano Pontífice é o Vigário de Jesus Cristo porque ele O representa na terra, e faz as suas vezes no governo da Igreja.

##### 194 - Por que o Romano Pontífice é o Chefe visível da Igreja?

O Romano Pontífice é o Chefe visível da Igreja porque a dirige visivelmente com a mesma autoridade de Jesus Cristo, que é a cabeça invisível da Igreja.

##### 195 - Qual é, pois, a dignidade do Papa?

A dignidade do Papa é a maior entre todas as dignidades da terra e dá-lhe um poder supremo e imediato sobre todos e cada um dos Pastores e dos fiéis.

##### 196 - Pode errar o Papa ao ensinar à Igreja?

O Papa não pode errar, quer dizer, é infalível nas definições que dizem respeito à fé e aos costumes.

##### 197 - Qual é o motivo por que o Papa é infalível?

O Papa é infalível em razão da promessa de Jesus Cristo e da contínua assistência do Espírito Santo.

##### 198 - Quando o Papa é infalível?

O Papa é infalível só quando, na sua qualidade de Pastor e Mestre de todos os cristãos, em virtude da sua suprema autoridade apostólica, define uma doutrina relativa à fé e aos costumes, que deve ser seguida por toda a Igreja.

##### 199 - Quem não acreditasse nas definições solenes do Papa, que pecado cometeria?

Quem não acreditasse nas definições solenes do Papa, ou ainda só duvidasse delas, pecaria contra a fé; e, se se obstinasse nesta incredulidade, já não seria mais católico, mas herege.

##### 200 - Para que fim Deus concedeu ao Papa o dom da infalibilidade?

Deus concedeu ao Papa o dom da infalibilidade, a fim de que todos estejam certos e seguros da verdade que ti Igreja ensina.

##### 201 - Quando foi definido que o Papa é infalível?

A infalibilidade do Papa foi definida pela Igreja rio Concílio do Vaticano; e, se alguém ousasse contradizer esta definição, seria herege e excomungado

##### 202 - A Igreja, ao definir que o Papa é infalível, estabeleceu porventura uma nova verdade de fé?

Não. A Igreja, ao definir que o Papa é infalível, não estabeleceu uma nova verdade de fé, mas só definiu, para se opor a erros novos, que a infalibilidade do Papa, contida já na Sagrada Escritura e na Tradição, e uma verdade revelada por Deus, e que por conseguinte se deve crer como dogma ou artigo de fé.

##### 203 - Como todo o católico deve proceder para com o Papa?

Todo o católico deve reconhecer o Papa como Pai, Pastor e Mestre universal, e estar unido a ele de espírito e coração.

##### 204 - Depois do Papa quais são, por instituição divina, as personagens mais venerandas na Igreja?

Depois do Papa, por instituição divina, as personagens mais venerandas da Igreja são os Bispos.

##### 205 - Quem são os Bispos?

OsBispos são osPastores aos fiéis, estabelecidos pelo Espírito Santo para governar ti Igreja de Deus, nas sedesque lhes são confiadas sob i] dependência do Romano Pontífice.

##### 206 - Que é o Bispo na própria diocese?

O Bispo na própria diocese é o Pastor legítimo, o Pai, o Mestre, o superior de todos os fiéis, eclesiásticos e leigos, que pertencem à mesma diocese.

##### 207 - Por que o Bispo se chama Pastor legítimo?

Chama-se o Bispo Pastor legítimo, porque a jurisdição, isto é, o poder que tem de governar os fiéis da própria diocese, foi-lhe conferido segundo as normas e leis da Igreja.

##### 208 - De quem são sucessores o Papa e os Bispos?

O Papa é sucessor de São Pedro, Príncipe dos Apóstolos, e os Bispos são sucessores dos Apóstolos, no que diz respeito ao governo ordinário da Igreja.

##### 209 - Deve o fiei estar unido ao próprio Bispo?

Sim, todo o fiel, eclesiástico ou leigo, deve estar unido de espírito e de coração ao próprio Bispo que está em graça e comunhão com a Se Apostólica.

##### 210 - Como deve proceder o fiei para com o próprio Bispo?

Todo o fiel, eclesiástico ou leigo, deve respeitar, amar e honrar o próprio Bispo, e prestar-lhe obediência em tudo o que se refere ao bem das almas e ao governo espiritual da diocese.

##### 211 - Quais são os auxiliares do Bispo na cura das almas?

Os auxiliares do Bispo na cura das almas são os Sacerdotes, e principalmente os párocos.

##### 212 - Quem é o pároco?

O pároco é uni Sacerdote delegado para presidir e dirigir, sob a dependência do Bispo, uma porção da diocese, que se chama paróquia.

##### 213 - Que deveres têm os fiéis para com o seu pároco?

Os fiéis devem conservar-se unidos ao seu pároco, ouvi-lo com docilidade, professar-lhe respeito e submissão em tudo o que interessa ao bem da paróquia.

#### 5º - Da comunhão dos Santos

O que era desde o princípio, o que ouvimos, o que vimos com os olhos, o que contemplamos e nossas mãos apalparam no tocante ao Verbo da vida a porque a vida se manifestou e nós vimos e testemunhamos, anunciando-vosa vida eterna que estava com o Pai e nos foi manifestada o que vimos e ouvimos, nós também vos anunciamos a fim de que também vós vivaisem comunhão conosco. Ora, nossa comunhão é com o Pai e seu Filho, Jesus Cristo. Nós vos escrevemos estas coisas para nossa alegria ser completa! Para viver na luz. A mensagem que dele ouvimos e vos anunciamos é esta: Deus é luz, nele não há trevas. Se dizemos ter comunhão com ele mas andamos nas trevas, mentimos e não praticamos a verdade. Se, porém, andamos na luz, assim como ele está na luz, estamos em comunhão uns com os outros e o sangue de Jesus, seu Filho, nos purifica de todo pecado. Se dizemos que em nós não há pecado, enganamos a nós mesmos e a verdade não está conosco. Se confessamos nossos pecados, fiel e justo é Deus para nos perdoar e nos purificar de toda iniqüidade. Se dizemos que não pecamos, chamamos Deus de mentiroso e sua palavra não está conosco. I João 1, 1-10

##### 214 - Que nos ensina o nono artigo do Credo com aquelas palavras: na comunhão dos Santos?

Com as palavras: na comunhão dos Santos, o nono artigo do Credo ensina-nos que na Igreja, pela íntima união que existe entre todos os seus membros, são comuns os bens espirituais, assim internos como externos, que lhe pertencem.

##### 215 - Quais são na Igreja os bens comuns internos?

Os bens comuns internos na Igreja são: a graça que se recebe nos Sacramentos, a Fé, a Esperança, a Caridade, os merecimentos infinitos de Jesus Cristo, os merecimentos superabundantes da Santíssima Virgem e dosSantos, e o fruto de todas as boas obras que na mesma Igreja se fazem.

##### 216 - Quais são os bens externos comuns na Igreja?

Os bens externos comuns na Igreja são: os sacramentos, o Santo Sacrifício da Missa, as orações públicas, as funções religiosas, e todas as outras práticas exteriores que unem entre si os fiéis.

##### 217 - Nesta comunhão de bens entram todos os filhos da Igreja?

Na comunhão dos bens internos entram somente os cristãos que estão em graça de Deus; os que estão em pecado mortal não participam de todos estes bens.

##### 218 - Por que não participam de todos estes bens aqueles que estão em pecado mortal?

Porque é a graça de Deus. vida sobrenatural da alma, que une os fiéis a Deus e a Jesus Cristo como seus membros vivos e os torna capazes de fazer obras meritórias para a vida eterna; e porque aqueles que se encontram em estado de pecado mortal, não tendo a graça de Deus, estão excluídos da comunhão perfeita dos bens espirituais e não podem fazer obras meritórias rias para a vida eterna.

##### 219 - Então os cristãos que estão em pecado mortal não tiram proveito nenhum dos bens internos e espirituais da Igreja?

Os cristãos que estão em pecado mortal tiram ainda assim algum proveito dos bens internos e espirituais da Igreja, porquanto conservam o caráter de cristãos, que é indelével, e a virtude da Fé que é a raiz de toda justificação. Por isso são auxiliados pelas orações e boas obras dos fiéis, para obterem a graça da conversão.

##### 220 - Os que estão em pecado mortal podem participar dos bens externos da Igreja?

Os que estão em pecado mortal podem participar dos bens externos da Igreja, contanto que não estejam separados da mesma Igreja pela excomunhão.

##### 221 - Por que os membros desta comunhão, considerados no seu conjunto, se chamam Santos?

Os membros desta comunhão chamam-se Santos, porque todos são chamados à santidade, e foram santificados por meio do Batismo, e muitos deles já atingiram a santidade perfeita.

##### 222 - A comunhão dos Santos estende-se também ao Céu e ao Purgatório?

Sim, a comunhão dos Santos estende-se também ao Céu e ao Purgatório, porque a caridade une as três igrejas: triunfante, padecente e militante; e os Santos rogam a Deus por nós e pelas almas do Purgatório, e nós damos honra e glória aos Santos, e podemos aliviar as almas do Purgatório, aplicando, em sufrágio delas, Missas, esmolas, indulgências e outras boas obras.

#### 6º - Daqueles que estão fora da Igreja

##### 223 - Quem são os que não participam da comunhão dos Santos?

Aqueles que não participam da comunhão dos Santos são, na outra vida, os condenados, e nesta vida aqueles que não pertencem nem à alma nem ao corpo da Igreja, quer dizer, aqueles que estão em estado de pecado rnortal e se encontram fora da verdadeira Igreja.

##### 224 - Quem são os que se encontram fora da verdadeira Igreja?

Encontram-se fora da verdadeira Igreja os infiéis, os judeus, os hereges, os apóstatas, os cismáticos e os excomungados.

##### 225 - Quem são os infiéis?

Os infiéis são aqueles que não foram batizados e não crêem em Jesus Cristo, seja porque crêem e adoram falsas divindades, como os idólatras; seja porque, embora admitam o único Deus verdadeiro, não crêem em Cristo Messias, nem como vindo na pessoa de Jesus Cristo, nem como havendo de vir ainda: tais são os maometanos e outros semelhantes.

##### 226 - Quem são os judeus?

Os judeus são aqueles que professam a lei de Moisés, não receberam o batismo, nem crêem em Jesus Cristo.

##### 227 - Quem são os hereges?

Os hereges são as pessoas batizadas que recusam com pertinácia crer em alguma verdade revelada por Deus e ensinada conto de fé pela Igreja Católica: por exemplo, os arianos, os nestorianos e as várias seitas dos protestantes.

##### 228 - Quem são os apóstatas?

Os apóstatas são aqueles que abjuram, isto é, renegam, com ato externo, a fé católica, que antes professavam.

##### 229 - Quem são os cismáticos?

Os cismáticos são os cristãos que, não negando explicitamente dogma algum, se separam voluntariamente da Igreja de Jesus Cristo, ou dos legítimos Pastores.

##### 230 - Quem são os excomungados?

Os excomungados são aqueles que por faltas graves são fulminados com excomunhão pelo Papa ou pelo Bispo, e portanto são separados, como indignos, do corpo da Igreja, a qual espera e deseja a sua conversão.

##### 231 - Deve-se temer a excomunhão?

Deve-se temer grandemente a excomunhão, porque é o castigo mais grave e mais terrível que a Igreja pode infligir aos seus filhos rebeldes e obstinados.

##### 232 - De que bens ficam privados os excomungados?

Os excomungados ficam privados das orações publicas, dos Sacramentos, das indulgências e excluídos da sepultura eclesiástica.

##### 233 - Podemos nós auxiliar de alguma maneira os excomungados?

Nós podemos auxiliar de alguma maneira os excomungados e todos os outros que estão fora da verdadeira Igreja com advertências salutares, com orações e boas obras, suplicando a Deus que pela sua misericórdia lhes conceda a graça de se converterem à Fé e de entrarem na comunhão dos Santos.