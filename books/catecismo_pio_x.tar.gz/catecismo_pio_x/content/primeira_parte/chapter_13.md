## XIII - <em>Do duodécimo artigo do Credo</em>

Lázaro caiu doente em Betânia, onde estavam Maria e sua irmã Marta. Maria era aquela que tinha ungido o Senhor com óleo perfumado e lhe tinha enxugado os pés com os cabelos. Seu irmão Lázaro estava enfermo. As irmãs mandaram dizer a Jesus: Senhor, aquele a quem amas está doente. Quando ouviu isso, Jesus disse: Esta doença não causará a morte mas se destina à glória de Deus: por ela o Filho de Deus será glorificado. Ora, Jesus amava Marta, sua irmã e Lázaro. Embora estivesse informado de que ele estava doente, demorou-se ainda doisdiasnaquele lugar. Depois disse aos discípulos: Voltemos para a Judéia. Os discípulos disseram: Mestre, há pouco os judeus te queriam apedrejar e tu voltas para lá? Jesus respondeu: Não são doze as horas do dia? Se alguém caminha durante o dia, não tropeça porque vê a luz deste mundo; mas se caminha de noite, tropeça porque lhe falta a luz. Depois destas palavras, acrescentou: Lázaro, nosso amigo, adormeceu mas eu vou despertá-lo. Senhor, se ele está dormindo é porque vai ficar bom disseram os discípulos. Jesus se referia à morte, mas eles pensavam que estivesse falando do repouso do sono. Então Jesus lhes falou claramente: Lázaro morreu. Eu me alegro de não ter estado lá, para que vós assim acrediteis. Mas vamos até ele. Tomé, chamado Dídimo, disse então aos companheiros: Vamos nós também para morrermos com ele. Quando Jesus chegou, já fazia quatro dias que Lázaro estava no túmulo. Betânia ficava perto de Jerusalém, a uns três quilômetros. Muitos judeus tinham vindo até Marta e Maria para as consolar da morte do irmão. Quando Marta ouviu que Jesus havia chegado, saiu-lhe ao encontro. Maria ficou sentada em casa. Marta disse a Jesus: Senhor, se tivesses estado aqui, meu irmão não teria morrido. Sei, porém, que tudo quanto pedires a Deus ele te concederá. Jesus respondeu: Teu irmão ressuscitará.* Sei que ele ressuscitará na ressurreição do último dia disse Marta. Jesus lhe disse: Eu sou a ressurreição e a vida. Quem crê em mim, ainda que esteja morto, viverá. E quem vive e crê em mim jamais morrerá. Crês isto? Sim, Senhor respondeu ela creio que és o Cristo, o Filho deDeus, quedevia vir a estemundo. Dito isso, ela foi chamar sua irmã Maria e disse-lhe baixinho: O Mestre está aí e te chama. Ao ouvir isso, Maria levantou-se imediatamente e foi ao encontro dele. É que Jesus ainda não havia entrado no povoado mas ficou lá onde Marta o tinha encontrado. Os judeus, que estavam em casa com ela e a consolavam, vendo que Maria se tinha levantado e saído às pressas, seguiram-na pensando: Ela vai ao sepulcro para chorar. Assim que Maria chegou onde Jesus estava, lançou-se aos pés dele e disse: Senhor, se tivesses estado aqui, o meu irmão não teria morrido. Quando viu que Maria e todos os judeus que vinham com ela estavam chorando, Jesus se comoveu profundamente. E emocionado, perguntou: Onde o pusestes? Senhor, vem ver disseram-lhe. Jesus começou a chorar. Os judeus comentavam: Vede como ele o amava. Al- guns, porém, disseram: Ele, que abriu os olhos do cego de nascença, não podia fazer com que Lázaro não morresse? Tomado novamente de profunda emoção, Jesus se dirigiu ao sepulcro. Era uma gruta com uma pedra colocada na entrada. Jesus ordenou: Tirai a pedra. Marta, irmã do morto, disse: Senhor, já está cheirando mal, pois já são quatro dias que está aí. Jesus respondeu: Eu não te disse que, se acreditasses, verias a glória de Deus? Tiraram então a pedra. Jesus levantou os olhos para o alto e disse: Pai, eu te dou graças porque me atendeste. Eu sei que sempre me atendes, mas digo isto por causa da multidão que me rodeia, para que creiam que tu me enviaste. Depois dessas palavras, gritou bem forte: Lázaro, vem para fora! O morto saiu com os pés e as mãos atados com faixas e o rosto envolto num sudário. Jesus ordenou: Desatai-o e deixai-o andar. João 11, 1-44

##### 245 - Que nos ensina o último artigo do Credo: na vida eterna?

O último artigo do Credo ensina-nos que depois da vida presente há outra, ou eternamente feliz para os eleitos no Paraíso, ou eternamente desgraçada para os condenados no Inferno.

##### 246 - Podemos compreender a felicidade do Paraíso?

Não. Não podemos compreender a felicidade do Paraíso, porque excede os conhecimentos da nossa inteligência limitada, e porque osbensao Céu não podem comparar-se aos bens deste mundo.

##### 247 - Em que consiste a felicidade dos eleitos?

A felicidade dos eleitos consiste em ver, amar e possuir para sempre a Deus, fonte de todo o bem.

##### 248 - Em que consiste a desgraça dos condenados?

A desgraça dos condenados consiste em serem para sempre privados da vista de Deus, e punidos com tormentos eternos no Inferno.

##### 249 - Por agora são só para as almas os bens do Paraíso e os males do Inferno?

Os bens do Paraíso e os males do Inferno, por agora, são só para as almas porque por enquanto só as almas estão no Paraíso, ou no Inferno; mas depois da ressurreição da carne, os homens, na plenitude da sua natureza, isto é, em corpo e alma, serão ou felizes ou infelizes para sempre.

##### 250 - Serão iguais Para os eleitos os bens do Paraíso, e para os condenados os males do Inferno?

Os bens do Paraíso para os eleitos, e os males do Inferno para os condenados, serão iguais na substância e na duração eterna; mas na medida, isto é, no grau, serão maiores ou menores, segundo os méritos ou deméritos de cada um.

##### 251 - Que quer dizer a palavra Amém no fim do Credo?

A palavra Amém no fim das orações significa: assim seja; no fim do Credo significa: assim é, que quer dizer: creio que é absolutamente verdadeiro tudo o que nestes doze artigos se contém, e estou mais certo disso do que se o visse com os meus olhos.