## XII - <em>Do undécimo artigo do Credo</em>

No dia seguinte, isto é, depois da sexta-feira, os sumos sacerdotes e os fariseus foram a Pilatos e disseram: Senhor, lembramo-nos de que aquele impostor disse em vida: Depois de três dias ressuscitarei. Manda, pois, guardar o sepulcro até o terceiro dia para não acontecer que os seus discípulos venham roubar o corpo e digam ao povo: Ele ressuscitou dosmortos. E esta última impostura será pior do que a primeira. Pilatos lhes disse: Vós tendes a guarda. Ide e guardai-o como bem entendeis. Eles foram e puseram guarda ao sepulcro depois de selarem a pedra. Passado o sábado, ao amanhecer do primeiro dia da semana, Maria Madalena e a outra Maria foram ver o sepulcro. Subitamente houve um grande terremoto, pois um anjo do Senhor desceu do céu, aproximou-se, rolou a pedra do sepulcro e sentou-se nela. O seu aspecto era como o de um relâmpago e sua veste, branca como a neve. Paralisados de medo, os guardas ficaram como mortos. O anjo, dirigindo-se às mulheres, disse: Não tenhais medo. Sei que procurais Jesus, o crucificado. Ele não está aqui! Ressuscitou conforme tinha dito. Vinde ver o lugar onde estava. Ide logo dizer a seus discípulos que ele ressuscitou dos mortos e que vai à frente de vós para a Galiléia. Lá o vereis. E isso que eu tinha a dizer. Jesus aparece às mulheres. Afastando-se logo do túmulo, cheias de temor e grande alegria, correram para dar a notícia aos discípulos. De repente, Jesus saiu ao encontro delas e disse-lhes: Salve! Elas se aproximaram, abraçaram-lhe os pés e se prostraram diante dele. Disse-lhes então Jesus: Não tenhais medo! Ide dizer a meus irmãos que se dirijam à Galiléia e lá me verão. Mt 27, 62-65; 28, 1-10.

##### 238 - Que nos ensina o undécimo artigo do Credo: na ressurreição da carne?

O undécimo artigo do Credo ensina-nos que todos os homens hão de ressuscitar, retomando cada alma o corpo que teve nesta vida.

##### 239 - Como se fará a ressurreição dos mortos?

A ressurreição dos mortos realizar-se-á por virtude de Deus Onipotente, a Quem nada é impossível.

##### 240 - Quando será a ressurreição dos mortos?

A ressurreição de todos os mortos será no fim do mundo, e depois seguir-se-á o Juízo universal.

##### 241 - Por que quer Deus a ressurreição dos corpos?

Deus quer a ressurreição dos corpos para que a nossa alma, tendo feito o bem ou o final unida ao corpo, receba juntamente com ele o prêmio ou o castigo.

##### 242 - Ressuscitarão os homens, todos da mesma maneira?

Não. Haverá enorme diferença entre os corpos dos eleitos e os corpos dos condenados; porque somente os corpos dos eleitos terão, à semelhança de Jesus Cristo ressuscitado, os dotes dos corpos gloriosos.

##### 243 - Quais são estes dotes que adornarão os corpos dos bem-aventurados?

Os dotes que adornarão os corpos gloriosos dos bem-aventurados são:

<ul>
  <li>
    1º - a impassibilidade, pela qual eles não mais poderão estar sujeitos a
    males, nem dores de espécie alguma, nem às necessidades de alimento, de
    repouso e de qualquer outra coisa;
  </li>
  <li>
    2º - a claridade, pela qual eles resplandecerão como o sol e as estrelas;
  </li>
  <li>
    3º - a agilidade, pela qual eles poderão passar num momento sem fadiga, de
    um lugar para outro e da terra ao Céu;
  </li>
  <li>
    4º - a sutileza, pela qual eles poderão, sem obstáculo, passar através de
    qualquer corpo, como fez Jesus Cristo ressuscitado.
  </li>
</ul>

##### 244 - Como serão os corpos dos condenados?

Os corpos dos condenados serão destituídos dos dotes dos corpos gloriosos dos bem-aventurados, e trarão o horrível estigma da reprovação eterna.