## VIII - <em>Do sétimo artigo do Credo</em>

Quando o Filho do homem vier em sua glória com todos os seus anjos, então se assentará no seu trono glorioso. Em sua presença, todas as nações se reunirão e ele vai separar uns dos outros, como o pastor separa as ovelhas dos cabritos. Colocará as ovelhas à sua direita e os cabritos, à esquerda. E o rei dirá aos que estiverem à sua direita: Vinde, abençoados por meu Pai! Tomai posse do Reino preparado para vós desde a criação do mundo. Porque tive fome e me destes de comer, tive sede e me destes de beber, fui peregrino e me acolhestes e, estive nu e me vestistes, enfermo e me visitastes, estava na cadeia e viestes ver-me. E os justos perguntarão: Senhor, quando foi que te vimos com fome e te alimentamos, com sede e te demos de beber? Quando foi que te vimos peregrino e te acolhemos, nu e te vestimos? Quando foi que te vimosenfermo ou na cadeia e te fomos visitar? E o rei dirá: Eu vos garanto: todasas vezes que fizestes isso a um desses meus irmãos menores, a mim o fizestes. Depois dirá aos da esquerda: Afastai-vos de mim, malditos, para o fogo eterno, preparado para o diabo e seus anjos. Porque eu tive fome e não me destes de comer, tive sede e não me destes de beber, fui peregrino e não me destes abrigo; estive nu e não me vestistes, enfermo e na cadeia e não me visitastes. E eles perguntarão: Senhor, quando foi que te vimos faminto ou sedento, peregrino ou enfermo ou na cadeia e não te servimos? E ele lhes responderá: Eu vos garanto: quando deixastes de fazer isso a um desses pequeninos, foi a mim quenão o fizestes. E estesirão para o castigo eterno, enquanto os justos, para a vida eterna. Mt 25, 31-46

##### 124 - Que nos ensina o sétimo artigo do Credo: de onde ha de vir a julgar os vivos e os mortos?

O sétimo artigo do Credo ensina-nos que no fim do mundo Jesus Cristo cheio de glória e de majestade, há de vir do Céu para julgar todos os homens, bons e maus, e para dar a cada um o prêmio ou o castigo que tiver merecido.

##### 125 - Se cada um, logo depois da morte há de ser julgado por Jesus Cristo no juízo particular, por que havemos de ser julgados todos no Juízo universal?

Havemos de ser julgados todos no Juízo universal por várias razões:

<ul>
  <li>1º - para glória de Deus;</li>
  <li>2º - para glória de Jesus Cristo;</li>
  <li>3º - para glória dos Santos;</li>
  <li>4º - para confusão dos maus;</li>
  <li>
    5º - finalmente para que o corpo, depois da ressurreição universal, tenha
    juntamente com a alma a sua sentença de prêmio ou de castigo.
  </li>
</ul>

##### 126 - Como é que no Juízo universal há de manifestar-se a glória de Deus?

No Juízo universal há de manifestar-se a de Deus, porque todos hão de reconhecer a justiça com que Deus governa o mundo, embora se vejam às vezes os bons a sofrer e o maus em prosperidade.

##### 127 - Como é que no Juízo universal há de manifestar-se glória de Jesus Cristo?

No Juízo universal há de manifestar-se a glória de Jesus Cristo, porque, tendo Ele sido injustamente condenado pelos homens, aparecerá então à face do mundo inteiro como Juiz supremo de todos.

##### 128 - Como é que no Juízo universal há de manifestar-se a glória dos Santos?

No Juízo universal há de manifestar-se a glória dos Santos, porque muitos deles, que morreram desprezados pelos maus, hão de ser glorificados em presença de todos os homens.

##### 129 - No Juízo universal qual será a confusão dos maus?

No Juízo universal a confusão dos maus será enorme, especialmente a daqueles que oprimiram os justos, e ti daqueles que, durante a vida, procuraram ser tidos, falsamente, por homens virtuosos e bons, pois verão manifestados, à vista de todo o mundo, os pecados que cometeram ainda os mais ocultos.