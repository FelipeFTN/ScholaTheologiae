## II - <em>Do primeiro artigo do Credo</em>

Assim podeis comportar-vos de maneira digna do Senhor, procurando agradar-lhe em tudo, frutificando em boas obras e crescendo no conhecimento de Deus, confortados pelo poder de sua glória para tudo suportar com paciência, firmeza e alegria. Agradecei a Deus Pai que vos tornou capazes de participar da herança * dos santos na luz. Ele nos livrou do poder das trevas e nos transportou ao reino de seu Filho amado, no qual temos a libertação: o perdão dospecados. Epístolas aos Colossences 1, 9-14

#### 1º - De Deus Padre e da Criação

##### 22 - Que nos ensina o primeiro artigo do Credo: creio em Deus Padre, todo-poderoso, Criador do céu e da terra?

O primeiro artigo do Credo ensina-nos que há um só Deus, o qual é todo- poderoso, e criou o céu e a terra e todas as coisas que no céu e na terra se contêm, isto é, todo o universo.

##### 23 - Como sabemos nós que há Deus?

Sabemos que há Deus, porque a nossa razão no-lo demonstra, e a fé no-lo confirma.

##### 24 - Por que se dá a Deus o nome de Pai?

Dá-se a Deus o nome de Pai:

<ul>
  <li>
    1º - porque é Pai, por natureza, da segunda Pessoa da Santíssima Trindade,
    isto é, do Filho por Ele gerado;
  </li>
  <li>
    2º - porque Deus é Pai de todos os homens, que Ele criou, conserva e
    governa;
  </li>
  <li>
    3º - porque, finalmente, é Pai, pela graça, de todos os cristãos, os quais
    por isso se chamam filhos adotivos de Deus.
  </li>
</ul>

##### 25 - Por que o Padre é a primeira Pessoa da Santíssima Trindade?

O Padre é a primeira Pessoa da Santíssima Trindade, porque não procede de outra Pessoa, mas é o princípio das outras duas Pessoas, isto é, do Filho e do Espírito Santo.

##### 26 - Que quer dizer a palavra todo-poderoso?

A palavra todo-poderoso quer dizer que Deus pode fazer tudo o que quer.

##### 27 - Deus não pode pecar nem morrer; como é então que se diz que Ele pode fazer tudo?

Diz-se que Deus pode fazer tudo, embora não possa pecar nem morrer, porque o poder pecar ou morrer não é efeito de potência mas de fraqueza, a qual não pode existir em Deus, que é perfeitíssimo.

##### 28 - Que quer dizer Criador do céu e da terra?

Criar quer dizer fazer do nada; portanto, Deus diz-se Criador do céu e da terra, porque fez do nada o céu e a terra, e todas as coisas que no céu e na terra se contêm, isto é, todo o universo.

##### 29 - O mundo foi criado somente pelo Padre?

O mundo foi criado igualmente por todas as três Pessoas divinas, porque aquilo que uma Pessoa faz relativamente às criaturas, fazem-no com um só e o mesmo ato também as outras.

##### 30 - Por que então a criação se atribui particularmente ao Padre?

Atribui-se a criação particularmente ao Padre, porque a criação é efeito da onipotência divina a qual se atribui particularmente ao Padre, como se atribui a sabedoria ao Filho e a bondade ao Espírito Santo, embora todas as três Pessoas tenham a mesma onipotência, sabedoria e bondade.

##### 31 - Deus cuida do mundo e de todas as coisas que criou?

Sim, Deus cuida do mundo e de todas as coisas que criou, conserva-as e governa-as com a sua infinita bondade e sabedoria, e nada sucede no mundo, sem que Deus o queira, ou o permita.

##### 32 - Por que dizeis que nada sucede, sem que Deus o queira, ou o permita?

Diz-se que nada sucede no mundo, sem que Deus o queira, ou o permita, porque há coisas que Deus quer e manda, e outras que Ele não quer, porém, não impede, como o pecado.

##### 33 - Por que Deus não impede o pecado?

Deus não impede o pecado, porque até mesmo do abuso que o homem faz da liberdade que lhe concedeu, sabe tirar um bem, e fazer resplandecer ainda maisa sua misericórdia ou a sua justiça.

#### 2º - Dos Anjos

Vou declarar-vos toda a verdade e nada vos ocultarei. Já vos declarei e disse: É bom guardar oculto o segredo de um rei; as obras de Deus, porém, devem ser reveladas, com a glória devida. Quando tu e Sara fazíeis oração, eu apresentava o memorial de vossa prece diante da glória do Senhor; e fazia o mesmo quando tu, Tobi, enterravas os mortos. Quando não hesitaste em levantar-te e deixar tua refeição e saíste para resguardar o cadáver, fui enviado a ti para ter pôr à prova. E Deus me enviou, também, para curar a ti e a Sara, tua nora. Eu sou Rafael, um dos sete anjos que permanecem diante da glória do Senhor e têm acesso à sua presença. Atônitos, os dois, prostraram-se com a face por terra, cheios de temor. Mas ele prosseguiu: Não temais! A paz esteja convosco! bendizei a Deus por todos os séculos. Quando estava convosco, não era por benevolência minha que vos assistia, mas pela vontade de Deus. Bendizei-o todos os dias e cantai seus louvores. Vós me víeis comer, embora eu nada comesse. Era só aparência o que víeis. Agora, bendizei o Senhor sobre a terra e dai graças a Deus. Eis que eu subo para junto de Quem me enviou. Escrevei tudo o que vos aconteceu. E ele subiu. Então levantaram-se, masnão o viram mais. Tobias 12, 11-20

##### 34 - Quais são as criaturas mais nobres que Deus criou?

As criaturas mais nobres, criadas por Deus, são os Anjos.

##### 35 - Quem são os Anjos?

Os Anjos são criaturas inteligentes e puramente espirituais, sem corpo.

##### 36 - Para que fim criou Deus os Anjos?

Deus criou os Anjos para ser por eles honrado e servido, e para os fazer eternamente felizes.

##### 37 - Que forma e que figura têm os Anjos?

Os Anjos não têm forma nem figura alguma sensível, porque são puros espíritos, criados por Deus para subsistirem, sem terem de estar unidos a corpo algum.

##### 38 - Por que então se representam os Anjos com formas sensíveis?

Representam-se os Anjos com formas sensíveis: para auxiliar a nossa imaginação; porque assim apareceram muitas vezes aos homens, como lemos na Sagrada Escritura.

##### 39 - Foram os Anjos todos fiéis a Deus?

Os Anjos não foram todos fiéis a Deus, mas muitos por soberba pretenderam ser iguais a Ele, e independentes do seu poder; e por este pecado foram excluídos para sempre do Paraíso, e condenados ao Inferno.

##### 40 - Como se chamam osAnjos excluídos para sempre do Paraíso, e condenados ao Inferno?

Os Anjos excluídos para sempre do Paraíso e condenados ao Inferno, chamam-se demônios, e o seu chefe chama-se Lúcifer ou Satanás.

##### 41 - Os demônios podem fazer-nos algum mal?

Sim, os demônios podem fazer-nos muito mal à alma e ao corpo, se Deus lhes der licença, sobretudo tentando-nos a pecar.

##### 42 - Por que nos tentam os demônios?

Os demônios tentam-nos pela inveja que nos têm e que lhes faz desejar a nossa eterna condenação, e por ódio a Deus, cuja imagem em nós resplandece. E Deus permite as tentações, a fim de que nós, vencendo-as com a sua graça, pratiquemos as virtudes e alcancemos merecimentos para o Céu.

##### 43 - Como podemos vencer as tentações?

Vencem-se as tentações com a vigilância, com a oração e com a mortificação cristã.

##### 44 - Os Anjos que se conservaram fiéis a Deus, como se chamam?

Os Anjos que se conservaram fiéis a Deus chamam-se Anjos bons, Espíritos celestes, ou simplesmente Anjos.

##### 45 - Que aconteceu aos Anjos que se conservaram fiéis a Deus?

Os Anjos que se conservaram fiéis a Deus, foram confirmados em graça, gozam para sempre da vista de Deus, amam-No, bendizem-No e louvam-No eternamente.

##### 46 - Deus serve-se dos Anjos como seus ministros?

Sim, Deus serve-se dos Anjos coma seus ministros, e especialmente confia a muitos dentre eles o ofício de nossos guardas e protetores.

##### 47 - Devemos ter particular devoção ao nosso Anjo da guarda?

Sim, devemos ter particular devoção ao nosso Anjo da guarda, honrá-lo, implorar o seu auxílio, seguir as suas inspirações rações e ser-lhe reconhecidos pela assistência contínua que nos dá.

#### 3º - Do Homem

O Senhor Deus formou, pois, o homem do barro da terra, e inspirou no seu rosto um sopro de vida, e o homem tornou-se alma (pessoa) vivente. Ora, o Senhor Deus tinha plantado, desde o princípio um paraíso de delícias, no qual Pôs o homem que tinha formado. E o Senhor Deus tinha produzido da terra toda a casta de árvores formosas à vista, e de frutos doces para comer; e a árvore da vida no meio do paraíso, e a árvore da ciência do bem e do mal. Deste lugar de delícias saía um rio para regar o paraíso, o qual dali se divide em quatro braços. O nome do primeiro é Fison, e é aquele que torneia todo o país de Evilat, onde se encontra o ouro. E o ouro deste pais é ótimo; ali (também) se acha o bdélio e a pedra ônix. O nome do segundo rio é Gion; este é aquele que torneia toda a terra de Etiópia. O nome, porém, do terceiro rio é Tigre, que corre para a banda dos assírios. E o quarto rio é o Eufrates. Tomou Pois, o Senhor Deus o homem, e colocou-o no paraíso de delícias, para que o cultivasse e guardasse. E deu-lhe este preceito, dizendo: Come de todasasárvoresdo paraíso masnão comasdo fruto da árvore da ciência do bem e do mal; porque em qualquer dia que comeres dele, morrerás indubitavelmente. "Disse mais o Senhor Deus: Não é bom que o homem esteja só; façamos-lhe um adjutório semelhante a ele Tendo, pois, o Senhor Deus formado da terra todos os animais terrestres, e todas as aves do céu. levou-os diante de Adão, para este ver como os havia de chamar; e todo o nome que Adão pôs aos animais vivos, esse é o seu verdadeiro nome. E Adão pôs nomes convenientes a todos os animais, a todas as aves do céu, e a todos os animais selváticos; mas não se achava para Adão um adjutório semelhante a ele. Formação da mulher e instituição do matrimônio. Mandou, pois, o Senhor Deus um profundo sono a Adão; e, enquanto ele estava dormindo, tirou uma das suas costelas, e pôs carne no lugar dela. E da costela, que tinha tirado de Adão, formou o Senhor Deus uma mulher; e a levou a Adão. E Adão disse: Eis aqui agora o osso de meus ossos e a carne da minha carne; ela se chamará Virago, porque do varão foi tomada. Gênesis 2, 7-23

##### 48 - Qual é a criatura mais nobre que Deus colocou sobre a terra?

A criatura mais nobre que Deus colocou sobre a terra, é o homem.

##### 49 - Que é o homem?

O homem é uma criatura racional, composta de alma e corpo.

##### 50 - Que é a alma?

A alma é a parte mais nobre do homem, porque é substância espiritual, dotada de inteligência e de vontade, capaz de conhecer a Deus e de O possuir eternamente.

##### 51 - Pode-se ver e apalpar a alma humana?

Não se pode ver nem apalpar a nossa alma, porque é espírito.

##### 52 - Morre a alma humana com o corpo?

A alma humana nunca morre; a fé e a mesma razão provam que la é imortal.

##### 53 - É livre o homem nas suas ações?

Sim, o homem é livre nas suas ações; e cada qual sente, dentro de si mesmo, que pode fazer uma ação e deixar de fazê-la, ou fazer antes uma que outra.

##### 54 - Explicai com um exemplo a liberdade humana.

Se eu disser voluntariamente uma mentira, sinto que poderia deixar de dizê-la, e calar-me, e que poderia também falar de outro modo, dizendo a verdade.

##### 55 - Por que se diz que o homem foi criado à imagem e semelhança de Deus?

Diz-se que o homem foi criado à imagem e semelhança de Deus, porque a alma humana é espiritual e racional, livre na sua ação, capaz de conhecer e de amar a Deus, e de gozá-Lo eternamente, perfeiçõesque refletem em nósum raio da infinita grandeza de Deus.

##### 56 - Em que estado criou Deus os nossos primeiros pais Adão e Eva?

Deus criou Adão e Eva no estado de inocência e de graça; mas depressa o perderam, pelo pecado.

##### 57 - Além da inocência e da graça santificante, com cedeu Deus ao nossos primeiros pais outros dons?

Além da inocência e da graça santificante, Deus concedeu aos nossos primeiros pais outros dons, que eles deviam transmitir, juntamente com a graça santificante, aos seus descendentes, e eram: a integridade, isto é, a perfeita sujeição dos sentidos à razão; a imortalidade; a imunidade de todas as dores e misérias; e a ciência proporcionada ao seu estado.

##### 58 - Qual foi o pecado de Adão?

O pecado de Adão foi um pecado de soberba e de grave desobediência.

##### 59 - Qual foi o castigo do pecado de Adão e Eva?

Adão e Eva perderam a graça de Deus e o direito que tinham ao céu, foram expulsos do Paraíso Terrestre, sujeitos a muitas misérias na alma e no corpo, e condenados a morrer.

##### 60 - Se Adão e Eva não tivessem pecado, ficariam livres da morte?

Se Adão e Eva não tivessem pecado, mas se se tivessem conservado fiéis a Deus, depois de uma permanência feliz e tranqüila neste mundo, teriam sido levados por Deus ao Céu, sem morrer, a gozar uma vida eterna e gloriosa.

##### 61 - Eram estes dons devidos ao homem?

Estes dons não eram devidos por nenhum título ao homem, mas eram absolutamente gratuitos e preternaturais; e por isso, tendo Adão desobedecido ao preceito divino, Deus pôde, sem injustiça, privar deles a Adão e a toda a sua descendência.

##### 62 - Este pecado, é próprio somente de Adão?

Este pecado não é só de Adão, mas é também nosso, embora por diverso título. É próprio de Adão, porque ele o cometeu com um ato da sua vontade, e por isso nele foi pessoal. É nosso, porque tendo Adão pecado como cabeça e fonte de todo o gênero humano, é transmitido por geração natural a todosos seusdescendentes, e por isso para nós é pecado original.

##### 63 - Como é possível que o pecado original se transmita a todos os homens?

O pecado original transmite-se a todos os homens, porque tendo Deus conferido ao gênero humano, em Adão, a graça santificante e os outros dons preternaturais, com a condição de que ele não desobedecesse, e tendo este desobedecido tia sua qualidade de cabeça e pai do gênero humano, tornou a natureza humana rebelde a Deus. Por isso a natureza humana é transmitida a todos os descendentes de Adão num estado de rebeldia contra Deus, privada da graça divina e dos outros dons.

##### 64 - Contraem todos os homens o pecado original?

Sim, todos os homens contraem o pecado original, exceto a Santíssima Virgem que dele foi preservada por Deus, com singular privilégio, na previsão dos merecimentos de Jesus Cristo Nosso Salvador.

##### 65 - Depois do pecado de Adão, já não poderiam os homens salvar-se?

Depois do pecado de Adão, os homens já não poderiam salvar-se, se Deus não tivesse usado para com eles de misericórdia.

##### 66 - Qual foi a misericórdia de que Deus usou para com o gênero humano?

A misericórdia de que Deus usou para com o gênero humano, foi prometer logo a Adão um Redentor divino, ou Messias, enviá-Lo depois a seu tempo, para libertar os homens da escravidão do demônio e do pecado.

##### 67 - Quem é o Messias prometido?

O Messias prometido é Jesus Cristo, como nos ensina o segundo artigo do Credo.