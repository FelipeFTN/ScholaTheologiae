## IX - <em>Do oitavo artigo do Credo</em>

Chegando o dia de Pentecostes, estavam todos reunidos no mesmo lugar. De repente veio do céu um ruído, como de um vento impetuoso, que encheu toda a casa em que estavam sentados. Viram aparecer, então, uma espécie de línguas de fogo, que se repartiram e foram pousar sobre cada um deles. Todos ficaram cheios do Espírito Santo e começaram a falar em outras línguas, conforme o Espírito Santo lhes concedia que falassem. Ora, em Jerusalém moravam judeus, homens piedosos, de todas as nações que há debaixo do céu. Ouvindo aquele ruído, acorreu muita gente e se maravilhava de que cada um os ouvisse falar em sua própria língua. Profundamente impressionados, manifestavam sua admiração e diziam: Estes que estão falando não são todos galileus? Como, então, todos nós os ouvimos falar, cada um em nossa própria língua materna? Partos, medos, elamitas, os que habitam a Mesopotâmia, a Judéia, a Capadócia, o Ponto, a Ásia, a Frígia, a Panfília, o Egito e as províncias da Líbia, próximas de Cirene, peregrinos romanos, judeus ou convertidos ao judaísmo, cretenses e árabes todos os ouvimos falar as grandezas de Deus em nossas próprias línguas. Atônitos e fora de si, diziam uns para os outros: O que quer dizer isso? Outros, zombando, diziam: Eles estão cheios de vinho. Atos 2, 1-13

##### 130 - Que nos ensina o oitavo artigo do Credo: creio no Espírito Santo?

O oitavo artigo do Credo ensina-nos que existe o Espírito Santo, terceira Pessoa da Santíssima Trindade, e que Ele é Deus eterno, infinito, onipotente, Criador e Senhor de todas as coisas, como o Padre e o Filho.

##### 131 - De quem procede o Espírito Santo?

O Espírito Santo procede do Padre e do Filho como de um só princípio, por via de vontade e de amor.

##### 132 - Se o Filho procede do Padre, e o Espírito Santo procede do Padre e do Filho, parece que o Padre e o Filho existem antes do Espírito Santo. Como então se diz que são eternas todas as três Pessoas divinas?

Diz-se que são eternas todas as três Pessoas divinas, porque o Padre gerou o Filho desde toda a eternidade, e do Padre e do Filho procede o Espírito Santo, também desde toda a eternidade.

##### 133 - Por que a tecera Pessoa da Santíssima Trindade se designas particularmente com o nome de Espírito Santo?

Designa-se a terceira Pessoa da Santíssima Trindade particularmente com o nome de Espírito Santo, porque procede do Padre e do Filho por meio de expiração e de amor.

##### 134 - Que obra se atribui especialmente ao Espírito Santo?

Ao Espírito Santo atribui-se especialmente a santificação das almas.

##### 135 - O Padre e o filho santificam-nos também, como o Espírito Santo?

Sim, todas as três Pessoas divinas nos santificam igualmente.

##### 136 - Se assim é, por que é atribuída em particular ao Espírito Santo a santificação das almas?

Atribui-se em particular ao Espírito Santo a santificação das almas porque é obra de amor, e as obras de amor atribuem-se ao Espírito Santo.

##### 137 - Quando o Espírito Santo desceu sobre os Apóstolos?

O Espírito Santo desceu sobre os Apóstolos no dia de Pentecostes, isto é, cinqüenta dias depois da Ressurreição de Jesus Cristo, e dez dias depois da sua Ascensão.

##### 138 - Onde ficaram os Apóstolos nos dez dias antes da festa de Pentecostes?

Os Apóstolos ficaram reunidos no Cenáculo em companhia da Virgem Maria e os outros discípulos, e perseveravam na oração esperando o Espírito Santo que Jesus lhes havia prometido.

##### 139 - Quais foram os efeitos que o Espírito Santo produziu nos Apóstolos?

O Espírito Santo confirmou na fé os Apóstolos, encheu-os de luzes, de forças, de caridade e da abundância de todos os seus dons.

##### 140 - Foi enviado o Espírito Santo só aos Apóstolos?

O Espírito Santo foi enviado a toda a Igreja e a todas as almas fiéis.

##### 141 - Que opera o Espírito Santo na Igreja?

O Espírito Santo, como a alma no corpo, vivifica a Igreja com a sua graça e com os seus dons; estabelece nEla o reino da verdade e do amor; e assiste-Lhe a fim de que oriente os seus filhos com firmeza ao caminho do Céu.