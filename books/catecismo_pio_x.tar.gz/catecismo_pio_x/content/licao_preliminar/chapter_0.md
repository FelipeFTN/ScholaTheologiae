## Da Doutrina Cristã suas partes principais

<aside>Em seguida Barnabé foi para Tarso, à procura de Saulo. Encontrou-o e o levou para Antioquia. Durante um ano estiveram juntos naquela igreja e instruíram muita gente. Foi em Antioquia que, pela primeira vez, os discípulos foram chamados cristãos. At 11, 25-26.</aside>

##### 1 - Sois cristão?

Sim, sou cristão pela graça de Deus.

##### 2 - Por que dizeis pela graça de Deus?

Digo: pela graça de Deus, porque o ser cristão é um dom de Deus, inteiramente gratuito, que nós não podemos merecer.

##### 3 - E quem é verdadeiro cristão?

Verdadeiro cristão é aquele que é batizado, crê e professa a doutrina cristã e obedece aos legítimos Pastores da Igreja.

##### 4 - Que é a Doutrina Cristã?

A Doutrina Cristã é a doutrina que Jesus Cristo Nosso Senhor nos ensinou, para nos mostrar o caminho da salvação.

##### 5 - É necessário aprender a doutrina ensinada por Jesus Cristo?

Certamente, é necessário aprender a doutrina ensinada por Jesus Cristo, e cometem falta grave aqueles que se descuidam de o fazer.

##### 6 - Os pais e patrões estão obrigados a mandar ao catecismo os seus filhos e dependentes?

Os pais e patrões são obrigados a procurar que seus filhos e dependentes aprendam a Doutrina Cristã; e são culpados diante de Deus, se desprezarem esta obrigação.

##### 7 - De quem devemos nós receber e aprender a Doutrina Cristã?

Devemos receber e aprender a Doutrina Cristã da Santa Igreja Católica.

##### 8 - Como é que temos a certeza de que a Doutrina Cristã, que recebemos da Santa Igreja Católica, é verdadeira?

Temos a certeza de que a Doutrina Cristã, que recebemos da Igreja Católica, é verdadeira, porque Jesus Cristo, autor divino desta doutrina, a confiou por meio aos seus Apóstolos à Igreja Católica, por Ele fundada e constituída Mestra infalível de todos os homens, prometendo-Lhe a sua divina assistência até à consumação dos séculos.

##### 9 - Há mais provas da verdade da Doutrina Cristã?

A verdade da Doutrina Cristã é demonstrada ainda pela santidade eminente de tantos que a professaram e professam, pela heróica fortaleza dos mártires, pela sua rápida e admirável propagação no mundo, e pela sua plena conservação através de tantos séculos de muitas e contínuas lutas.

##### 10 - Quantas e quais são as partes principais e mais necessárias da Doutrina Cristã?

As partes principais e mais necessárias da Doutrina Cristã são quatro: o Credo, o Padre-Nosso, os Mandamentos e os Sacramentos.

##### 11 - Que nos ensina o Credo?

O Credo ensina-nos os principais artigos da nossa santa Fé.

##### 12 - Que nos ensina o Padre-Nosso?

O Padre-Nosso ensina-nos tudo o que devemos esperar de Deus, e tudo o que Lhe devemos pedir.

##### 13 - Que nos ensinam os Mandamentos?

Os Mandamentos ensinam-nos tudo o que devemos fazer para agradar a Deus; em resumo, amar a Deus sobre todas as coisas, e amar ao próximo como a nós mesmos, por amor de Deus.

##### 14 - Que nos ensina a doutrina dos Sacramentos?

A doutrina dos Sacramentos faz-nos conhecer a natureza e o bom uso desses meios que Jesus Cristo instituiu Para nos perdoar os pecados, comunicar-nos a sua graça, e infundir e aumentar em nós as virtudes da fé, da esperança e da caridade.